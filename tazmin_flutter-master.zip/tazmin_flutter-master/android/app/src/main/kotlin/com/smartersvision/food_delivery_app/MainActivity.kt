package com.tazmin.android

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
