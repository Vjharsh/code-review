import 'package:flutter/material.dart';

import 'food.dart';

class CategoryWithFoods {
  String id = '';
  String name = '';
  String image = '';
  GlobalKey key = GlobalKey();
  GlobalKey tabKey = GlobalKey();
  List<Food>? foods = [];

  CategoryWithFoods();

  CategoryWithFoods.fromJSON(Map<String, dynamic> jsonMap)
      : id = jsonMap['id'].toString(),
        name = jsonMap['name'],
        image = jsonMap['media'] != null && (jsonMap['media'] as List).length > 0 ? jsonMap['media'][0]['url'] : '',
        foods = jsonMap['foods'] != null
            ? List.from(jsonMap['foods']).map((element) => Food.fromJSON(element)).toList()
            : [];
}
