import 'package:food_delivery_app/src/models/extra_by_group.dart';
import '../models/extra.dart';
import '../models/food.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class Cart {
  String id = '';
  Food food = Food();
  double quantity = 0.0;
  List<Extra> extras = [];
  List<ExtraByGroup> extraGroup = [];
  String userId = '';
  String extrasOrderByGroup = '';

  Cart();

  Cart.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      quantity =
          jsonMap['quantity'] != null ? jsonMap['quantity'].toDouble() : 0.0;
      food =
          jsonMap['food'] != null ? Food.fromJSON(jsonMap['food']) : Food();
      extras = jsonMap['extras'] != null
          ? List.from(jsonMap['extras'])
              .map((element) => Extra.fromJSON(element))
              .toList()
          : [];
      extraGroup = jsonMap['extra_group'] != null
          ? List.from(jsonMap['extra_group'])
              .map((element) => ExtraByGroup.fromJSON(element))
              .toList()
          : [];
      //food.price = getFoodPrice();
      food.priceWithExtra = getFoodPriceWithExtra();
      extrasOrderByGroup = getExtrasOrderByGroup(extraGroup);
    } catch (e) {
      id = '';
      quantity = 0.0;
      food = new Food();
      extras = [];
      // print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  String getExtrasOrderByGroup(List<ExtraByGroup> extraGroups) {
    print('extraGroups len:${extraGroups.length}');
    String extraGroupStr = '';
    for (int i = 0; i < extraGroups.length; i++) {
      ExtraByGroup extraGroup = extraGroups[i];
      extraGroupStr += '<h3>'+extraGroup.extra_group_name.toString() + ':<\/h3>\n';
      String extraStr = '';
      for (int j = 0; j < extraGroup.extras.length; j++) {
        Extra extra = extraGroup.extras[j];
        if (extraGroup.extras.length - 1 != j) {
          extraStr += extra.name.toString() +
              ' (' +
              settingsRepo.setting.value.defaultCurrency +
              extra.extraPivot.extra_price.toStringAsFixed(0) +
              '*' +
              extra.extraPivot.extra_qty.round().toString() +
              ')' +
              '<BR>';
        } else {
          extraStr += extra.name.toString() +
              ' (' +
              settingsRepo.setting.value.defaultCurrency +
              extra.extraPivot.extra_price.toStringAsFixed(0) +
              '*' +
              extra.extraPivot.extra_qty.round().toString() +
              ')<BR>';
        }
      }

      if (extraGroups.length - 1 != i) {
        extraGroupStr += extraStr + '\n';
      } else {
        extraGroupStr += extraStr;
      }
    }

    print('extraGroupStr:$extraGroupStr');
    return extraGroupStr;
  }

  double getFoodPriceWithExtra() {
    double result = food.price;
    if (extras.isNotEmpty) {
      extras.forEach((Extra extra) {
        double extraPrice = extra.extraPivot.extra_price;
        double extraQty = extra.extraPivot.extra_qty;
        result += extraPrice * extraQty;
      });
    }
    return result;
  }

  Map toMap(bool isForAdd) {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["quantity"] = quantity;
    map["food_id"] = food.id;
    map["food_name"] = food.name;
    map["food_price"] = food.price;
    map["food_price_extra"] = food.priceWithExtra;
    map["user_id"] = userId;
//    map["extras"] = extras.map((element) => element.id).toList();
    if (isForAdd)
      map["extras"] = extras.map((element) => element.toMap()).toList();
    return map;
  }

  double getFoodPrice() {
    double result = food.price;
    if (extras.isNotEmpty) {
      extras.forEach((Extra extra) {
        double extraPrice = extra.extraPivot.extra_price;
        double extraQty = extra.extraPivot.extra_qty;
//        result += extra.price != null ? extra.price : 0;
        result += extraPrice * extraQty;
      });
    }
    return result;
  }

  bool isSame(Cart cart) {
    bool _same = true;
    _same &= this.food == cart.food;
    _same &= this.extras.length == cart.extras.length;
    if (_same) {
      this.extras.forEach((Extra _extra) {
        _same &= cart.extras.contains(_extra);
      });
    }
    return _same;
  }

  @override
  bool operator ==(dynamic other) {
    return other.id == this.id;
  }

  @override
  int get hashCode => super.hashCode;
}
