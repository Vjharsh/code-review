import 'package:location/location.dart';

import '../helpers/custom_trace.dart';

class CurrentLocationDTO {
  String long_name = '';
  String short_name = '';
  List<dynamic> types = [];

  CurrentLocationDTO();

  CurrentLocationDTO.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      long_name = jsonMap['long_name'] != null ? jsonMap['long_name'].toString() : '';
      short_name = jsonMap['short_name'] != null ? jsonMap['short_name'].toString() : '';
      types = jsonMap['types'];
    } catch (e) {
      print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["long_name"] = long_name;
    map["short_name"] = short_name;
    map["types"] = types;
    return map;
  }

}
