import 'package:food_delivery_app/src/helpers/custom_trace.dart';
import 'package:food_delivery_app/src/models/addresses.dart';

import '../models/media.dart';
import '../repository/settings_repository.dart' as settingRepo;

class UserModel {
  String id = '';
  String name = '';
  String email = '';
  String password = '';
  String apiToken = '';
  String deviceToken = '';
  String phone = '';
  String address = '';
  String bio = '';
  Media image = Media();
  bool auth = false;
  String message = '';
  bool isOtpVerified = false;
  bool isForRegister = false;
  bool isForProfile = false;
  bool isForNewUser = false;
  bool isForEmail = false;
  bool isForLogin = false;

  UserModel();

  UserModel.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      name = jsonMap['name'] != null ? jsonMap['name'] : '';
      email = jsonMap['email'] != null ? jsonMap['email'] : '';
      apiToken = jsonMap['api_token']!=null ?jsonMap['api_token']:'';
      deviceToken = jsonMap['device_token']!=null ? jsonMap['device_token'] : '';
      /*phone = (jsonMap['custom_fields'] as List).isNotEmpty
          ? jsonMap['custom_fields']['phone']['view']
          : jsonMap['phone'];*/
      try {
        // phone = jsonMap['phone'];
        phone = jsonMap['custom_fields'] != null && jsonMap['custom_fields']['phone']['view'] != null
            ? jsonMap['custom_fields']['phone']['view']
            : jsonMap['phone'];
      } catch (e) {
        try {
          phone = jsonMap['custom_fields']['phone']['view'] != null
              ? jsonMap['custom_fields']['phone']['view']
              : '';
        } catch (e) {
          try {
            phone = jsonMap['phone'];
          } catch (e) {
            phone = "";
          }
        }
      }
      try {
        address = jsonMap['custom_fields'] != null && jsonMap['custom_fields']['address']['view'] != null
            ? jsonMap['custom_fields']['address']['view']
            : '';
      } catch (e) {
        try {
          address = jsonMap['custom_fields']['address']['view'] != null ?jsonMap['custom_fields']['address']['view']:'';
        } catch (e) {
          address = "";
        }
      }
      address = address == '' ? '' : address;
      try {
        bio = jsonMap['custom_fields'] != null && jsonMap['custom_fields']['bio']['view']  != null
            ? jsonMap['custom_fields']['bio']['view'].toString()
            : '';
      } catch (e) {
        try {
          bio = jsonMap['custom_fields']['bio']['view'];
        } catch (e) {
          bio = "";
        }
      }
      bio = bio == '' ? "" : bio;
      image = jsonMap['media'] != null && (jsonMap['media'] as List).length > 0
          ? Media.fromJSON(jsonMap['media'][0])
          : new Media();
      isForNewUser = false;
      isForEmail = false;
    } catch (e) {
      phone = jsonMap['phone'];
      // print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["email"] = email!='' ? email.replaceAll(" ", "") : email;
    map["name"] = name;
    map["password"] = password;
    map["api_token"] = apiToken;
    map["device_token"] = deviceToken;
    map["device_token"] = settingRepo.setting.value.deviceToken;
    map["phone"] = phone;
    map["address"] = address;
    map["bio"] = bio;
    map["media"] = image.toMap();
    map["isOtpVerified"] = isOtpVerified;
    map["isForRegister"] = isForRegister;
    map["isForProfile"] = isForProfile;
    return map;
  }

  @override
  String toString() {
    var map = this.toMap();
    map["auth"] = this.auth;
    return map.toString();
  }

  bool profileCompleted() {
    return address != '' && phone != '';
  }
}
