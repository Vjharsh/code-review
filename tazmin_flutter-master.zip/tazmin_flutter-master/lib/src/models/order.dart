import '../helpers/custom_trace.dart';
import '../models/addresses.dart';
import '../models/food_order.dart';
import '../models/order_status.dart';
import '../models/payment.dart';
import '../models/user.dart';

class Order {
  String id = '';
  List<FoodOrder> foodOrders = [];
  OrderStatus orderStatus = OrderStatus();
  double tax = 0.0;
  double deliveryFee = 0.0;
  String deliveryFeeName = '';
  double couponDiscount = 0.0;
  int couponTypeId = 0;
  var is_used = 0;
  var coupon_code = '';
  var orderNote = '';
  String hint = '';
  DateTime dateTime = DateTime.now();
  UserModel user = UserModel();
  Payment payment = Payment('');
  Addresses deliveryAddress = Addresses();
  bool active = false;

  Order();

  Order.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'] != null ? jsonMap['id'].toString():'';
      tax = jsonMap['tax'] != null ? jsonMap['tax'].toDouble() : 0.0;
      deliveryFee = jsonMap['delivery_fee'] != null ? jsonMap['delivery_fee'].toDouble() : 0.0;
      deliveryFeeName = jsonMap['delivery_fee_name'] != null ? jsonMap['delivery_fee_name'].toString() : '';
      couponDiscount = jsonMap['coupon_discount'] != null ? jsonMap['coupon_discount'].toDouble() : 0.0;
      couponTypeId = jsonMap['coupon_type_id'] != null ? int.parse(jsonMap['coupon_type_id'].toString()) : 0;
      hint = jsonMap['hint']!= null ?jsonMap['hint'].toString():'';
      active =  jsonMap['active']!= null ? jsonMap['active'] : false;
      orderStatus = jsonMap['order_status'] != null ? OrderStatus.fromJSON(jsonMap['order_status']) : new OrderStatus();
      dateTime = DateTime.parse(jsonMap['updated_at']);
      user = jsonMap['user'] != null ? UserModel.fromJSON(jsonMap['user']) : new UserModel();
      deliveryAddress = jsonMap['delivery_address'] != null ? Addresses.fromJSON(jsonMap['delivery_address']) : new Addresses();
      payment = jsonMap['payment'] != null ? Payment.fromJSON(jsonMap['payment']) : Payment.fromJSON({});
      foodOrders = jsonMap['food_orders'] != null ? List.from(jsonMap['food_orders']).map((element) => FoodOrder.fromJSON(element)).toList() : [];
    } catch (e) {
      id = '';
      tax = 0.0;
      deliveryFee = 0.0;
      deliveryFeeName = '';
      hint = '';
      orderStatus = new OrderStatus();
      dateTime = DateTime(0);
      user = new UserModel();
      deliveryAddress = new Addresses();
      foodOrders = [];
      print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["user_id"] = user.id;
    map["order_status_id"] = orderStatus.id;
    map["tax"] = tax;
    map["delivery_fee"] = deliveryFee;
    map["delivery_fee_name"] = deliveryFeeName;
    map["coupon_code"] = coupon_code;
    map["is_used"] = is_used;
    map["order_note"] = orderNote;
    map["foods"] = foodOrders.map((element) => element.toMap()).toList();
    map["payment"] = payment.toMap();
    if (deliveryAddress.id != '' && deliveryAddress.id != 'null') map["delivery_address_id"] = deliveryAddress.id;
    map["latitude"] = deliveryAddress.latitude;
    map["longitude"] = deliveryAddress.longitude;
    map["address"] = deliveryAddress.address;
    return map;
  }
  Map cancelMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    if (orderStatus.id != null && orderStatus.id == '1') map["active"] = false;
    return map;
  }

  bool canCancelOrder() {
    return this.active == true && this.orderStatus.id == '1'; // 1 for order received status
  }
}
