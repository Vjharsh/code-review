import 'package:flutter/material.dart';

class CategoriesTab {
  bool isSelected = false;
  String name = '';
}
