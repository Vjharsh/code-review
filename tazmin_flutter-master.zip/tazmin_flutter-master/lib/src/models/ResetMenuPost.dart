class ResetMenuPost {
  ResetMenuPost({
      this.success, 
      this.data, 
      this.message,});

  ResetMenuPost.fromJson(dynamic json) {
    success = json['success'];
    data = json['data'];
    message = json['message'];
  }
  bool? success;
  int? data;
  String? message;
ResetMenuPost copyWith({  bool? success,
  int? data,
  String? message,
}) => ResetMenuPost(  success: success ?? this.success,
  data: data ?? this.data,
  message: message ?? this.message,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['success'] = success;
    map['data'] = data;
    map['message'] = message;
    return map;
  }

}