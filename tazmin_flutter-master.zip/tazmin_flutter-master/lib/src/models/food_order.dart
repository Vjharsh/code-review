import 'package:food_delivery_app/src/models/extra_by_group.dart';

import '../helpers/custom_trace.dart';
import '../models/extra.dart';
import '../models/food.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class FoodOrder {
  String id = '';
  double price = 0.0;
  double price_with_extra = 0.0;
  double quantity = 0.0;
  List<Extra> extras = [];
  List<ExtraByGroup> extraGroup = [];
  String extrasOrderByGroup = '';
  Food food = Food();
  DateTime dateTime = DateTime.now();

  FoodOrder();

  FoodOrder.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'] != null ? jsonMap['id'].toString():'';
      price = jsonMap['price'] != null ? jsonMap['price'].toDouble() : 0.0;
      quantity = jsonMap['quantity'] != null ? jsonMap['quantity'].toDouble() : 0.0;
      food = jsonMap['food'] != null ? Food.fromJSON(jsonMap['food']) : new Food();
      dateTime = DateTime.parse(jsonMap['updated_at']);
      extras = jsonMap['extras'] != null ? List.from(jsonMap['extras']).map((element) => Extra.fromJSON(element)).toList() : [];
      extraGroup = jsonMap['extra_group'] != null
          ? List.from(jsonMap['extra_group'])
          .map((element) => ExtraByGroup.fromJSON(element))
          .toList()
          : [];
      extrasOrderByGroup = getExtrasOrderByGroup(extraGroup);
    } catch (e) {
      id = '';
      price = 0.0;
      quantity = 0.0;
      food = new Food();
      dateTime = DateTime(0);
      extras = [];
      print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }
  String getExtrasOrderByGroup(List<ExtraByGroup> extraGroups) {
    //print('extraGroups len:${extraGroups.length}');
    //color: #8c98a8;
    String extraGroupStr = '';
    for (int i = 0; i < extraGroups.length; i++) {
      ExtraByGroup extraGroup = extraGroups[i];
      extraGroupStr += '<div style="font-weight: bold;">'+extraGroup.extra_group_name.toString() + ':<\/div>\n';
      String extraStr = '';
      for (int j = 0; j < extraGroup.extras.length; j++) {
        Extra extra = extraGroup.extras[j];
        if (extraGroup.extras.length - 1 != j) {
          extraStr += extra.name.toString() +
              '(' +
              settingsRepo.setting.value.defaultCurrency +
              extra.extraPivot.extra_price.toString() +
              '*' +
              extra.extraPivot.extra_qty.round().toString() +
              ')' +
              ', ';
        } else {
          extraStr += extra.name.toString() +
              '(' +
              settingsRepo.setting.value.defaultCurrency +
              extra.extraPivot.extra_price.toString() +
              '*' +
              extra.extraPivot.extra_qty.round().toString() +
              ')';
        }
      }
      if (extraGroups.length - 1 != i) {
        extraGroupStr += extraStr + '\n';
      } else {
        extraGroupStr += extraStr;
      }
    }
    //print('extraGroupStr:$extraGroupStr');
    return extraGroupStr;
  }
  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["price"] = price;
    map["price_with_extra"] = price_with_extra;
    map["quantity"] = quantity;
    map["food_id"] = food.id;
//    map["extras"] = extras.map((element) => element.id).toList();
    map["extras"] = extras.map((element) => element.toMap()).toList();
    return map;
  }
}
