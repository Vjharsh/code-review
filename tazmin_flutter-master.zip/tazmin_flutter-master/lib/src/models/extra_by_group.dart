import '../helpers/custom_trace.dart';
import '../models/extra.dart';

class ExtraByGroup {
  String extra_group_id = '';
  String extra_group_name = '';
  List<Extra> extras = [];

  ExtraByGroup();

  ExtraByGroup.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      extra_group_id = jsonMap['id'] != null ? jsonMap['id'].toString() : '';
      extra_group_name = jsonMap['extra_group_name'] != null ? jsonMap['extra_group_name'].toString() : '';
      extras = jsonMap['extras'] != null
          ? List.from(jsonMap['extras'])
              .map((element) => Extra.fromJSON(element))
              .toList()
          : [];
    } catch (e) {
      extra_group_id = '';
      extra_group_name = '';
      extras = [];
      // print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }
}
