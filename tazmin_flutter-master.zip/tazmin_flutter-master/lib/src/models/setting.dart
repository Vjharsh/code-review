import 'package:flutter/material.dart';

import '../helpers/custom_trace.dart';

class Setting {
  String appName = '';
  String deviceToken = '';
//  double defaultTax;
  double deliveryFee = 0.0;
  String deliveryFeeName = '';
  String farDeliveryFee = '';
  String normalDeliveryFee = '';
  String normalDeliveryFee2 = '';
  String normalDeliveryFee3 = '';
  String normalDeliveryFee4 = '';
  String normalDeliveryFee5 = '';
  var is_used = 0;
  var couponType = 0;
  var coupon_code = '';
  var discount = 0.0;
  double orderAmount = 0.0;
  String defaultCurrency = '';
  String distanceUnit = '';
  bool currencyRight = false;
  bool payPalEnabled = true;
  bool stripeEnabled = true;
  String mainColor = '';
  String mainDarkColor = '';
  String secondColor = '';
  String secondDarkColor = '';
  String accentColor = '';
  String accentDarkColor = '';
  String scaffoldDarkColor = '';
  String scaffoldColor = '';
  String googleMapsKey = '';
  ValueNotifier<Locale> mobileLanguage = new ValueNotifier(Locale('he', ''));
  String appVersion = '';
  bool enableVersion = true;
  String checkoutAlertEnabled = "0";
  String checkoutAlertMessage = "";
  String messageClose = "";
  String announcement = "";
  String town_area_message = "";
  String town_area_distance = "0";
  double town_area_lat = 0.0;
  double town_area_long = 0.0;
  var orderNote = "";
  var busyModeMessage = "";
  List<dynamic> jsonArray = [];
  bool disableCreditCard = false;
  bool disablePickUp = false;
  bool offerFirstTime = true;
  String disableLaunchScreen = '';
  String disableTrendingFood = '';
  String customTitle1 = '';
  String customTitle2 = '';
  String description = '';
  int cartCounter = 0;
  ValueNotifier<Brightness> brightness = new ValueNotifier(Brightness.light);

  Setting();

  Setting.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      appName = jsonMap['app_name'] ?? '';
      mainColor = jsonMap['main_color'] ?? '';
      mainDarkColor = jsonMap['main_dark_color'] ?? '';
      secondColor = jsonMap['second_color'] ?? '';
      secondDarkColor = jsonMap['second_dark_color'] ?? '';
      accentColor = jsonMap['accent_color'] ?? '';
      accentDarkColor = jsonMap['accent_dark_color'] ?? '';
      scaffoldDarkColor = jsonMap['scaffold_dark_color'] ?? '';
      scaffoldColor = jsonMap['scaffold_color'] ?? '';
      googleMapsKey = jsonMap['google_maps_key'] ?? '';
      description = jsonMap['description'] ?? '';
//      mobileLanguage.value = Locale(jsonMap['mobile_language'] ?? "he", '');
      mobileLanguage.value = Locale('he', '');
      appVersion = jsonMap['app_version'] ?? '';
      normalDeliveryFee = jsonMap['normal_delivery_fee'] != null
          ? jsonMap['normal_delivery_fee']
          : null;
      normalDeliveryFee2 = jsonMap['normal_delivery_fee2'] != null
          ? jsonMap['normal_delivery_fee2']
          : null;
      normalDeliveryFee3 = jsonMap['normal_delivery_fee3'] != null
          ? jsonMap['normal_delivery_fee3']
          : null;
      normalDeliveryFee4 = jsonMap['normal_delivery_fee4'] != null
          ? jsonMap['normal_delivery_fee4']
          : null;
      normalDeliveryFee5 = jsonMap['normal_delivery_fee5'] != null
          ? jsonMap['normal_delivery_fee5']
          : null;
      farDeliveryFee = jsonMap['far_delivery_fee'] != null
          ? jsonMap['far_delivery_fee']
          : null;
      distanceUnit = jsonMap['distance_unit'] ?? 'km';
      enableVersion =
          jsonMap['enable_version'] == '0' || jsonMap['enable_version'] == '0'
              ? false
              : true;
      /*defaultTax = double.tryParse(jsonMap['default_tax']) ??
          0.0;*/ //double.parse(jsonMap['default_tax'].toString());
      defaultCurrency = jsonMap['default_currency'] ?? '';
      currencyRight =
          jsonMap['currency_right'] == '0' || jsonMap['currency_right'] == '0'
              ? false
              : true;
      payPalEnabled =
          jsonMap['enable_paypal'] == '0' || jsonMap['enable_paypal'] == '0'
              ? false
              : true;
      stripeEnabled =
          jsonMap['enable_stripe'] == '0' || jsonMap['enable_stripe'] == '0'
              ? false
              : true;
      town_area_lat = double.parse(jsonMap['town_area_lat']);
      town_area_long = double.parse(jsonMap['town_area_long']);
      town_area_distance = jsonMap['town_area_distance'] ?? '0';
      town_area_message = jsonMap['town_area_message'] ?? '';
      checkoutAlertEnabled = jsonMap['block_checkout'] ?? '0';
      checkoutAlertMessage = jsonMap['block_checkout_msg'] ?? '';
      messageClose = jsonMap['message_close'] ?? '';
      announcement =
          jsonMap['announcement'] == null ? '' : jsonMap['announcement'];
      busyModeMessage = jsonMap['busy_mode_message'] == null
          ? ''
          : jsonMap['busy_mode_message'];
      disableLaunchScreen = jsonMap['disable_launch_screen'] == null
          ? '0'
          : jsonMap['disable_launch_screen'];
      disableTrendingFood =
          jsonMap['trending_food'] == null ? '0' : jsonMap['trending_food'];
      customTitle1 =
          jsonMap['custom_title_1'] == null ? '' : jsonMap['custom_title_1'];
      customTitle2 =
          jsonMap['custom_title_2'] == null ? '' : jsonMap['custom_title_2'];
    } catch (e) {
      print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["app_name"] = appName;
    map["app_version"] = appVersion;
//    map["default_tax"] = defaultTax;
    map["default_tax"] = 0;
    map["default_currency"] = defaultCurrency;
    map["currency_right"] = currencyRight;
    map["enable_paypal"] = payPalEnabled;
    map["enable_stripe"] = stripeEnabled;
    map["mobile_language"] = mobileLanguage.value.languageCode;
    map["block_checkout"] = checkoutAlertEnabled;
    map["block_checkout_msg"] = checkoutAlertMessage;
    return map;
  }
}
