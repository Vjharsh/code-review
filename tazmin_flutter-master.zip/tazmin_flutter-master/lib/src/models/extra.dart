import '../helpers/custom_trace.dart';
import '../models/media.dart';
import 'extra_pivot.dart';

class Extra {
  String id = '';
  String extraGroupId = '';
  String extra_group_is_active = '';
  String limitQty = '';
  String qtyEnable = '';
  String name = '';
  double price = 0.0;
  double totalPrice = 0.0;
  double qty = 1.0;
  Media image = Media();
  String description = '';
  bool checked = false;
  ExtraPivot extraPivot = ExtraPivot();
  int pizzaStatus = 0;
  String halfPrice = '0';
  String fullPrice = '0';
  String pizzaType = '';

  Extra();

  Extra.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id']!=null ? jsonMap['id'].toString() : '';
      extraGroupId = jsonMap['extra_group_id'] != null ? jsonMap['extra_group_id'].toString() : '0';
      extra_group_is_active = jsonMap['extra_group_is_active'] != null ? jsonMap['extra_group_is_active'].toString() : '0';
      limitQty = jsonMap['limit_qty'] != null ? jsonMap['limit_qty'].toString() : '0';
      qtyEnable = jsonMap['qty_enable'] != null ? jsonMap['qty_enable'].toString() : '0';
      name = jsonMap['name'] != null ? jsonMap['name'].toString() : '';
      price = jsonMap['price'] != null ? jsonMap['price'].toDouble() : 0;
      description = jsonMap['description']!=null ? jsonMap['description']:'';
      extraPivot = (jsonMap['pivot'] != null ? ExtraPivot.fromJSON(jsonMap['pivot']) : ExtraPivot());
      checked = false;
      image = jsonMap['media'] != null && (jsonMap['media'] as List).length > 0 ? Media.fromJSON(jsonMap['media'][0]) : new Media();
    } catch (e) {
      // print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    /*map["id"] = id;
    map["name"] = name;
    map["price"] = price;
    map["description"] = description;*/
    // map["extra_group_id"] = extraGroupId;
    map["extra_id"] = id;
    map["extra_price"] = price;
    map["extra_qty"] = qty;

    map["pizza_type"] = pizzaType;
    map["pizza_status"] = pizzaStatus;
    map["half_price"] = halfPrice;
    map["full_price"] = fullPrice;
    return map;
  }

  @override
  bool operator ==(dynamic other) {
    return other.id == this.id;
  }

  @override
  int get hashCode => this.id.hashCode;
}
