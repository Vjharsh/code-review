import 'package:flutter/widgets.dart';
import '../../generated/l10n.dart';
import 'package:food_delivery_app/constants.dart' as Constants;

class PaymentMethod {
  String id = '';
  String title = '';
  String name = '';
  String description = '';
  String logo = '';
  String route = '';
  bool isDefault = false;

  PaymentMethod(this.id, this.title, this.name, this.description, this.route, this.logo, {this.isDefault = false});
}

class PaymentMethodList {
  List<PaymentMethod> _paymentsList = [];
  List<PaymentMethod> _cashList = [];
  List<PaymentMethod> _pickupList = [];
  PaymentMethodList(BuildContext context,bool isForPickUp) {
    this._paymentsList = [
      new PaymentMethod("visacard",S.of(context).visa_card, isForPickUp? Constants.PAYMENT_METHOD_YAADPAY_ON_PICKUP : Constants.PAYMENT_METHOD_YAADPAY, isForPickUp ? S.of(context).i_will_pay_with_credit_card: S.of(context).click_to_pay_with_your_visa_card, "/YaadPay", "assets/img/visacard.png",
          isDefault: true),
//      new PaymentMethod("mastercard", S.of(context).mastercard, S.of(context).click_to_pay_with_your_mastercard, "/Checkout", "assets/img/mastercard.png"),
      new PaymentMethod("paypal", S.of(context).paypal, Constants.PAYMENT_METHOD_PAYPAL, S.of(context).click_to_pay_with_your_paypal_account, "/PayPal", "assets/img/paypal.png"),
    ];
    this._cashList = [
      if(!isForPickUp)new PaymentMethod("cod", S.of(context).cash_on_delivery, Constants.PAYMENT_METHOD_CASH_ON_DELIVERY, S.of(context).click_to_pay_cash_on_delivery, "/CashOnDelivery", "assets/img/cash.png"),
      if(isForPickUp)new PaymentMethod("pop", S.of(context).pay_on_pickup, Constants.PAYMENT_METHOD_PICKUP, S.of(context).i_will_pay_in_store, "/PayOnPickup", "assets/img/pay_pickup.png"),
    ];
    this._pickupList = [
      new PaymentMethod("pop", S.of(context).pay_on_pickup, Constants.PAYMENT_METHOD_PICKUP, S.of(context).click_to_pay_on_pickup, "/PayOnPickup", "assets/img/pay_pickup.png"),
    ];
  }

  List<PaymentMethod> get paymentsList => _paymentsList;
  List<PaymentMethod> get cashList => _cashList;
  List<PaymentMethod> get pickupList => _pickupList;
}
