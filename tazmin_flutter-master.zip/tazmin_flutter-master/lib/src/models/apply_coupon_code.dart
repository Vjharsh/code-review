class ApplyCouponCode {
  var success;
  var coupon_type;
  var coupon_type_id;
  var coupon_discount;
  var message;

  ApplyCouponCode();

  ApplyCouponCode.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      success = jsonMap['success'];
      message = jsonMap['message'] != null ? jsonMap['message'] : '';
      coupon_type = jsonMap['data']['coupon_type'] != null ? jsonMap['data']['coupon_type'].toString() : '';
      coupon_type_id = jsonMap['data']['coupon_type_id'] != null ? jsonMap['data']['coupon_type_id'] : 0;
      coupon_discount = jsonMap['data']['coupon_discount'] != null ? jsonMap['data']['coupon_discount'] : 0.0;

    } catch (e) {
      coupon_type = '';
      coupon_type_id = 0;
      coupon_discount = 0.0;
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["success"] = success;
    map["coupon_type"] = coupon_type;
    map["coupon_type_id"] = coupon_type_id;
    map["coupon_discount"] = coupon_discount;
    map["message"] = message;
    return map;
  }
}
