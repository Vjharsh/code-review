class ExtraPivot {
  String cart_id = '';
  String extra_id = '';
  double extra_qty = 0;
  double extra_price = 0;
  String pizza_status = '';
  String full_price = '';
  String half_price = '';
  String pizza_type = '';

  ExtraPivot();

  ExtraPivot.fromJSON(Map<String, dynamic> jsonMap)
      : cart_id = jsonMap.containsKey('cart_id') ? jsonMap['cart_id'].toString() : "0",
        extra_id = jsonMap['extra_id'] != null ? jsonMap['extra_id'].toString() : '',
        extra_qty = jsonMap.containsKey('extra_qty') ? double.parse(jsonMap['extra_qty'].toString()) : 0,
        extra_price = jsonMap.containsKey('extra_price') ? double.parse(jsonMap['extra_price'].toString()) : 0,
        pizza_status = jsonMap.containsKey('pizza_status') ?jsonMap['pizza_status'].toString() : '0',
        full_price = jsonMap.containsKey('full_price') ?jsonMap['full_price'].toString() : '0',
        half_price = jsonMap.containsKey('half_price') ?jsonMap['half_price'].toString() : '0',
        pizza_type = jsonMap.containsKey('pizza_type') ?jsonMap['pizza_type'].toString() : '0';
  Map toMap() {
    var map = new Map<String, dynamic>();
    map["extra_id"] = extra_id;
    map["extra_price"] = extra_price;
    map["extra_qty"] = extra_qty;
    map["pizza_status"] = pizza_status;
    map["full_price"] = full_price;
    map["half_price"] = half_price;
    map["pizza_type"] = pizza_type;
    return map;
  }
}
