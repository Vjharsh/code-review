class ResetMenu {
  bool? success;
  Data? data;
  String? message;

  ResetMenu({this.success, this.data, this.message});

  ResetMenu.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int? isReset;

  Data({this.isReset});

  Data.fromJson(Map<String, dynamic> json) {
    isReset = json['is_reset'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['is_reset'] = this.isReset;
    return data;
  }
}