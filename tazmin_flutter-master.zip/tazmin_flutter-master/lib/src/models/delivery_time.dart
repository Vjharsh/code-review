class DeliveryTime {
  String? startDeliveryTime = '';
  String? startDeliveryMinutes = '';
  String? endDeliveryTime = '';
  String? endDeliveryMinutes = '';

  DeliveryTime(
      {
        this.startDeliveryTime,
        this.startDeliveryMinutes,
        this.endDeliveryTime,
        this.endDeliveryMinutes});

  DeliveryTime.fromJson(Map<String, dynamic> json) {
    startDeliveryTime = json['start_delivery_time'];
    startDeliveryMinutes = json['start_delivery_minutes'];
    endDeliveryTime = json['end_delivery_time'];
    endDeliveryMinutes = json['end_delivery_minutes'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['start_delivery_time'] = this.startDeliveryTime;
    data['start_delivery_minutes'] = this.startDeliveryMinutes;
    data['end_delivery_time'] = this.endDeliveryTime;
    data['end_delivery_minutes'] = this.endDeliveryMinutes;
    return data;
  }

  bool getDriverDeliveryStatus() {
    bool resOpeningStatus = false;
    DateTime date = DateTime.now();
    final currentTime = DateTime.now();
    final startTime = DateTime(currentTime.year, currentTime.month,
        currentTime.day, int.parse(startDeliveryTime!), int.parse(startDeliveryMinutes!), 0);
    final endTime = DateTime(currentTime.year, currentTime.month,
        currentTime.day, int.parse(endDeliveryTime!), int.parse(endDeliveryMinutes!), 0);

    print('startTime:$startTime');
    print('endTime:$endTime');
    if (currentTime.isAfter(startTime) && currentTime.isBefore(endTime)) {
      // do something
      resOpeningStatus = true;
    }
    print('resOpeningStatus: $resOpeningStatus');
    return resOpeningStatus;
  }
}