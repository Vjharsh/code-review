import 'package:food_delivery_app/src/models/extra.dart';

import '../helpers/custom_trace.dart';

class ExtraGroup {
  String id = '';
  String is_active = '';
  String name = '';
  int pizzaStatus = 0;
  String halfPrice = '0';
  String fullPrice = '0';
  String limitQty = '0';
  bool requireField = false;
  int selectedQty = 0;
  String qtyEnable = '';
  bool extraGroupSettings = false;
  List<Extra> extras = <Extra>[];

  ExtraGroup();

  ExtraGroup.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      is_active = jsonMap['is_active'] != null ? jsonMap['is_active'].toString() : '';
      name = jsonMap['name'] != null ? jsonMap['name'].toString() : '';
      requireField = jsonMap['is_required'] != null ? jsonMap['is_required'] : false;
      pizzaStatus = jsonMap['pizza_status'] != null ? int.parse(jsonMap['pizza_status'].toString()) : 0;
      halfPrice = jsonMap['half_price'] != null ? jsonMap['half_price'].toString() : '';
      fullPrice = jsonMap['full_price'] != null ? jsonMap['full_price'].toString() : '';
      limitQty = jsonMap['total_quantity'] != null ? jsonMap['total_quantity'].toString() : '0';
      qtyEnable = jsonMap['limit_option'] != null ? jsonMap['limit_option'].toString() : '0';
      selectedQty = 0;
      extraGroupSettings = jsonMap['extra_group_settings'] != null ? jsonMap['extra_group_settings'].toString() == '1' ? true: false : false;
    } catch (e) {
      id = '';
      is_active = '';
      name = '';
      requireField = false;
      // print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["is_active"] = is_active;
    map["name"] = name;
    map["require_field"] = requireField;
    return map;
  }

  @override
  String toString() {
    return this.toMap().toString();
  }

  @override
  bool operator ==(dynamic other) {
    return other.id == this.id;
  }

  @override
  int get hashCode => this.id.hashCode;
}
