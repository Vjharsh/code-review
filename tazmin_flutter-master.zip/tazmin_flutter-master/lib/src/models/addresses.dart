import 'package:location/location.dart';

import '../helpers/custom_trace.dart';

class Addresses {
  String id = '';
  String description = '';
  String address = '';
  double latitude = 0.0;
  double longitude = 0.0;
  bool isDefault = false;
  String userId = '';

  Addresses();

  Addresses.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'] != null ? jsonMap['id'].toString() : '';
      description = jsonMap['description'] != null ? jsonMap['description'].toString() : '';
      address = jsonMap['address'] != null ? jsonMap['address'] : '';
      latitude = jsonMap['latitude'] != null ? jsonMap['latitude'].toDouble() : 0.0;
      longitude = jsonMap['longitude'] != null ? jsonMap['longitude'].toDouble() : 0.0;
      isDefault = jsonMap['is_default'] ?? false;
    } catch (e) {
      print(CustomTrace(StackTrace.current, message: e.toString()));
    }
  }

  bool isUnknown() {
    return latitude == null || longitude == null;
  }

  Map toMap() {
    var map = new Map<String, dynamic>();
    map["id"] = id;
    map["description"] = description;
    map["address"] = address;
    map["latitude"] = latitude;
    map["longitude"] = longitude;
    map["is_default"] = isDefault;
    map["user_id"] = userId;
    return map;
  }

  LocationData toLocationData() {
    return LocationData.fromMap({
      "latitude": latitude,
      "longitude": longitude,
    });
  }
}
