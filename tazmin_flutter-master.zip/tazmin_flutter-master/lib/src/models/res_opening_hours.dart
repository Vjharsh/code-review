class ResOpeningHours {
  String week = '';
  String startHours = '';
  String startMinutes = '';
  String endHours = '';
  String endMinutes = '';
  String isOpen = '';

  ResOpeningHours();

  ResOpeningHours.fromJSON(Map<String, dynamic> jsonMap)
      : week = jsonMap['week'].toString(),
        startHours = jsonMap['start_time'].toString(),
        startMinutes = jsonMap['start_minutes'].toString(),
        endHours = jsonMap['end_time'].toString(),
        endMinutes = jsonMap['end_minutes'].toString(),
        isOpen = jsonMap['is_open'].toString();
  Map<String, dynamic> toMap() {
    return {
      'week': week,
      'startHours': startHours,
      'startMinutes': startMinutes,
      'endHours': endHours,
      'endMinutes': endMinutes,
      'isOpen': isOpen,
    };
  }
}
