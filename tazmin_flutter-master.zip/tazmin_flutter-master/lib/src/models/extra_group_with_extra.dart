import 'package:food_delivery_app/src/models/extra_group.dart';
class ExtraGroupWithExtras {
  ExtraGroup extraGroup = ExtraGroup();
}
