import 'dart:convert';

class AllRestaurantsWithMenu {
  String id = '';
  String menu = '';

  AllRestaurantsWithMenu();

  AllRestaurantsWithMenu.fromJSON(Map<String, dynamic> jsonMap)
      : id = jsonMap['id'].toString(),
        menu = jsonMap['menu'] != null ? jsonEncode(jsonMap['menu']).toString() : '';

  Map<String, dynamic> toMap() {
    return {'id': id, 'menu': menu};
  }
}
