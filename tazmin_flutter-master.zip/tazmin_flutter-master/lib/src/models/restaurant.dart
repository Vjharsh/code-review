import 'package:food_delivery_app/main.dart';
import 'package:food_delivery_app/src/models/res_opening_hours.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import '../helpers/custom_trace.dart';
import '../models/media.dart';

class Restaurant {
  String id = '';
  String name = '';
  Media image = Media();
  String video = '';
  String videoURL = '';
  String rate = '';
  String address = '';
  String description = '';
  String shortDescription = '';
  String phone = '';
  String mobile = '';
  String information = '';
  double deliveryFee = 0.0;
  double adminCommission = 0.0;
  double defaultTax = 0.0;
  String latitude = '';
  String longitude = '';
  bool closed = false;
  bool availableForDelivery = false;
  double deliveryRange = 0.0;
  double deliveryRange2 = 0.0;
  double deliveryRange3 = 0.0;
  double deliveryRange4 = 0.0;
  double deliveryRange5 = 0.0;
  double distance = 0.0;
  // String originDistance = '';
  bool resOpeningStatus = false;
  List<ResOpeningHours> res_opening_hours = [];
  double minOrderPrice = 0.0;
  bool busyMode = false;

  Restaurant();

  bool disableCreditCard = false;
  bool disablePickup = false;
  bool freeShipping = false;
  bool res_onoff = false;
  String res_onoff_date = '';
  bool animationSelected = false;

  Restaurant.fromJSON(Map<String, dynamic> jsonMap) {
    try {
      id = jsonMap['id'].toString();
      name = jsonMap['name'] != null ? jsonMap['name'] : '';
      video = jsonMap['video'] != null ? jsonMap['video'] : '';
      videoURL = jsonMap['videoURL'] != null ? jsonMap['videoURL'] : '';
      image = jsonMap['media'] != null && (jsonMap['media'] as List).length > 0
          ? Media.fromJSON(jsonMap['media'][0])
          : new Media();
      rate = jsonMap['rate'] ?? '0';
      deliveryFee = jsonMap['delivery_fee'] != null
          ? jsonMap['delivery_fee'].toDouble()
          : 0.0;
      adminCommission = jsonMap['admin_commission'] != null
          ? jsonMap['admin_commission'].toDouble()
          : 0.0;
      deliveryRange = jsonMap['delivery_range'] != null
          ? jsonMap['delivery_range'].toDouble()
          : 0.0;
      deliveryRange2 = jsonMap['delivery_range2'] != null
          ? jsonMap['delivery_range2'].toDouble()
          : 0.0;
      deliveryRange3 = jsonMap['delivery_range3'] != null
          ? jsonMap['delivery_range3'].toDouble()
          : 0.0;
      deliveryRange4 = jsonMap['delivery_range4'] != null
          ? jsonMap['delivery_range4'].toDouble()
          : 0.0;
      deliveryRange5 = jsonMap['delivery_range5'] != null
          ? jsonMap['delivery_range5'].toDouble()
          : 0.0;
      address = jsonMap['address'] != null ? jsonMap['address'] : '';
      description =
          jsonMap['description'] != null ? jsonMap['description'] : '';
      shortDescription = jsonMap['short_description'] != null
          ? jsonMap['short_description']
          : '';
      phone = jsonMap['phone'] != null ? jsonMap['phone'] : '';
      mobile = jsonMap['mobile'] != null ? jsonMap['mobile'] : '';
      defaultTax = jsonMap['default_tax'] != null
          ? double.parse(jsonMap['default_tax'].toString())
          : 0.0;
      information =
          jsonMap['information'] != null ? jsonMap['information'].toString() : '';
      // originDistance = getTranslateForDistance(jsonMap['origin_distance']);
      // jsonMap['origin_distance'] != null ? jsonMap['origin_distance'] : '';
      latitude = jsonMap['latitude'] != null ? jsonMap['latitude'] : '0';
      longitude = jsonMap['longitude'] != null ? jsonMap['longitude'] : '0';
      /*getDistance(latitude,longitude).then((value) {
        originDistance = value;
      });*/
      closed = jsonMap['closed'] != null ? jsonMap['closed'] : false;
      busyMode = jsonMap['busy_mode'] != null ? jsonMap['busy_mode'] : false;
      res_onoff = jsonMap['res_onoff'] != null ? jsonMap['res_onoff'] : false;
      res_onoff_date = jsonMap['res_onoff_date'] != null &&
              jsonMap['res_onoff_date'] != 'null'
          ? jsonMap['res_onoff_date']
          : '1111-11-11 11:11:11';
      availableForDelivery = jsonMap['available_for_delivery'] ?? false;
      distance = jsonMap['distance'] != null ? double.parse(jsonMap['distance'].toString()) : 0.0;
      disableCreditCard = jsonMap['disable_credit_card'] != null
          ? jsonMap['disable_credit_card']
          : false;
      disablePickup =
          jsonMap['disable_pickup'] != null ? jsonMap['disable_pickup'] : false;
      freeShipping =
          jsonMap['free_shipping'] != null ? jsonMap['free_shipping'] : false;
      animationSelected = false;
      minOrderPrice = jsonMap['min_order_price'] != null
          ? double.parse(jsonMap['min_order_price'].toString())
          : 0;
      res_opening_hours = jsonMap.containsKey('res_opening_hours') && jsonMap['res_opening_hours'] != null
              ? List.from(jsonMap['res_opening_hours'])
                  .map((element) => ResOpeningHours.fromJSON(element)).toList()
              : [];
      resOpeningStatus = getResOpeningStatus(res_opening_hours);
    } catch (e) {
      /*id = '';
      name = '';
      image = new Media();
      rate = '0';
      deliveryFee = 0.0;
      adminCommission = 0.0;
      deliveryRange = 0.0;
      address = '';
      description = '';
      phone = '';
      mobile = '';
      defaultTax = 0.0;
      information = '';
      latitude = '0';
      longitude = '0';
      closed = false;
      busyMode = false;
      availableForDelivery = false;
      disableCreditCard = false;
      disablePickup = false;
      distance = 0.0;
      minOrderPrice = 0.0;
      resOpeningStatus = false;
      animationSelected = false;
      res_onoff_date = '${DateTime.now()}';*/
      /*if(StackTrace.current != null) {
        print(CustomTrace(StackTrace.current, message: e.toString()));
      }*/
    }
  }

  /*Future<String> getDistance(String latitude,String longitude) async{
    double distance = 0;
    if(MyApp.addressDTO !=null) {
      print('latitude:$latitude');
      print('longitude:$longitude');
      print('MyApp.addressDTO.latitude:${MyApp.addressDTO.latitude}');
      print('MyApp.addressDTO.longitude:${MyApp.addressDTO.longitude}');
      distance = await Geolocator().distanceBetween(
          double.parse(latitude),
          double.parse(longitude),
          MyApp.addressDTO.latitude,
          MyApp.addressDTO.longitude);
      distance = distance / 1000;
      print('distance:$distance');
    }
    return distance.toStringAsFixed(2);
  }*/

  String getTranslateForDistance(String originDistance) {
    if (originDistance != null && originDistance.isNotEmpty) {
      print('originDistance:$originDistance');
      if (originDistance.contains('km')) {
        originDistance = originDistance.replaceAll('km', 'ק׳׳מ');
      } else {
        originDistance = originDistance.replaceAll('m', 'מטרים');
      }
    } else {
      originDistance = '0 km';
      originDistance = originDistance.replaceAll('km', 'ק׳׳מ');
    }
    return originDistance;
  }

  bool getResOpeningStatus(List<ResOpeningHours> resOpeningHoursList) {
    // print('resOpeningHoursList:${resOpeningHoursList.length}');
    bool resOpeningStatus = false;
    if (resOpeningHoursList.isNotEmpty) {
      DateTime date = DateTime.now();
//      String currentWeekOfDay = DateFormat('EEEE').format(date);
      String currentWeekOfDay = DateFormat.EEEE('en_US').format(date);
//      print('currentDay:$currentWeekOfDay');
      for (int i = 0; i < resOpeningHoursList.length; i++) {
        ResOpeningHours resOpeningHours = resOpeningHoursList[i];
        if (currentWeekOfDay == resOpeningHours.week) {
          // print('resOpeningHours.isOpen:${resOpeningHours.isOpen}');
          if (resOpeningHours.isOpen == "1") {
            // print('ResOpeningHours:${resOpeningHours.toMap()}');
            final currentTime = DateTime.now();
            final startTime = DateTime(
                currentTime.year,
                currentTime.month,
                currentTime.day,
                int.parse(resOpeningHours.startHours),
                int.parse(resOpeningHours.startMinutes),
                0);
            final endTime = DateTime(
                currentTime.year,
                currentTime.month,
                currentTime.day,
                int.parse(resOpeningHours.endHours),
                int.parse(resOpeningHours.endMinutes),
                0);

            //print('startTime:$startTime');
            //print('endTime:$endTime');
            if (currentTime.isAfter(startTime) &&
                currentTime.isBefore(endTime)) {
              // do something
              resOpeningStatus = true;
              try {
                DateTime newDateTime = DateTime.now();
                String newDate = DateFormat("yyyy-MM-dd").format(newDateTime);
                DateTime resonoffdateTime =
                    DateFormat("yyyy-MM-dd hh:mm:ss").parse(res_onoff_date);
                String resonoffdateNew = DateFormat("yyyy-MM-dd")
                    .format(resonoffdateTime)
                    .toString();
                // print('res_onoff_date:$resonoffdateNew');
                if (newDate.toString().toLowerCase() ==
                    resonoffdateNew.toString().toLowerCase()) {
                  // if(!res_onoff) {
                  resOpeningStatus = res_onoff;
                  //print('match date');
                  // }
                } else {
                  //print('not match date');
                }
              } catch (e) {}
            }
          }
          break;
        }
      }
    }
    // print('resOpeningStatus:$resOpeningStatus');
    return resOpeningStatus;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'latitude': latitude,
      'longitude': longitude,
      'delivery_fee': deliveryFee,
      'distance': distance,
    };
  }

  Map<String, dynamic> toMap2() {
    return {
      'id': id,
      'name': name,
      'latitude': latitude,
      'longitude': longitude,
      'delivery_fee': deliveryFee,
      'distance': distance,
      'res_opening_hours': res_opening_hours.asMap(),
    };
  }
}
