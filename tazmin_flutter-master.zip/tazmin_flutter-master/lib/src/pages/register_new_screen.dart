import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:food_delivery_app/src/models/user.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../generated/l10n.dart';
import '../controllers/user_controller.dart';
import '../elements/BlockButtonWidget.dart';
import '../helpers/app_config.dart' as config;

class RegisterNewScreen extends StatefulWidget {
  final RouteArgument routeArgument;

  RegisterNewScreen({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _RegisterNewScreenState createState() => _RegisterNewScreenState();
}

class _RegisterNewScreenState extends StateMVC<RegisterNewScreen> {
  late UserController _con;
  bool _isChecked = false;
  String _password = "";
  String _confirmPassword = "";

  TextEditingController emailTEC = TextEditingController();
  TextEditingController passwordTEC = TextEditingController();
  TextEditingController confirmPasswordTEC = TextEditingController();
  TextEditingController phoneTEC = TextEditingController();
  TextEditingController userNameTEC = TextEditingController();

  _RegisterNewScreenState() : super(UserController()) {
    _con = controller as UserController;
    _con.user.isForLogin = false;
  }

  List<String> messagesList = <String>[];

  @override
  void initState() {
    if (widget.routeArgument != null && widget.routeArgument != UserModel()) {
      _con.user = widget.routeArgument.param;
      // _con.verificationId = widget.routeArgument.id;
      print('_con.user.isForEmail: ${_con.user.isForEmail}');
      if (!_con.user.isForEmail) {
        phoneTEC.text = _con.user.phone;
        print('phoneTEC.text: ${phoneTEC.text}');
      } else if (_con.user.isForEmail) {
        emailTEC.text = _con.user.email;
        passwordTEC.text = _con.user.password;
      }
      print('User Data: ${_con.user}');
    }
    super.initState();
  }

  void goToTermsOfService() async {
    String url = "https://tazmin.net/terms-of-service/";
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    messagesList.clear();
    messagesList.add(S.of(context).register_email_description); //1 email
    messagesList.add(S
        .of(context)
        .register_password_description); //2 both password & confirm password
    messagesList.add(S.of(context).register_username_description); //3 user name
    messagesList.add(S.of(context).register_number_description); //4 phone
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
          key: _con.scaffoldKey,
          body: Container(
              height: MediaQuery.of(context).size.height + 150,
              child: Stack(
                alignment: AlignmentDirectional.topCenter,
                children: <Widget>[
                  Positioned(
                    top: 0,
                    child: Container(
                      width: config.App(context).appWidth(100),
                      height: config.App(context).appHeight(29.5),
                      decoration:
                          BoxDecoration(color: Theme.of(context).secondaryHeaderColor),
                    ),
                  ),
                  if (_con.isFor == 1)
                    SafeArea(
                      child: Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(right: 15),
                            child: IconButton(
                              icon: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                                size: 40,
                              ),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  Positioned(
                    top: config.App(context).appHeight(29.5) - 120,
                    child: Container(
                      width: config.App(context).appWidth(84),
                      height: config.App(context).appHeight(29.5),
                      child: Text(
                        S.of(context).lets_start_with_register,
                        style: Theme.of(context).textTheme.headline2!.merge(
                            TextStyle(color: Theme.of(context).primaryColor)),
                      ),
                    ),
                  ),
                  Positioned(
                    top: config.App(context).appHeight(29.5) - 50,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 50,
                              color: Theme.of(context).hintColor.withOpacity(0.2),
                            )
                          ]),
                      margin: EdgeInsets.symmetric(
                        horizontal: 20,
                      ),
                      padding: EdgeInsets.symmetric(vertical: 30, horizontal: 27),
                      width: config.App(context).appWidth(88),
//              height: config.App(context).appHeight(55),
                      child: Form(
                        key: _con.loginFormKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            // if(isFor == 1)SizedBox(height: 30),
                            Text(
                              messagesList[_con.isFor - 1],
                              style: Theme.of(context).textTheme.headline4!.merge(
                                  TextStyle(color: Theme.of(context).hintColor)),
                            ),
                            SizedBox(height: 30),
                            if (_con.isFor == 1)
                              TextFormField(
                                controller: emailTEC,
                                keyboardType: TextInputType.emailAddress,
                                onSaved: (input) => _con.user.email = input!,
                                validator: (input) => !input!.contains('@')
                                    ? S.of(context).should_be_a_valid_email
                                    : null,
                                decoration: InputDecoration(
                                  labelText: S.of(context).email,
                                  labelStyle: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                  contentPadding: EdgeInsets.all(12),
                                  hintText: 'האימייל שלך',
                                  hintStyle: TextStyle(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.alternate_email,
                                      color: Theme.of(context).secondaryHeaderColor),
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.5))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                ),
                              ),
                            // if(_con.isFor == 2)SizedBox(height: 30),
                            if (_con.isFor == 2)
                              TextFormField(
                                controller: passwordTEC,
                                obscureText: _con.hidePassword,
                                onSaved: (input) => _password = input!,
                                validator: (input) {
                                  if (input!.length < 6) {
                                    return S
                                        .of(context).should_be_more_than_6_letters;
                                  } else {
                                    return null;
                                  }
                                },
                                decoration: InputDecoration(
                                  labelText: S.of(context).password,
                                  labelStyle: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                  contentPadding: EdgeInsets.all(12),
                                  hintText: '••••••••••••',
                                  hintStyle: TextStyle(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.lock_outline,
                                      color: Theme.of(context).secondaryHeaderColor),
                                  suffixIcon: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        _con.hidePassword = !_con.hidePassword;
                                      });
                                    },
                                    color: Theme.of(context).focusColor,
                                    icon: Icon(_con.hidePassword
                                        ? Icons.visibility
                                        : Icons.visibility_off),
                                  ),
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.5))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                ),
                              ),
                            if (_con.isFor == 2) SizedBox(height: 30),
                            if (_con.isFor == 2)
                              TextFormField(
                                controller: confirmPasswordTEC,
                                obscureText: _con.hideConfirmPassword,
                                onSaved: (input) => _confirmPassword = input!,
                                validator: (input) {
                                  if (input!.length < 6) {
                                    return S
                                        .of(context).should_be_more_than_6_letters;
                                  } else if (input != passwordTEC.text) {
                                    return "הסיסמאות אינן תואמות";
                                  } else {
                                    _con.user.password = input;
                                    print(
                                        '_con.user.password:${_con.user.password}');
                                    return null;
                                  }
                                },
                                decoration: InputDecoration(
                                  labelText: S.of(context).confirmpassword,
                                  labelStyle: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                  contentPadding: EdgeInsets.all(12),
                                  hintText: '••••••••••••',
                                  hintStyle: TextStyle(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.lock_outline,
                                      color: Theme.of(context).secondaryHeaderColor),
                                  suffixIcon: IconButton(
                                    onPressed: () {
                                      setState(() {
                                        _con.hideConfirmPassword =
                                            !_con.hideConfirmPassword;
                                      });
                                    },
                                    color: Theme.of(context).focusColor,
                                    icon: Icon(_con.hideConfirmPassword
                                        ? Icons.visibility
                                        : Icons.visibility_off),
                                  ),
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.5))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                ),
                              ),
                            // if(_con.isFor == 3)SizedBox(height: 30),
                            if (_con.isFor == 3)
                              TextFormField(
                                controller: userNameTEC,
                                keyboardType: TextInputType.text,
                                onSaved: (input) => _con.user.name = input!,
                                validator: (input) => input!.length < 3
                                    ? S.of(context).should_be_more_than_3_letters
                                    : null,
                                decoration: InputDecoration(
                                  labelText: S.of(context).full_name,
                                  labelStyle: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                  contentPadding: EdgeInsets.all(12),
                                  hintText: S.of(context).john_doe,
                                  hintStyle: TextStyle(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.person_outline,
                                      color: Theme.of(context).secondaryHeaderColor),
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.5))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                ),
                              ),
                            if (_con.isFor == 4)
                              TextFormField(
                                controller: phoneTEC,
                                inputFormatters: [
                                  FilteringTextInputFormatter.digitsOnly
                                ],
                                keyboardType: TextInputType.number,
                                onSaved: (input) => _con.user.phone = input!,
                                validator: (input) => input!.trim().length < 6
                                    ? S.of(context)
                                    .not_a_valid_phone
                                    : null,
                                decoration: InputDecoration(
                                  labelText: S.of(context).phone,
                                  labelStyle: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                  contentPadding: EdgeInsets.all(12),
                                  hintText: 'מספר טלפון',
                                  hintStyle: TextStyle(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.7)),
                                  prefixIcon: Icon(Icons.phone,
                                      color: Theme.of(context).secondaryHeaderColor),
                                  border: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                  focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.5))),
                                  enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                          color: Theme.of(context)
                                              .focusColor
                                              .withOpacity(0.2))),
                                ),
                              ),
                            if (_con.isFor == 4) SizedBox(height: 20),
                            if (_con.isFor == 4)
                              Row(
                                children: <Widget>[
                                  Checkbox(
                                    value: _isChecked,
                                    onChanged: (isChecked) {
                                      setState(() {
                                        _isChecked = isChecked!;
                                      });
                                    },
                                  ),
                                  InkWell(
                                    child: Text.rich(
                                      TextSpan(
                                        text: S.of(context).i_agree_txt,
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline1!
                                            .merge(TextStyle(
                                                fontSize: 17,
                                                color: Theme.of(context)
                                                    .secondaryHeaderColor)),
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: S
                                                  .of(context).terms_of_service_txt,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .headline1!
                                                  .merge(TextStyle(
                                                      fontSize: 17,
                                                      decoration: TextDecoration
                                                          .underline,
                                                      color: Theme.of(context).secondaryHeaderColor))),
                                          // can add more TextSpans here...
                                        ],
                                      ),
                                    ),
                                    /*Text(S.of(context).terms_of_service_txt,style: Theme.of(context)
                              .textTheme
                              .display4
                              .merge(TextStyle(color: Theme.of(context).secondaryHeaderColor)),),*/
                                    onTap: () {
                                      goToTermsOfService();
                                    },
                                  )
                                ],
                              ),
                            SizedBox(height: 40),
                            Row(
                              children: [
                                if (_con.isFor > 1)
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        if (_con.isFor > 1) {
                                          _con.isFor--;
                                        }
                                      });
                                    },
                                    child: Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 20, vertical: 10),
                                      decoration: BoxDecoration(
                                          color: config.Colors().mainColor(1),
                                          borderRadius:
                                              BorderRadius.circular(30)),
                                      child: Text(
                                        S.of(context).back,
                                        style: Theme.of(context)
                                            .textTheme
                                            .headline4!
                                            .merge(TextStyle(
                                                color: Theme.of(context)
                                                    .primaryColor)),
                                      ),
                                    ),
                                  ),
                                Expanded(
                                  child: SizedBox(
                                    width: 5,
                                  ),
                                ),
                                _con.isFetchingData
                                    ? Container(
                                        height: 50,
                                        width: 50,
                                        child: Center(
                                          child: CircularProgressIndicator(
                                            valueColor: AlwaysStoppedAnimation<
                                                    Color>(
                                                Theme.of(context).secondaryHeaderColor),
                                          ),
                                        ),
                                      )
                                    : InkWell(
                                        onTap: () {
                                          setState(() {
                                            if (_con.loginFormKey.currentState
                                                !.validate()) {
                                              if (_con.isFor < 4) {
                                                if (_con.isFor == 1) {
                                                  _con.checkForEmailAlreadyExists();
                                                } else {
                                                  FocusScope.of(context).unfocus();
                                                  _con.isFor++;
                                                }
                                              } else if (_con.isFor == 4) {
                                                if (_isChecked) {
                                                  _con.user.email = emailTEC.text;
                                                  _con.user.password =
                                                      passwordTEC.text;
                                                  _con.user.phone = phoneTEC.text;
                                                  _con.user.name =
                                                      userNameTEC.text;
                                                  _con.user.isForRegister = true;
                                                  _con.user.isOtpVerified = true;
                                                  _con.user.isForProfile = false;
                                                  _con.loginFormKey.currentState
                                                      ?.save();
                                                  _con.checkForNumberAlreadyExists();
                                                } else {
                                                  ScaffoldMessenger.of(_con.scaffoldKey.currentContext!).showSnackBar(SnackBar(
                                                    content: Text(S
                                                        .of(context)
                                                        .agree_with_terms),
                                                  ));
                                                }
                                                // _con.sendOTP();
                                              }
                                            } else {
                                              _con.loginFormKey.currentState
                                                  ?.validate();
                                            }
                                          });
                                        },
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 20, vertical: 10),
                                          decoration: BoxDecoration(
                                              color: config.Colors().mainColor(1),
                                              borderRadius:
                                                  BorderRadius.circular(30)),
                                          child: Text(
                                            S.of(context).next,
                                            style: Theme.of(context)
                                                .textTheme
                                                .headline4!
                                                .merge(TextStyle(
                                                    color: Theme.of(context)
                                                        .primaryColor)),
                                          ),
                                        ),
                                      )
                              ],
                            ),
                            SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ))),
    );
  }
}
