import 'dart:ui';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/helpers/sqlite_helper.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../controllers/splash_screen_controller.dart';
import 'package:location/location.dart' as Location;
import '../repository/settings_repository.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;
import 'dart:io' show Platform;

class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SplashScreenState();
  }
}

class SplashScreenState extends StateMVC<SplashScreen>
    with TickerProviderStateMixin {
  late SplashScreenController _con;

  //var location = new Location.Location();
  late BuildContext splashContext;
  late AnimationController animationController;
  late Animation<double> _fadeInFadeOut;

  SplashScreenState() : super(SplashScreenController()) {
    _con = controller as SplashScreenController;
  }

  @override
  void initState() {
    super.initState();
    createDataBase();
    animationController = AnimationController(
        duration: const Duration(milliseconds: 2000), vsync: this);
    _fadeInFadeOut = CurvedAnimation(parent: animationController, curve: Curves.fastOutSlowIn);
    animationController.forward();
    //location.requestService();

    FirebaseCrashlytics.instance.setCrashlyticsCollectionEnabled(true);
    //Crashlytics.instance.enableInDevMode = true;

    // Pass all uncaught errors from the framework to Crashlytics.
    FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;
    Future.delayed(const Duration(seconds: 3), () {
      checkLocationPermission();
    });
  }

  @override
  Widget build(BuildContext context) {
    splashContext = context;
    return Scaffold(
      key: _con.scaffoldKey,
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          color: Theme.of(context).secondaryHeaderColor,
        ),
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FadeTransition(
                      opacity: _fadeInFadeOut,
                      child: Image.asset(
                        'assets/img/logo.png',
                        width: 200,
                        color: Colors.white,
                        fit: BoxFit.cover,
                      )),
                  SizedBox(height: 50),
                  /*CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                        Theme.of(context).hintColor),
                  ),*/
                  SpinKitThreeBounce(color: Color(0xFFFFFFFF),size: 28,)
                ],
              ),
            ),
            Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  margin: const EdgeInsets.only(bottom: 30),
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    S.of(context).splash_subtext,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.caption?.merge(TextStyle(
                        color: Color(0xFFFFFFFF), fontSize: 21, fontWeight: FontWeight.bold)),
                  ),
                )),
          ],
        ),
      ),
    );
  }
  void goToDashboard()
  {
    if (Platform.isAndroid) {
      Navigator.of(context)
          .pushReplacementNamed('/PagesWithAnimation', arguments: 2);
    } else if (Platform.isIOS) {
      Navigator.of(context)
          .pushReplacementNamed('/Pages', arguments: 2);
    }
  }
  void checkLocationPermission() async {
    var geolocationStatus =
        await Geolocator.checkPermission();
    print('geolocationStatus.value:${geolocationStatus}');
    if (geolocationStatus != LocationPermission.whileInUse) {
       //requestLocationPermission();
      Navigator.of(context).pushReplacementNamed('/LocationScreen');
    } else {
      var serviceStatus = await Geolocator.checkPermission();
          //await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        goToDashboard();
        getCurrentLocation();
      } else {
        Navigator.of(context).pushReplacementNamed('/LocationScreen');
      }
    }
  }

  /*Future<bool> requestLocationPermission() async {
    return _requestPermission();
  }*/

  void getCurrentLocation() {
    print('getCurrentLocation');
    Geolocator
        .getLastKnownPosition(forceAndroidLocationManager: true)
        .then((position) async {
      if (position != null) {
        deliveryAddress.value.latitude = position.latitude;
        deliveryAddress.value.longitude = position.longitude;
      } else {
        print('last position null');
        Geolocator
            .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
            .then((position) async {
          if (position != null) {
            deliveryAddress.value.latitude = position.latitude;
            deliveryAddress.value.longitude = position.longitude;
          }
        });
      }
    });
  }

  /*Future<bool> _requestPermission() async {
    print('_requestPermission');
    var result = await LocationPermissions().requestPermissions();
    if (result == PermissionStatus.granted) {
      ServiceStatus serviceStatus =
          await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == ServiceStatus.enabled) {
        goToDashboard();
        getCurrentLocation();
      } else{
        Navigator.of(context).pushNamed('/LocationScreen');
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      ServiceStatus serviceStatus =
          await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      Navigator.of(context).pushNamed('/LocationScreen');
      //}
    }
    return false;
  }*/

  void createDataBase() async{
    SQLiteHelper().getDatabase();
  }
}

class MyCustomPageRoute extends MaterialPageRoute {
  final Widget previousPage;

  MyCustomPageRoute(
      {required this.previousPage, required WidgetBuilder builder, RouteSettings? settings})
      : super(builder: builder, settings: settings);

  @override
  Widget buildTransitions(BuildContext context, Animation<double> animation,
      Animation<double> secondaryAnimation, Widget currentPage) {
    Animation<Offset> _slideAnimationPage1 =
        Tween<Offset>(begin: Offset(0.0, -1.0), end: Offset(0.0, 0.0))
            .animate(animation);
    Animation<Offset> _slideAnimationPage2 =
        Tween<Offset>(begin: Offset(0.0, 0.0), end: Offset(0.0, 0.0))
            .animate(animation);
    return Stack(
      children: <Widget>[
        SlideTransition(position: _slideAnimationPage1, child: previousPage),
        SlideTransition(position: _slideAnimationPage2, child: currentPage),
      ],
    );
  }
}
