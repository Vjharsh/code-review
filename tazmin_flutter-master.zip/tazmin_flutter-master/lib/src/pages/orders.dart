import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../../generated/l10n.dart';
import '../controllers/order_controller.dart';
import '../elements/EmptyOrdersWidget.dart';
import '../elements/OrderItemWidget.dart';
import '../elements/PermissionDeniedWidget.dart';
import '../elements/SearchBarWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../repository/user_repository.dart';

class OrdersWidget extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;

  OrdersWidget({
    Key? key,
    required this.parentScaffoldKey}) : super(key: key);

  @override
  OrdersWidgetState createState() => OrdersWidgetState();
}

class OrdersWidgetState extends StateMVC<OrdersWidget> {
  late OrderController _con;
  bool isRunningActivity = true;

  OrdersWidgetState() : super(OrderController()) {
    _con = controller as OrderController;
  }

  @override
  void initState() {
    super.initState();
    intervalForOrderRefresh();
  }

  void dispose() {
    super.dispose();
    isRunningActivity = false;
  }

  void intervalForOrderRefresh() {
    if (isRunningActivity) {
      Future.delayed(const Duration(seconds: 10), () async {
        intervalForOrderRefresh();
        print('call OrdersWidget');
        _con.orders.clear();
        _con.listenForOrders();
      });
    }
  }

  /*@override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.inactive:
        print('appLifeCycleState inactive');
        break;
      case AppLifecycleState.resumed:
        isRunningActivity = true;
        print('appLifeCycleState resumed');
        break;
      case AppLifecycleState.paused:
        isRunningActivity = false;
        print('appLifeCycleState paused');
        break;
      case AppLifecycleState.detached:
        break;
    }
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      appBar: AppBar(
        leading: new IconButton(
          icon: new Icon(Icons.sort, color: Theme.of(context).hintColor),
          onPressed: () => widget.parentScaffoldKey.currentState?.openDrawer(),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          S.of(context).my_orders,
          style: Theme.of(context)
              .textTheme
              .headline6!
              .merge(TextStyle(letterSpacing: 1.3)),
        ),
        actions: <Widget>[
          new ShoppingCartButtonWidget(
              iconColor: Theme.of(context).hintColor,
              labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      body: currentUser.value.apiToken.isEmpty
          ? PermissionDeniedWidget()
          : _con.orders.isEmpty
              ? EmptyOrdersWidget()
              : RefreshIndicator(
                  onRefresh: _con.refreshOrders,
                  child: SingleChildScrollView(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: SearchBarWidget(),
                        ),
                        SizedBox(height: 20),
                        ListView.separated(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          primary: false,
                          itemCount: _con.orders.length,
                          itemBuilder: (context, index) {
                            var _order = _con.orders.elementAt(index);
                            return OrderItemWidget(
                              index: index,
                              selectedIndex: _con.selectedIndex,
                              isLoading: _con.isLoading,
                              expanded: index == 0 ? true : false,
                              order: _order,
                              onCanceled: (e) {
                                _con.doCancelOrder(_order);
                              },
                              reOrder: () {
                                _con.selectedIndex = index;
                                _con.foodOrders =
                                    _con.orders.elementAt(index).foodOrders;
                                _con.addToCartFromFoodArray();
                              },
                            );
                          },
                          separatorBuilder: (context, index) {
                            return SizedBox(height: 20);
                          },
                        ),
                      ],
                    ),
                  ),
                ),
    );
  }
}
