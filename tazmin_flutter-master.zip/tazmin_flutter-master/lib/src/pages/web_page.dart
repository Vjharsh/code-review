import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:mvc_pattern/mvc_pattern.dart';


class WebPageWidget extends StatefulWidget {
  RouteArgument routeArgument;

  WebPageWidget({Key? key, required this.routeArgument}) : super(key: key);

  @override
  _WebPageWidgetState createState() => _WebPageWidgetState();
}

class _WebPageWidgetState extends StateMVC<WebPageWidget> {
  double web_progress = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          widget.routeArgument.id!,
          style: Theme.of(context)
              .textTheme
              .headline6!
              .merge(TextStyle(letterSpacing: 1.3,color: Theme.of(context).secondaryHeaderColor)),
        ),
      ),
      body: widget.routeArgument.id!.isEmpty
          ? CircularLoadingWidget(height: 300)
          : Stack(
              children: <Widget>[
                InAppWebView(
                  initialFile: widget.routeArgument.id,
               //   initialHeaders: {},
                  //initialOptions: {},//for version 1.2.2
                  /*initialOptions: InAppWebViewWidgetOptions(
                    inAppWebViewOptions: InAppWebViewOptions(
                      javaScriptEnabled: true,
                    ),
                  ),*/
                  onWebViewCreated: (InAppWebViewController controller) {

                  },
                  onLoadStop: (InAppWebViewController controller, Uri? url){},

                  onProgressChanged:
                      (InAppWebViewController controller, int progress) {
                    setState(() {
                      web_progress = progress / 100;
                    });
                  },
                ),

                web_progress < 1
                    ? SizedBox(
                        height: 3,
                        child: LinearProgressIndicator(
                          value: web_progress,
                          backgroundColor:
                              Theme.of(context).secondaryHeaderColor.withOpacity(0.2),
                        ),
                      )
                    : SizedBox(),
              ],
            ),
    );
  }
}
