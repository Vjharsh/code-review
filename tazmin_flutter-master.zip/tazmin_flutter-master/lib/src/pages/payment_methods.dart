import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/controllers/yaadpay_controller.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/payment.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart'
    as settingRepo;
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;

import '../../generated/l10n.dart';
import '../elements/PaymentMethodListItemWidget.dart';
import '../elements/SearchBarWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/payment_method.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart';

class PaymentMethodsWidget extends StatefulWidget {
  final RouteArgument routeArgument;

  PaymentMethodsWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _PaymentMethodsWidgetState createState() => _PaymentMethodsWidgetState();
}

class _PaymentMethodsWidgetState extends StateMVC<PaymentMethodsWidget> {
  late PaymentMethodList list;
  late YaadPayController _con;
  double subtotal = 0;
  double deliveryFee = 0;
  String deliveryFeeName = '';
  double discount = 0;
  double total = 0;
  double labelFontSize = 25;
  double amountFontSize = 25;
  bool isForPickUp = false;

  _PaymentMethodsWidgetState() : super(YaadPayController()) {

    _con = controller as YaadPayController;
  }
  @override
  void initState() {
    super.initState();
    if(widget.routeArgument.param !=null)
    {
      isForPickUp = widget.routeArgument.param;
    }
    subtotal = settingRepo.setting.value.orderAmount;
    total = subtotal;
    print('is_used: ${settingRepo.setting.value.is_used}');
    print('isForPickUp: $isForPickUp');
    deliveryFee = settingRepo.setting.value.deliveryFee;
    deliveryFeeName = settingRepo.setting.value.deliveryFeeName;
    if ((settingRepo.setting.value.is_used == 1 && settingRepo.setting.value.couponType ==1) || isForPickUp) {
      deliveryFee = 0.0;
      settingRepo.setting.value.deliveryFee = 0;
    }
    total += deliveryFee;
    if (settingRepo.setting.value.is_used == 1) {
      discount = settingRepo.setting.value.discount;
      total -= discount;
    }
  }

  @override
  Widget build(BuildContext context) {
    print('paymentMethod page isForPickUp:$isForPickUp');
    list = new PaymentMethodList(context,isForPickUp);
    if (!setting.value.payPalEnabled)
      list.paymentsList.removeWhere((element) {
        return element.id == "paypal";
      });
    if (!setting.value.stripeEnabled)
      list.paymentsList.removeWhere((element) {
        return element.id == "visacard" || element.id == "mastercard";
      });
    return Scaffold(
      key: _con.scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          S.of(context).payment_mode,
          style: Theme.of(context)
              .textTheme
              .headline6!
              .merge(TextStyle(letterSpacing: 1.3)),
        ),
        actions: <Widget>[
          new ShoppingCartButtonWidget(
              iconColor: Theme.of(context).hintColor,
              labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      body:
          /*_con.isLoading
          ? Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              color: Colors.white,
              child: Center(child: CircularLoadingWidget(height: 300)))
          :*/
          Stack(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SearchBarWidget(),
                ),
                SizedBox(
                    height:
                        settingRepo.setting.value.disableCreditCard ? 0 : 15),
                /*SizedBox(
              height: 20,
            ),
            Align(
              alignment: Alignment.center,
              child: Helper.getPrice(total, context,
                  style: Theme.of(context).textTheme.headline4.merge(TextStyle(
                      color: Theme.of(context).secondaryHeaderColor, fontSize: 40))),
            ),*/
                SizedBox(
                  height: 20,
                ),
                list.paymentsList.length > 0 &&
                        !settingRepo.setting.value.disableCreditCard
                    ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(vertical: 0),
                          leading: Icon(
                            Icons.payment,
                            color: Theme.of(context).hintColor,
                          ),
                          title: Text(
                            S.of(context).payment_options,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.headline4,
                          ),
                          subtitle: Text(
                              S.of(context).select_your_preferred_payment_mode),
                        ),
                      )
                    : SizedBox(
                        height: 0,
                      ),
                SizedBox(
                    height:
                        settingRepo.setting.value.disableCreditCard ? 0 : 10),
                settingRepo.setting.value.disableCreditCard
                    ? SizedBox(
                        height: 0,
                      )
                    : ListView.separated(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        primary: false,
                        itemCount: list.paymentsList.length,
                        separatorBuilder: (context, index) {
                          return SizedBox(height: 10);
                        },
                        itemBuilder: (context, index) {
                          return PaymentMethodListItemWidget(
                            paymentMethod: list.paymentsList.elementAt(index),
                            isLoading: _con.isLoading,
                            onclick: (isForCreditCard) {
                              print('isForCreditCard:$isForCreditCard');
                              if (isForCreditCard) {
                                setState(() {
                                  _con.isLoading = true;
                                });
                                _con.getOrderJsonArray(isForPickUp);
                              }
                            },
                          );
                        },
                      ),
                list.cashList.length > 0
                    ? Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 20),
                        child: ListTile(
                          contentPadding: EdgeInsets.symmetric(vertical: 0),
                          leading:
                              /*Container(
                          width: 40,
                          height: 40,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              color: Theme.of(context).hintColor,
                              borderRadius:
                                  BorderRadius.all(Radius.circular(50))),
                          child: Center(
                            child:*/
                              Text(
                            setting.value.defaultCurrency,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.headline3!.merge(
                                TextStyle(color: Theme.of(context).hintColor)),
                          ),
                          //)),
                          /*Icon(
                              Icons.monetization_on,
                              color: Theme.of(context).hintColor,
                            ),*/
                          title: Text(
                            S.of(context).cash_on_delivery,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.headline4,
                          ),
                          subtitle: Text(
                              S.of(context).select_your_preferred_payment_mode),
                        ),
                      )
                    : SizedBox(
                        height: 0,
                      ),
                ListView.separated(
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  primary: false,
                  itemCount: list.cashList.length,
                  separatorBuilder: (context, index) {
                    return SizedBox(height: 10);
                  },
                  itemBuilder: (context, index) {
                    return PaymentMethodListItemWidget(
                      paymentMethod: list.cashList.elementAt(index),
                      onclick: (isForCreditCard) {},
                    );
                  },
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 10,
            left: 10,
            right: 10,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(20)),
                  boxShadow: [
                    BoxShadow(
                        color: Theme.of(context).secondaryHeaderColor.withOpacity(0.15),
                        offset: Offset(0, 1),
                        blurRadius: 5.0)
                  ]),
              child: SizedBox(
                width: MediaQuery.of(context).size.width - 40,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    if (!isForPickUp)
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            S.of(context).subtotal,
                            style: Theme.of(context).textTheme.headline2!.merge(
                                TextStyle(
                                    fontSize: labelFontSize,
                                    color: config.Colors().secondColor(1))),
                          ),
                        ),
                        Helper.getPrice(subtotal, context,
                            style: Theme.of(context)
                                .textTheme
                                .headline6!
                                .merge(TextStyle(fontSize: amountFontSize)))
                      ],
                    ),
                    if (!isForPickUp)
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            S.of(context).delivery_fee,
                            style: Theme.of(context).textTheme.headline2!.merge(
                                TextStyle(
                                    fontSize: labelFontSize,
                                    color: config.Colors().secondColor(1))),
                          ),
                        ),
                        Helper.getPrice(deliveryFee, context,
                            style: Theme.of(context)
                                .textTheme
                                .headline6!
                                .merge(TextStyle(fontSize: amountFontSize)))
                      ],
                    ),
                    if (discount > 0)
                      Row(
                        children: <Widget>[
                          Expanded(
                            child: Text(
                              S.of(context).discount,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline2!
                                  .merge(TextStyle(
                                      fontSize: labelFontSize,
                                      color: config.Colors().secondColor(1))),
                            ),
                          ),
                          Helper.getPrice(discount, context,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6!
                                  .merge(TextStyle(fontSize: amountFontSize))),
                          Text(
                            '-',
                            style: Theme.of(context)
                                .textTheme
                                .headline6!
                                .merge(TextStyle(fontSize: amountFontSize)),
                          ),
                        ],
                      ),
                    //if (discount > 0 || deliveryFee > 0)
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            S.of(context).total,
                            style: Theme.of(context).textTheme.headline2!.merge(
                                TextStyle(
                                    fontSize: labelFontSize,
                                    color: config.Colors().secondColor(1))),
                          ),
                        ),
                        Helper.getPrice(total, context,
                            style: Theme.of(context)
                                .textTheme
                                .headline6!
                                .merge(TextStyle(fontSize: amountFontSize)))
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
