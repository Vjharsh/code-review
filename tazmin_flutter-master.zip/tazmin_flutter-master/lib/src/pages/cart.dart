import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import '../../generated/l10n.dart';
import '../../src/helpers/app_config.dart' as config;
import '../controllers/cart_controller.dart';
import '../elements/CartItemWidget.dart';
import '../elements/EmptyCartWidget.dart';
import '../helpers/helper.dart';
import '../models/route_argument.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart'
    as settingRepo;

class CartWidget extends StatefulWidget {
  final RouteArgument routeArgument;

  CartWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _CartWidgetState createState() => _CartWidgetState();
}

class _CartWidgetState extends StateMVC<CartWidget> {
  late CartController _con;
  bool isLoading = false;
  var couponCodeEt = false;
  var couponCodeValue = '';
  var orderNoteValue = '';
  bool isDisplayOrderNote = false;
  bool isForNewScreen = true;
  TextEditingController orderNoteTEC = TextEditingController();

  _CartWidgetState() : super(CartController()) {
    _con = controller as CartController;
  }

  @override
  void initState() {
    super.initState();
    if (widget.routeArgument != null) {
      if (widget.routeArgument.id != null) {
        if (widget.routeArgument.id == '-1') {
          isForNewScreen = false;
        }
      }
    }
    _con.listenForDeliveryTime();
    _con.listenForCarts();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        key: _con.scaffoldKey,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: !isForNewScreen
              ? Container()
              : IconButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    /* if (widget.routeArgument.param == '/Food') {
                Navigator.of(context).pushReplacementNamed('/Food',
                    arguments: RouteArgument(id: widget.routeArgument.id));
              } else {
                Navigator.of(context)
                    .pushReplacementNamed('/Pages', arguments: 2);
              }*/
                  },
                  icon: Icon(Icons.arrow_back),
                  color: Theme.of(context).hintColor,
                ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: Text(
            S.of(context).cart,
            style: Theme.of(context)
                .textTheme
                .headline6!
                .merge(TextStyle(letterSpacing: 1.3)),
          ),
        ),
        body: RefreshIndicator(
          onRefresh: _con.refreshCarts,
          child: _con.carts.isEmpty
              ? EmptyCartWidget()
              : Stack(
                  fit: StackFit.expand,
                  children: <Widget>[
                    Container(
                      margin: EdgeInsets.only(bottom: 165),
                      padding: EdgeInsets.only(bottom: 15),
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          mainAxisSize: MainAxisSize.max,
                          children: <Widget>[
                            if (_con.isRunning)
                              SizedBox(
                                height: 3,
                                child: LinearProgressIndicator(
                                  backgroundColor: Theme.of(context)
                                      .secondaryHeaderColor
                                      .withOpacity(0.2),
                                ),
                              ),
                            Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.only(left: 20, right: 10),
                                    child: ListTile(
                                      contentPadding:
                                          EdgeInsets.symmetric(vertical: 0),
                                      leading: Icon(
                                        Icons.shopping_cart,
                                        color: Theme.of(context).hintColor,
                                      ),
                                      title: Text(
                                        S.of(context).shopping_cart,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context).textTheme.headline4,
                                      ),
                                      subtitle: Text(
                                        S
                                            .of(context).verify_your_quantity_and_click_checkout,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context).textTheme.caption,
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: InkWell(
                                    child: Chip(
                                      padding: EdgeInsets.all(8),
                                      label: Text(
                                        S.of(context).addToOrder,
                                        textAlign: TextAlign.start,
                                        style: TextStyle(
                                            color: Theme.of(context)
                                                .primaryColor),
                                      ),
                                      backgroundColor: Theme.of(context)
                                          .secondaryHeaderColor
                                          .withOpacity(0.9),
                                      shape: StadiumBorder(),
                                    ),
                                    onTap: () {
                                      Navigator.of(context).pushNamed('/Details',
                                          arguments:
                                          RouteArgument(id: _con.carts[0].food.restaurant.id, heroTag: 'Cart'));
                                    },
                                  ),
                                )
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 15, right: 15, top: 0, bottom: 0),
                              child: couponCodeEt
                                  ? Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                            child: _con.appliedDiscount
                                                ? Text(
                                                    '${S.of(context).applied_coupon_code} - $couponCodeValue',
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    maxLines: 1,
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .subtitle1,
                                                  )
                                                : TextFormField(
                                                    onChanged: (input) =>
                                                        couponCodeValue = input,
                                                    decoration: InputDecoration(
                                                      labelText: S
                                                          .of(context).coupon_code,
                                                      labelStyle: TextStyle(
                                                          color:
                                                              Theme.of(context)
                                                                  .secondaryHeaderColor),
                                                      contentPadding:
                                                          EdgeInsets.all(12),
                                                      hintText: S
                                                          .of(context).coupon_code,
                                                      hintStyle: TextStyle(
                                                          color:
                                                              Theme.of(context)
                                                                  .focusColor
                                                                  .withOpacity(
                                                                      0.7)),
                                                      border: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(
                                                                      context)
                                                                  .focusColor
                                                                  .withOpacity(
                                                                      0.2))),
                                                      focusedBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(
                                                                      context)
                                                                  .focusColor
                                                                  .withOpacity(
                                                                      0.5))),
                                                      enabledBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                              color: Theme.of(
                                                                      context)
                                                                  .focusColor
                                                                  .withOpacity(
                                                                      0.2))),
                                                    ),
                                                  )),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        _con.isCouponCodeLoading
                                            ? Container(
                                                width: 30,
                                                height: 30,
                                                child: CircularLoadingWidget(
                                                  height: 30,
                                                ),
                                              )
                                            : InkWell(
                                                onTap: () {
                                                  if (_con.appliedDiscount) {
                                                    setState(() {
                                                      couponCodeValue = '';
                                                      couponCodeEt = false;
                                                    });
                                                    _con.resetCouponCode();
                                                  } else {
                                                    print(
                                                        'couponCodeValue:$couponCodeValue');
                                                    _con.applyNewCouponCode(
                                                        couponCodeValue);
                                                  }
                                                },
                                                child: Chip(
                                                  padding: EdgeInsets.all(5),
                                                  label: Text(
                                                    _con.appliedDiscount
                                                        ? S.of(context).cancel
                                                        : S.of(context).apply,
                                                    textAlign: TextAlign.start,
                                                    style: TextStyle(
                                                        color: Theme.of(context)
                                                            .primaryColor),
                                                  ),
                                                  backgroundColor:
                                                      Theme.of(context)
                                                          .secondaryHeaderColor
                                                          .withOpacity(0.9),
                                                  shape: StadiumBorder(),
                                                ),
                                              ),
                                        couponCodeEt &&
                                                !_con.appliedDiscount &&
                                                !_con.isCouponCodeLoading
                                            ? IconButton(
                                                onPressed: () {
                                                  setState(() {
                                                    couponCodeEt = false;
                                                  });
                                                },
                                                icon: Icon(Icons.cancel),
                                                color:
                                                    Theme.of(context).hintColor,
                                              )
                                            : Container(),
                                      ],
                                    )
                                  : Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          S.of(context).have_a_coupon,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        InkWell(
                                          child: Chip(
                                            padding: EdgeInsets.all(5),
                                            label: Text(
                                              S.of(context).insert_here,
                                              textAlign: TextAlign.start,
                                              style: TextStyle(
                                                  color: Theme.of(context)
                                                      .primaryColor),
                                            ),
                                            backgroundColor: Theme.of(context)
                                                .secondaryHeaderColor
                                                .withOpacity(0.9),
                                            shape: StadiumBorder(),
                                          )
                                          /*Text(
                                            S.of(context).insert_here,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            style: Theme.of(context)
                                                .textTheme
                                                .subtitle1
                                                .merge(TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                    color: Theme.of(context)
                                                        .secondaryHeaderColor)),
                                          )*/
                                          ,
                                          onTap: () {
                                            setState(() {
                                              couponCodeEt = true;
                                            });
                                          },
                                        )
                                      ],
                                    ),
                            ),
                            /*Padding(
                              padding: const EdgeInsets.only(top: 5,right: 10,left: 10),
                              child: Container(
                                height: 10,
                                color: config.Colors().secondColor(1),
                              ),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[

                              ],
                            ),*/
                            ListView.separated(
                              padding: EdgeInsets.symmetric(vertical: 15),
                              scrollDirection: Axis.vertical,
                              shrinkWrap: true,
                              primary: false,
                              itemCount: _con.carts.length,
                              separatorBuilder: (context, index) {
                                return SizedBox(height: 15);
                              },
                              itemBuilder: (context, index) {
                                return CartItemWidget(
                                  cart: _con.carts.elementAt(index),
                                  heroTag: 'cart',
                                  increment: () {
                                    _con.incrementQuantity(
                                        _con.carts.elementAt(index));
                                  },
                                  decrement: () {
                                    _con.decrementQuantity(
                                        _con.carts.elementAt(index));
                                  },
                                  onDismissed: () {
                                    _con.removeFromCart(_con.carts.elementAt(index));
                                    _con.listenForCartsCount();
                                  },
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      child: Container(
//                        height: 195,
                        padding:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                        decoration: BoxDecoration(
                            color: Theme.of(context).primaryColor,
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(20),
                                topLeft: Radius.circular(20)),
                            boxShadow: [
                              BoxShadow(
                                  color: Theme.of(context)
                                      .focusColor
                                      .withOpacity(0.15),
                                  offset: Offset(0, -2),
                                  blurRadius: 5.0)
                            ]),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width - 40,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              isDisplayOrderNote
                                  ? SizedBox(
                                      height: 0,
                                    )
                                  : Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            S.of(context).order_note,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1,
                                          ),
                                        ),
                                        InkWell(
                                            onTap: () {
                                              setState(() {
                                                isDisplayOrderNote = true;
                                              });
                                            },
                                            child: Chip(
                                              padding: EdgeInsets.all(5),
                                              label: Text(
                                                S.of(context).click_here,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                    color: Theme.of(context)
                                                        .primaryColor),
                                              ),
                                              backgroundColor: Theme.of(context)
                                                  .secondaryHeaderColor
                                                  .withOpacity(0.9),
                                              shape: StadiumBorder(),
                                            )),
                                      ],
                                    ),
                              isDisplayOrderNote
                                  ? Stack(children: [
                                      TextFormField(
                                        controller: orderNoteTEC,
                                        maxLines: 3,
                                        textInputAction: TextInputAction.done,
                                        keyboardType: TextInputType.text,
                                        onChanged: (input) =>
                                            orderNoteValue = input,
                                        decoration: InputDecoration(
                                          labelText: S.of(context).order_note,
                                          labelStyle: TextStyle(
                                              color: Theme.of(context)
                                                  .secondaryHeaderColor),
                                          contentPadding: EdgeInsets.only(
                                              left: 35,
                                              right: 12,
                                              top: 12,
                                              bottom: 12),
                                          hintText: S.of(context).order_note,
                                          hintStyle: TextStyle(
                                              color: Theme.of(context)
                                                  .focusColor
                                                  .withOpacity(0.7)),
                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Theme.of(context)
                                                      .focusColor
                                                      .withOpacity(0.2))),
                                          focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Theme.of(context)
                                                      .focusColor
                                                      .withOpacity(0.5))),
                                          enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Theme.of(context)
                                                      .focusColor
                                                      .withOpacity(0.2))),
                                        ),
                                      ),
                                      Positioned(
                                          top: 0,
                                          left: 0,
                                          child: IconButton(
                                            onPressed: () {
                                              setState(() {
                                                isDisplayOrderNote = false;
                                              });
                                            },
                                            icon: Icon(
                                              Icons.keyboard_arrow_down,
                                              size: 35,
                                            ),
                                            color: Theme.of(context).hintColor,
                                          )),
                                    ])
                                  : SizedBox(
                                      height: 0,
                                    ),
                              if (_con.orderOption != 0)
                                SizedBox(
                                  height: 5,
                                ),
                              if (_con.orderOption != 0)
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Text(
                                        S.of(context).subtotal,
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1,
                                      ),
                                    ),
                                    Helper.getPrice(_con.subTotal, context,
                                        style: Theme.of(context)
                                            .textTheme
                                            .subtitle1!)
                                  ],
                                ),
                              if (_con.orderOption == 2) SizedBox(height: 5),
                              if (_con.orderOption == 2)
                                Row(
                                  children: <Widget>[
                                    Text(
                                      _con.appliedDiscount &&
                                              _con.couponType == 1
                                          ? '${S.of(context).delivery_fee} (${S.of(context).applied_coupon_code})'
                                          : S.of(context).delivery_fee,
                                      style:
                                          Theme.of(context).textTheme.bodyText1,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    InkWell(
                                      child: Chip(
                                        padding: EdgeInsets.all(5),
                                        label: Text(
                                          S.of(context).change_address,
                                          textAlign: TextAlign.start,
                                          style: TextStyle(
                                              color: Theme.of(context)
                                                  .primaryColor),
                                        ),
                                        backgroundColor: Theme.of(context)
                                            .secondaryHeaderColor
                                            .withOpacity(0.9),
                                        shape: StadiumBorder(),
                                      ),
                                      onTap: () {
                                        _con.checkLocationPermission(true);
                                      },
                                    ),
                                    Expanded(
                                        child: SizedBox(
                                      width: 5,
                                    )),
                                    Helper.getPrice(_con.deliveryFee, context,
                                        style: Theme.of(context)
                                            .textTheme
                                            .subtitle1!)
                                  ],
                                ),
                              /*Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Text(
                                      '${S.of(context).tax} (${_con.carts[0].food.restaurant.defaultTax}%)',
                                      style:
                                          Theme.of(context).textTheme.bodyText1,
                                    ),
                                  ),
                                  Helper.getPrice(_con.taxAmount, context,
                                      style:
                                          Theme.of(context).textTheme.subtitle1)
                                ],
                              ),*/
                              _con.appliedDiscount &&
                                      (_con.couponType == 2 ||
                                          _con.couponType == 3)
                                  ? Row(
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            '${S.of(context).discount} (${S.of(context).applied_coupon_code})',
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1,
                                          ),
                                        ),
                                        Helper.getPrice(_con.discount, context,
                                            style: Theme.of(context)
                                                .textTheme
                                                .subtitle1!),
                                        Text(
                                          '-',
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                      ],
                                    )
                                  : Container(),
                              SizedBox(height: 10),
                              _con.isGettingDistance
                                  ? SizedBox(
                                      height: 50,
                                      child: Center(
                                        child: CircularProgressIndicator(),
                                      ),
                                    )
                                  : _con.orderOption == 0
                                      ? Row(
                                          children: [
                                            Expanded(
                                              child: FlatButton(
                                                onPressed: () {
                                                  if(_con.carts[0].food.restaurant.resOpeningStatus) {
                                                    FocusScope.of(context).requestFocus(new FocusNode());
                                                    _con.isForPickUp = true;
                                                    settingRepo.setDeliveryOption(false);
                                                    if (!_con.disablePickUp) {
                                                      setState(() {
                                                        _con.orderOption = 1;
                                                        _con
                                                            .calculateSubtotal();
                                                      });
                                                    }
                                                  } else {
                                                    Alert(
                                                      context: context,
                                                      type: AlertType.warning,
                                                      title: S.of(context).closed,
                                                      style: AlertStyle(
                                                          titleStyle: Theme.of(context)
                                                              .textTheme
                                                              .bodyText1!
                                                              .merge(TextStyle(fontSize: 20)),
                                                          descStyle: Theme.of(context)
                                                              .textTheme
                                                              .bodyText1!
                                                              .merge(TextStyle(fontSize: 18))),
                                                      desc: setting.value.messageClose,
                                                      buttons: [
                                                        DialogButton(
                                                          child: Text(
                                                            S.of(context).alert_ok,
                                                            style: TextStyle(color: Colors.white, fontSize: 21),
                                                          ),
                                                          onPressed: () {
                                                            Navigator.pop(context);
                                                          },
                                                          width: 120,
                                                        )
                                                      ],
                                                    ).show();
                                                  }
                                                  //checkoutProcess();
                                                },
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 14),
                                                color: !_con.disablePickUp
                                                    ? Theme.of(context)
                                                        .secondaryHeaderColor
                                                    : Theme.of(context)
                                                        .hintColor
                                                        .withOpacity(0.5),
                                                shape: StadiumBorder(),
                                                child: Text(
                                                  S.of(context).pay_on_pickup,
                                                  textAlign: TextAlign.start,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline4!
                                                      .merge(TextStyle(
                                                          color: Theme.of(
                                                                  context)
                                                              .primaryColor)),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Expanded(
                                              child: FlatButton(
                                                onPressed: () {
                                                  if(_con.isDeliveryTime) {
                                                    if (_con.carts[0].food
                                                        .restaurant
                                                        .resOpeningStatus) {
                                                      FocusScope.of(context)
                                                          .requestFocus(
                                                          new FocusNode());
                                                      settingRepo
                                                          .setDeliveryOption(
                                                          true);
                                                      _con.isForPickUp = false;
                                                      _con
                                                          .checkLocationPermission(
                                                          true);
                                                    } else {
                                                      Alert(
                                                        context: context,
                                                        type: AlertType.warning,
                                                        title: S.of(context).closed,
                                                        style: AlertStyle(
                                                            titleStyle: Theme
                                                                .of(context)
                                                                .textTheme
                                                                .bodyText1!
                                                                .merge(
                                                                TextStyle(
                                                                    fontSize: 20)),
                                                            descStyle: Theme
                                                                .of(context)
                                                                .textTheme
                                                                .bodyText1!
                                                                .merge(
                                                                TextStyle(
                                                                    fontSize: 18))),
                                                        desc: setting.value.messageClose,
                                                        buttons: [
                                                          DialogButton(
                                                            child: Text(S.of(context).alert_ok,
                                                              style: TextStyle(color: Colors.white, fontSize: 21),
                                                            ),
                                                            onPressed: () {
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                            width: 120,
                                                          )
                                                        ],
                                                      ).show();
                                                    }
                                                  }
                                                },
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 14),
                                                color: _con.isDeliveryTime ? Theme.of(context).secondaryHeaderColor:config.Colors().secondColor(1.0),
                                                shape: StadiumBorder(),
                                                child: Text(
                                                  S.of(context).delivery,
                                                  textAlign: TextAlign.start,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline4!
                                                      .merge(TextStyle(
                                                          color: Theme.of(
                                                                  context)
                                                              .primaryColor)),
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      : Stack(
                                          fit: StackFit.loose,
                                          alignment:
                                              AlignmentDirectional.centerEnd,
                                          children: <Widget>[
                                            SizedBox(
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width -
                                                  40,
                                              child: FlatButton(
                                                onPressed: () {
                                                  FocusScope.of(context)
                                                      .requestFocus(
                                                          new FocusNode());
                                                  checkoutProcess();
                                                },
                                                //disabledColor: Theme.of(context).focusColor.withOpacity(0.5),
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 14),
//                                      color:!_con.carts[0].food.restaurant.closed ? Theme.of(context).secondaryHeaderColor : Theme.of(context).focusColor.withOpacity(0.5),
                                                color: Theme.of(context)
                                                    .secondaryHeaderColor,
                                                shape: StadiumBorder(),
                                                child: Text(
                                                  _con.orderOption == 2
                                                      ? S.of(context).checkout
                                                      : S
                                                          .of(context).finish_order,
                                                  textAlign: TextAlign.start,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline4!
                                                      .merge(TextStyle(
                                                          color: Theme.of(
                                                                  context)
                                                              .primaryColor)),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                      horizontal: 20),
                                              child: Helper.getPrice(
                                                _con.total,
                                                context,
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .headline4!
                                                    .merge(TextStyle(
                                                        color: Theme.of(context)
                                                            .primaryColor)),
                                              ),
                                            ),
                                            Align(
                                              alignment: Alignment.centerRight,
                                              child: InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    _con.orderOption = 0;
                                                    _con.calculateSubtotal();
                                                  });
                                                },
                                                child: Padding(
                                                  padding: const EdgeInsets
                                                          .symmetric(
                                                      horizontal: 20,
                                                      vertical: 5),
                                                  child: Icon(
                                                    Icons.arrow_back,
                                                    color: Theme.of(context)
                                                        .primaryColor,
                                                    size: 35,
                                                  ),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
//                              SizedBox(height: 10),
                            ],
                          ),
                        ),
                      ),
                    )
                  ],
                ),
        ),
      ),
    );
  }

  void checkoutProcess() {
    settingRepo.setting.value.orderAmount = _con.subTotal;
    settingRepo.setting.value.orderNote = orderNoteValue;
    if (_con.carts.length > 0) {
      /*settingRepo.setting.value.deliveryFee =
          _con.carts[0].food.restaurant.deliveryFee;*/
      settingRepo.setting.value.disableCreditCard =
          _con.carts.elementAt(0).food.restaurant.disableCreditCard;
      settingRepo.setting.value.disablePickUp =
          _con.carts.elementAt(0).food.restaurant.disablePickup;
    }
    if (_con.appliedDiscount) {
      settingRepo.setting.value.couponType = _con.couponType;
      settingRepo.setting.value.is_used = 1;
      settingRepo.setting.value.coupon_code = couponCodeValue;
      settingRepo.setting.value.discount = _con.discount;
    } else {
      settingRepo.setting.value.is_used = 0;
    }
    //_con.goToDeliveryAddress();
    if (_con.subTotal >=
        _con.carts.elementAt(0).food.restaurant.minOrderPrice) {
      setState(() {
        isLoading = false;
      });
      print(
          'called checkout:${settingRepo.setting.value.checkoutAlertEnabled}');
      if (settingRepo.setting.value.checkoutAlertEnabled == '1') {
        _con.checkoutAlert(settingRepo.setting.value.checkoutAlertMessage);
      } else {
        _con.goToPaymentMethodPage();
      }
    } else {
      _con.minOrderAlert(_con.carts.elementAt(0).food.restaurant.minOrderPrice);
    }
  }
}
