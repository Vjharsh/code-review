import 'dart:convert';
import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:html/parser.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:food_delivery_app/src/elements/CategoriesFoodItemWidget.dart';
import 'package:food_delivery_app/src/elements/ShoppingCartButtonWidget.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:shimmer/shimmer.dart';
import 'package:sticky_headers/sticky_headers.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import '../../generated/l10n.dart';
import '../controllers/restaurant_controller.dart';
import '../elements/CircularLoadingWidget.dart';
import '../elements/FoodItemWidget.dart';
import '../elements/GalleryCarouselWidget.dart';
import '../elements/ShoppingCartFloatButtonWidget.dart';
import '../helpers/helper.dart';
import '../models/route_argument.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;

class DetailsWidget extends StatefulWidget {
  final RouteArgument routeArgument;

  DetailsWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _DetailsWidgetState createState() {
    return _DetailsWidgetState();
  }
}

class _DetailsWidgetState extends StateMVC<DetailsWidget>
    with TickerProviderStateMixin {
  late RestaurantController _con;

  //auto scroll tab and list
  late ScrollController _sController;
  late ScrollController _sTabController;

  GlobalKey appBarKey = GlobalKey();
  GlobalKey sizeBox1Key = GlobalKey();
  GlobalKey detailImageKey = GlobalKey();
  GlobalKey detailNameSectionKey = GlobalKey();
  GlobalKey detailBusyModeSectionKey = GlobalKey();
  GlobalKey detailCreditCardKey = GlobalKey();
  GlobalKey detailDescriptionKey = GlobalKey();
  GlobalKey detailFreeShippingKey = GlobalKey();
  GlobalKey detailGalleriesKey = GlobalKey();
  GlobalKey expandInfoTitleKey = GlobalKey();
  GlobalKey expandInfoKey = GlobalKey();
  GlobalKey detailAddressKey = GlobalKey();
  GlobalKey detailPhoneKey = GlobalKey();
  GlobalKey tabKey = GlobalKey();
  GlobalKey stickyHeaderKey = GlobalKey();
  GlobalKey menuKey = GlobalKey();
  GlobalKey categoriesWithFoodsTitleKey = GlobalKey();
  GlobalKey featuredFoodsTitleKey = GlobalKey();
  GlobalKey featuredFoodsListKey = GlobalKey();

  double stickyValue = 0;
  Color tabColor = Colors.transparent;
  int currentValue = 0;
  int oldValue = 0;
  int itemSelectIndex = -1;
  int oldItemSelectIndex = -1;
  bool isTabClick = false;
  int isStartScroll = 0;
  List<double> offsetList = <double>[];
  List<double> tabItemOffsetList = <double>[];
  bool isExpandedInfo = false;
  double expandedInfoOffset = 0;

  _DetailsWidgetState() : super(RestaurantController()) {
    _con = controller as RestaurantController;
  }

  late AnimationController _controller;
  Tween<double> _selectedTween = Tween(begin: 0, end: 1);
  late AnimationController expandController;
  late Animation<double> animation;

  @override
  void initState() {
    super.initState();

    _con.isLoadedAllMenu = false;
    _con.isLoadedAllMenuLoading = false;
    _con.isLoadedDetail = false;
    _con.isLoadedGalleries = false;
    _con.isLoadedFeaturedFoods = false;
    expandController = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    animation = CurvedAnimation(parent: expandController, curve: Curves.fastOutSlowIn);
    initController();
    _con.listenForDeliveryTime();
    _con.resetMenuApi(widget.routeArgument.id.toString());
    /*_con.listenRestaurantMenuFromDB(widget.routeArgument.id.toString());
    _con.listenForRestaurant(id: widget.routeArgument.id);
    _con.listenForGalleries(widget.routeArgument.id.toString());
    _con.listenForFeaturedFoods(widget.routeArgument.id.toString());*/
    _controller = AnimationController(duration: const Duration(milliseconds: 800), vsync: this);
    _controller
      ..addStatusListener((AnimationStatus status) {
        if (status == AnimationStatus.completed) {
          // _controller.reverse();
        }
      });

    Future.delayed(const Duration(milliseconds: 700), () {
      _controller.forward();
    });
  }

  void initController() {
    _sController = ScrollController();
    _sTabController = ScrollController();
    _sController.addListener(() {
      isStartScroll = 1;
      if (stickyValue <= 0) {
        currentValue = 0;
      } else {
        currentValue = 1;
      }
      if (currentValue != oldValue) {
        oldValue = currentValue;
        setState(() {
          tabColor = currentValue == 0
              ? Theme.of(context).scaffoldBackgroundColor
              : Colors.transparent;
        });
      }
      if(_con.isLoadedAllMenuLoading) {
        if (_con.categoriesWithFoods.length > 0 && !isTabClick) {
          for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
            RenderBox? renderBox =
            _con.categoriesWithFoods[i].key.currentContext?.findRenderObject() as RenderBox?;
            if (renderBox != null) {
              Offset positionOfRenderBox = renderBox.localToGlobal(Offset.zero);
              if (positionOfRenderBox.dy < 160) {
                itemSelectIndex = i;
                RenderBox? tabKeyItemRenderBox = _con
                    .categoriesWithFoods[i].tabKey.currentContext
                    ?.findRenderObject() as RenderBox?;
                if (tabKeyItemRenderBox != null) {
                  tabKeyItemRenderBox.localToGlobal(Offset.zero);
                  if (tabItemOffsetList.elementAt(i) < 0) {
                    _sTabController
                        .animateTo(tabItemOffsetList.elementAt(i).abs(),
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut)
                        .then((value) {});
                  } else {
                    _sTabController
                        .animateTo(-tabItemOffsetList.elementAt(i),
                        duration: const Duration(milliseconds: 250),
                        curve: Curves.easeOut)
                        .then((value) {});
                  }
                }
              }
            }
          }
        }
      }
    });
  }

  void readyOfWidget() {
    offsetList.clear();
    tabItemOffsetList.clear();
    double total = 0;
    RenderBox? renderBox = appBarKey.currentContext?.findRenderObject() as RenderBox?;
    double offset = 0;
    renderBox = detailImageKey.currentContext?.findRenderObject() as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = detailNameSectionKey.currentContext?.findRenderObject() as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = detailBusyModeSectionKey.currentContext?.findRenderObject() as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    if (_con.restaurant.disableCreditCard) {
      renderBox = detailCreditCardKey.currentContext?.findRenderObject()as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        total += offset;
      }
    }

    if (_con.restaurant.freeShipping) {
      renderBox = detailFreeShippingKey.currentContext?.findRenderObject()as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        total += offset;
      }
    }
    /*renderBox = detailDescriptionKey.currentContext.findRenderObject();
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = detailGalleriesKey.currentContext.findRenderObject();
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = detailAddressKey.currentContext.findRenderObject();
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = detailPhoneKey.currentContext.findRenderObject();
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }*/
    renderBox = expandInfoTitleKey.currentContext?.findRenderObject()as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = expandInfoKey.currentContext?.findRenderObject()as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      expandedInfoOffset = renderBox.size.height;
      total += offset;
    }

    if (_con.featuredFoods.isNotEmpty) {
      renderBox = featuredFoodsTitleKey.currentContext?.findRenderObject()as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        total += offset;
      }
      renderBox = featuredFoodsListKey.currentContext?.findRenderObject()as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        total += offset;
      }
    }
    renderBox = categoriesWithFoodsTitleKey.currentContext?.findRenderObject()as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      total += offset;
    }
    renderBox = sizeBox1Key.currentContext?.findRenderObject()as RenderBox?;
    offset = 0;
    double sizeBox10Height = 0;
    if (renderBox != null) {
      offset = renderBox.size.height + 5;
      sizeBox10Height = renderBox.size.height;
      total += offset;
    }
    for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
      if (i != 0) {
        RenderBox? renderBox = _con.categoriesWithFoods[i - 1].key.currentContext!
            .findRenderObject() as RenderBox?;
        double offset = 0;
        if (renderBox != null) {
          offset = renderBox.size.height + sizeBox10Height;
        }
        total += offset;
        offsetList.add(total);
      } else {
        offsetList.add(total);
      }
    }
    for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
      RenderBox? tabKeyItemRenderBox =
          _con.categoriesWithFoods[i].tabKey.currentContext!.findRenderObject() as RenderBox?;
      if (tabKeyItemRenderBox != null) {
        Offset positionOfRenderBox =
            tabKeyItemRenderBox.localToGlobal(Offset.zero);
        tabItemOffsetList.add(positionOfRenderBox.dx);
      }
    }
    print('renderLoaded');
  }

  @override
  Widget build(BuildContext context) {
    if (_con.isLoadedAllMenu &&
        _con.isLoadedDetail &&
        _con.isLoadedGalleries &&
        _con.isLoadedFeaturedFoods) {
      _con.isLoadedAllMenu = false;
      _con.isLoadedDetail = false;
      _con.isLoadedGalleries = false;
      _con.isLoadedFeaturedFoods = false;
      if(_con.isLoadedAllMenuLoading) {
        Future.delayed(const Duration(milliseconds: 900), () {
          readyOfWidget();
        });
      }
    }
    return Scaffold(
        key: _con.scaffoldKey,
        appBar: AppBar(
          key: appBarKey,
          toolbarHeight: 70,
          automaticallyImplyLeading: false,
          leading: IconButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            icon: Icon(
              Icons.arrow_back,
              size: 30,
            ),
            color: Theme.of(context).hintColor,
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: false,
          title: Text(
            _con.restaurant.name,
            style: Theme.of(context)
                .textTheme
                .headline6!
                .merge(TextStyle(letterSpacing: 1.3)),
          ),
          actions: [
            /*ShoppingCartFloatButtonWidget(
              iconColor: Theme.of(context).primaryColor,
              labelColor: Theme.of(context).hintColor,
              backIconColor: Theme.of(context).hintColor,
            ),*/
            Align(
                alignment: Alignment.center,
                child: Container(
                  margin: EdgeInsets.only(left: 5),
                  child: ShoppingCartButtonWidget(
                      iconColor: Theme.of(context).hintColor,
                      labelColor: Theme.of(context).secondaryHeaderColor),
                )),
          ],
        ),
        body: RefreshIndicator(
            onRefresh: _con.refreshRestaurant,
            child: _con.restaurant == null
                ? Center(
                    child: SpinKitThreeBounce(
                      color: config.Colors().mainColor(1),
                      size: 28,
                    ),
                  ) //CircularLoadingWidget(height: 500)
                : NotificationListener<ScrollNotification>(
                    onNotification: (scrollNotification) {
                      if (isStartScroll == 1) {
                        if (scrollNotification is ScrollStartNotification) {
                        } else if (scrollNotification
                            is ScrollUpdateNotification) {
                        } else if (scrollNotification
                            is ScrollEndNotification) {
                          if (oldItemSelectIndex != itemSelectIndex) {
                            oldItemSelectIndex = itemSelectIndex;
                            _con.categoriesTabList.forEach(
                                (element) => element.isSelected = false);
                            setState(() {
                              _con.categoriesTabList
                                  .elementAt(itemSelectIndex)
                                  .isSelected = true;
                            });
                          }
                          if (isStartScroll == 1) {
                            isStartScroll = 3;
                          }
                        }
                      }
                      return true;
                    },
                    child: SingleChildScrollView(
                      controller: _sController,
                      physics: ClampingScrollPhysics(),
                      // padding: EdgeInsets.symmetric(vertical: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          Container(
                            key: detailImageKey,
                            height: 250,
                            width: MediaQuery.of(context).size.width,
                            child: Hero(
                              tag: widget.routeArgument.heroTag! +
                                  _con.restaurant.id,
                              child: _con.restaurant.video.isNotEmpty &&
                                      _con.videoPlayerController != null
                                  ? VideoPlayer(_con.videoPlayerController!) /*AspectRatio(
                                      child: CachedVideoPlayer(
                                          _con.videoController),
                                      aspectRatio: _con.videoPlayerController
                                          .value.aspectRatio,
                                    )*/
                                  : CachedNetworkImage(
                                      fit: BoxFit.cover,
                                      imageUrl: _con.restaurant.image.url,
                                      placeholder: (context, url) =>
                                          Image.asset(
                                        'assets/img/loading.gif',
                                        fit: BoxFit.cover,
                                      ),
                                      errorWidget: (context, url, error) =>
                                          Icon(Icons.error),
                                    ),
                            ),
                          ),
                          Padding(
                            key: detailNameSectionKey,
                            padding: const EdgeInsets.only(
                                right: 20, left: 20, bottom: 10, top: 25),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Expanded(
                                    child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    ScaleTransition(
                                        alignment: Alignment.topRight,
                                        scale: _selectedTween.animate(
                                            CurvedAnimation(
                                                parent: _controller,
                                                curve: Curves.easeOut)),
                                        child: Text(
                                          _con.restaurant.name,
                                          textDirection: TextDirection.rtl,
                                          overflow: TextOverflow.fade,
                                          softWrap: false,
                                          maxLines: 2,
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline3!
                                              .merge(TextStyle(fontSize: 26)),
                                        )),
                                    if (_con.restaurant.disableCreditCard)
                                      SizedBox(
                                        height: 5,
                                      ),
                                    _con.restaurant.minOrderPrice > 0
                                        ? Row(
                                            children: <Widget>[
                                              Text(
                                                S.of(context).min_order,
                                                overflow: TextOverflow.fade,
                                                softWrap: false,
                                                maxLines: 2,
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .headline5,
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Helper.getPrice(
                                                  _con.restaurant.minOrderPrice,
                                                  context),
                                            ],
                                          )
                                        : Container(),
                                  ],
                                )),
                                SizedBox(
                                  height: 32,
                                  child: Chip(
                                    padding: EdgeInsets.all(0),
                                    label: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(_con.restaurant.rate,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1!
                                                .merge(TextStyle(
                                                    color: Theme.of(context)
                                                        .primaryColor))),
                                        Icon(
                                          Icons.star_border,
                                          color: Theme.of(context).primaryColor,
                                          size: 16,
                                        ),
                                      ],
                                    ),
                                    backgroundColor: Theme.of(context)
                                        .secondaryHeaderColor
                                        .withOpacity(0.9),
                                    shape: StadiumBorder(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            key: detailBusyModeSectionKey,
                            children: <Widget>[
                              SizedBox(width: 20),
                              if (_con.restaurant.busyMode)
                                Container(
                                    margin: EdgeInsets.only(left: 10),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 3),
                                    decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius:
                                            BorderRadius.circular(24)),
                                    child: Text(S.of(context).busy,
                                        style: Theme.of(context)
                                            .textTheme
                                            .caption!
                                            .merge(
                                              TextStyle(color: Colors.white),
                                            ))),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 3),
                                decoration: BoxDecoration(
                                    color: !_con.isOpeningRestaurantStatus
                                        ? Colors.grey
                                        : Colors.green,
                                    borderRadius: BorderRadius.circular(24)),
                                child: !_con.isOpeningRestaurantStatus
                                    ? Text(
                                        S.of(context).closed,
                                        style: Theme.of(context)
                                            .textTheme
                                            .caption!
                                            .merge(TextStyle(
                                                color: Theme.of(context)
                                                    .primaryColor)),
                                      )
                                    : Text(
                                        S.of(context).open,
                                        style: Theme.of(context)
                                            .textTheme
                                            .caption!
                                            .merge(TextStyle(
                                                color: Theme.of(context)
                                                    .primaryColor)),
                                      ),
                              ),
                              SizedBox(width: 10),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 3),
                                decoration: BoxDecoration(
                                    color: _con.isDeliveryTime &&
                                            _con.isOpeningRestaurantStatus
                                        ? Colors.green
                                        : Colors.grey,
                                    borderRadius: BorderRadius.circular(24)),
                                child: Text(
                                  _con.isDeliveryTime &&
                                          _con.isOpeningRestaurantStatus
                                      ? S.of(context).openForDeliveries
                                      : S.of(context).closedForDeliveries,
                                  // S.of(context).delivery,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption!
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                ),
                              ),
                            ],
                          ),
                          if (_con.restaurant.disableCreditCard)
                            Column(
                              key: detailCreditCardKey,
                              children: [
                                SizedBox(
                                  height: 5,
                                ),
                                Container(
                                  margin: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 3),
                                  decoration: BoxDecoration(
                                      color: config.Colors().mainColor(1),
                                      borderRadius: BorderRadius.circular(24)),
                                  child: Text(
                                    S.of(context).cash_only,
                                    style: Theme.of(context)
                                        .textTheme
                                        .caption!
                                        .merge(TextStyle(
                                            color: Theme.of(context)
                                                .primaryColor)),
                                  ),
                                ),
                              ],
                            ),
                          if (_con.restaurant.freeShipping)
                            Container(
                                key: detailFreeShippingKey,
                                margin: EdgeInsets.only(right: 20, top: 20),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 3),
                                decoration: BoxDecoration(
                                    color: Colors.red,
                                    borderRadius: BorderRadius.circular(24)),
                                child: Text('משלוח חינם',
                                    style: Theme.of(context)
                                        .textTheme
                                        .caption!
                                        .merge(
                                          TextStyle(color: Colors.white),
                                        ))),
                          InkWell(
                            onTap: () {
                              setState(() {
                                isExpandedInfo = !isExpandedInfo;

                                if (isExpandedInfo) {
                                  expandController.forward();
                                } else {
                                  expandController.reverse();
                                }
                              });
                            },
                            child: Padding(
                                key: expandInfoTitleKey,
                                padding: EdgeInsets.only(
                                    left: 20, right: 20, top: 20),
                                child: ListTile(
                                  dense: true,
                                  contentPadding:
                                      EdgeInsets.symmetric(vertical: 0),
                                  leading: Icon(
                                    isExpandedInfo
                                        ? Icons.keyboard_arrow_up
                                        : Icons.keyboard_arrow_down,
                                    color: Theme.of(context).hintColor,
                                    size: 40,
                                  ),
                                  title: Text(
                                    S.of(context).details,
                                    style:
                                        Theme.of(context).textTheme.headline4,
                                  ),
                                )),
                          ),
                          SizeTransition(
                              axisAlignment: 1.0,
                              sizeFactor: animation,
                              child: Column(
                                key: expandInfoKey,
                                children: [
                                  if(_con.restaurant.description.isNotEmpty && _con.restaurant.description != '<p><br><\/p>')Padding(
                                    key: detailDescriptionKey,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 10),
                                    child: Helper.applyHtml(context, _con.restaurant.description,
                                        style: TextStyle(fontSize: 20))/*Html(data: _con.restaurant.description)*/,
                                  ),
                                  ImageThumbCarouselWidget(
                                      key: detailGalleriesKey,
                                      galleriesList: _con.galleries),
                                  Container(
                                    key: detailAddressKey,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 20),
                                    margin:
                                        const EdgeInsets.symmetric(vertical: 5),
                                    color: Theme.of(context).primaryColor,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            _con.restaurant.address,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1,
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        SizedBox(
                                          width: 42,
                                          height: 42,
                                          child: _con.isLoadingCurrentLocation
                                              ? CircularLoadingWidget(
                                                  height: 30,
                                                )
                                              : FlatButton(
                                                  padding: EdgeInsets.all(0),
                                                  onPressed: () {
                                                    //Navigator.of(context).pushNamed('/Pages', arguments: new RouteArgument(id: '1', param: _con.restaurant));
                                                    //checkLocationPermission();
                                                    _con.openMapsSheet(
                                                        context,
                                                        double.parse(_con
                                                            .restaurant
                                                            .latitude),
                                                        double.parse(_con
                                                            .restaurant
                                                            .longitude),
                                                        _con.restaurant.name);
                                                  },
                                                  child: Icon(
                                                    Icons.directions,
                                                    color: Theme.of(context)
                                                        .primaryColor,
                                                    size: 24,
                                                  ),
                                                  color: Theme.of(context)
                                                      .secondaryHeaderColor
                                                      .withOpacity(0.9),
                                                  shape: StadiumBorder(),
                                                ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    key: detailPhoneKey,
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 20),
                                    margin:
                                        const EdgeInsets.symmetric(vertical: 5),
                                    color: Theme.of(context).primaryColor,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          child: Text(
                                            '${_con.restaurant.phone} \n${_con.restaurant.mobile}',
                                            overflow: TextOverflow.ellipsis,
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodyText1,
                                          ),
                                        ),
                                        SizedBox(width: 10),
                                        SizedBox(
                                          width: 42,
                                          height: 42,
                                          child: FlatButton(
                                            padding: EdgeInsets.all(0),
                                            onPressed: () {
                                              launch(
                                                  "tel:${_con.restaurant.mobile}");
                                            },
                                            child: Icon(
                                              Icons.call,
                                              color: Theme.of(context)
                                                  .primaryColor,
                                              size: 24,
                                            ),
                                            color: Theme.of(context)
                                                .secondaryHeaderColor
                                                .withOpacity(0.9),
                                            shape: StadiumBorder(),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              )),
                          _con.featuredFoods.isEmpty
//                                  ? SizedBox(height: 0)
                              ? _con.isFeaturedFoods
                                  ? CircularLoadingWidget(
                                      height: 50,
                                    )
                                  : Container()
                              : Padding(
                                  key: featuredFoodsTitleKey,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 20),
                                  child: ListTile(
                                    dense: true,
                                    contentPadding:
                                        EdgeInsets.symmetric(vertical: 0),
                                    leading: Icon(
                                      Icons.restaurant,
                                      color: Theme.of(context).hintColor,
                                    ),
                                    title: Text(
                                      S.of(context).featured_foods,
                                      style:
                                          Theme.of(context).textTheme.headline4,
                                    ),
                                  ),
                                ),
                          _con.featuredFoods.isEmpty
                              ? SizedBox(height: 0)
                              : ListView.separated(
                                  key: featuredFoodsListKey,
                                  padding: EdgeInsets.symmetric(vertical: 10),
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  primary: false,
                                  itemCount: _con.featuredFoods.length,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10);
                                  },
                                  itemBuilder: (context, index) {
                                    return FoodItemWidget(
                                      heroTag: 'details_featured_food',
                                      food: _con.featuredFoods.elementAt(index),
                                      isForCategories: false,
                                    );
                                  },
                                ),
                          Padding(
                            key: categoriesWithFoodsTitleKey,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            child: ListTile(
                              dense: true,
                              contentPadding: EdgeInsets.symmetric(vertical: 0),
                              leading: Icon(
                                Icons.category,
                                color: Theme.of(context).hintColor,
                              ),
                              title: Text(
                                S.of(context).all_menu,
                                key: menuKey,
                                style: Theme.of(context).textTheme.headline4,
                              ),
                            ),
                          ),
                          if (_con.categoriesWithFoods.isNotEmpty)
                            SizedBox(key: sizeBox1Key, height: 10),
                          if (_con.isLoadedAllMenuLoading)
                            _con.categoriesWithFoods.isEmpty
                                ? CircularLoadingWidget(height: 50)
                                : StickyHeader(
                                    key: stickyHeaderKey,
                                    callback: (value) {
                                      stickyValue = value;
                                    },
                                    header: Container(
                                      key: tabKey,
                                      color: tabColor,
                                      height: 60,
                                      child: Align(
                                        alignment: Alignment.centerRight,
                                        child: SingleChildScrollView(
                                            controller: _sTabController,
                                            scrollDirection: Axis.horizontal,
                                            physics: ClampingScrollPhysics(),
                                            child: ListView(
                                              primary: false,
                                              shrinkWrap: true,
                                              scrollDirection: Axis.horizontal,
                                              children: List.generate(
                                                  _con.categoriesWithFoods
                                                      .length, (index) {
                                                return Container(
                                                  key: _con.categoriesWithFoods
                                                      .elementAt(index)
                                                      .tabKey,
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsetsDirectional
                                                                .only(
                                                            start: 10, end: 10),
                                                    child: RawChip(
                                                      elevation: 0,
                                                      label: Text(_con
                                                          .categoriesTabList
                                                          .elementAt(index)
                                                          .name),
                                                      labelStyle: _con
                                                              .categoriesTabList
                                                              .elementAt(index)
                                                              .isSelected
                                                          ? Theme.of(context)
                                                              .textTheme
                                                              .bodyText2!
                                                              .merge(TextStyle(
                                                                  color: Theme.of(
                                                                          context)
                                                                      .primaryColor))
                                                          : Theme.of(context)
                                                              .textTheme
                                                              .bodyText2!
                                                              .merge(TextStyle(
                                                                  color: Theme.of(
                                                                          context)
                                                                      .primaryColor)),
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 10,
                                                              vertical: 10),
                                                      backgroundColor:
                                                          Theme.of(context)
                                                              .hintColor,
                                                      selectedColor:
                                                          Theme.of(context)
                                                              .secondaryHeaderColor,
                                                      selected: _con
                                                          .categoriesTabList
                                                          .elementAt(index)
                                                          .isSelected,
                                                      showCheckmark: false,
                                                      onSelected: (bool value) {
                                                        isTabClick = true;
                                                        _con.categoriesTabList
                                                            .forEach((element) =>
                                                                element.isSelected =
                                                                    false);
                                                        setState(() {
                                                          _con.categoriesTabList
                                                                  .elementAt(index)
                                                                  .isSelected =
                                                              !_con
                                                                  .categoriesTabList
                                                                  .elementAt(
                                                                      index)
                                                                  .isSelected;
                                                          Future.delayed(
                                                              const Duration(
                                                                  milliseconds:
                                                                      100), () {
                                                            _sController
                                                                .animateTo(
                                                                    isExpandedInfo
                                                                        ? offsetList[
                                                                            index]
                                                                        : offsetList[index] -
                                                                            expandedInfoOffset,
                                                                    duration: const Duration(
                                                                        milliseconds:
                                                                            500),
                                                                    curve: Curves
                                                                        .easeOut)
                                                                .then((value) {
                                                              isTabClick =
                                                                  false;
                                                            });
                                                          });
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                );
                                              }),
                                            )),
                                      ),
                                    ),
                                    content: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 30),
                                      child: ListView.separated(
                                        key: ObjectKey(
                                            '${Random().nextInt(10000)}'),
                                        scrollDirection: Axis.vertical,
                                        shrinkWrap: true,
                                        primary: false,
                                        itemCount:
                                            _con.categoriesWithFoods.length,
                                        separatorBuilder: (context, index) {
                                          return SizedBox(height: 10);
                                        },
                                        itemBuilder: (context, index) {
                                          return CategoriesFoodItemWidget(
                                            heroTag: 'menu_list',
                                            categoryWithFoods: _con
                                                .categoriesWithFoods
                                                .elementAt(index),
                                            index: index,
                                          );
                                        },
                                      ),
                                    ),
                                  ),
                          if (!_con.isLoadedAllMenuLoading)
                            StickyHeader(
                              key: stickyHeaderKey,
                              callback: (value) {
                                stickyValue = value;
                              },
                              header: Container(
                                key: tabKey,
                                color: tabColor,
                                height: 60,
                                child: Align(
                                  alignment: Alignment.centerRight,
                                  child: SingleChildScrollView(
                                      controller: _sTabController,
                                      scrollDirection: Axis.horizontal,
                                      physics: ClampingScrollPhysics(),
                                      child: Shimmer.fromColors(
                                          baseColor: Colors.grey[300]!,
                                          highlightColor: Colors.grey[100]!,
                                          enabled: true,
                                          child: ListView.builder(
                                            scrollDirection: Axis.horizontal,
                                            shrinkWrap: true,
                                            primary: false,
                                            itemBuilder: (_, __) => Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .only(start: 10, end: 10),
                                              child: RawChip(
                                                elevation: 0,
                                                label: Text('          '),
                                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                backgroundColor: Colors.white,
                                                showCheckmark: false,
                                              ),
                                            ),
                                            itemCount: 6,
                                          ))),
                                ),
                              ),
                              content: Padding(
                                padding: const EdgeInsets.only(bottom: 30),
                                child: ListView.separated(
                                  key: ObjectKey('${Random().nextInt(10000)}'),
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  primary: false,
                                  itemCount: 1,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10);
                                  },
                                  itemBuilder: (context, index) {
                                    return Shimmer.fromColors(
                                        baseColor: Colors.grey[300]!,
                                        highlightColor: Colors.grey[100]!,
                                        enabled: true,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: <Widget>[
                                            SizedBox(height: 25),
                                            /*Padding(
                                                padding: EdgeInsets.only(left: 20, right: 20),
                                                child: Text(S.of(context).test,style: Theme.of(context)
                                                    .textTheme
                                                    .headline4!
                                                    .merge(TextStyle(fontSize: 32,color: Colors.white)),
                                                )),
                                            SizedBox(height: 20),*/
                                            ListView.separated(
                                              scrollDirection: Axis.vertical,
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: 2,
                                              separatorBuilder: (context, index) {
                                                return SizedBox(height: 10);
                                              },
                                              itemBuilder: (context, index) {
                                                return Container(
                                                  height: 100,
                                                  padding: EdgeInsets.symmetric(horizontal: 25, vertical: 10),
                                                  decoration: BoxDecoration(
                                                    color: Theme.of(context).primaryColor.withOpacity(0.9),
                                                    boxShadow: [
                                                      BoxShadow(
                                                          color: Theme.of(context).focusColor.withOpacity(0.1),
                                                          blurRadius: 5,
                                                          offset: Offset(0, 2)),
                                                    ],
                                                  ),
                                                  child: Row(
                                                    mainAxisAlignment: MainAxisAlignment.end,
                                                    mainAxisSize: MainAxisSize.max,
                                                    children: <Widget>[
                                                      Flexible(
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: <Widget>[
                                                            Row(
                                                              mainAxisSize: MainAxisSize.max,
                                                              children: [
                                                                Flexible(
                                                                  child: Container(),
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(height: 10),
                                                          ],
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                );
                                              },
                                            ),

                                          ],
                                        )
                                    );
                                  },
                                ),
                              ),
                            )
                        ],
                      ),
                    ))));
  }

  @override
  void dispose() {
    _con.videoPlayerController = null;
    _con.videoPlayerController?.dispose();
    super.dispose();
  }
}
