import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/controllers/restaurants_with_cuisines_controller.dart';
import 'package:food_delivery_app/src/elements/RestaurantsWithCuisinesItemWidget.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../../generated/l10n.dart';
import '../elements/CircularLoadingWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class RestaurantsWithCuisines extends StatefulWidget {
  @override
  RestaurantsWithCuisinesState createState() => RestaurantsWithCuisinesState();
  final RouteArgument routeArgument;

  RestaurantsWithCuisines({Key? key,
    required this.routeArgument}) : super(key: key);
}

class RestaurantsWithCuisinesState extends StateMVC<RestaurantsWithCuisines> {
  late RestaurantsWithCuisinesController _con;

  RestaurantsWithCuisinesState() : super(RestaurantsWithCuisinesController()) {
    _con = controller as RestaurantsWithCuisinesController;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      //drawer: DrawerWidget(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: ValueListenableBuilder(
          valueListenable: settingsRepo.setting,
          builder: (context, value, child) {
            return Text(
              settingsRepo.setting.value.appName.isNotEmpty ? settingsRepo.setting.value.appName : S.of(context).res_categories_title,
              style: Theme.of(context)
                  .textTheme
                  .headline6!
                  .merge(TextStyle(letterSpacing: 1.3)),
            );
          },
        )/*Text(
          S.of(context).res_categories_title,
          overflow: TextOverflow.fade,
          softWrap: false,
          style: Theme.of(context).textTheme.headline6.merge(TextStyle(letterSpacing: 0)),
        )*/,
        actions: <Widget>[
          new ShoppingCartButtonWidget(iconColor: Theme.of(context).hintColor, labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            /*Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SearchBarWidget(),
            ),*/
           /* Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ListTile(
                dense: true,
                contentPadding: EdgeInsets.symmetric(vertical: 0),
                leading: Icon(
                  Icons.category,
                  color: Theme.of(context).hintColor,
                ),
                title: Text(
//                  S.of(context).food_categories,
                  S.of(context).all_menu,
                  style: Theme.of(context).textTheme.display1,
                ),
              ),
            ),*/
            SizedBox(height: 10),
            _con.isLoading ? CircularLoadingWidget(height: 150) :  ListView.separated(
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              primary: false,
              itemCount: _con.restaurantsWithCuisines.length,
              separatorBuilder: (context, index) {
                return SizedBox(height: 10);
              },
              itemBuilder: (context, index) {
                return RestaurantsWithCuisinesItemWidget(
                  heroTag: 'restaurantsWithCuisines',
                  cuisine: _con.restaurantsWithCuisines.elementAt(index),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
