import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/controllers/restaurants_by_cuisine_controller.dart';
import 'package:food_delivery_app/src/elements/CardWidget.dart';
import 'package:food_delivery_app/src/elements/GridWidgetRestaurantCuisines.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../elements/CircularLoadingWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class RestaurantsByCuisine extends StatefulWidget {
  RestaurantsByCuisine({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  RestaurantsByCuisineState createState() => RestaurantsByCuisineState();
  final RouteArgument routeArgument;
}

class RestaurantsByCuisineState extends StateMVC<RestaurantsByCuisine> {
  late RestaurantsByCuisineController _con;

  RestaurantsByCuisineState() : super(RestaurantsByCuisineController()) {
    _con = controller as RestaurantsByCuisineController;
  }

  @override
  void initState() {
    super.initState();
    print('widget.routeArgument.id:${widget.routeArgument.id}');
    _con.listenForDeliveryTime();
    _con.listenForCuisines(widget.routeArgument.id!);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      //drawer: DrawerWidget(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: ValueListenableBuilder(
          valueListenable: settingsRepo.setting,
          builder: (context, value, child) {
            return Text(
              '${widget.routeArgument.param.toString()}',
              style: Theme.of(context)
                  .textTheme
                  .headline6!
                  .merge(TextStyle(letterSpacing: 1.3)),
            );
          },
        ),
        actions: <Widget>[
          new ShoppingCartButtonWidget(iconColor: Theme.of(context).hintColor, labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            SizedBox(height: 10),
            _con.isLoading ? CircularLoadingWidget(height: 150) :
            Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child:
                ListView.builder(
                  shrinkWrap: true,
                  primary: false,
                  physics: NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  itemCount: _con.cuisine.restaurants.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.of(context).pushNamed('/Details',
                            arguments: RouteArgument(
                              id: _con.cuisine.restaurants.elementAt(index).id,
                              heroTag: 'grid_by_restaurant_cuisines_tag',
                            ));
                      },
                      child: CardWidget(
                        restaurant: _con.cuisine.restaurants.elementAt(index),
                        heroTag: 'grid_by_restaurant_cuisines_tag',
                        isForAppMapDirection: false,
                        onDirectionPress: () {

                        },
                        isDeliveryTime: _con.isDeliveryTime,
                      ),
                    );
                  },
                )
              /*GridWidgetRestaurantCuisines(
                  heroTag: 'grid_by_restaurant_cuisines_tag',
                  restaurantsList: _con.cuisine.restaurants,
                )*/
            ),
          ],
        ),
      ),
    );
  }
}
