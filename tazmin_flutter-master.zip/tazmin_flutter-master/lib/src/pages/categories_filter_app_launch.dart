import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:food_delivery_app/src/controllers/filter_category_controller.dart';
import 'package:food_delivery_app/src/elements/CuisinesGridItemWidget.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;
import 'package:mvc_pattern/mvc_pattern.dart';
import '../../generated/l10n.dart';
import '../models/filter.dart';

class CategoriesFilterAppLaunch extends StatefulWidget {
  final ValueChanged<Filter>? onFilter;

  CategoriesFilterAppLaunch({
    Key? key,
     this.onFilter}) : super(key: key);

  @override
  CategoriesFilterAppLaunchState createState() =>
      CategoriesFilterAppLaunchState();
}

class CategoriesFilterAppLaunchState
    extends StateMVC<CategoriesFilterAppLaunch> {
  FilterCategoryController? _con;

  CategoriesFilterAppLaunchState() : super(FilterCategoryController()) {
    _con = controller as FilterCategoryController?;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
            backgroundColor: config.Colors().mainColor(1),
            body: _con!.isLoading
                ? Center(
                    child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                        Theme.of(context).scaffoldBackgroundColor),
                  ))
                : Center(
                    child: Container(
                    height: MediaQuery.of(context).size.height / 1.5,
                    decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 50,
                            color: Theme.of(context).hintColor.withOpacity(0.2),
                          )
                        ]),
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.all(10),
                    width: config.App(context).appWidth(88),
//              height: config.App(context).appHeight(55),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text(
                          S.of(context).res_categories_title,
                          style: Theme.of(context).textTheme.headline4!.merge(
                              TextStyle(
                                  fontSize: 24,
                                  color: config.Colors().mainColor(1))),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Expanded(
//                            child: SingleChildScrollViewWithScrollbar(
                                child: GridView.count(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  primary: false,
                                  crossAxisSpacing: 10,
                                  mainAxisSpacing: 10,
                                  padding: EdgeInsets.symmetric(horizontal: 5),
                                  crossAxisCount: 3,
                                  childAspectRatio: 1/1.6,
                                  //rows
                                  children: List.generate(_con!.cuisines.length, (index) {
                                    return CuisinesGridItemWidget(
                                      heroTag: 'cat_filter_list',
                                      cuisine: _con!.cuisines.elementAt(index),
                                      onPressed: (){
                                        _con!.onChangeCuisinesFilter(index);
                                      },
                                    );
                                  }),
                                )/*ListView.separated(
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  primary: false,
                                  itemCount: _con.cuisines.length,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(height: 10);
                                  },
                                  itemBuilder: (context, index) {
                                    return CategoriesFilterListItem(
                                      heroTag: 'cat_filter_list',
                                      cuisine: _con.cuisines.elementAt(index),
                                      position: index,
                                      onPressed: () {
                                        _con.onChangeCuisinesFilter(index);
                                      },
                                    );
                                  },
                                )*/
//                            )
                        ),
                        SizedBox(height: 5,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(width: 20),
                            Text(
                              S.of(context).all,
                              style: Theme.of(context).textTheme.headline4!.merge(
                                  TextStyle(
                                      fontSize: 22,
                                      color: config.Colors().mainColor(1))),
                            ),
                            Checkbox(
                              value: _con!.isSelected,
                              onChanged: (bool? selected) {
                                _con?.onChangedAll();
                              },
                            )
                          ],
                        ),
                        SizedBox(height: 5),
                        FlatButton(
                          onPressed: () {
                            _con!.saveFilter().whenComplete(() {
                              //widget.onFilter(_con.filter);
                              Navigator.of(context)
                                  .pushReplacementNamed('/Pages', arguments: 2);
                            });
                          },
                          padding: EdgeInsets.all(10),
                          color: Theme.of(context).secondaryHeaderColor,
                          shape: StadiumBorder(),
                          child: Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          /*Text(
                        S.of(context).apply_filters,
                        textAlign: TextAlign.start,
                        style: TextStyle(color: Theme.of(context).primaryColor),
                      ),*/
                        ),
                        SizedBox(height: 5)
                      ],
                    ),
                  )));
  }
}
