import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/controllers/restaurant_controller.dart';
import 'package:food_delivery_app/src/elements/GridWidgetRestaurantCuisines.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../../generated/l10n.dart';
import '../elements/CircularLoadingWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class AllRestaurants extends StatefulWidget {

  @override
  AllRestaurantsState createState() => AllRestaurantsState();
  final RouteArgument? routeArgument;

  AllRestaurants({Key? key,
     this.routeArgument}) : super(key: key);
}

class AllRestaurantsState extends StateMVC<AllRestaurants> {
  RestaurantController? _con;

  AllRestaurantsState() : super(RestaurantController()) {
    _con = controller as RestaurantController;
  }

  @override
  void initState() {
    super.initState();
    _con?.listenForAllRestaurant();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con?.scaffoldKey,
      //drawer: DrawerWidget(),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: ValueListenableBuilder(
          valueListenable: settingsRepo.setting,
          builder: (context, value, child) {
            return Text(
              settingsRepo.setting.value.appName.isNotEmpty ? settingsRepo.setting.value.appName : S.of(context).res_categories_title,
              style: Theme.of(context)
                  .textTheme
                  .headline6!
                  .merge(TextStyle(letterSpacing: 1.3)),
            );
          },
        )/*Text(
          S.of(context).res_categories_title,
          overflow: TextOverflow.fade,
          softWrap: false,
          style: Theme.of(context).textTheme.headline6.merge(TextStyle(letterSpacing: 0)),
        )*/,
        actions: <Widget>[
          new ShoppingCartButtonWidget(iconColor: Theme.of(context).hintColor, labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
        child:_con!.isLoading ? CircularLoadingWidget(height: 150) :GridWidgetRestaurantCuisines(
          heroTag: 'grid_widget_restaurant_cuisines_tag',
          restaurantsList: _con!.allRestaurant, onDirectionPress: () {  }, isForAppMapDirection:false,
          ),
      ),
    );
  }
}
