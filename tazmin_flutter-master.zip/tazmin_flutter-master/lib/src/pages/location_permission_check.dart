import 'dart:io';

import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/addresses.dart';
import 'package:geolocator/geolocator.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import '../helpers/app_config.dart' as config;
import 'package:food_delivery_app/src/repository/settings_repository.dart' as settingRepo;

class LocationPermissionCheck extends StatefulWidget {
  ValueNotifier<Addresses> deliveryAddress = new ValueNotifier(new Addresses());

  @override
  _LocationPermissionCheckState createState() =>
      _LocationPermissionCheckState();
}

class _LocationPermissionCheckState extends State<LocationPermissionCheck> {
  late BuildContext locationPermissionContext;

  @override
  Widget build(BuildContext context) {
    locationPermissionContext = context;
    return Scaffold(
        body: Container(
            height: MediaQuery.of(context).size.height + 150,
            child: Stack(
              alignment: AlignmentDirectional.topCenter,
              children: <Widget>[
                Positioned(
                  top: 0,
                  child: Stack(
                    children: [
                      Container(
                        width: config.App(context).appWidth(100),
                        height: config.App(context).appHeight(40),
                        decoration:
                            BoxDecoration(color: Theme.of(context).secondaryHeaderColor),
                      ),
                      Container(
                        width: config.App(context).appWidth(100),
                        height: config.App(context).appHeight(40),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.location_on,
                              color: Colors.white,
                              size: 80,
                            ),
                            Text(
                              S.of(context).location_permission_title,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: config.App(context).appHeight(40) - 50,
                  child: Container(
                    decoration: BoxDecoration(
                        color: Theme.of(context).primaryColor,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 50,
                            color: Theme.of(context).hintColor.withOpacity(0.2),
                          )
                        ]),
                    margin: EdgeInsets.symmetric(
                      horizontal: 20,
                    ),
                    padding: EdgeInsets.symmetric(vertical: 30, horizontal: 27),
                    width: config.App(context).appWidth(88),
//              height: config.App(context).appHeight(55),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Container(
                              alignment: Alignment.center,
                              child:
                                Text(Helper.skipHtml(
                                    settingRepo.setting.value.description),textAlign: TextAlign.center,),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                setState(() {
                                  settingRepo.setDeliveryOption(true);
                                  checkLocationPermission();
                                });
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 10),
                                decoration: BoxDecoration(
                                    color: config.Colors().mainColor(1),
                                    borderRadius: BorderRadius.circular(30)),
                                child: Text(
                                  // 'Delivery',
                                  S.of(context).delivery,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline4!
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            InkWell(
                              onTap: () {
                                settingRepo.setDeliveryOption(false);
                                if (Platform.isAndroid) {
                                  Navigator.of(context).pushReplacementNamed(
                                      '/PagesWithAnimation',
                                      arguments: 2);
                                } else if (Platform.isIOS) {
                                  Navigator.of(context).pushReplacementNamed(
                                      '/Pages',
                                      arguments: 2);
                                }
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 10),
                                decoration: BoxDecoration(
                                    color: config.Colors().mainColor(1),
                                    borderRadius: BorderRadius.circular(30)),
                                child: Text(
                                  S.of(context).pickup_btn,
                                  // S.of(context).pickup,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline4!
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )));
  }

  void checkLocationPermission() async {
    var geolocationStatus =
        await Geolocator.checkPermission();
   // await Geolocator().checkGeolocationPermissionStatus();
    print('geolocationStatus.value:${geolocationStatus}');
    if (geolocationStatus != LocationPermission.whileInUse) {
      requestLocationPermission();
    } else {
      var serviceStatus = await Geolocator.checkPermission();
      //await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      } else {
        locationEnableAlert();
      }
    }
  }

  Future<bool> requestLocationPermission() async {
    return _requestPermission();
  }

  void getCurrentLocation() {
    print('getCurrentLocation');
    Geolocator
        .getLastKnownPosition(forceAndroidLocationManager: true,)
        .then((position) async {
      if (position != null) {
        // deliveryAddress.value.latitude = position.latitude;
        // deliveryAddress.value.longitude = position.longitude;
        if (Platform.isAndroid) {
          Navigator.of(context)
              .pushReplacementNamed('/PagesWithAnimation', arguments: 2);
        } else if (Platform.isIOS) {
          Navigator.of(context).pushReplacementNamed('/Pages', arguments: 2);
        }
      } else {
        if (Platform.isAndroid) {
          Navigator.of(context)
              .pushReplacementNamed('/PagesWithAnimation', arguments: 2);
        } else if (Platform.isIOS) {
          Navigator.of(context).pushReplacementNamed('/Pages', arguments: 2);
        }
        print('last position null');
        Geolocator
            .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
            .then((position) async {
          if (position != null) {
            // deliveryAddress.value.latitude = position.latitude;
            // deliveryAddress.value.longitude = position.longitude;
          }
        });
      }
    });
  }

  Future<bool> _requestPermission() async {
    print('_requestPermission');
    var result = await Geolocator.requestPermission();
    //var result = await LocationPermissions().requestPermissions();
    if (result == LocationPermission.whileInUse) {
      var serviceStatus = await Geolocator.checkPermission();
      // await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      var serviceStatus = await Geolocator.checkPermission();
      // LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        locationEnableAlert();
        print('locationEnableAlert()');
      } else {
        Alert(
          context: context,
          type: AlertType.warning,
          title: S.of(context).alert_location_service_permission_title,
          desc: S.of(context).alert_location_service_permission_message,
          style: AlertStyle(
              titleStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 18)),
              descStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 16))),
          buttons: [
            DialogButton(
              child: Text(
                S.of(context).alert_location_service_btn,
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
              onPressed: () {
                Navigator.pop(context);
                //LocationPermissions().openAppSettings();
                Geolocator.openAppSettings();
              },
            )
          ],
        ).show();
      }
    }
    return false;
  }

  void locationEnableAlert() {
    Alert(
      context: context,
      type: AlertType.warning,
      title: S.of(context).alert_location_service_title,
      desc: S.of(context).alert_location_service_message,
      style: AlertStyle(
          titleStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(context).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(context);
            //LocationPermissions().openAppSettings();
            Geolocator.openLocationSettings();
          },
        )
      ],
    ).show();
  }
}
