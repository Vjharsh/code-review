import 'package:flutter/material.dart';
import 'package:flutter_broadcast_receiver/flutter_broadcast_receiver.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/controllers/cart_controller.dart';
import 'package:food_delivery_app/src/pages/cart.dart';
import 'package:food_delivery_app/src/pages/profile.dart';
import 'package:food_delivery_app/src/repository/user_repository.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../elements/DrawerWidget.dart';
import '../models/route_argument.dart';
import '../pages/favorites.dart';
import '../pages/home.dart';
import '../pages/orders.dart';
import '../repository/settings_repository.dart' as settingsRepo;
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;
import 'package:food_delivery_app/main.dart';

// ignore: must_be_immutable
class PagesWidget extends StatefulWidget {
  dynamic currentTab;
  late RouteArgument routeArgument;
  Widget currentPage = Container();
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  PagesWidgetState pagesWidgetState = PagesWidgetState();

  PagesWidget({
    Key? key,
    this.currentTab,
  }) {
    MyApp.pagesWidget = this;
    if (currentTab != null) {
      if (currentTab is RouteArgument) {
        routeArgument = currentTab;
        currentTab = int.parse(currentTab.id);
      }
    } else {
      currentTab = 2;
    }
  }

  void refreshCartCount() {
    pagesWidgetState.refreshCartCountAPI();
  }

  @override
  PagesWidgetState createState() {
    pagesWidgetState = new PagesWidgetState();
    return pagesWidgetState;
  }
}

class PagesWidgetState extends StateMVC<PagesWidget>
    with WidgetsBindingObserver {
  late CartController _con;

  PagesWidgetState() : super(CartController()) {
    _con = controller as CartController;
  }

  @override
  initState() {
    super.initState();
    WidgetsBinding.instance?.addObserver(this);
    settingsRepo.animationLooper.value = 0;
    _selectTab(widget.currentTab);
    _con.listenForCartsCount();
    /*FBroadcast.instance().register('cart_count', (value, __) {
      setState(() {
        _con.cartCount = value;
      });
    }, context: this);*/
    BroadcastReceiver().subscribe<String>('cart_count', (value) {
      setState(() {
        _con.cartCount = int.parse(value);
      });
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance?.removeObserver(this);
    super.dispose();
  }

  @override
  void didUpdateWidget(PagesWidget oldWidget) {
    print('didUpdateWidget');
    _selectTab(oldWidget.currentTab);
    super.didUpdateWidget(oldWidget);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print('didChangeAppLifecycleState:$state');
    if (state == AppLifecycleState.resumed) {
      _con.listenForCartsCount();
      /*FBroadcast.instance().register('cart_count', (value, __) {
        setState(() {
          _con.cartCount = value;
        });
      }, context: this);*/
      BroadcastReceiver().subscribe<String>('cart_count', (value) {
        setState(() {
          _con.cartCount = int.parse(value);
        });
      });
      //do your stuff
    }
    super.didChangeAppLifecycleState(state);
  }

  void _selectTab(int tabItem) {
    refreshCartCountAPI();
    setState(() {
      widget.currentTab = tabItem;
      switch (tabItem) {
        case 0:
          /*widget.currentPage =
              NotificationsWidget(parentScaffoldKey: widget.scaffoldKey);*/
          if (currentUser.value.apiToken.isNotEmpty) {
            widget.currentPage = ProfileWidget();
          } else {
            Navigator.of(context).pushNamed('/Login');
          }
          break;
        case 1:
          if (currentUser.value.apiToken.isNotEmpty) {
            widget.currentPage =
                CartWidget(routeArgument: RouteArgument(id: '-1'));
          } else {
            Navigator.of(context).pushNamed('/Login');
          }
          break;
        case 2:
          widget.currentPage =
              HomeWidget(parentScaffoldKey: widget.scaffoldKey);
          // HomeWidget(parentScaffoldKey: widget.scaffoldKey);
          MyApp.homeWidget = widget.currentPage as HomeWidget?;
          break;
        case 3:
          widget.currentPage =
              OrdersWidget(parentScaffoldKey: widget.scaffoldKey);
          break;
        case 4:
          widget.currentPage =
              FavoritesWidget(parentScaffoldKey: widget.scaffoldKey);
          break;
      }
    });
  }

  void refreshCartCountAPI() {
    _con.listenForCartsCount();
    /*FBroadcast.instance().register('cart_count', (value, __) {
      setState(() {
        _con.cartCount = value;
      });
    }, context: this);*/
    BroadcastReceiver().subscribe<String>('cart_count', (value) {
      setState(() {
        _con.cartCount = int.parse(value);
      });
    });
    setState(() {
      // _con.cartCount = settingsRepo.setting.value.cartCounter;
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child:
        Scaffold(
            key: widget.scaffoldKey,
            drawer: DrawerWidget(),
            /*endDrawer: FilterWidget(onFilter: (filter) {
          Navigator.of(context)
              .pushReplacementNamed('/Pages', arguments: widget.currentTab);
        }),*/
            body: widget.currentPage,
            bottomNavigationBar: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _con.cartCount > 1 && widget.currentTab != 1
                    ? Container(
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        color: config.Colors().mainColor(1),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                                child: Text(
                                  'יש לך ${_con.cartCount} מאכלים בהזמנה',
                                  style: TextStyle(color: Colors.white),
                            )),
                            InkWell(
                              onTap: () {
                                if (currentUser.value.apiToken.isNotEmpty) {
                                  Navigator.of(context).pushNamed('/Cart',
                                      arguments: RouteArgument(
                                          param: '/Pages', id: '2'));
                                } else {
                                  Navigator.of(context).pushNamed('/Login');
                                }
                              },
                              child: Container(
                                margin: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 15),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 3),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(24)),
                                child: Text(
                                  S.of(context).checkout,
                                  style: TextStyle(
                                      color: Theme.of(context).secondaryHeaderColor),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(),
                BottomNavigationBar(
                  type: BottomNavigationBarType.fixed,
                  selectedItemColor: Theme.of(context).secondaryHeaderColor,
                  selectedFontSize: 0,
                  unselectedFontSize: 0,
                  iconSize: 22,
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  selectedIconTheme: IconThemeData(size: 28),
                  unselectedItemColor:
                      Theme.of(context).focusColor.withOpacity(1),
                  currentIndex: widget.currentTab,
                  onTap: (int i) {
                    this._selectTab(i);
                  },
                  // this will be set when a new tab is tapped
                  items: [
                    BottomNavigationBarItem(
                      icon: Icon(Icons.person,size: 25,),
                      label: '',
                    ),
                    BottomNavigationBarItem(
                      icon: Stack(
                        alignment: AlignmentDirectional.bottomEnd,
                        children: <Widget>[
                          Icon(
                            Icons.shopping_cart,
                            //color: this.widget.iconColor,
                            size: 25,
                          ),
                          Container(
                            child: Align(
                                alignment: Alignment.center,
                                child: Text(
                                  _con.cartCount.toString(),
                                  textAlign: TextAlign.center,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline2!
                                      .merge(
                                        TextStyle(
                                            color:
                                                Theme.of(context).primaryColor,
                                            fontSize: 10),
                                      ),
                                )),
                            padding: EdgeInsets.all(0),
                            decoration: BoxDecoration(
                                color: Theme.of(context).secondaryHeaderColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10))),
                            constraints: BoxConstraints(
                                minWidth: 15,
                                maxWidth: 15,
                                minHeight: 15,
                                maxHeight: 15),
                          ),
                        ],
                      ), //Icon(Icons.shopping_cart),
                      label: '',
                    ),
                    BottomNavigationBarItem(
                        label: '',
                        icon: Padding(
                          padding: const EdgeInsets.only(bottom: 5.0),
                          child: Container(
                            width: 42,
                            height: 42,
                            decoration: BoxDecoration(
                              color: Theme.of(context).secondaryHeaderColor,
                              borderRadius: BorderRadius.all(
                                Radius.circular(50),
                              ),
                              boxShadow: [
                                BoxShadow(
                                    color: Theme.of(context)
                                        .secondaryHeaderColor
                                        .withOpacity(0.4),
                                    blurRadius: 40,
                                    offset: Offset(0, 15)),
                                BoxShadow(
                                    color: Theme.of(context)
                                        .secondaryHeaderColor
                                        .withOpacity(0.4),
                                    blurRadius: 13,
                                    offset: Offset(0, 3))
                              ],
                            ),
                            child: new Icon(Icons.home,
                                color: Theme.of(context).primaryColor),
                          ),
                        )),
                    BottomNavigationBarItem(
                      icon: new Icon(Icons.fastfood),
                      label: '',
                    ),
                    BottomNavigationBarItem(
                      icon: new Icon(Icons.favorite),
                      label: '',
                    ),
                  ],
                ),
              ],
            )
            /* BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Theme.of(context).secondaryHeaderColor,
          selectedFontSize: 0,
          unselectedFontSize: 0,
          iconSize: 22,
          elevation: 0,
          backgroundColor: Colors.transparent,
          selectedIconTheme: IconThemeData(size: 28),
          unselectedItemColor: Theme.of(context).focusColor.withOpacity(1),
          currentIndex: widget.currentTab,
          onTap: (int i) {
            this._selectTab(i);
          },
          // this will be set when a new tab is tapped
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications),
              title: new Container(height: 0.0),
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.location_on),
              title: new Container(height: 0.0),
            ),
            BottomNavigationBarItem(
                title: new Container(height: 5.0),
                icon: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Theme.of(context).secondaryHeaderColor,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                          color: Theme.of(context).secondaryHeaderColor.withOpacity(0.4),
                          blurRadius: 40,
                          offset: Offset(0, 15)),
                      BoxShadow(
                          color: Theme.of(context).secondaryHeaderColor.withOpacity(0.4),
                          blurRadius: 13,
                          offset: Offset(0, 3))
                    ],
                  ),
                  child: new Icon(Icons.home,
                      color: Theme.of(context).primaryColor),
                )),
            BottomNavigationBarItem(
              icon: new Icon(Icons.fastfood),
              title: new Container(height: 0.0),
            ),
            BottomNavigationBarItem(
              icon: new Icon(Icons.favorite),
              title: new Container(height: 0.0),
            ),
          ],
        ),*/
            ),
            );
  }
}
