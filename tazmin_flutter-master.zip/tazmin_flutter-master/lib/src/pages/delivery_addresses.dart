import 'dart:async';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/maps_util.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../../generated/l10n.dart';
import '../controllers/delivery_addresses_controller.dart';
import '../elements/CircularLoadingWidget.dart';
import '../elements/DeliveryAddressDialog.dart';
import '../elements/DeliveryAddressesItemWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/addresses.dart';
import '../models/payment_method.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart';

class DeliveryAddressesWidget extends StatefulWidget {
  final RouteArgument? routeArgument;
  final String? lat;
  final String? long;


  DeliveryAddressesWidget({
    Key? key,
    this.routeArgument, this.lat, this.long}) : super(key: key);

  @override
  _DeliveryAddressesWidgetState createState() =>
      _DeliveryAddressesWidgetState();
}

class _DeliveryAddressesWidgetState extends StateMVC<DeliveryAddressesWidget> with TickerProviderStateMixin {
  late DeliveryAddressesController _con;
  late PaymentMethodList list;
  Timer? timer;

  _DeliveryAddressesWidgetState() : super(DeliveryAddressesController()) {
    _con = controller as DeliveryAddressesController;
  }

  Addresses? addresses;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _textEditingController = TextEditingController();


  @override
  void initState() {
    super.initState();
    _con.isLoadingData = true;
    timer = Timer.periodic(Duration(seconds: 5), (Timer t) => _con.getCurrentLocation());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  // void saveAddressAlert(Addresses address) {
  //   Alert(
  //     context: context,
  //     type: AlertType.info,
  //     title: S.of(context).alert_title_save_address,
  //     desc: S.of(context).alert_message_save_address,
  //     style: AlertStyle(
  //         titleStyle: Theme.of(context)
  //             .textTheme
  //             .bodyText1!
  //             .merge(TextStyle(fontSize: 20)),
  //         descStyle: Theme.of(context)
  //             .textTheme
  //             .bodyText1!
  //             .merge(TextStyle(fontSize: 16))),
  //     buttons: [
  //       DialogButton(
  //         child: Text(
  //           S.of(context).alert_yes,
  //           style: TextStyle(color: Colors.white, fontSize: 20),
  //         ),
  //         onPressed: () {
  //           address.description = "";
  //           Navigator.pop(context);
  //           DeliveryAddressDialog(
  //               context: context,
  //               address: address,
  //               onChanged: (Addresses _address) {
  //                 _con.addAddress(_address);
  //               },
  //               isForCurrentLocation: true,
  //               newSetState: (String newValue){
  //               },
  //               predictions: null!,
  //               isNewAddress: false);
  //         },
  //         width: 120,
  //       ),
  //       DialogButton(
  //         child: Text(
  //           S.of(context).alert_no,
  //           style: TextStyle(color: Colors.white, fontSize: 20),
  //         ),
  //         onPressed: () {
  //           Navigator.pop(context);
  //           //Navigator.of(context).pushNamed('/PaymentMethod');
  //           // Navigator.pop(context);
  //         },
  //         width: 120,
  //       )
  //     ],
  //   ).show();
  // }

  @override
  Widget build(BuildContext context) {
    list = new PaymentMethodList(context,false);
    return WillPopScope(
        onWillPop: () async {
          debugPrint("onWillPop");
          return false;
        },
        child: Scaffold(
          key: _con.scaffoldKey,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
            automaticallyImplyLeading: false,
            title: Text(
              S.of(context).delivery_addresses,
              style: Theme.of(context)
                  .textTheme
                  .headline6!
                  .merge(TextStyle(letterSpacing: 1.3)),
            ),
            leading: InkWell(
              onTap: () {
                Navigator.of(context).pushNamedAndRemoveUntil(
                    '/Pages', (Route<dynamic> route) => false,
                    arguments: 2);
              },
              child: Icon(
                Icons.home,
                size: 30,
                color: Theme.of(context).hintColor,
              ),
            ),
            actions: <Widget>[
              new ShoppingCartButtonWidget(
                  iconColor: Theme.of(context).hintColor,
                  labelColor: Theme.of(context).secondaryHeaderColor),
            ],
          ),
          floatingActionButton: Stack(
            children: [
              Positioned(
                right: 30,
                bottom: MediaQuery.of(context).size.height / 30,
                child: FloatingActionButton(
                  elevation: 8,
                  backgroundColor: Theme.of(context).secondaryHeaderColor,
                  child: Icon(Icons.add),
                  onPressed: () async {
                    DeliveryAddressDialog(
                        context: context,
                        address: Addresses(),
                        onChanged: (Addresses _address) {
                          _con.addAddress(_address);
                        },
                        isForCurrentLocation: false,
                        lat: widget.lat!,
                        long: widget.long!,
                        isNewAddress: true);
                   // await showInformationDialog(context);
                  },
                ),
              ),
            ],
          ),
          /*floatingActionButton:
          FloatingActionButton(
                  onPressed: () async {
                    LocationResult result = await showLocationPicker(
                      context,
                      setting.value.googleMapsKey,
                        initialCenter: LatLng(32.6938,35.0554),
//                      initialCenter: LatLng(deliveryAddress.value?.latitude ?? 0,deliveryAddress.value?.longitude ?? 0),
                      //automaticallyAnimateToCurrentLocation: true,
                      //mapStylePath: 'assets/mapStyle.json',
                      myLocationButtonEnabled: true,
                      //resultCardAlignment: Alignment.bottomCenter,
                        countries: ['IL'],
                        language: 'He',
                        automaticallyAnimateToCurrentLocation: false,
                        hintText: S.of(context).search_place
                    );
                    _con.addAddress(new Addresses.fromJSON({
                      'address': result.address,
                      'latitude': result.latLng.latitude,
                      'longitude': result.latLng.longitude,
                    }));
                    print("result = $result");
                    //setState(() => _pickedLocation = result);
                  },
                  backgroundColor: Theme.of(context).secondaryHeaderColor,
                  child: Icon(
                    Icons.add,
                    color: Theme.of(context).primaryColor,
                  ))
              ,*/
          body: RefreshIndicator(
            onRefresh: _con.refreshAddresses,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  Padding(
                    padding:
                        const EdgeInsets.only(top: 10, left: 20, right: 20),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(vertical: 0),
                      leading: Icon(
                        Icons.map,
                        color: Theme.of(context).hintColor,
                      ),
                      title: Text(
                        S.of(context).delivery_addresses,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.headline4,
                      ),
                      subtitle: Text(
                        S
                            .of(context).long_press_to_edit_item_swipe_item_to_delete_it,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.caption,
                      ),
                    ),
                  ),
                  _con.isLoadingData
                      ? CircularLoadingWidget(height: 250)
                      : ListView.separated(
                          padding: EdgeInsets.symmetric(vertical: 15),
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          primary: false,
                          itemCount: _con.addresses.length,
                          separatorBuilder: (context, index) {
                            return SizedBox(height: 15);
                          },
                          itemBuilder: (context, index) {
                            return DeliveryAddressesItemWidget(
                              address: _con.addresses.elementAt(index),
                              onPressed: (Addresses _address) {
                                /*if (widget.routeArgument.param) {
                                  _con.chooseDeliveryAddress(_address);
                                  if (index != 0 && _address.id != '0') {
                                    /*Navigator.of(context).pushNamed(
                                    '/PaymentMethod');*/
                                    Navigator.of(context).pop();
                                  } else {
                                    saveAddressAlert(_address);
                                  }
                                }*/
                                _con.chooseDeliveryAddress(_address);
                                Navigator.pop(context);
                              },
                              onSaved: (Addresses _address) {
                                DeliveryAddressDialog(
                                    context: context,
                                    address: _address,
                                    onChanged: (Addresses _address) {
                                      _con.addAddress(_address);
                                    },
                                    lat: widget.lat!,
                                    long: widget.long!,
                                    isNewAddress: false,
                                    isForCurrentLocation: true);
                              },
                              onLongPress: (Addresses _address) {
                                DeliveryAddressDialog(
                                    context: context,
                                    address: _address,
                                    lat: widget.lat!,
                                    long: widget.long!,
                                    onChanged: (Addresses _address) {
                                      _con.updateAddress(_address);
                                    },
                                    isForCurrentLocation: false,
                                  isNewAddress: false,
                                );
                              },
                              onDismissed: index == 0
                                  ? null
                                  : (Addresses _address) {
                                      if (_address.id != '0') {
                                        _con.removeDeliveryAddress(_address);
                                      }
                                    },
                            );
                          },
                        ),
                ],
              ),
            ),
          ),
        ));
  }

  // getSearchedLocationData(String searchData) async{
  //   MapsUtil mapsUtil = new MapsUtil();
  //   var _addressName = await mapsUtil.getSearchedLocation(searchData);
  //   print("locationPrint ${_addressName.toJson()}");
  //   for (int i = 0; i >= _addressName.predictions!.length; i++) {
  //     // items2.add(_addressName.predictions![i].structuredFormatting!.mainText);
  //     print('listtt ${_addressName.predictions![i].structuredFormatting!.mainText}');
  //     items2.add(_addressName.predictions![i].structuredFormatting!.mainText);
  //     print('listtt2 ${items2.length}');
  //   }
  //   return _addressName;
  // }

  // Future<void> showInformationDialog(BuildContext context) async {
  //   return await showDialog(
  //       context: context,
  //       builder: (context) {
  //         bool isChecked = false;
  //         return StatefulBuilder(builder: (context, setState) {
  //           return AlertDialog(
  //             content: Form(
  //                 key: _formKey,
  //                 child: Column(
  //                   mainAxisSize: MainAxisSize.min,
  //                   children: [
  //                     // TextFormField(
  //                     //   controller: _textEditingController,
  //                     //   validator: (value) {
  //                     //     return value!.isNotEmpty ? null : "Enter any text";
  //                     //   },
  //                     //   onChanged: (value){
  //                     //     getSearchedLocationData(_textEditingController.text.toString());
  //                     //   },
  //                     //   decoration:
  //                     //   InputDecoration(hintText: "Please Enter Text"),
  //                     // ),
  //                     GooglePlaceAutoCompleteTextField(
  //                         textEditingController: _textEditingController,
  //                         googleAPIKey: "AIzaSyAK4kgheqF6rqWiRJQ8TUfdwdDNMFMTxrY",
  //                         inputDecoration: InputDecoration(hintText: "Search your location"),
  //                         debounceTime: 800,
  //                         countries: ["isr"],
  //                         isLatLngRequired: true,
  //                         getPlaceDetailWithLatLng: (Prediction prediction) {
  //                           print("placeDetails" + prediction.lng.toString());
  //                         },
  //                         itmClick: (Prediction prediction) {
  //                           _textEditingController.text = prediction.description!;
  //
  //                           _textEditingController.selection = TextSelection.fromPosition(
  //                               TextPosition(offset: prediction.description!.length));
  //                         }
  //                       // default 600 ms ,
  //                     ),
  //                     Row(
  //                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                       children: [
  //                         Text("Choice Box"),
  //                         Checkbox(
  //                             value: isChecked,
  //                             onChanged: (checked) {
  //                               setState(() {
  //                                 isChecked = checked!;
  //                               });
  //                             })
  //                       ],
  //                     )
  //                   ],
  //                 )),
  //             title: Text('Stateful Dialog'),
  //             actions: <Widget>[
  //               InkWell(
  //                 child: Text('OK   '),
  //                 onTap: () {
  //                   if (_formKey.currentState!.validate()) {
  //                     // Do something like updating SharedPreferences or User Settings etc.
  //                     Navigator.of(context).pop();
  //                   }
  //                 },
  //               ),
  //             ],
  //           );
  //         });
  //       });
  // }

}