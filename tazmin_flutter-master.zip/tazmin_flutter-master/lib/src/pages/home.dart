import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/elements/CuisineCaregoriesWidget.dart';
import 'package:food_delivery_app/src/elements/FoodCategoryWidget.dart';
import 'package:food_delivery_app/src/elements/PopularRestaurantsWidget.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import '../../generated/l10n.dart';
import '../controllers/home_controller.dart';
import '../elements/CardsCarouselWidget.dart';
import '../elements/FoodsCarouselWidget.dart';
import '../elements/GridWidget.dart';
import '../elements/ReviewsListWidget.dart';
import '../elements/SearchBarWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/setting.dart';
import '../repository/settings_repository.dart' as settingsRepo;
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;
import 'package:food_delivery_app/main.dart';

class HomeWidget extends StatefulWidget {
  final GlobalKey<ScaffoldState> parentScaffoldKey;

  HomeWidget({Key? key,
    required this.parentScaffoldKey}) : super(key: key);
  late HomeWidgetState homeWidgetState;

  void callInternal() {
    if (homeWidgetState != null) {
      homeWidgetState.intervalForGridItem();
    }
  }

  @override
  HomeWidgetState createState() => homeWidgetState = new HomeWidgetState();
}

class HomeWidgetState extends StateMVC<HomeWidget>
    with TickerProviderStateMixin {
  late HomeController _con;
  int _current = 0;
  bool isFirstTime = true;
  late GlobalKey<ScaffoldState> _scaffoldKey;

  HomeWidgetState() : super(HomeController()) {
    _con = controller as HomeController;
  }

  List<T> returnMap<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }

  @override
  void initState() {
    super.initState();
    _scaffoldKey = GlobalKey<ScaffoldState>();
  }

  @override
  dispose() {
    super.dispose();
  }

  void intervalForGridItem() {
    if (_con.popularRestaurants.length > 0) {
      if (settingsRepo.animationLooper.value !=
          _con.popularRestaurants.length - 1) {
        settingsRepo.animationLooper.value++;
      } else {
        settingsRepo.animationLooper.value = 0;
      }
      setState(() {});
      var currentTime = DateTime.now();
      var minutes = currentTime.difference(MyApp.oldTime).inMinutes + 1;

      if (!MyApp.isFirstTime && _con.isFirsTime) {
        _con.isFirsTime = false;
        _con.listenForTopRestaurants();
      } else {
        //print('minutes: $minutes');
        if (minutes > 3) {
          MyApp.oldTime = currentTime;
          _con.listenForTopRestaurants();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (settingsRepo.deliveryAddress.value != null) {
      //print('deliveryAddress:${settingsRepo.deliveryAddress.value.address}');
      if (settingsRepo.deliveryAddress.value.address != null) {
        MyApp.addressDTO = settingsRepo.deliveryAddress.value;
        //print('MyApp.address:${MyApp.address}');
      }
    }
    return Scaffold(
        key: _con.scaffoldKey,
        appBar: AppBar(
          /*leading: new IconButton(
            icon: new Icon(Icons.sort, color: Theme.of(context).hintColor),
            onPressed: () => widget.parentScaffoldKey.currentState.openDrawer(),
          ),*/
          leadingWidth: 100,
          leading: Row(
            children: [
              new IconButton(
                icon: new Icon(Icons.sort, color: Theme.of(context).hintColor),
                iconSize: 30,
                onPressed: () =>
                    widget.parentScaffoldKey.currentState?.openDrawer(),
              ), /*
              SizedBox(
                width: 10,
              ),
              InkWell(
                onTap: () {
                  Navigator.of(context)
                      .pushReplacementNamed('/CategoriesFilter');
                },
                child: ImageIcon(
                  AssetImage("assets/img/res_cat.png"),
                  color: Theme.of(context).hintColor,
                  size: 28,
                ),
              ),*/
            ],
          ),
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          title: ValueListenableBuilder(
            valueListenable: settingsRepo.setting,
            builder: (context, value, child) {
              return Text(
                settingsRepo.setting.value.appName.isNotEmpty ? settingsRepo.setting.value.appName : S.of(context).home,
                style: Theme.of(context)
                    .textTheme
                    .headline6!
                    .merge(TextStyle(letterSpacing: 1.3)),
              );
            },
          ),
//        title: Text(
//          settingsRepo.setting?.value.appName ?? S.of(context).home,
//          style: Theme.of(context).textTheme.headline6.merge(TextStyle(letterSpacing: 1.3)),
//        ),
          actions: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                /*InkWell(
                  onTap: () {
                    Navigator.of(context)
                        .pushReplacementNamed('/CategoriesFilter');
                  },
                  child: ImageIcon(
                    AssetImage("assets/img/res_cat.png"),
                    color: Theme.of(context).hintColor,
                    size: 28,
                  ),
                ),*/
                ShoppingCartButtonWidget(
                    iconColor: Theme.of(context).hintColor,
                    labelColor: Theme.of(context).secondaryHeaderColor),
                /*SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: () {
                    widget.parentScaffoldKey.currentState.openEndDrawer();
                  },
                  child: Icon(Icons.filter_list,
                      size: 30, color: Theme.of(context).hintColor),
                ),
                SizedBox(
                  width: 10,
                ),*/
              ],
            )
          ],
        ),
        body: RefreshIndicator(
          onRefresh: _con.refreshHome,
          child: ListView(
            shrinkWrap: true,
            primary: true,
            //crossAxisAlignment: CrossAxisAlignment.start,
            //mainAxisAlignment: MainAxisAlignment.start,
            //mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SearchBarWidget(
                  onClickFilter: (event) {
                    widget.parentScaffoldKey.currentState?.openEndDrawer();
                  },
                ),
              ),
              SizedBox(
                height: 5,
              ),
              settingsRepo.setting.value != Setting() &&
                      settingsRepo.setting.value.announcement.isNotEmpty
                  ? Container(
                      width: MediaQuery.of(context).size.width,
                      margin: EdgeInsets.only(
                          left: 20, right: 20, top: 0, bottom: 0),
                      decoration: BoxDecoration(
                        color: Theme.of(context).secondaryHeaderColor,
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        boxShadow: [
                          BoxShadow(
                              color:
                                  Theme.of(context).focusColor.withOpacity(0.2),
                              blurRadius: 15,
                              offset: Offset(0, 5)),
                        ],
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(10),
                        child: Text(
                          settingsRepo.setting.value.announcement,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.headline1?.merge(
                              TextStyle(color: Theme.of(context).primaryColor)),
                        ),
                      ),
                    )
                  : Container(),
              SizedBox(height: 5),
              Container(
                width: 300,
                margin:
                    EdgeInsets.only(left: 15, right: 15, top: 0, bottom: 0),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  boxShadow: [
                    BoxShadow(
                        color: Theme.of(context).focusColor.withOpacity(0.1),
                        blurRadius: 15,
                        offset: Offset(0, 5)),
                  ],
                ),
                child: Wrap(children: <Widget>[
                  settingsRepo.setting.value.customTitle1 != ''
                      ? Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 0),
                      leading: Icon(
                        Icons.location_on,
                        color: Theme.of(context).hintColor,
                      ),
                      title: Text(
                        settingsRepo.setting.value.customTitle1,
                        style: Theme.of(context).textTheme.headline4,
                      ),
                    ),
                  ) : SizedBox(height: 0),
                  Padding(
                    padding: EdgeInsets.only(top: 0, left: 10, right: 30),
                    child: ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 0),
                      // leading: SizedBox(width: 0),
                      /*IconButton(
                    onPressed: () {
                      //if (currentUser.value.apiToken.isEmpty) {
                      _con.requestForCurrentLocation(context);
                      */ /*} else {
                          var bottomSheetController = widget
                              .parentScaffoldKey.currentState
                              .showBottomSheet(
                            (context) => DeliveryAddressBottomSheetWidget(
                                scaffoldKey: widget.parentScaffoldKey),
                            shape: RoundedRectangleBorder(
                              borderRadius: new BorderRadius.only(
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                            ),
                          );
                          bottomSheetController.closed.then((value) {
                            _con.refreshHome();
                          });
                        }*/ /*
                    },
                    icon: Icon(
                      Icons.my_location,
                      color: Theme.of(context).hintColor,
                    ),
                  ),*/
                      /*InkWell(
                      child: Column(children: [
                        ImageIcon(
                          AssetImage("assets/img/res_cat.png"),
                          color: Theme.of(context).hintColor,
                          size: 20,
                        ),
                        Container(
                            margin: EdgeInsets.only(left: 2, right: 2, top: 5),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 2),
                            decoration: BoxDecoration(
                                color: config.Colors().mainColor(1),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              S.of(context).show_all,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline2
                                  .merge(TextStyle(
                                  fontSize: 13, color: Colors.white)),
                            )),
                      ]),
                      onTap: () {
                        Navigator.of(context)
                            .pushNamed('/RestaurantsWithCuisines');
                      }),*/
                      /*title: AutoSizeText(
                    S.of(context).top_restaurants,
                    textDirection: TextDirection.rtl,
                    style: Theme.of(context).textTheme.headline4,
                    maxLines: 1,
                    overflow: TextOverflow.visible,
                  ),*/
                      /*Text(
                      S.of(context).top_restaurants,
                      textDirection: TextDirection.rtl,
                      style: Theme.of(context).textTheme.headline4,
                    ),*/
                      title: InkWell(
                        child: AutoSizeText(
                          S.of(context).near_to +
                              " " +
                              (MyApp.addressDTO?.address ??
                                  settingsRepo.deliveryAddress.value.address),
                          style: Theme.of(context).textTheme.headline4,
                          maxLines: 1,
                          minFontSize: 15,
                          overflow: TextOverflow.visible,
                        ),
                        onTap: () {
                          checkLocationPermission();
                        },
                      ),
                      /*Text(
                      S.of(context).near_to +
                          " " +
                         (MyApp.address ??
                              settingsRepo.deliveryAddress.value?.address ??
                              S.of(context).unknown),
                      style: Theme.of(context).textTheme.caption,
                    ),*/
                    ),
                  ),
                ]),
              ),
              SizedBox(height: 10),
              _con.bannerList.isEmpty
                  ? Center(child: CircularLoadingWidget(height: 200))
                  : Directionality(
                      textDirection: TextDirection.rtl,
                      child: Column(children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, right: 10, top: 0, bottom: 0),
                          child: CarouselSlider(
                            items: returnMap<Widget>(
                              _con.bannerList,
                                  (index, i) {
                                return Container(
                                  color: Colors.transparent,
                                  margin: EdgeInsets.all(5.0),
                                  child: ClipRRect(
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(10.0)),
                                    child: Stack(children: <Widget>[
                                      GestureDetector(
                                          child: CachedNetworkImage(
                                              fit: BoxFit.cover,
                                              width: 1000.0,
                                              placeholder: (context, url) =>
                                              /*Center(
                                                                child:
                                                                CircularLoadingWidget(height: 200)
                                                            )*/
                                              /*Image.asset(
                                                          'assets/img/loading_circle.gif',
                                                          fit: BoxFit.cover,
                                                          width: double.infinity,
                                                        )*/
                                              Container(
                                                  color:
                                                  Colors.transparent),
                                              imageUrl: i),
                                          /*Image.network(i,
                                            fit: BoxFit.cover, width: 1000.0),*/
                                          onTap: () {
                                            print('onTap:$index');
                                            print(
                                                'onTapType_id:${_con.bannerAppList[index].type_id}');
                                            print(
                                                'onTapRedirectUrl:${_con.bannerAppList[index].redirect_url}');

                                            if (_con.bannerAppList[index]
                                                .type_id ==
                                                '1') {
                                              //Restaurant
                                              Navigator.of(context).pushNamed(
                                                  '/Details',
                                                  arguments: RouteArgument(
                                                    id: _con
                                                        .bannerAppList[index]
                                                        .redirect_url,
                                                    heroTag: "",
                                                  ));
                                            } else if (_con.bannerAppList[index]
                                                .type_id ==
                                                '2') {
                                              //Category
                                              Navigator.of(context).pushNamed(
                                                  '/Category',
                                                  arguments: RouteArgument(
                                                      id: _con
                                                          .bannerAppList[index]
                                                          .redirect_url));
                                            } else if (_con.bannerAppList[index]
                                                .type_id ==
                                                '3') {
                                              //Food
                                              Navigator.of(context).pushNamed(
                                                  '/Food',
                                                  arguments: RouteArgument(
                                                      id: _con
                                                          .bannerAppList[index]
                                                          .redirect_url,
                                                      heroTag: ""));
                                            } else if (_con.bannerAppList[index]
                                                .type_id ==
                                                '4') {
                                              //Custom URL
                                              Navigator.of(context).pushNamed(
                                                  '/Web',
                                                  arguments: RouteArgument(
                                                      id: _con
                                                          .bannerAppList[index]
                                                          .redirect_url));
                                            }
                                          }),
                                    ]),
                                  ),
                                );
                              },
                            ).toList(),
                            options: CarouselOptions(
                              aspectRatio: 2.5,
                              viewportFraction: 1.0,
                              autoPlay: true,
                              autoPlayInterval: Duration(seconds: 5),
                              enlargeCenterPage: true,
                              onPageChanged:(index,reason){
                                setState(() {
                                  _current = index;

                                });
                              }
                              // onPageChanged:(index){
                              //   assert(index = null);
                              //   _current = index;
                              // }
                            ),

                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: returnMap<Widget>(
                            _con.bannerList,
                            (index, url) {
                              return Container(
                                width: 20.0,
                                height: 3.0,
                                margin: EdgeInsets.only(
                                    top: 5, left: 2, right: 2, bottom: 15),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(8),
                                    ),
                                    color: _current == index
                                        ? Color(0xFFf77f00).withOpacity(1)
                                        : Color(0xFFf77f00).withOpacity(0.3)),
                              );
                            },
                          ),
                        ),
                      ])),
              SizedBox(
                height: 15,
              ),
              /*Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.symmetric(vertical: 0),
                  leading: Icon(
                    Icons.category,
                    color: Theme.of(context).hintColor,
                  ),
                  title: Text(
                    S.of(context).food_categories,
                    style: Theme.of(context).textTheme.headline4,
                  ),
                ),
              ),*/
          /*    CuisineCategoriesWidget(
                cuisines: _con.cuisines,
              ), */
       /*       Padding(
                padding: EdgeInsets.only(top: 0, left: 10, right: 10),
                child: ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.only(left: 25),
                  leading: /*settingsRepo.setting.value.customTitle1 != ''?*/ IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.restaurant,
                      color: Theme.of(context).hintColor,
                    ),
                  ) /*:SizedBox(width: 0,)*/,
                  trailing: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                          onTap: () {
                            Navigator.of(context)
                                .pushNamed('/RestaurantsWithCuisines');
                          },
                          child: Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                  color: config.Colors().mainColor(1),
                                  borderRadius: BorderRadius.circular(15)),
                              child: Text(
                                S.of(context).show_all,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline2!
                                    .merge(TextStyle(
                                        fontSize: 16, color: Colors.white)),
                              )))
                    ],
                  ),
                  /*InkWell(
                      child: Column(children: [
                        ImageIcon(
                          AssetImage("assets/img/res_cat.png"),
                          color: Theme.of(context).hintColor,
                          size: 20,
                        ),
                        Container(
                            margin: EdgeInsets.only(left: 2, right: 2, top: 5),
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 2),
                            decoration: BoxDecoration(
                                color: config.Colors().mainColor(1),
                                borderRadius: BorderRadius.circular(10)),
                            child: Text(
                              S.of(context).show_all,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline2
                                  .merge(TextStyle(
                                  fontSize: 13, color: Colors.white)),
                            )),
                      ]),
                      onTap: () {
                        Navigator.of(context)
                            .pushNamed('/RestaurantsWithCuisines');
                      }),*/
                  title: settingsRepo.setting.value.customTitle2 != ''
                      ? Text(
                          settingsRepo.setting.value.customTitle2,
                          style: Theme.of(context).textTheme.headline4,
                        )
                      : SizedBox(width: 0),
                  /*Text(
                      S.of(context).top_restaurants,
                      textDirection: TextDirection.rtl,
                      style: Theme.of(context).textTheme.headline4,
                    ),*/
                  /*subtitle: AutoSizeText(
                    S.of(context).near_to +
                        " " +
                        (MyApp.addressDTO.address ??
                            settingsRepo.deliveryAddress.value?.address ??
                            S.of(context).unknown),
                    style: Theme.of(context).textTheme.caption,
                    maxLines: 1,
                    minFontSize: 15,
                    overflow: TextOverflow.visible,
                  ),*/
                  /*Text(
                      S.of(context).near_to +
                          " " +
                         (MyApp.address ??
                              settingsRepo.deliveryAddress.value?.address ??
                              S.of(context).unknown),
                      style: Theme.of(context).textTheme.caption,
                    ),*/
                ),
              ), */
              /* if (_con.popularRestaurants.length > 0)
                Padding(
                  padding:
                      const EdgeInsets.only(left: 20, right: 20, bottom: 20),
                  child: ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.symmetric(vertical: 0),
                    leading: Icon(
                      Icons.trending_up,
                      color: Theme.of(context).hintColor,
                    ),
                    title: Text(
                      S.of(context).most_popular,
                      style: Theme.of(context).textTheme.headline4,
                    ),
                  ),
                ),*/
              SizedBox(
                height: 0,
              ),
              if(_con.popularRestaurants.isNotEmpty)
                PopularRestaurantsWidget(
                  restaurantsList: _con.popularRestaurants,
                  heroTag: 'popular_restaurants_widget',
                  callback: () {
                    // print('callback');
                  },
                  isDeliveryTime: _con.isDeliveryTime,
                  ),
              _con.openRestaurantsCount != 0
                  ? Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.symmetric(vertical: 0),
                        leading: Icon(
                          Icons.restaurant_menu,
                          color: Theme.of(context).hintColor,
                        ),
                        title: Text(
                          _con.openRestaurantsCount == 0
                              ? S.of(context).all_restaurants
                              : S.of(context).open_restaurants_right_now(
                                  _con.openRestaurantsCount),
                          style: Theme.of(context).textTheme.headline4,
                        ),
                      ),
                    )
                  : SizedBox(width: 0),
              CardsCarouselWidget(
                restaurantsList: _con.topRestaurants,
                heroTag: 'home_top_restaurants',
                isForAppMapDirection: false,
                isDeliveryTime: _con.isDeliveryTime,
              ),
              SizedBox(
                height: 15,
              ),
              if (settingsRepo.setting.value.disableTrendingFood != '1')
                SizedBox(
                  height: 15,
                ),
              if (settingsRepo.setting.value.disableTrendingFood != '1')
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.symmetric(horizontal: 20),
                  leading: Icon(
                    Icons.trending_up,
                    color: Theme.of(context).hintColor,
                  ),
                  title:
                      /*ScaleTransition(
                          key: title2Key,
                          alignment: Alignment.topRight,
                          scale: _selectedTween.animate(CurvedAnimation(
                              parent: _controller2, curve: Curves.easeOut)),
                          child: */
                      Text(
                    S.of(context).trending_this_week,
                    style: Theme.of(context).textTheme.headline4,
                    // )
                  ),
                  subtitle: Text(
                    S.of(context).double_click_on_the_food_to_add_it_to_the,
                    style: Theme.of(context)
                        .textTheme
                        .caption!
                        .merge(TextStyle(fontSize: 16)),
                  ),
                ),
              if (settingsRepo.setting.value.disableTrendingFood != '1')
                FoodsCarouselWidget(
                    foodsList: _con.trendingFoods,
                    heroTag: 'home_food_carousel_widget'),
              SizedBox(
                height: 15,
              ),
              if (_con.recentReviews.length > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.symmetric(vertical: 20),
                    leading: Icon(
                      Icons.recent_actors,
                      color: Theme.of(context).hintColor,
                    ),
                    title: Text(
                      S.of(context).recent_reviews,
                      style: Theme.of(context).textTheme.headline4,
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ReviewsListWidget(
                  reviewsList: _con.recentReviews,
                  isLoading: _con.isReviewLoading,
                ),
              ),
              if (_con.recentReviews.length > 0)
                SizedBox(
                  height: 15,
                ),
            ],
          ),
          //),
        ));
  }

  void checkLocationPermission() async {
    var geolocationStatus =
    await Geolocator.checkPermission();
    // await Geolocator().checkGeolocationPermissionStatus();
    print('geolocationStatus.value:${geolocationStatus}');
    if (geolocationStatus != LocationPermission.whileInUse) {
      requestLocationPermission();
    } else {
      var serviceStatus = await Geolocator.checkPermission();
      //await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        _con.requestForCurrentLocation(context);
      } else {
        locationEnableAlert();
      }
    }
  }

  Future<bool> requestLocationPermission() async {
    return _requestPermission();
  }

  Future<bool> _requestPermission() async {
    print('_requestPermission');
    var result = await Geolocator.requestPermission();
    //var result = await LocationPermissions().requestPermissions();
    if (result == LocationPermission.whileInUse) {
      var serviceStatus = await Geolocator.checkPermission();
      // await LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      var serviceStatus = await Geolocator.checkPermission();
      // LocationPermissions().checkServiceStatus();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        locationEnableAlert();
        print('locationEnableAlert()');
      } else {
        Alert(
          context: context,
          type: AlertType.warning,
          title: S.of(context).alert_location_service_permission_title,
          desc: S.of(context).alert_location_service_permission_message,
          style: AlertStyle(
              titleStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 18)),
              descStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 16))),
          buttons: [
            DialogButton(
              child: Text(
                S.of(context).alert_location_service_btn,
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
              onPressed: () {
                Navigator.pop(context);
                //LocationPermissions().openAppSettings();
                Geolocator.openAppSettings();
              },
            )
          ],
        ).show();
      }
    }
    return false;
  }

  void locationEnableAlert() {
    Alert(
      context: context,
      type: AlertType.warning,
      title: S.of(context).alert_location_service_title,
      desc: S.of(context).alert_location_service_message,
      style: AlertStyle(
          titleStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(context).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(context);
            //LocationPermissions().openAppSettings();
            Geolocator.openLocationSettings();
          },
        )
      ],
    ).show();
  }
}
