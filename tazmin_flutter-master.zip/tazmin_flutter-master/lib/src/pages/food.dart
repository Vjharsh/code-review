import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:food_delivery_app/src/elements/ExtraChipItemWidget.dart';
import 'package:food_delivery_app/src/models/extra.dart';
import 'package:food_delivery_app/src/models/food.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:shimmer/shimmer.dart';

import '../../generated/l10n.dart';
import '../controllers/food_controller.dart';
import '../elements/ReviewsListWidget.dart';
import '../elements/ShoppingCartFloatButtonWidget.dart';
import '../helpers/app_config.dart' as config;
import '../helpers/helper.dart';
import '../models/route_argument.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart'
    as settingRepo;
import '../repository/user_repository.dart';

// ignore: must_be_immutable
class FoodWidget extends StatefulWidget {
  RouteArgument routeArgument;

  FoodWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _FoodWidgetState createState() {
    return _FoodWidgetState();
  }
}

class _FoodWidgetState extends StateMVC<FoodWidget>
    with TickerProviderStateMixin {
  late FoodController _con;

  // var scrollController = ScrollController();
  late AnimationController _controller;
  late AnimationController limitQtyAnimationController;
  late Animation<Offset> _offsetAnimation;
  late Animation<Offset> _tempOffsetAnimation;
  Tween<double> _selectedTween = Tween(begin: 0, end: 1);
  int tempGroupId = 0;
  String tempId = "";
  bool isForFirstInEdit = false;
  int animatedExtraIndex = 0;

  _FoodWidgetState() : super(FoodController()) {
    _con = controller as FoodController;
  }

  @override
  void initState() {
    super.initState();
    if (widget.routeArgument.param != null) {
      _con.cart = widget.routeArgument.param;
      _con.isForEdit = true;
      isForFirstInEdit = true;
      /*_con.total = Helper.getTotalCartPrice(widget.routeArgument.param);
      print('_con.total: ${_con.total}');*/
      print('cart:${_con.cart.toMap(true)}');
    } else {
      _con.isForEdit = false;
    }

    /*scrollController.addListener(() {
      if (scrollController.position.atEdge) {
        if (scrollController.position.pixels == 0) {
          print('scrollController top');
          // You're at the top.
        } else {
          print('scrollController bottom');
          // You're at the bottom.
          print('isForPaging: ${_con.isForPaging}');
          print('isForNextGroup: ${_con.isForNextGroup}');
          if (_con.isForPaging) {
            _con.listenForExtra(foodId: widget.routeArgument.id);
          }
        }
      }
    });*/
    limitQtyAnimationController = AnimationController(
        duration: const Duration(milliseconds: 500), vsync: this);
    limitQtyAnimationController
      ..addStatusListener((AnimationStatus status) {
        if (status == AnimationStatus.completed) {
          limitQtyAnimationController.reverse();
        }
      });
    _offsetAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(1.0, 0.0),
    ).animate(CurvedAnimation(
      parent: limitQtyAnimationController,
      curve: Curves.elasticIn,
    ));
    _tempOffsetAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: const Offset(0.0, 0.0),
    ).animate(CurvedAnimation(
      parent: limitQtyAnimationController,
      curve: Curves.elasticIn,
    ));
    _controller = AnimationController(
        duration: const Duration(milliseconds: 800), vsync: this);
    _controller
      ..addStatusListener((AnimationStatus status) {
        if (status == AnimationStatus.completed) {
          // _controller.reverse();
        }
      });
    _con.listenForFood(foodId: widget.routeArgument.id);
    _con.listenForCart();
    _con.listenForFavorite(foodId: widget.routeArgument.id);
    _con.listenForExtraGroup(foodId: widget.routeArgument.id);

    Future.delayed(const Duration(milliseconds: 700), () {
      _controller.forward();
    });

    if (widget.routeArgument.param != null) {
      _con.total = Helper.getTotalCartPrice(widget.routeArgument.param);
      print('_con.total: ${_con.total}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      body: _con.food! == Food()
          ? Center(
              child: SpinKitThreeBounce(
                color: config.Colors().mainColor(1),
                size: 28,
              ),
            ) //CircularLoadingWidget(height: 500)
          : RefreshIndicator(
              onRefresh: _con.refreshFood,
              child: Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  Container(
                    margin: _con.isEnableAddToCart
                        ? EdgeInsets.only(bottom: 5)
                        : EdgeInsets.only(bottom: 0),
                    padding: _con.isEnableAddToCart
                        ? EdgeInsets.only(bottom: 5)
                        : EdgeInsets.only(bottom: 0),
                    child: CustomScrollView(
                      // controller: scrollController,
                      primary: false,
                      shrinkWrap: false,
                      slivers: <Widget>[
                        SliverAppBar(
                          leading: Container(),
                          backgroundColor:
                              Theme.of(context).secondaryHeaderColor.withOpacity(0.9),
                          expandedHeight: 300,
                          elevation: 0,
                          iconTheme: IconThemeData(
                              color: Theme.of(context).primaryColor),
                          flexibleSpace: FlexibleSpaceBar(
                            collapseMode: CollapseMode.parallax,
                            background: Hero(
                              tag: widget.routeArgument.heroTag ??
                                  '' + _con.food!.id,
                              child: CachedNetworkImage(
                                fit: BoxFit.cover,
                                imageUrl: _con.food!.image.url,
                                placeholder: (context, url) => Image.asset(
                                  'assets/img/loading.gif',
                                  fit: BoxFit.cover,
                                ),
                                errorWidget: (context, url, error) =>
                                    Icon(Icons.error),
                              ),
                            ),
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 15),
                            child: Wrap(
                              runSpacing: 8,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: ScaleTransition(
                                        alignment: Alignment.topRight,
                                        scale: _selectedTween.animate(
                                            CurvedAnimation(
                                                parent: _controller,
                                                curve: Curves.easeOut)),
                                        child: Text(
                                          _con.food!.name,
                                          textDirection: TextDirection.rtl,
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 2,
                                          style: Theme.of(context)
                                              .textTheme
                                              .headline3,
                                        ),
                                      ),
                                    ),
                                    Helper.getPrice(
                                      _con.food!.price,
                                      context,
                                      style:
                                          Theme.of(context).textTheme.headline2!,
                                    ),
                                  ],
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                      flex: 3,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          /*Text(
                                            _con.food!.name,
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            style: Theme.of(context)
                                                .textTheme
                                                .headline3,
                                          ),*/
                                          InkWell(
                                              onTap: () {
                                                Navigator.of(context).pushNamed(
                                                    '/Details',
                                                    arguments: RouteArgument(
                                                      id: _con
                                                          .food!.restaurant.id,
                                                      heroTag:
                                                          'ResDetail${_con.food!.restaurant.id}',
                                                    ));
                                              },
                                              child: Text(
                                                _con.food!.restaurant.name,
                                                overflow: TextOverflow.ellipsis,
                                                maxLines: 2,
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyText2,
                                              )),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.end,
                                        children: <Widget>[
                                          /*Helper.getPrice(
                                            _con.food!.price,
                                            context,
                                            style: Theme.of(context)
                                                .textTheme
                                                .headline2,
                                          ),*/
                                          _con.food!.discountPrice > 0
                                              ? Helper.getPrice(
                                                  _con.food!.discountPrice,
                                                  context,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyText2!
                                                      .merge(TextStyle(
                                                          decoration:
                                                              TextDecoration
                                                                  .lineThrough)))
                                              : SizedBox(height: 0),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: <Widget>[
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 3),
                                      decoration: BoxDecoration(
                                          color: _con.food!.foodStatus
                                              ? Colors.green
                                              : Colors.grey,
                                          borderRadius:
                                              BorderRadius.circular(24)),
                                      child: Text(
                                        _con.food!.foodStatus
                                            ? S.of(context).in_stock
                                            : S.of(context).out_of_stock,
                                        style: Theme.of(context)
                                            .textTheme
                                            .caption!
                                            .merge(TextStyle(
                                                color: Theme.of(context)
                                                    .primaryColor)),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 3),
                                      decoration: BoxDecoration(
                                          color: _con.food!.deliverable
                                              ? Colors.green
                                              : Colors.orange,
                                          borderRadius:
                                              BorderRadius.circular(24)),
                                      child: _con.food!.deliverable
                                          ? Text(
                                              S.of(context).deliverable,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .caption!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor)),
                                            )
                                          : Text(
                                              S.of(context).not_deliverable,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .caption!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor)),
                                            ),
                                    ),
                                    Expanded(child: SizedBox(height: 0)),
                                    _con.food!.weight != '0'
                                        ? Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 3),
                                            decoration: BoxDecoration(
                                                color: Theme.of(context)
                                                    .focusColor,
                                                borderRadius:
                                                    BorderRadius.circular(24)),
                                            child: Text(
                                              _con.food!.weight +
                                                  " " +
                                                  _con.food!.unit,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .caption!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor)),
                                            ))
                                        : SizedBox(
                                            height: 0,
                                          ),
                                    SizedBox(width: 5),
                                    _con.food!.packageItemsCount != '0'
                                        ? Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 12, vertical: 3),
                                            decoration: BoxDecoration(
                                                color: Theme.of(context)
                                                    .focusColor,
                                                borderRadius:
                                                    BorderRadius.circular(24)),
                                            child: Text(
                                              _con.food!.packageItemsCount +
                                                  " " +
                                                  S.of(context).items,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .caption!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor)),
                                            ))
                                        : SizedBox(
                                            height: 0,
                                          ),
                                  ],
                                ),
                                // if(_con.food!.description.isNotEmpty)Divider(height: 20),
                                if(_con.food!.description.isNotEmpty && _con.food!.description != '<p><br><\/p>')Helper.applyHtml(context, _con.food!.description,
                                    style: TextStyle(fontSize: 20)),
                                /*_con.extraGroupList.length > 0
                                    ? ListTile(
                                        dense: true,
                                        contentPadding:
                                            EdgeInsets.symmetric(vertical: 10),
                                        leading: Icon(
                                          Icons.add_circle,
                                          color: Theme.of(context).hintColor,
                                        ),
                                        title: Text(
                                          S.of(context).extras,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                        subtitle: Text(
                                          S
                                              .of(context)
                                              .select_extras_to_add_them_on_the_food,
                                          style: Theme.of(context)
                                              .textTheme
                                              .caption,
                                        ),
                                      )
                                    : SizedBox(
                                        height: 0,
                                      ),*/
                                /*_con.extraGroupList.length == 0
                                    ? SpinKitThreeBounce(
                                        color: config.Colors().mainColor(1),
                                        size: 28,
                                      ) //CircularLoadingWidget(height: 100)
                                    : */
                                _con.extraGroupList.length > 0
                                    ? ListView.separated(
                                        // controller: scrollController,
                                        padding: EdgeInsets.all(0),
                                        itemCount: _con.extraGroupList.length,
                                        separatorBuilder: (context, index) {
                                          return SizedBox(
                                            height: 0,
                                          );
                                        },
                                        primary: false,
                                        shrinkWrap: true,
                                        itemBuilder: (context, extraGroupIndex) {
                                          bool isSelectedAll = true;
                                          bool isSelectedAtLeastOne = false;
                                          for (int j = 0; j < _con.extraGroupList.elementAt(extraGroupIndex).extras.length; j++) {
                                            Extra extra = _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(j);
                                            if (!extra.checked) {
                                              isSelectedAll = false;
                                            } else {
                                              isSelectedAtLeastOne = true;
                                            }
                                          }
                                          return _con.extraGroupList.elementAt(extraGroupIndex).extras.length == 0
                                              ? SizedBox(
                                                  height: 0,
                                                )
                                              : Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    tempId == '$extraGroupIndex'
                                                        ? Container(height: 0)
                                                        : Container(height: 25),
                                                    Container(
                                                        height: 15,
                                                        width: MediaQuery.of(
                                                                context)
                                                            .size
                                                            .width,
                                                        color: Colors.grey[300]
                                                            !.withOpacity(0.4)),
                                                    ListTile(
                                                      dense: true,
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              vertical: 0),
                                                      leading: Icon(
                                                        Icons
                                                            .add_circle_outline,
                                                        color: Theme.of(context)
                                                            .hintColor,
                                                      ),
                                                      title: Row(
                                                        children: [
                                                          Expanded(
                                                            child: Row(
                                                              children: [
                                                                Text(
                                                                  _con.extraGroupList.elementAt(extraGroupIndex).name,
                                                                  style: Theme.of(
                                                                          context)
                                                                      .textTheme
                                                                      .subtitle1,
                                                                ),
                                                                _con.extraGroupList.elementAt(extraGroupIndex).requireField ?
                                                                Text('*',style: TextStyle(color: Colors.red,fontSize: 30),):SizedBox(width: 0)
                                                              ],
                                                            ),
                                                          ),
                                                          Row(
                                                            children: [
                                                              if (_con.extraGroupList.elementAt(extraGroupIndex).extraGroupSettings &&
                                                                  _con.extraGroupList.elementAt(extraGroupIndex).qtyEnable == "0")
                                                                InkWell(
                                                                  onTap: () {
                                                                    _con.extraGroupList.elementAt(extraGroupIndex)
                                                                        .extras.forEach((element) {
                                                                      setState(() {
                                                                        element.checked = true;
                                                                      });
                                                                    });
                                                                  },
                                                                  child: /*newExtras.elementAt(int.parse(tempId)).qtyEnable == '0' ? */ Container(
                                                                    margin: EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            10,
                                                                        vertical:
                                                                            10),
                                                                    padding: EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            12,
                                                                        vertical:
                                                                            3),
                                                                    decoration: BoxDecoration(
                                                                        color: isSelectedAll
                                                                            ? Theme.of(context)
                                                                                .secondaryHeaderColor
                                                                            : Theme.of(context)
                                                                                .hintColor,
                                                                        borderRadius:
                                                                            BorderRadius.circular(24)),
                                                                    child: Text(
                                                                      S.of(context).select_all,
                                                                      style: Theme.of(
                                                                              context)
                                                                          .textTheme
                                                                          .caption!
                                                                          .merge(
                                                                              TextStyle(color: Theme.of(context).primaryColor)),
                                                                    ),
                                                                  ) /*: SizedBox(height: 0,)*/,
                                                                ),
                                                              if (_con.extraGroupList.elementAt(extraGroupIndex).extraGroupSettings)
                                                                InkWell(
                                                                  onTap: () {
                                                                    _con.extraGroupList.forEach((element) {
                                                                      element.selectedQty = 0;
                                                                    });
                                                                    _con.extraGroupList.elementAt(extraGroupIndex).extras.forEach((element) {
                                                                      setState(() {
                                                                        element.checked = false;
                                                                        element.qty = 0;
                                                                      });
                                                                    });
                                                                  },
                                                                  child:
                                                                      Container(
                                                                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                                                                    decoration: BoxDecoration(
                                                                        color: !isSelectedAll && !isSelectedAtLeastOne
                                                                            ? Theme.of(context)
                                                                                .secondaryHeaderColor
                                                                            : Theme.of(context)
                                                                                .hintColor,
                                                                        borderRadius:
                                                                            BorderRadius.circular(24)),
                                                                    child: Text(
                                                                      S
                                                                          .of(context).none,
                                                                      style: Theme.of(
                                                                              context)
                                                                          .textTheme
                                                                          .caption!
                                                                          .merge(
                                                                              TextStyle(color: Theme.of(context).primaryColor)),
                                                                    ),
                                                                  ),
                                                                ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    if (_con.extraGroupList
                                                                .elementAt(
                                                                    extraGroupIndex)
                                                                .qtyEnable ==
                                                            '1' &&
                                                        int.parse(_con.extraGroupList
                                                                .elementAt(
                                                                    extraGroupIndex)
                                                                .limitQty) >
                                                            1)
                                                      SlideTransition(
                                                          position: animatedExtraIndex ==
                                                                  extraGroupIndex
                                                              ? _offsetAnimation
                                                              : _tempOffsetAnimation,
                                                          child: Container(
                                                            margin:
                                                                EdgeInsets.only(
                                                                    top: 10,
                                                                    bottom: 10,
                                                                    right: 10),
                                                            child: Text(
                                                              'בחרו עד ${_con.extraGroupList.elementAt(extraGroupIndex).limitQty} פריטים —  ${_con.extraGroupList.elementAt(extraGroupIndex).selectedQty}/${_con.extraGroupList.elementAt(extraGroupIndex).limitQty} נבחרו',
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .caption!
                                                                  .merge(TextStyle(
                                                                      color: Theme.of(
                                                                              context)
                                                                          .hintColor)),
                                                            ),
                                                          )),
                                                    _con.extraGroupList.elementAt(extraGroupIndex).extras.length > 0
                                                        ? Wrap(
                                                            spacing: 6.0,
                                                            runSpacing: 6.0,
                                                            children: List<Widget>.generate(
                                                                _con.extraGroupList
                                                                    .elementAt(
                                                                        extraGroupIndex)
                                                                    .extras
                                                                    .length,
                                                                (int extraIndex) {
                                                              return ExtraChipItemWidget(
                                                                  extra: _con
                                                                      .extraGroupList
                                                                      .elementAt(
                                                                          extraGroupIndex)
                                                                      .extras
                                                                      .elementAt(
                                                                          extraIndex),
                                                                  index:
                                                                      extraIndex,
                                                                  onQtyAlert:
                                                                      (String
                                                                          limitQty) {
                                                                    animatedExtraIndex =
                                                                        extraGroupIndex;
                                                                    limitQtyAnimationController
                                                                        .forward();
                                                                  },
                                                                  onChanged: (int
                                                                          index,
                                                                      bool
                                                                          isForPizza) {
                                                                    isForFirstInEdit = false;
                                                                    if (currentUser.value.apiToken == '') {
                                                                      Navigator.of(context).pushNamed("/Login");
                                                                    } else {
                                                                      if (isForPizza) {
                                                                        _con.totalExtras += 1;
                                                                      } else {
                                                                        _con.totalExtras -= 1;
                                                                      }
                                                                      int totalQty = 0;
                                                                      _con.extraGroupList.elementAt(extraGroupIndex).extras.forEach((element) {
                                                                        if (element.checked) {
                                                                          print('checked:${element.qty}');
                                                                          totalQty += int.parse(element.qty.toStringAsFixed(0));
                                                                        }
                                                                      });
                                                                      print('totalQty:$totalQty');
                                                                      print('limitQty:${_con.extraGroupList.elementAt(extraGroupIndex).limitQty}');
                                                                      if (totalQty > int.parse(_con.extraGroupList.elementAt(extraGroupIndex).limitQty) &&
                                                                          _con.extraGroupList.elementAt(extraGroupIndex).qtyEnable == '1') {
                                                                        if (_con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).qty == 1) {
                                                                          if (int.parse(_con.extraGroupList.elementAt(extraGroupIndex).limitQty) > 1) {
                                                                            _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).checked = false;
                                                                          } else {
                                                                            _con.extraGroupList.elementAt(extraGroupIndex).extras.forEach((element) {element.checked = false;});
                                                                            _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).checked = true;
                                                                          }
                                                                        } else {
                                                                          _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).qty -= 1;
                                                                          _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).totalPrice =
                                                                              _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).price * _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(extraIndex).qty;
                                                                        }

                                                                        animatedExtraIndex = extraGroupIndex;
                                                                        limitQtyAnimationController.forward();
                                                                      } else {
                                                                        _con.extraGroupList.elementAt(extraGroupIndex).selectedQty = totalQty;
                                                                      }
                                                                      _con.calculateTotal();
                                                                      if (_con.extraGroupList.elementAt(extraGroupIndex).pizzaStatus == 1) {
                                                                        if (isForPizza && totalQty <= int.parse(_con.extraGroupList.elementAt(extraGroupIndex).limitQty)) {
                                                                          _con.pizzaTypeAlert(S.of(context).pizza_type, extraGroupIndex, index);
                                                                        } else {
                                                                          for (int i = 0; i < _con.extraGroupList.elementAt(extraGroupIndex).extras.length; i++) {
                                                                            if (_con.extraGroupList.elementAt(extraGroupIndex).extras[i].id ==
                                                                                _con.extraGroupList.elementAt(extraGroupIndex).extras.elementAt(index).id) {
                                                                              if(totalQty > int.parse(_con.extraGroupList.elementAt(extraGroupIndex).limitQty) &&
                                                                                  _con.extraGroupList.elementAt(extraGroupIndex).qtyEnable == '1'){
                                                                                _con.extraGroupList.elementAt(extraGroupIndex).extras[i].checked = false;
                                                                              }
                                                                              _con.extraGroupList.elementAt(extraGroupIndex).extras[i].pizzaStatus = 0;
                                                                              _con.extraGroupList.elementAt(extraGroupIndex).extras[i].pizzaType = '';
                                                                              _con.extraGroupList.elementAt(extraGroupIndex).extras[i].fullPrice = '0';
                                                                              _con.extraGroupList.elementAt(extraGroupIndex).extras[i].halfPrice = '0';
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                      setState(() {});
                                                                    }
                                                                  });
                                                            }),
                                                          )
                                                        : SizedBox(height: 0),
                                                  ],
                                                );
                                        },
                                      )
                                    :  SizedBox(height: 0),
                                if(_con.isForShimmer)ListView.separated(
                                  // controller: scrollController,
                                  padding: EdgeInsets.all(0),
                                  itemCount: 1,
                                  separatorBuilder: (context, index) {
                                    return SizedBox(
                                      height: 0,
                                    );
                                  },
                                  primary: false,
                                  shrinkWrap: true,
                                  itemBuilder: (context, extraGroupIndex) {
                                    return Shimmer.fromColors(
                                        baseColor: Colors.grey[300]!,
                                        highlightColor: Colors.grey[100]!,
                                        enabled: true,
                                        child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Container(height: 0),
                                              Container(
                                                  height: 15,
                                                  width: MediaQuery.of(context).size.width,
                                                  color: Colors.grey[300]!.withOpacity(0.4)),
                                              ListTile(
                                                dense: true,
                                                contentPadding: EdgeInsets.symmetric(vertical: 0),
                                                leading: Icon(
                                                  Icons.add_circle_outline,
                                                  color: Colors.white,
                                                ),
                                                title: Row(
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Container(
                                                          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                                                          decoration: BoxDecoration(
                                                              color: Theme.of(context).hintColor,
                                                              borderRadius: BorderRadius.circular(24)),
                                                          child: Text(S.of(context).select_all,
                                                            style: Theme.of(context).textTheme.caption!.merge(TextStyle(color: Colors.white)),
                                                          ),
                                                        ),
                                                        Container(
                                                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                                                          decoration: BoxDecoration(
                                                              color: Theme.of(context).hintColor,
                                                              borderRadius: BorderRadius.circular(24)),
                                                          child: Text(S.of(context).none,
                                                            style: Theme.of(context).textTheme.caption!.merge(TextStyle(color: Colors.white)),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Wrap(
                                                spacing: 6.0,
                                                runSpacing: 6.0,
                                                children: List<Widget>.generate(7, (int extraIndex) {
                                                  return RawChip(
                                                    elevation: 0,
                                                    label: Text('                  '),
                                                    labelStyle: Theme.of(context).textTheme.bodyText2
                                                        !.merge(TextStyle(color: Theme.of(context).primaryColor)),
                                                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                                    backgroundColor: Colors.white,
                                                    showCheckmark: false,
                                                    onSelected: (bool value) {},
                                                  );
                                                }),
                                              ),
                                            ]));
                                  },
                                ),
                                _con.food!.ingredients != '' &&
                                        _con.food!.ingredients.length > 0 &&
                                        _con.food!.ingredients != '<p><br><\/p>'
                                    ? ListTile(
                                        dense: true,
                                        contentPadding:
                                            EdgeInsets.symmetric(vertical: 10),
                                        leading: Icon(
                                          Icons.donut_small,
                                          color: Theme.of(context).hintColor,
                                        ),
                                        title: Text(
                                          S.of(context).ingredients,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                      )
                                    : SizedBox(
                                        height: 0,
                                      ),
                                _con.food!.ingredients != '' &&
                                        _con.food!.ingredients.length > 0 &&
                                        _con.food!.ingredients != '<p><br><\/p>'
                                    ? Helper.applyHtml(
                                        context, _con.food!.ingredients,
                                        style: TextStyle(fontSize: 12))
                                    : SizedBox(
                                        height: 0,
                                      ),
                                _con.food!.nutritions.isNotEmpty &&
                                        _con.food!.nutritions.length > 0
                                    ? ListTile(
                                        dense: true,
                                        contentPadding:
                                            EdgeInsets.symmetric(vertical: 10),
                                        leading: Icon(
                                          Icons.local_activity,
                                          color: Theme.of(context).hintColor,
                                        ),
                                        title: Text(
                                          S.of(context).nutrition,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                      )
                                    : SizedBox(height: 0),
                                _con.food!.nutritions.isNotEmpty &&
                                        _con.food!.nutritions.length > 0
                                    ? Wrap(
                                        spacing: 8,
                                        runSpacing: 8,
                                        children: List.generate(
                                            _con.food!.nutritions.length,
                                            (index) {
                                          return Container(
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 8),
                                            decoration: BoxDecoration(
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(5)),
                                                boxShadow: [
                                                  BoxShadow(
                                                      color: Theme.of(context)
                                                          .focusColor
                                                          .withOpacity(0.2),
                                                      offset: Offset(0, 2),
                                                      blurRadius: 6.0)
                                                ]),
                                            child: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: <Widget>[
                                                Text(
                                                    _con.food!.nutritions
                                                        .elementAt(index)
                                                        .name,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .caption),
                                                _con.food!.price == 0.0 ?SizedBox(width: 0,):Text(
                                                    _con.food!.nutritions
                                                        .elementAt(index)
                                                        .quantity
                                                        .toString(),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .headline5),
                                              ],
                                            ),
                                          );
                                        }),
                                      )
                                    : SizedBox(height: 0),
                                _con.food!.foodReviews.length > 0 &&
                                        !_con.isForPaging
                                    ? ListTile(
                                        dense: true,
                                        contentPadding:
                                            EdgeInsets.symmetric(vertical: 10),
                                        leading: Icon(
                                          Icons.recent_actors,
                                          color: Theme.of(context).hintColor,
                                        ),
                                        title: Text(
                                          S.of(context).reviews,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                      )
                                    : SizedBox(height: 0),
                                if (!_con.isForPaging)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 15),
                                    child: ReviewsListWidget(
                                      reviewsList: _con.food!.foodReviews,
                                      isLoading: _con.isFoodLoading,
                                    ),
                                  ),
                                Container(
                                  height: _con.isEnableAddToCart ? 150 : 10,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  _con.isEnableAddToCart
                      ? Positioned(
                          top: 32,
                          right: 0,
                          left: 0,
                          child: _con.loadCart
                              ? Container(
                                  width: MediaQuery.of(context).size.width,
                                  child: Padding(
                                      padding:
                                          EdgeInsets.only(left: 20, right: 20),
                                      child: Stack(
                                        children: <Widget>[
                                          Align(
                                              alignment: Alignment.centerLeft,
                                              child: SizedBox(
                                                width: 60,
                                                height: 60,
                                                child:
                                                    RefreshProgressIndicator(),
                                              )),
                                        ],
                                      )),
                                )
                              : ShoppingCartFloatButtonWidget(
                                  iconColor: Theme.of(context).primaryColor,
                                  labelColor: Theme.of(context).hintColor,
                                  backIconColor: Theme.of(context).primaryColor,
                                  food: _con.food!),
                        )
                      : Container(
                          height: 0,
                        ),
                  _con.isEnableAddToCart && _con.food!.foodStatus
                      ? Positioned(
                          bottom: 0,
                          child: Container(
                            height: 150,
                            padding: EdgeInsets.symmetric(
                                horizontal: 20, vertical: 8),
                            decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor,
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(20),
                                    topLeft: Radius.circular(20)),
                                boxShadow: [
                                  BoxShadow(
                                      color: Theme.of(context)
                                          .focusColor
                                          .withOpacity(0.15),
                                      offset: Offset(0, -2),
                                      blurRadius: 5.0)
                                ]),
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width - 40,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Text(
                                          S.of(context).quantity,
                                          style: Theme.of(context)
                                              .textTheme
                                              .subtitle1,
                                        ),
                                      ),
                                      Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          IconButton(
                                            onPressed: () {
                                              _con.decrementQuantity();
                                            },
                                            iconSize: 30,
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 5, vertical: 10),
                                            icon: Icon(
                                                Icons.remove_circle_outline),
                                            color: Theme.of(context).hintColor,
                                          ),
                                          Text(_con.quantity.toString(),
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .subtitle1),
                                          IconButton(
                                            onPressed: () {
                                              _con.incrementQuantity();
                                            },
                                            iconSize: 30,
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 5, vertical: 10),
                                            icon:
                                                Icon(Icons.add_circle_outline),
                                            color: Theme.of(context).hintColor,
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: _con.favorite?.id != ''
                                            ? OutlineButton(
                                                onPressed: () {
                                                  _con.removeFromFavorite(
                                                      _con.favorite!);
                                                },
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 14),
                                                color: Theme.of(context)
                                                    .primaryColor,
                                                shape: StadiumBorder(),
                                                borderSide: BorderSide(
                                                    color: Theme.of(context)
                                                        .secondaryHeaderColor),
                                                child: Icon(
                                                  Icons.favorite,
                                                  color: Theme.of(context)
                                                      .secondaryHeaderColor,
                                                ))
                                            : FlatButton(
                                                onPressed: () {
                                                  if (currentUser
                                                          .value.apiToken == '') {
                                                    Navigator.of(context)
                                                        .pushNamed("/Login");
                                                  } else {
                                                    _con.addToFavorite(
                                                        _con.food!);
                                                  }
                                                },
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 14),
                                                color: Theme.of(context)
                                                    .secondaryHeaderColor,
                                                shape: StadiumBorder(),
                                                child: Icon(
                                                  Icons.favorite,
                                                  color: Theme.of(context)
                                                      .primaryColor,
                                                )),
                                      ),
                                      SizedBox(width: 10),
                                      Stack(
                                        fit: StackFit.loose,
                                        alignment:
                                            AlignmentDirectional.centerEnd,
                                        children: <Widget>[
                                          SizedBox(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width -
                                                110,
                                            child: FlatButton(
                                              onPressed: () {
                                                if (currentUser.value.apiToken == '') {
                                                  Navigator.of(context).pushNamed("/Login");
                                                } else {
                                                  if (_con.isForEdit) {
                                                    _con.updateFoodToCart();
                                                  } else {
                                                    if (_con.food!.restaurant
                                                        .busyMode) {
                                                      _con.busyRestaurantsAlert();
                                                    } else {
                                                      settingRepo
                                                          .getDeliveryOption()
                                                          .then((value) {
                                                        if (value) {
                                                          _con.checkLocationPermission();
                                                        } else {
                                                          _con.goToItemAddInCart();
                                                        }
                                                      });
                                                    }
                                                  }
                                                }
                                              },
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 14),
                                              color:
                                                  Theme.of(context).secondaryHeaderColor,
                                              shape: StadiumBorder(),
                                              child: Container(
                                                width: double.infinity,
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 20),
                                                child: Text(
                                                  _con.isForEdit
                                                      ? S.of(context).update_btn
                                                      : S
                                                          .of(context).add_to_cart,
                                                  textAlign: TextAlign.start,
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headline4!
                                                      .merge(TextStyle(
                                                          color: Theme.of(
                                                                  context)
                                                              .primaryColor)),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 20),
                                            child: _con.isForEdit && isForFirstInEdit?Helper.getPrice(Helper.getTotalCartPrice(_con.cart),
                                              context,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .headline4!
                                                  .merge(TextStyle(
                                                  color: Theme.of(context)
                                                      .primaryColor))):Helper.getPrice(
                                              _con.total,
                                              context,
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .headline4!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor)),
                                            ),
                                          )
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                ],
                              ),
                            ),
                          ),
                        )
                      : Container(
                          height: 0,
                        )
                ],
              ),
            ),
    );
  }
}
