import 'package:flutter/material.dart';

// import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:food_delivery_app/src/models/credit_card.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/controllers/yaadpay_controller.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:food_delivery_app/src/repository/user_repository.dart'
    as userRepo;
import 'package:food_delivery_app/src/repository/yaadpay_repository.dart';
import 'package:webview_flutter/webview_flutter.dart';

class YaadPayPaymentWidget extends StatefulWidget {
  RouteArgument routeArgument;

  YaadPayPaymentWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);

  @override
  _YaadPayPaymentWidgetState createState() => _YaadPayPaymentWidgetState();
}

class _YaadPayPaymentWidgetState extends StateMVC<YaadPayPaymentWidget> {
  late YaadPayController _con;
  bool isIos = false;
  bool isWebviewLoading = false;

  _YaadPayPaymentWidgetState() : super(YaadPayController()) {
    _con = controller as YaadPayController;
  }

  void goToOrderSuccessPage() {
    Navigator.of(context).pushReplacementNamed('/YaadPayCreditCard',
        arguments: new RouteArgument(param: 'Credit Card (YaadPay Gateway)'));
  }

  void saveCreditCardToken(String transactionId) async {
    final Stream<String> stream =
        await getTokenSavingCreditCard(transactionId, _con.orderId);
    stream.listen((String response) async {
      print('getToken Response:$response');
      String token = "";
      String ccMonth = "";
      String ccYear = "";
      List<String> splitUrl = response.split("&");
      for (var i = 0; i < splitUrl.length; i++) {
        String splitItem = splitUrl[i];
        if (splitItem.startsWith("Token")) {
          List<String> splitValue = splitItem.split("=");
          token = splitValue[1];
          print("token:$token");
        }
        if (splitItem.startsWith("Tokef")) {
          List<String> splitValue = splitItem.split("=");
          String ccDate = splitValue[1];
          print("ccDate:$ccDate");
          for (var i = 0; i < ccDate.length; i++) {
            if (i < 2) {
              ccYear = ccYear + ccDate[i];
            } else {
              ccMonth = ccMonth + ccDate[i];
            }
          }
        }
      }
      userRepo.getCreditCard().then((creditCard) {
        print('credicard:${creditCard.toMap()}');
        creditCard.token = token;
        creditCard.expYear = ccYear;
        creditCard.expMonth = ccMonth;
        userRepo.setCreditCard(creditCard);
        goToOrderSuccessPage();
      });
    });
  }

  void savingCardAlert(
      String userId, String cardLast4Digit, String transactionId) {
    Alert(
      context: context,
      type: AlertType.none,
      title: S.of(context).saving_card_alert_title,
      desc: S
          .of(context).saving_card_alert_message("XXXX-XXXX-XXXX-$cardLast4Digit"),
      style: AlertStyle(
          titleStyle: Theme.of(context)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          descStyle: Theme.of(context)
              .textTheme
              .caption!
              .merge(TextStyle(fontSize: 20, fontWeight: FontWeight.w500))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(context).alert_yes,
            style: TextStyle(color: Colors.white, fontSize: 15),
          ),
          onPressed: () {
            Navigator.pop(context);
            CreditCard creditCard = CreditCard();
            creditCard.number = "XXXX-XXXX-XXXX-$cardLast4Digit";
            creditCard.userId = userId;
            userRepo.setCreditCard(creditCard);
            saveCreditCardToken(transactionId);
          },
          width: 120,
        ),
        DialogButton(
          child: Text(
            S.of(context).alert_no,
            style: TextStyle(color: Colors.white, fontSize: 15),
          ),
          onPressed: () {
            Navigator.pop(context);
            goToOrderSuccessPage();
          },
          width: 50,
        ),
      ],
    ).show();
  }

  JavascriptChannel _toasterJavascriptChannel(BuildContext context) {
    return JavascriptChannel(
        name: 'Toaster',
        onMessageReceived: (JavascriptMessage message) {
          // ignore: deprecated_member_use
          Scaffold.of(context).showSnackBar(
            SnackBar(content: Text(message.message)),
          );
        });
  }

  @override
  void initState() {
    //_con.url = widget.routeArgument.param;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _con.scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          S.of(context).yaadpay_payment,
          style: Theme.of(context)
              .textTheme
              .headline6!
              .merge(TextStyle(letterSpacing: 1.3)),
        ),
      ),
      body:
          /*_con.url.isEmpty
          ? CircularLoadingWidget(height: 300)
          : */
          Stack(
        children: <Widget>[
          WebView(
            initialUrl:
                // "<!DOCTYPE html><html><head><title></title></head><body><p></p></body></html>",
                widget.routeArgument.param,
            javascriptChannels: <JavascriptChannel>[
              _toasterJavascriptChannel(context),
            ].toSet(),
            javascriptMode: JavascriptMode.unrestricted,
            onWebViewCreated: (WebViewController webViewController) {
              _con.webViewController = webViewController;
            },
            navigationDelegate: (NavigationRequest request) {
              print('allowing navigation to $request');
              return NavigationDecision.navigate;
            },
            onPageStarted: (String url) {
              print('Page started loading: $url');
              setState(() {
                isWebviewLoading = true;
              });
              if (url.startsWith("https://icom.yaad.net/p3/?action=pay")) {
                setState(() {
                  _con.isLoading = false;
                });
              }
              if (url.startsWith(
                  "https://icom.yaad.net/yaadpay/tmp/apitest/yaadsuccesspagedemo.htm")) {
                List<String> splitUrl1 = url.split("?");
                List<String> splitUrl = splitUrl1[1].split("&");
                String transactionId = "";
                String last4Digit = "";
                String userId = "";
                int transactionStatus = -1;
                for (var i = 0; i < splitUrl.length; i++) {
                  String splitItem = splitUrl[i];
                  if (splitItem.startsWith("CCode")) {
                    List<String> splitValue = splitItem.split("=");
                    transactionStatus = int.parse(splitValue[1]);
                    print("transactionStatus:$transactionStatus");
                  }
                  if (splitItem.startsWith("Id")) {
                    List<String> splitValue = splitItem.split("=");
                    transactionId = splitValue[1];
                    print("transactionId:$transactionId");
                  }
                  if (splitItem.startsWith("L4digit")) {
                    List<String> splitValue = splitItem.split("=");
                    last4Digit = splitValue[1];
                    print("last4Digit:$last4Digit");
                  }
                  if (splitItem.startsWith("UserId")) {
                    List<String> splitValue = splitItem.split("=");
                    userId = splitValue[1];
                    print("UserId:$userId");
                  }
                }

                if (transactionStatus == 0) {
                  /*Navigator.of(context).pushReplacementNamed(
                              '/YaadPayCreditCard',
                              arguments: new RouteArgument(
                                  param: 'Credit Card (YaasPay Gateway)'));*/
                  savingCardAlert(userId, last4Digit, transactionId);
                } else {
                  //transaction failed
                }
              }
              //for live return url
              if (url.startsWith(
                  "https://icom.yaad.net/p3/?action=thankYouPage")) {
                List<String> splitUrl1 = url.split("?");
                List<String> splitUrl = splitUrl1[1].split("&");
                String tranId = "";
                String last4Digit = "";
                String userId = "";
                int transactionStatus = -1;
                for (var i = 0; i < splitUrl.length; i++) {
                  String splitItem = splitUrl[i];
                  if (splitItem.startsWith("CCode")) {
                    List<String> splitValue = splitItem.split("=");
                    transactionStatus = int.parse(splitValue[1]);
                    print("transactionStatus:$transactionStatus");
                  }
                  if (splitItem.startsWith("Id")) {
                    List<String> splitValue = splitItem.split("=");
                    tranId = splitValue[1];
                    print("transactionId:$tranId");
                  }
                  if (splitItem.startsWith("L4digit")) {
                    List<String> splitValue = splitItem.split("=");
                    last4Digit = splitValue[1];
                    print("transactionId:$last4Digit");
                  }
                  if (splitItem.startsWith("UserId")) {
                    List<String> splitValue = splitItem.split("=");
                    userId = splitValue[1];
                    print("UserId:$userId");
                  }
                }
                if (transactionStatus == 0) {
                  /*Navigator.of(context).pushReplacementNamed(
                              '/YaadPayCreditCard',
                              arguments: new RouteArgument(
                                  param: 'Credit Card (YaasPay Gateway)'));*/
                  savingCardAlert(userId, last4Digit, tranId);
                } else {
                  //transaction failed
                }
              }
            },
            onPageFinished: (String url) {
              print('Page finished loading: $url');
              setState(() {
                isWebviewLoading = false;
              });
            },
            gestureNavigationEnabled: true,
          ),
          if (_con.isLoading)
            Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                color: Colors.white,
                child: Center(child: CircularLoadingWidget(height: 300))),
          if (isWebviewLoading)
            SizedBox(
              height: 3,
              child: LinearProgressIndicator(
                backgroundColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.2),
              ),
            )
        ],
      ),
    );
  }
}
