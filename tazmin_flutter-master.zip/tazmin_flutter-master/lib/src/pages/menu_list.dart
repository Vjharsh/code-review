import 'dart:math';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/CategoriesFoodItemWidget.dart';
import 'package:food_delivery_app/src/models/category_with_foods.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:sticky_headers/sticky_headers.dart';

import '../../generated/l10n.dart';
import '../controllers/restaurant_controller.dart';
import '../elements/CircularLoadingWidget.dart';
import '../elements/DrawerWidget.dart';
import '../elements/FoodsCarouselWidget.dart';
import '../elements/SearchBarWidget.dart';
import '../elements/ShoppingCartButtonWidget.dart';
import '../models/route_argument.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as Config;
import '../repository/settings_repository.dart' as settingsRepo;

class MenuWidget extends StatefulWidget {
  @override
  _MenuWidgetState createState() => _MenuWidgetState();
  final RouteArgument routeArgument;

  MenuWidget({
    Key? key,
    required this.routeArgument}) : super(key: key);
}

class _MenuWidgetState extends StateMVC<MenuWidget>
    with TickerProviderStateMixin {
  late RestaurantController _con;
  late ScrollController _sController;
  late ScrollController _sTabController;
  bool titleKeyAnimation = false;
  double animationTopPosition = 0;
  double animationBottomPosition = 0;
  int isStartScroll = 0;

  //List<AnimationController> animationControllerList = <AnimationController>[];
  GlobalKey appBarKey = GlobalKey();
  GlobalKey sizeBox1Key = GlobalKey();
  GlobalKey tabKey = GlobalKey();
  GlobalKey stickyHeaderKey = GlobalKey();
  GlobalKey textKey = GlobalKey();
  GlobalKey searchBarKey = GlobalKey();
  GlobalKey trendingFoodsTitleKey = GlobalKey();
  GlobalKey trendingFoodsListKey = GlobalKey();
  GlobalKey categoriesWithFoodsTitleKey = GlobalKey();
  double stickyValue = 0;
  Color tabColor = Colors.transparent;
  int currentValue = 0;
  int oldValue = 0;
  int itemSelectIndex = -1;
  int oldItemSelectIndex = -1;
  // bool isClickEnable = true;
  bool isTabClick = false;
  List<double> offsetList = <double>[];
  List<double> tabItemOffsetList = <double>[];

  _MenuWidgetState() : super(RestaurantController()) {
    _con = controller as RestaurantController;
  }

  @override
  void initState() {
    super.initState();
    initController();
    _con.isLoadedCategoriesWithFoods = false;
    _con.listenForFoods(widget.routeArgument.id!);
    _con.listenForTrendingFoods(widget.routeArgument.id!);
    _con.listenForCategoriesWithFoods(widget.routeArgument.id!);
  }

  void initController() {
    _sController = ScrollController();
    _sTabController = ScrollController();
    _sController.addListener(() {
      isStartScroll = 1;
      // isClickEnable = false;
      /*if(stickyValue <= 0)
      {
        setState(() {
          tabColor = Colors.white;
        });
      } else {
        setState(() {
          tabColor = Colors.transparent;
        });
      }*/
      if (stickyValue <= 0) {
        currentValue = 0;
      }else {
        currentValue = 1;
      }
      if(currentValue != oldValue)
      {
        oldValue = currentValue;
        setState(() {
          tabColor = currentValue == 0 ? Theme.of(context).scaffoldBackgroundColor : Colors.transparent;
        });
      }
      if (_con.categoriesWithFoods.length > 0 && !isTabClick) {
        for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
          RenderBox? renderBox =
              _con.categoriesWithFoods[i].key.currentContext!.findRenderObject() as RenderBox?;
          if (renderBox != null) {
            Offset positionOfRenderBox = renderBox.localToGlobal(Offset.zero);
            // print('position : ${positionOfRenderBox.dy}');
            if (positionOfRenderBox.dy < 160) {
                itemSelectIndex = i;
                /*_con.categoriesTabList
                    .forEach((element) => element.isSelected = false);
                setState(() {
                  _con.categoriesTabList
                      .elementAt(i)
                      .isSelected = true;
                });*/
              RenderBox? tabKeyItemRenderBox = _con
                  .categoriesWithFoods[i].tabKey.currentContext!
                  .findRenderObject() as RenderBox?;
              if (tabKeyItemRenderBox != null) {
                Offset positionOfRenderBox =
                    tabKeyItemRenderBox.localToGlobal(Offset.zero);
                // print('tabKeyItemRenderBox dx : ${positionOfRenderBox.dx}');
                // print('tabKeyItemRenderBoxheight : ${positionOfRenderBox.dy}');
                // print('tabItemOffsetList.elementAt($i) : ${tabItemOffsetList.elementAt(i)}');
                if (tabItemOffsetList.elementAt(i) < 0) {
                  /* Future.delayed(
                      const Duration(
                          milliseconds: 100), () {*/
                  _sTabController
                      .animateTo(tabItemOffsetList.elementAt(i).abs(),
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut)
                      .then((value) {});
                  //});
                } else {
                  /*Future.delayed(
                      const Duration(
                          milliseconds: 100), () {*/
                  _sTabController
                      .animateTo(-tabItemOffsetList.elementAt(i),
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut)
                      .then((value) {});
                  // });
                }
              }
            }
          }
        }
      }
    });
  }

  /*void updateScrollAnimation() {
    isClickEnable = true;
  }*/

  void readyOfWidget() {
    offsetList.clear();
    tabItemOffsetList.clear();
    double total = 0;
    RenderBox? renderBox = appBarKey.currentContext!.findRenderObject() as RenderBox?;
    double offset = 0;
    renderBox = searchBarKey.currentContext!.findRenderObject() as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      print('searchBarKey height : $offset');
      total += offset;
    }
    if (_con.trendingFoods.length > 0 && settingsRepo.setting.value.disableTrendingFood != '1') {
      renderBox = trendingFoodsTitleKey.currentContext!.findRenderObject() as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        print('trendingFoodsTitleKey height : $offset');
        total += offset;
      }
      renderBox = trendingFoodsListKey.currentContext!.findRenderObject() as RenderBox?;
      offset = 0;
      if (renderBox != null) {
        offset = renderBox.size.height;
        print('trendingFoodsListKey height : $offset');
        total += offset;
      }
    }
    renderBox = categoriesWithFoodsTitleKey.currentContext!.findRenderObject() as RenderBox?;
    offset = 0;
    if (renderBox != null) {
      offset = renderBox.size.height;
      print('categoriesWithFoodsTitleKey height : $offset');
      total += offset;
    }
    renderBox = sizeBox1Key.currentContext!.findRenderObject() as RenderBox?;
    offset = 0;
    double sizeBox10Height = 0;
    if (renderBox != null) {
      offset = renderBox.size.height + 5;
      sizeBox10Height = renderBox.size.height;
      print('sizeBox1Key height : $offset');
      total += offset;
    }
    print('total offset : $total');
    print(
        '_con.categoriesWithFoods.length : ${_con.categoriesWithFoods.length}');
    for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
      if (i != 0) {
        RenderBox? renderBox = _con.categoriesWithFoods[i - 1].key.currentContext!
            .findRenderObject() as RenderBox?;
        double offset = 0;
        if (renderBox != null) {
          offset = renderBox.size.height + sizeBox10Height;
          // offset = renderBox.size.height;
          print('height : $offset');
        }
        total += offset;
        offsetList.add(total);
      } else {
        print('height : $total');
        offsetList.add(total);
      }
    }
    for (int i = 0; i < _con.categoriesWithFoods.length; i++) {
      RenderBox? tabKeyItemRenderBox =
          _con.categoriesWithFoods[i].tabKey.currentContext!.findRenderObject() as RenderBox?;
      if (tabKeyItemRenderBox != null) {
        Offset positionOfRenderBox =
            tabKeyItemRenderBox.localToGlobal(Offset.zero);
        print('tabKeyItemRenderBox dx {$i}: ${positionOfRenderBox.dx}');
        // print('tabKeyItemRenderBoxheight : ${positionOfRenderBox.dy}');
        // print('tabKeyItemRenderBox width : ${tabKeyItemRenderBox.size.width}');
        tabItemOffsetList.add(positionOfRenderBox.dx);
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    if (_con.isLoadedCategoriesWithFoods) {
      _con.isLoadedCategoriesWithFoods = false;
      Future.delayed(const Duration(milliseconds: 900), () {
        readyOfWidget();
      });
    }
    return Scaffold(
      key: _con.scaffoldKey,
      drawer: DrawerWidget(),
      appBar: AppBar(
        key: appBarKey,
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Text(
          _con.foods.isNotEmpty ? _con.foods[0].restaurant.name : '',
          overflow: TextOverflow.fade,
          softWrap: false,
          style: Theme.of(context)
              .textTheme
              .headline6!
              .merge(TextStyle(letterSpacing: 0)),
        ),
        actions: <Widget>[
          new ShoppingCartButtonWidget(
              iconColor: Theme.of(context).hintColor,
              labelColor: Theme.of(context).secondaryHeaderColor),
        ],
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      body: NotificationListener<ScrollNotification>(
          onNotification: (scrollNotification) {
            if (isStartScroll == 1) {
              if (scrollNotification is ScrollStartNotification) {
                // print('ScrollStartNotification');
              } else if (scrollNotification is ScrollUpdateNotification) {
                //isClickEnable = false;
                // print('ScrollUpdateNotification');
              } else if (scrollNotification is ScrollEndNotification) {
                // print('ScrollEndNotification');
                /*setState(() {
                  tabColor =
                      stickyValue <= 0 ? Colors.white : Colors.transparent;
                });*/
                if(oldItemSelectIndex != itemSelectIndex) {
                  oldItemSelectIndex = itemSelectIndex;
                  _con.categoriesTabList
                      .forEach((element) => element.isSelected = false);
                  setState(() {
                    _con.categoriesTabList
                        .elementAt(itemSelectIndex)
                        .isSelected = true;
                  });
                }
                if (isStartScroll == 1) {
                  isStartScroll = 3;
                  //updateScrollAnimation();
                }
              }
            }
            return true;
          },
          child:
          SingleChildScrollView(
            controller: _sController,
            physics: ClampingScrollPhysics(),
            // padding: EdgeInsets.symmetric(vertical: 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Padding(
                  key: searchBarKey,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: SearchBarWidget(),
                ),
                if (_con.trendingFoods.length > 0 && settingsRepo.setting.value.disableTrendingFood != '1')
                  ListTile(
                    key: trendingFoodsTitleKey,
                    dense: true,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    leading: Icon(
                      Icons.trending_up,
                      color: Theme.of(context).hintColor,
                    ),
                    title: Text(
                      S.of(context).trending_this_week,
                      style: Theme.of(context).textTheme.headline4,
                    ),
                    subtitle: Text(
                      S.of(context).double_click_on_the_food_to_add_it_to_the,
                      style: Theme.of(context)
                          .textTheme
                          .caption!
                          .merge(TextStyle(fontSize: 16)),
                    ),
                  ),
                if (_con.trendingFoods.length > 0 && settingsRepo.setting.value.disableTrendingFood != '1')
                  FoodsCarouselWidget(
                      key: trendingFoodsListKey,
                      heroTag: 'menu_trending_food',
                      foodsList: _con.trendingFoods),
                Padding(
                  key: categoriesWithFoodsTitleKey,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.symmetric(vertical: 0),
                    leading: Icon(
                      Icons.category,
                      color: Theme.of(context).hintColor,
                    ),
                    title: Text(
                      S.of(context).all_menu,
                      key: textKey,
                      style: Theme.of(context).textTheme.headline4,
                    ),
                  ),
                ),
                if (_con.categoriesWithFoods.isNotEmpty)
                  SizedBox(key: sizeBox1Key, height: 10),
                _con.categoriesWithFoods.isEmpty
                    ? CircularLoadingWidget(height: 50)
                    : StickyHeader(
                        key: stickyHeaderKey,
                        callback: (value) {
                          // print('value:$value');
                          stickyValue = value;
                          if (stickyValue == 0) {}
                        },
                        header: Container(
                          key: tabKey,
                          // color: stickyValue <= 0 ? Colors.white : Colors.transparent,
                          color: tabColor,
                          height: 60,
                          child: Align(
                            alignment: Alignment.centerRight,
                            child: SingleChildScrollView(
                                controller: _sTabController,
                                scrollDirection: Axis.horizontal,
                                physics: ClampingScrollPhysics(),
                                child: ListView(
                                  primary: false,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  children: List.generate(
                                      _con.categoriesWithFoods.length, (index) {
                                    return Container(
                                      key: _con.categoriesWithFoods
                                          .elementAt(index)
                                          .tabKey,
                                      // color: index %2 ==0 ?Colors.red :Colors.green ,
                                      child: Padding(
                                        padding:
                                            const EdgeInsetsDirectional.only(
                                                start: 10, end: 10),
                                        child: RawChip(
                                          elevation: 0,
                                          label: Text(_con.categoriesTabList
                                              .elementAt(index)
                                              .name),
                                          labelStyle: _con.categoriesTabList
                                                  .elementAt(index)
                                                  .isSelected
                                              ? Theme.of(context)
                                                  .textTheme
                                                  .bodyText2!
                                                  .merge(TextStyle(
                                                      color: Theme.of(context)
                                                          .primaryColor))
                                              : Theme.of(context)
                                                  .textTheme
                                                  .bodyText2!.merge(TextStyle(
                                              color: Theme.of(context)
                                                  .primaryColor)),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 10),
                                          backgroundColor: Theme.of(context).hintColor,
                                          selectedColor:
                                              Theme.of(context).secondaryHeaderColor,
                                          selected: _con.categoriesTabList
                                              .elementAt(index)
                                              .isSelected,
                                          showCheckmark: false,
                                          onSelected: (bool value) {
                                            isTabClick = true;
                                            //if (isClickEnable) {
                                            _con.categoriesTabList.forEach(
                                                (element) =>
                                                    element.isSelected = false);
                                            setState(() {
                                              _con.categoriesTabList
                                                      .elementAt(index)
                                                      .isSelected =
                                                  !_con.categoriesTabList
                                                      .elementAt(index)
                                                      .isSelected;
                                              Future.delayed(
                                                  const Duration(
                                                      milliseconds: 100), () {
                                                _sController
                                                    .animateTo(
                                                        offsetList[index],
                                                        duration:
                                                            const Duration(
                                                                milliseconds:
                                                                    500),
                                                        curve: Curves.easeOut)
                                                    .then((value) {
                                                  isTabClick = false;
                                                });
                                              });
                                            });
                                            // }
                                          },
                                        ),
                                      ),
                                    );
                                  }),
                                )),
                          ),
                        ),
                        content: Padding(
                          padding: const EdgeInsets.only(bottom:30),
                          child: ListView.separated(
                            key: ObjectKey('${Random().nextInt(10000)}'),
                            scrollDirection: Axis.vertical,
                            shrinkWrap: true,
                            primary: false,
                            itemCount: _con.categoriesWithFoods.length,
                            separatorBuilder: (context, index) {
                              return SizedBox(height: 10);
                            },
                            itemBuilder: (context, index) {
                              return CategoriesFoodItemWidget(
                                heroTag: 'menu_list',
                                categoryWithFoods:
                                    _con.categoriesWithFoods.elementAt(index),
                                // animationController: animationControllerList[index],
                                index: index,
                                // sController: this._sController,
                              );
                            },
                          ),
                        ),
                      ),
              ],
            ),
          )
    ),
    );
  }
}
