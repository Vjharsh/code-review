import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../helpers/app_config.dart' as config;
import '../models/restaurant.dart';
import '../models/route_argument.dart';
import '../repository/settings_repository.dart' as settingRepo;

//ignore: must_be_immutable
class GridItemWidget extends StatefulWidget {
  final Restaurant restaurant;
  final String heroTag;
  final VoidCallback finishAnimation;
  int index;
  int total;
  final VoidCallback callback;

  GridItemWidget(
      {Key? key,
      required this.restaurant,
      required this.heroTag,
      required this.index,
      required this.total,
      required this.finishAnimation,
      required this.callback})
      : super(key: key);

  @override
  State<StatefulWidget> createState() => GridItemWidgetState();
}

class GridItemWidgetState extends StateMVC<GridItemWidget>
    with TickerProviderStateMixin {
  late Restaurant restaurant;
  late String heroTag;

  //AnimationController _controller;
  //Tween<double> _selectedTween = Tween(begin: 1, end: 1.15);
  //Tween<double> _unselectedTween = Tween(begin: 1, end: 1);

  @override
  void initState() {
    super.initState();
    print('GridItemWidget initState');

    this.restaurant = widget.restaurant;
    this.heroTag = widget.heroTag;
  }

  /*@override
  dispose() {
    _controller.dispose(); // you need this
    super.dispose();
  }*/

  @override
  Widget build(BuildContext context) {
    //print('GridItemWidget BuildContext:${widget.index}');
    /*_controller = AnimationController(
        duration: const Duration(milliseconds: 800), vsync: this);*/

    //widget.callback();
    /*if (settingRepo.animationLooper.value == widget.index) {
      _controller
        ..addStatusListener((AnimationStatus status) {
          if (status == AnimationStatus.completed) {
            _controller.reverse();
//            print('settingRepo.animationLooper.value:${settingRepo.animationLooper.value}');
            //widget.finishAnimation();
            //    _controller.repeat(reverse: true);
            //print('completed');
          }
          ;
        });
      _controller.forward();
    }*/
    return InkWell(
      highlightColor: Colors.transparent,
      splashColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.08),
      onTap: () {
        Navigator.of(context).pushNamed('/Details',
            arguments: RouteArgument(id: restaurant.id, heroTag: heroTag));
      },
      child:
          /*ScaleTransition(
          scale: settingRepo.animationLooper.value == widget.index
              ? _selectedTween.animate(
                  CurvedAnimation(parent: _controller, curve: Curves.easeOut))
              : _unselectedTween.animate(
                  CurvedAnimation(parent: _controller, curve: Curves.easeOut)),
          child:*/
          Container(
        decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            borderRadius: BorderRadius.all(Radius.circular(5)),
            boxShadow: [
              BoxShadow(
                  color: Theme.of(context).focusColor.withOpacity(0.05),
                  offset: Offset(0, 5),
                  blurRadius: 5)
            ]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            ClipRRect(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5), topRight: Radius.circular(5)),
              child: Hero(
                tag: heroTag + restaurant.id,
                child: CachedNetworkImage(
                  height: 100,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  imageUrl: restaurant.image.thumb,
                  placeholder: (context, url) => Image.asset(
                    'assets/img/loading.gif',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: 82,
                  ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                ),
              ),
            ),
            Expanded(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Expanded(
                        child: Text(
                      restaurant.name,
                      style: Theme.of(context).textTheme.headline4,
                    )),
                    SizedBox(height: 2),
                    /*InkWell(
                        onTap: () {
                          Navigator.of(context).pushNamed('/Menu',
                              arguments: new RouteArgument(id: restaurant.id));
                        },
                        child: Container(
                          margin:
                              EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                          padding:
                              EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                          decoration: BoxDecoration(
                              color: config.Colors().mainColor(1),
                              borderRadius: BorderRadius.circular(24)),
                          child: Text(
                            S.of(context).see_menu,
                            style: TextStyle(
                                color: Theme.of(context).primaryColor),
                          ),
                        )),*/
                    /*Row(
                      children: Helper.getStarsList(double.parse(restaurant.rate)),
                    ),*/
                  ],
                ),
              ),
            )
          ],
        ),
        //)
      ),
    );
  }
}
