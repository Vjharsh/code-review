import 'package:flutter/material.dart';
import '../helpers/app_config.dart' as config;
import '../helpers/helper.dart';
import '../models/extra.dart';

class ExtraGridItemWidget extends StatefulWidget {
  final Extra extra;
  final int index;
  final Function(int,bool) onChanged;
  final Function(String limitQty) onQtyAlert;
  ExtraGridItemWidget({
    Key? key,
    required this.extra,
    required this.index,
    required this.onChanged,
    required this.onQtyAlert
  }) : super(key: key);

  @override
  ExtraGridItemWidgetState createState() => ExtraGridItemWidgetState();
}

class ExtraGridItemWidgetState extends State<ExtraGridItemWidget> {

  @override
  void initState() {
    super.initState();
    setState(() {
      widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  incrementQuantity() {
    if(widget.extra.qtyEnable == '1') {
      if (int.parse('${widget.extra.qty.toStringAsFixed(0)}') <
          int.parse(widget.extra.limitQty)) {
        setState(() {
          ++widget.extra.qty;
          widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
          widget.onChanged(widget.index, false);
        });
        //calculateSubtotal();
      } else {
        widget.onQtyAlert(widget.extra.limitQty);
      }
    }else {
      setState(() {
        ++widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged(widget.index, false);
      });
    }
  }

  decrementQuantity() {
    if (widget.extra.qty > 1) {
      setState(() {
        --widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged(widget.index,false);
      });
      //calculateSubtotal();
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        widget.extra.checked = !widget.extra.checked;
        widget.onChanged(widget.index, widget.extra.checked);
      },
      child: Container(
          padding: EdgeInsets.all(5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(10)),
              color:  widget.extra.checked ?  config.Colors().mainColor(1).withOpacity(0.3):Colors.grey[300]?.withOpacity(0.4),
              border: Border.all(color: widget.extra.checked ?  config.Colors().mainColor(1).withOpacity(0.7): Colors.grey[300]!)),
          // margin: EdgeInsets.all(5),
          child:
            Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text(widget.extra.name,
                  textAlign: TextAlign.center,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .headline4!
                      .merge(TextStyle(fontSize: 18))),
              /* Stack(
                alignment: AlignmentDirectional.center,
                children: <Widget>[
                  RawChip(
                    elevation: 0,
                    label: Text(widget.extra?.name,textAlign: TextAlign.center,softWrap: true,maxLines: 2,overflow: TextOverflow.ellipsis,),
                    labelStyle: widget.extra.checked
                        ? Theme.of(context)
                        .textTheme
                        .bodyText2
                        .merge(TextStyle(
                        color: Theme.of(context)
                            .primaryColor))
                        : Theme.of(context)
                        .textTheme
                        .bodyText2,
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    backgroundColor: Colors.grey[300],
                    selectedColor:  Theme.of(context).secondaryHeaderColor,
                    selected:  widget.extra.checked,
                    // shape: StadiumBorder(side: BorderSide(width: 2,color: widget.extra.checked ? config.Colors().mainColor(0.5): Theme.of(context).focusColor.withOpacity(0.05))),
                    showCheckmark:  false,
                    onSelected: (value) {
                      widget.extra.checked = !widget.extra.checked;
                      widget.onChanged(widget.index, widget.extra.checked);
                    },
                  ),
                ],
              ),*/
              if (widget.extra.checked)
                SizedBox(height: 10),
              if (widget.extra.checked && widget.extra.totalPrice > 0)
                Helper.getPrice(widget.extra.totalPrice, context,
                    style: Theme.of(context)
                        .textTheme
                        .headline4!
                        .merge(TextStyle(fontSize: 13))),
              if (widget.extra.checked &&
                  widget.extra.extra_group_is_active == "1")
                SizedBox(height: 10),
              if (widget.extra.checked &&
                  widget.extra.extra_group_is_active == "1")
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: InkWell(
                        onTap: () {
                          decrementQuantity();
                        },
                        child: Icon(
                          Icons.remove_circle_outline,
                          size: 30,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 5, right: 5),
                      child: Text(widget.extra.qty.toStringAsFixed(0).toString(),
                          textAlign: TextAlign.center,
                          style: Theme.of(context)
                              .textTheme
                              .headline3!
                              .merge(TextStyle(fontSize: 17))),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(5),
                      child: InkWell(
                        onTap: () {
                          incrementQuantity();
                        },
                        child: Icon(
                          Icons.add_circle_outline,
                          size: 30,
                          color: Theme.of(context).hintColor,
                        ),
                      ),
                    )
                  ],
                ),
            ],
            //)
          )),
    );
  }
}
