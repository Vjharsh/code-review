import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;

// ignore: must_be_immutable
class CuisinesGridItemWidget extends StatefulWidget {
  Cuisine cuisine;
  String heroTag;
  VoidCallback onPressed;

  CuisinesGridItemWidget({
    Key? key,
    required this.heroTag,
    required this.cuisine,
    required this.onPressed})
      : super(key: key);

  @override
  CuisinesGridItemWidgetState createState() => CuisinesGridItemWidgetState();
}

class CuisinesGridItemWidgetState extends State<CuisinesGridItemWidget> {
  late Cuisine cuisine;
  late VoidCallback onPressed;

  @override
  void initState() {
    super.initState();
    this.cuisine = widget.cuisine;
    this.onPressed = widget.onPressed;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
        highlightColor: Colors.transparent,
        splashColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.08),
        onTap: () {
          onPressed();
        },
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(
                  color: cuisine.selected
                      ? config.Colors().mainColor(1)
                      : Colors.white,
                  width: 3),
              borderRadius: BorderRadius.all(Radius.circular(7))),
          child: Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                // Image of the card
                Hero(
//                    tag: widget.heroTag + restaurant.id,
                  tag: Random().nextInt(10000),
                  child: ClipRRect(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(5),
                      topRight: Radius.circular(5),
                    ),
                    child: CachedNetworkImage(
                      width: double.infinity,
                      height: 80,
                      fit: BoxFit.cover,
                      imageUrl: cuisine.image.thumb,
                      placeholder: (context, url) => Image.asset(
                        'assets/img/loading.gif',
                        fit: BoxFit.fill,
                        width: double.infinity,
                        height: 80,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    ),
                  ),
                ),
//                SizedBox(height: 2),
                Expanded(
                    child: Center(
                        child: Padding(
                  padding: const EdgeInsets.only(left: 2, right: 2),
                  child: Text(
                    cuisine.name,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headline2!.merge(
                        TextStyle(
                            fontSize: 20, color: Theme.of(context).hintColor)),
                  ),
                ))),
                /*Expanded(
                    child: Center(
                        child: Theme(
                            data: Theme.of(context).copyWith(
                              unselectedWidgetColor: config.Colors().mainColor(1),
                            ),
                            child: Checkbox(
                              value: cuisine.selected,
                              onChanged: (bool selected) {
                                onPressed();
                              },
                            )))),*/
                // SizedBox(height: 5),
              ],
            ),
          ),
        ));
  }
}
