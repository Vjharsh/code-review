import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import '../models/cuisine.dart';

// ignore: must_be_immutable
class CategoriesFilterListItem extends StatelessWidget {
  String heroTag;
  Cuisine cuisine;
  int position;
  VoidCallback onPressed;

  CategoriesFilterListItem(
      {Key? key,
        required this.heroTag,
        required this.cuisine,
        required this.position,
        required this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Theme.of(context).secondaryHeaderColor,
      focusColor: Theme.of(context).secondaryHeaderColor,
      highlightColor: Theme.of(context).primaryColor,
      onTap: () {
        onPressed();
      },
      child: Container(
        padding: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(0.9),
          boxShadow: [
            BoxShadow(
                color: Theme.of(context).focusColor.withOpacity(0.1),
                blurRadius: 10,
                offset: Offset(0, 2)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Checkbox(
              value: cuisine.selected,
              onChanged: (bool? selected) {
                onPressed();
              },
            ),
            position > 0
                ? Hero(
                    tag: heroTag + cuisine.id,
                    child: Container(
                      height: 60,
                      width: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                        image: DecorationImage(
                            image: NetworkImage(cuisine.image.thumb),
                            fit: BoxFit.cover),
                      ),
                    ),
                  )
                : Container(),
            SizedBox(width: 15),
            Flexible(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          cuisine.name,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: Theme.of(context)
                              .textTheme
                              .headline2!
                              .merge(TextStyle(fontSize: 20)),
                        ),
                        position > 0
                            ? Text(
                                '${Helper.skipHtml(cuisine.description)}',
                                overflow: TextOverflow.fade,
                                softWrap: true,
                                style: Theme.of(context)
                                    .textTheme
                                    .headline1!
                                    .merge(TextStyle(fontSize: 15)),
                              )
                            : Container(),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
