import 'package:flutter/material.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../elements/GridItemWidget.dart';
import '../models/restaurant.dart';
import '../repository/settings_repository.dart' as settingRepo;
import'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class GridWidget extends StatefulWidget {
  final List<Restaurant> restaurantsList;
  final String heroTag;
  final VoidCallback callback;
  GridWidget({Key? key,
    required this.restaurantsList,
    required this.heroTag,
    required this.callback});

  @override
  State<StatefulWidget> createState() => GridWidgetState();
}

class GridWidgetState extends StateMVC<GridWidget> {
  @override
  void initState() {
    super.initState();
    //print('GridWidgetState initState');
    settingRepo.animationLooper.value = 0;
  }
  @override
  Widget build(BuildContext context) {
    //print('GridWidgetState BuildContext');
    return StaggeredGrid.count(
     // primary: false,
     //  shrinkWrap: true,
      crossAxisCount: 4,
      mainAxisSpacing: 15.0,
      crossAxisSpacing: 15.0,
      // primary: false,
     // shrinkWrap: true,
        children: buildGrid(widget.restaurantsList),

      /*itemCount: widget.restaurantsList.length,
       itemBuilder: (BuildContext context, int index) {
        return GridItemWidget(
          restaurant: widget.restaurantsList.elementAt(index),
          heroTag: widget.heroTag,
          index: index,
          total: widget.restaurantsList.length, callback: () {  }, finishAnimation: () {  },

          *//*callback: (){
            widget.callback();
          },*//*
        );
      },*/
//                  staggeredTileBuilder: (int index) => new StaggeredTile.fit(index % 2 == 0 ? 1 : 2),
//         staggeredTileBuilder: (MediaQuery.of(context).orientation == Orientation.portrait ? 2 : 4)
//       staggeredTileBuilder: (int index) => new StaggeredTile.fit(
//           MediaQuery.of(context).orientation == Orientation.portrait ? 2 : 4),
//       mainAxisSpacing: 15.0,
//       crossAxisSpacing: 15.0,
    );
  }

  List<Widget> buildGrid(List<Restaurant> restaurant) {
    List<Widget> _gridItems = [];

    for(int i=0; i<restaurant.length;i++){
      _gridItems.add(GridItemWidget(
        restaurant: widget.restaurantsList.elementAt(i),
        heroTag: widget.heroTag,
        index: i,
        total: widget.restaurantsList.length, callback: () {  }, finishAnimation: () {  },
      ));
    }

    return _gridItems;
  }
}


