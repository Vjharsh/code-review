import 'package:android_intent/android_intent.dart';
import 'package:app_settings/app_settings.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:geolocator/geolocator.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io' show Platform;
import '../../generated/l10n.dart';
import '../helpers/helper.dart';
import '../models/restaurant.dart';
import '../models/route_argument.dart';
import 'package:location/location.dart' as LatLong;
import '../helpers/app_config.dart' as config;

// ignore: must_be_immutable
class CardWidget extends StatefulWidget {
  Restaurant restaurant;
  String heroTag;
  VoidCallback onDirectionPress;
  bool isForAppMapDirection;
  bool isDeliveryTime;

  CardWidget(
      {Key? key,
      required this.restaurant,
      required this.heroTag,
      required this.isForAppMapDirection,
      required this.isDeliveryTime,
      required this.onDirectionPress})
      : super(key: key);

  @override
  CardWidgetState createState() => CardWidgetState();
}

class CardWidgetState extends State<CardWidget> with TickerProviderStateMixin {
  late Restaurant restaurant;
  late LatLong.LocationData currentLocation;
  bool isLoadingCurrentlocation = false;

  late AnimationController _controller;
  Tween<double> _selectedTween = Tween(begin: 1, end: 1.15);

  @override
  void initState() {
    super.initState();
    this.restaurant = widget.restaurant;
    /*_controller =
        AnimationController(duration: const Duration(seconds: 2), vsync: this);
    _controller
      ..addStatusListener((AnimationStatus status) {
        if (status == AnimationStatus.completed) {
          _controller.reverse();
        }
      });
    _controller.forward();*/
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
        children: [
          Container(
            // width: 300,
            margin: EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 20),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              boxShadow: [
                BoxShadow(
                    color: Theme.of(context).focusColor.withOpacity(0.1),
                    blurRadius: 15,
                    offset: Offset(0, 5)),
              ],
            ),
            child: Wrap(
              //mainAxisAlignment: MainAxisAlignment.start,
              //mainAxisSize: MainAxisSize.max,
              //crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                // Image of the card
                Stack(
                  fit: StackFit.loose,
                  alignment: AlignmentDirectional.bottomStart,
                  children: <Widget>[
                    Hero(
                      tag: widget.heroTag + restaurant.id,
                      child: ClipRRect(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                        child: CachedNetworkImage(
                          height: 200,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          imageUrl: restaurant.image.url,
                          placeholder: (context, url) => Image.asset(
                            'assets/img/loading.gif',
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: 150,
                          ),
                          errorWidget: (context, url, error) =>
                              Icon(Icons.error),
                        ),
                      ),
                    ),
                    Row(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(right: 12, top: 8, bottom: 8, left: 10),
                          padding:
                              EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                          decoration: BoxDecoration(
                              color: !restaurant.resOpeningStatus
                                  ? Colors.grey
                                  : Colors.green,
                              borderRadius: BorderRadius.circular(24)),
                          child: !restaurant.resOpeningStatus
                              ? Text(
                                  S.of(context).closed,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption!
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                )
                              : Text(
                                  S.of(context).open,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption!
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 8),
                          padding: EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                          decoration: BoxDecoration(
                              color: widget.isDeliveryTime && restaurant.resOpeningStatus
                                  ? Colors.green : Colors.grey,
                              borderRadius: BorderRadius.circular(24)),
                          child: Text(
                                  widget.isDeliveryTime && restaurant.resOpeningStatus ? S.of(context).openForDeliveries : S.of(context).closedForDeliveries,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption!
                                      .merge(TextStyle(
                                          color: Theme.of(context).primaryColor)),
                                ),
                        ),/*
                        Container(
                          margin:
                              EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                          padding:
                              EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                          decoration: BoxDecoration(
                              color: *//*Helper.canDelivery(restaurant)
                                  ? Colors.green
                                  : Colors.orange,*//*Colors.green,
                              borderRadius: BorderRadius.circular(24)),
                          child: *//*Helper.canDelivery(restaurant)
                              ? Text(
                                  S.of(context).delivery,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                )
                              : Text(
                                  S.of(context).pickup,
                                  style: Theme.of(context)
                                      .textTheme
                                      .caption
                                      .merge(TextStyle(
                                          color:
                                              Theme.of(context).primaryColor)),
                                ),*//*Text(
                            S.of(context).delivery,
                            style: Theme.of(context)
                                .textTheme
                                .caption
                                .merge(TextStyle(
                                color:
                                Theme.of(context).primaryColor)),
                          )
                        ),*/
                      ],
                    ),
                  ],
                ),
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Expanded(
                        flex: 3,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(height: 4),
                            /*Text(
                          restaurant.name,
                          overflow: TextOverflow.visible,
                          softWrap: true,
                          maxLines: 2,
                          style: Theme.of(context).textTheme.headline4,
                        ),*/
                            Container(
                              height: 30,
                              child: AutoSizeText(
                                restaurant.name,
                                style: Theme.of(context).textTheme.headline4,
                                maxLines: 1,
                                // minFontSize: 22,
                                overflow: TextOverflow.visible,
                              ),
                            ),
                            Container(
                                height: 30,
                                margin: EdgeInsets.only(top: 0),
                                child: AutoSizeText(
                                  Helper.skipHtml(restaurant.shortDescription),
                                  style: Theme.of(context).textTheme.subtitle1,
                                  maxLines: 2,
                                  overflow: TextOverflow.visible,
                                )),
                            /*Text(
                          Helper.skipHtml(restaurant.shortDescription),
                          overflow: TextOverflow.ellipsis,
                          softWrap: true,
                          maxLines: 2,
                          style: Theme.of(context).textTheme.bodyText2,
                        ),*/
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      /*Expanded(
                        child: Column(
                          children: <Widget>[
                            isLoadingCurrentlocation
                                ? Container(
                                    height: 30,
                                    width: 30,
                                    child: CircularLoadingWidget(
                                      height: 30,
                                    ))
                                : FlatButton(
                                    padding: EdgeInsets.all(0),
                                    onPressed: () {
                                      openMapsSheet(
                                          context,
                                          double.parse(
                                              widget.restaurant.latitude),
                                          double.parse(
                                              widget.restaurant.longitude),
                                          widget.restaurant.name);
                                    },
                                    child: Icon(Icons.directions,
                                        color: Theme.of(context).primaryColor),
                                    color: Theme.of(context).secondaryHeaderColor,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(5)),
                                  ),
                          ],
                        ),
                      ),*/
                    ],
                  ),
                ),
                // SizedBox(height: 5),
                /*Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                    child: Row(
                      children: [
                        InkWell(
                            onTap: () {
                              Navigator.of(context).pushNamed('/Menu',
                                  arguments: new RouteArgument(
                                      id: widget.restaurant.id));
                            },
                            child: Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: 0, vertical: 5),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 13, vertical: 3),
                              decoration: BoxDecoration(
                                  color: config.Colors().mainColor(1),
                                  borderRadius: BorderRadius.circular(24)),
                              child: Text(
                                S.of(context).see_menu,
                                style: TextStyle(
                                    color: Theme.of(context).primaryColor),
                              ),
                            )),
                      ],
                    ),
                  ),
                ),*/
              ],
            ),
          ),
          if (restaurant.freeShipping)
            Align(
              alignment: Alignment.topRight,
              child: Container(
                margin: EdgeInsets.only(top: 20, right: 0),
                child: Stack(
                  children: [
                    Image.asset(
                      'assets/img/tag.png',
                      width: 170,
                      height: 50,
                    ),
                    Container(
                      margin: EdgeInsets.only(right: 25),
                      child: Text(
                        'משלוח חינם',
                        style: Theme.of(context).textTheme.headline3!.merge(
                            TextStyle(color: Theme.of(context).primaryColor)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  void getCurrentLocation() async {
    try {
      setState(() {
        isLoadingCurrentlocation = true;
      });
      Geolocator
          .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
          .then((position) async {
        if (position != null) {
          setState(() {
            isLoadingCurrentlocation = false;
          });
          currentLocation = LatLong.LocationData.fromMap(
              {"latitude": position.latitude, "longitude": position.longitude});
          goToMapExplore();
        }
      });
    } on Exception catch (e) {
      setState(() {
        isLoadingCurrentlocation = false;
      });
      print('Permission denied:${e}');
    }
  }

  void locationEnableAlert() {
    Alert(
      context: context,
      type: AlertType.warning,
      title: S.of(context).alert_location_service_title,
      desc: S.of(context).alert_location_service_message,
      style: AlertStyle(
          titleStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(context)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(context).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(context);
            //LocationPermissions().openAppSettings();
            AppSettings.openLocationSettings();
          },
        )
      ],
    ).show();
  }

  void checkLocationPermission() async {
    var geolocationStatus =
        await Geolocator.checkPermission();
    print('geolocationStatus.value:$geolocationStatus');
    if (geolocationStatus != LocationPermission.whileInUse) {
      requestLocationPermission();
    } else {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      } else {
        locationEnableAlert();
      }
    }
  }

  Future<bool> requestLocationPermission() async {
    return _requestPermission();
  }

  Future<bool> _requestPermission() async {
    print('_requestPermission');
    //var result = await LocationPermissions().requestPermissions();
    var result = await Geolocator.requestPermission();
    if (result == LocationPermission.whileInUse) {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      } else {
        locationEnableAlert();
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        locationEnableAlert();
      } else {
        Alert(
          context: context,
          type: AlertType.warning,
          title: S.of(context).alert_location_service_permission_title,
          desc: S.of(context).alert_location_service_permission_message,
          style: AlertStyle(
              titleStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 18)),
              descStyle: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 16))),
          buttons: [
            DialogButton(
              child: Text(
                S.of(context).alert_location_service_btn,
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () {
                Navigator.pop(context);
             //   LocationPermissions().openAppSettings();
                Geolocator.openAppSettings();
              },
            )
          ],
        ).show();
      }
      //}
    }
    return false;
  }

  void goToMapExplore() async {
    String url = "https://www.google.com/maps/dir/?api=1&origin=" +
        "${currentLocation.latitude},${currentLocation.longitude}" +
        "&destination=" +
        restaurant.latitude +
        "," +
        restaurant.longitude +
        "&travelmode=driving&dir_action=navigate";
    print('redirect URL: $url');
    if (Platform.isAndroid) {
      AndroidIntent intent = AndroidIntent(
          action: 'action_view',
          data: Uri.encodeFull(url),
          package: 'com.google.android.apps.maps');
      intent.launch();
    } else {
      if (await canLaunch("comgooglemaps://")) {
        await launch(
            "comgooglemaps://?saddr=${currentLocation.latitude},${currentLocation.longitude}&directionsmode=driving");
      } else {
        throw 'Could not launch';
      }
    }
  }

  openMapsSheet(context, lat, long, title) async {
    try {
      final coords = Coords(lat, long);
      final availableMaps = await MapLauncher.installedMaps;

      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
            child: SingleChildScrollView(
              child: Container(
                child: Wrap(
                  children: <Widget>[
                    for (var map in availableMaps)
                      ListTile(
                        onTap: () => map.showMarker(
                          coords: coords,
                          title: title,
                        ),
                        title: Text(map.mapName),
                        leading: Image.asset(
                          map.icon,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    } catch (e) {
      print(e);
    }
  }
}
