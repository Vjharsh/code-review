import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';

// ignore: must_be_immutable
class CardFoodCategoryWidget extends StatefulWidget {
  Cuisine cuisine;

  CardFoodCategoryWidget({Key? key, required this.cuisine}) : super(key: key);

  @override
  CardFoodCategoryWidgetState createState() => CardFoodCategoryWidgetState();
}

class CardFoodCategoryWidgetState extends State<CardFoodCategoryWidget>
    with TickerProviderStateMixin {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.08),
      highlightColor: Colors.transparent,
      onTap: () {
        print('cuisine id:${widget.cuisine.id}');
        Navigator.of(context).pushNamed('/RestaurantsByCuisine',
            arguments: RouteArgument(
                id: widget.cuisine.id, param: widget.cuisine.name));
      },
      child:  Container(
        height: 250,
        margin: EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 20),
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor,
          borderRadius: BorderRadius.all(Radius.circular(10)),
          boxShadow: [
            BoxShadow(
                color: Theme.of(context).focusColor.withOpacity(0.1),
                blurRadius: 15,
                offset: Offset(0, 5)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // Image of the card
            Stack(
              fit: StackFit.loose,
              alignment: AlignmentDirectional.bottomStart,
              children: <Widget>[
                ClipRRect(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10)),
                  child: CachedNetworkImage(
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.contain,
                    imageUrl: widget.cuisine.image.url,
                    placeholder: (context, url) => Image.asset(
                      'assets/img/loading.gif',
                      fit: BoxFit.cover,
                      width: double.infinity,
                      height: 150,
                    ),
                    errorWidget: (context, url, error) =>
                        Icon(Icons.error),
                  ),
                ),
              ],
            ),
            Container(
              alignment: Alignment.center,
              height: 30,
              child: AutoSizeText(
                widget.cuisine.name,
                style: Theme.of(context).textTheme.headline4,
                maxLines: 1,
                // minFontSize: 22,
                overflow: TextOverflow.visible,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
