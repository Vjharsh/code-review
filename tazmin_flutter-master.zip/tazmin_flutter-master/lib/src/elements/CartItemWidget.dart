import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import '../repository/settings_repository.dart' as settingsRepo;
import '../helpers/helper.dart';
import '../models/cart.dart';
import '../models/route_argument.dart';

// ignore: must_be_immutable
class CartItemWidget extends StatefulWidget {
  String heroTag;
  Cart cart;
  VoidCallback increment;
  VoidCallback decrement;
  VoidCallback onDismissed;

  CartItemWidget(
      {Key? key,
      required this.cart,
      required this.heroTag,
      required this.increment,
      required this.decrement,
      required this.onDismissed})
      : super(key: key);

  @override
  _CartItemWidgetState createState() => _CartItemWidgetState();
}

class _CartItemWidgetState extends State<CartItemWidget> {
  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(widget.cart.id),
      onDismissed: (direction) {
        setState(() {
          widget.onDismissed();
        });
      },
      child: InkWell(
        splashColor: Theme.of(context).secondaryHeaderColor,
        focusColor: Theme.of(context).secondaryHeaderColor,
        highlightColor: Theme.of(context).primaryColor,
        onTap: () {
          Navigator.of(context).pushNamed('/Food',
              arguments: RouteArgument(
                  id: widget.cart.food.id, heroTag: widget.heroTag));
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 7),
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withOpacity(0.9),
            boxShadow: [
              BoxShadow(
                  color: Theme.of(context).focusColor.withOpacity(0.1),
                  blurRadius: 5,
                  offset: Offset(0, 2)),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                child: CachedNetworkImage(
                  height: 90,
                  width: 90,
                  fit: BoxFit.cover,
                  imageUrl: widget.cart.food.image.thumb,
                  placeholder: (context, url) => Image.asset(
                    'assets/img/loading.gif',
                    fit: BoxFit.cover,
                    height: 90,
                    width: 90,
                  ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                ),
              ),
              SizedBox(width: 15),
              Flexible(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            widget.cart.food.name,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                            style: Theme.of(context).textTheme.subtitle1,
                          ),
                          Helper.getPrice(widget.cart.food.price, context,
                              style: Theme.of(context).textTheme.headline3),
                          /*Wrap(
                            children: List.generate(widget.cart.extras.length,
                                (index) {
                              var pizzaExtraStr = widget.cart.extras
                                  .elementAt(index)
                                  .name
                                  .toString() +
                                  '(' +
                                  settingsRepo.setting.value.defaultCurrency +
                                  widget.cart.extras
                                      .elementAt(index)
                                      .extraPivot
                                      .extra_price
                                      .toString() +
                                  '*' +
                                  widget.cart.extras
                                      .elementAt(index)
                                      .extraPivot
                                      .extra_qty
                                      .toString() +
                                  ')' +
                                  ', ';
                              var extraStr = widget.cart.extras.elementAt(index).name +
                                  '(' +
                                  settingsRepo.setting.value.defaultCurrency +
                                  widget.cart.extras
                                      .elementAt(index)
                                      .extraPivot
                                      .extra_price
                                      .toString() +
                                  '*' +
                                  widget.cart.extras
                                      .elementAt(index)
                                      .extraPivot
                                      .extra_qty
                                      .toString() +
                                  ')' +
                                  ', ';
                              return Text(
                                widget.cart.extras.elementAt(index).extraPivot.pizza_status ==  '1' ? pizzaExtraStr :extraStr,
                                style: Theme.of(context).textTheme.caption,
                              );
                            }),
                          ),*/
                          /*Wrap(
                            children: List.generate(widget.cart.extras.length,
                                    (index) {
                                  var extraStr = widget.cart.extras.elementAt(index).name.toString() +
                                      '(' +
                                      settingsRepo.setting.value.defaultCurrency +
                                      widget.cart.extras
                                          .elementAt(index)
                                          .extraPivot
                                          .extra_price
                                          .toString() +
                                      '*' +
                                      widget.cart.extras
                                          .elementAt(index)
                                          .extraPivot
                                          .extra_qty
                                          .toString() +
                                      ')' +
                                      ', ';
                                  return Text(
                                    // widget.cart.extras.elementAt(index).extraPivot.pizza_status ==  '1' ? pizzaExtraStr :extraStr,
                                    extraStr,
                                    style: Theme.of(context).textTheme.caption,
                                  );
                                }),
                          ),*/
                          if(widget.cart.extrasOrderByGroup.isNotEmpty && widget.cart.extrasOrderByGroup != '<p><br><\/p>')Helper.applyHtml(
                              context, widget.cart.extrasOrderByGroup,
                              style: Theme.of(context).textTheme.caption),
                          if (widget.cart.extraGroup.isNotEmpty)
                            SizedBox(
                              height: 5,
                            ),
                          if (widget.cart.extraGroup.isNotEmpty)
                            Row(
                              children: <Widget>[
                                Text(
                                  S.of(context).total_extras,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline6!
                                      .merge(TextStyle(fontSize: 13)),
                                ),
                                Text(
                                  ':',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline6!
                                      .merge(TextStyle(fontSize: 13)),
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Helper.getPrice(
                                    Helper.getTotalCartExtraPrice(widget.cart),
                                    context,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6!
                                        .merge(TextStyle(fontSize: 13)))
                              ],
                            ),
                          if (widget.cart.extraGroup.isNotEmpty)
                            SizedBox(
                              height: 5,
                            ),
                          if (widget.cart.extraGroup.isNotEmpty)
                            Row(
                              children: <Widget>[
                                Text(
                                  S.of(context).subtotal,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline6!
                                      .merge(TextStyle(fontSize: 13)),
                                ),
                                Text(
                                  ':',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headline6!
                                      .merge(TextStyle(fontSize: 13)),
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Helper.getPrice(
                                    Helper.getTotalCartPrice(widget.cart),
                                    context,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headline6!
                                        .merge(TextStyle(fontSize: 13)))
                              ],
                            ),
                          /*Text(
                            // widget.cart.extras.elementAt(index).extraPivot.pizza_status ==  '1' ? pizzaExtraStr :extraStr,
                            widget.cart.extrasOrderByGroup,
                            style: Theme.of(context).textTheme.caption,
                          )*/
                        ],
                      ),
                    ),
                    SizedBox(width: 5),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        IconButton(
                          onPressed: () {
                            setState(() {
                              widget.increment();
                            });
                          },
                          iconSize: 30,
                          padding: EdgeInsets.symmetric(horizontal: 5),
                          icon: Icon(Icons.add_circle_outline),
                          color: Theme.of(context).hintColor,
                        ),
                        Text(widget.cart.quantity.toString(),
                            style: Theme.of(context).textTheme.subtitle1),
                        IconButton(
                          onPressed: () {
                            setState(() {
                              widget.decrement();
                            });
                          },
                          iconSize: 30,
                          padding: EdgeInsets.symmetric(horizontal: 5),
                          icon: Icon(Icons.remove_circle_outline),
                          color: Theme.of(context).hintColor,
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        IconButton(
                          onPressed: () {
                            widget.onDismissed();
                          },
                          iconSize: 27,
                          padding: EdgeInsets.symmetric(horizontal: 1),
                          icon: Icon(Icons.delete),
                          color: Theme.of(context).hintColor,
                        ),
                        IconButton(
                          onPressed: () {
                            Navigator.of(context).pushReplacementNamed('/Food',
                                arguments: RouteArgument(
                                    id: widget.cart.food.id,
                                    heroTag: widget.heroTag,
                                    param: widget.cart));
                          },
                          iconSize: 27,
                          padding: EdgeInsets.symmetric(horizontal: 1),
                          icon: Icon(Icons.edit),
                          color: Theme.of(context).hintColor,
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
