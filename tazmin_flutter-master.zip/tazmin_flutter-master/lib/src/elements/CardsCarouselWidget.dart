import 'package:flutter/material.dart';
import '../models/restaurant.dart';
import '../models/route_argument.dart';
import 'CardWidget.dart';

// ignore: must_be_immutable
class CardsCarouselWidget extends StatefulWidget {
  List<Restaurant> restaurantsList;
  String heroTag;
  bool isForAppMapDirection;
  bool? isDeliveryTime;
  VoidCallback? onDirectionPress;

  CardsCarouselWidget(
      {Key? key,
      required this.restaurantsList,
      required this.heroTag,
      required this.isForAppMapDirection,
       this.isDeliveryTime,
       this.onDirectionPress})
      : super(key: key);

  @override
  _CardsCarouselWidgetState createState() => _CardsCarouselWidgetState();
}

class _CardsCarouselWidgetState extends State<CardsCarouselWidget> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return widget.isForAppMapDirection
        ? widget.restaurantsList.isEmpty
            ? SizedBox(height: 0)
            // ? CardsCarouselHorLoaderWidget()
            : ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: widget.restaurantsList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed('/Details',
                          arguments: RouteArgument(
                            id: widget.restaurantsList.elementAt(index).id,
                            heroTag: widget.heroTag,
                          ));
                    },
                    child: CardWidget(
                      restaurant: widget.restaurantsList.elementAt(index),
                      heroTag: widget.heroTag,
                      isForAppMapDirection: widget.isForAppMapDirection,
                      onDirectionPress: () {
                        widget.onDirectionPress!();
                      },
                      isDeliveryTime: widget.isDeliveryTime!,
                    ),
                  );
                },
              )
        : widget.restaurantsList.isEmpty
            // ? CardsCarouselLoaderWidget()
            ? SizedBox(height: 0)
            : ListView.builder(
                shrinkWrap: true,
                primary: false,
                physics: NeverScrollableScrollPhysics(),
                scrollDirection: Axis.vertical,
                itemCount: widget.restaurantsList.length,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed('/Details',
                          arguments: RouteArgument(
                            id: widget.restaurantsList.elementAt(index).id,
                            heroTag: widget.heroTag,
                          ));
                    },
                    child: CardWidget(
                      restaurant: widget.restaurantsList.elementAt(index),
                      heroTag: widget.heroTag,
                      isForAppMapDirection: widget.isForAppMapDirection,
                      onDirectionPress: () {
                        widget.onDirectionPress!();
                      },
                      isDeliveryTime: widget.isDeliveryTime!,
                    ),
                  );
                },
              );
  }
}
