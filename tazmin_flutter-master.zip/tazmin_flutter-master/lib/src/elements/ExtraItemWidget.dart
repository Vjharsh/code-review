import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../helpers/helper.dart';
import '../models/extra.dart';

class ExtraItemWidget extends StatefulWidget {
  final Extra extra;
  final VoidCallback onChanged;

  ExtraItemWidget({
    Key? key,
    required this.extra,
    required this.onChanged,
  }) : super(key: key);

  @override
  _ExtraItemWidgetState createState() => _ExtraItemWidgetState();
}

class _ExtraItemWidgetState extends State<ExtraItemWidget>
    with SingleTickerProviderStateMixin {
  late Animation animation;
  late AnimationController animationController;
  late Animation<double> sizeCheckAnimation;
  late Animation<double> rotateCheckAnimation;
  late Animation<double> opacityAnimation;
  late Animation opacityCheckAnimation;

  @override
  void initState() {
    super.initState();
    animationController =
        AnimationController(duration: Duration(milliseconds: 350), vsync: this);
    CurvedAnimation curve =
        CurvedAnimation(parent: animationController, curve: Curves.easeOut);
    animation = Tween(begin: 0.0, end: 60.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
    opacityAnimation = Tween(begin: 0.0, end: 0.5).animate(curve)
      ..addListener(() {
        setState(() {});
      });
    opacityCheckAnimation = Tween(begin: 0.0, end: 1.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
    rotateCheckAnimation = Tween(begin: 2.0, end: 0.0).animate(curve)
      ..addListener(() {
        setState(() {});
      });
    sizeCheckAnimation = Tween<double>(begin: 0, end: 36).animate(curve)
      ..addListener(() {
        setState(() {});
      });
    print('widget.extra.checked:${widget.extra.checked}');
    setState(() {
      if (widget.extra.checked) {
        animationController.forward();
      } else {
        animationController.reverse();
      }
      widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
    });
  }

  @override
  void dispose() {
    super.dispose();
    animationController.dispose();
  }

  incrementQuantity() {
    if (widget.extra.qty <= 99) {
      setState(() {
        ++widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged();
      });
      //calculateSubtotal();
    }
  }

  decrementQuantity() {
    if (widget.extra.qty > 1) {
      setState(() {
        --widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged();
      });
      //calculateSubtotal();
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        if (widget.extra.checked) {
          animationController.reverse();
        } else {
          animationController.forward();
        }
        widget.extra.checked = !widget.extra.checked;
        widget.onChanged();
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Stack(
            alignment: AlignmentDirectional.center,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(60)),
                child: CachedNetworkImage(
                  height: 60,
                  width: 60,
                  fit: BoxFit.fill,
                  imageUrl: widget.extra.image.thumb,
                  placeholder: (context, url) => Image.asset(
                    'assets/img/loading.gif',
                    fit: BoxFit.fill,
                    height: 60,
                    width: 60,
                  ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                ),
              ),
              /*Container(
                height: 60,
                width: 60,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(60)),
                  image: DecorationImage(image: NetworkImage(widget.extra.image?.thumb), fit: BoxFit.fill),
                ),
              ),*/
              Container(
                height: animation.value,
                width: animation.value,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(60)),
                  color: Theme.of(context)
                      .secondaryHeaderColor
                      .withOpacity(opacityAnimation.value),
                ),
                child: Transform.rotate(
                  angle: rotateCheckAnimation.value,
                  child: Icon(
                    Icons.check,
                    size: sizeCheckAnimation.value,
                    color: Theme.of(context)
                        .primaryColor
                        .withOpacity(opacityCheckAnimation.value),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(width: 15),
          Flexible(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        widget.extra.name,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: Theme.of(context).textTheme.subtitle1,
                      ),
                      widget.extra.description != null &&
                              widget.extra.description.length > 0 &&
                              widget.extra.description != '<p><br><\/p>' &&
                              widget.extra.description !=
                                  '<p style=\"direction: rtl; \"><br><\/p>' &&
                              widget.extra.description != '<br>'
                          ? Text(
                              Helper.skipHtml(widget.extra.description),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                              style: Theme.of(context).textTheme.caption,
                            )
                          : SizedBox(
                              height: 0,
                            ),
                      Helper.getPrice(widget.extra.price, context,
                          style: Theme.of(context).textTheme.headline4!),
                    ],
                  ),
                ),
                SizedBox(width: 8),
                widget.extra.checked &&
                        widget.extra.extra_group_is_active == "1"
                    ? Column(
                        children: <Widget>[
                          Helper.getPrice(widget.extra.totalPrice, context,
                              style: Theme.of(context).textTheme.headline3!),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              IconButton(
                                onPressed: () {
                                  decrementQuantity();
                                },
                                iconSize: 20,
                                padding: EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 0),
                                icon: Icon(Icons.remove_circle_outline),
                                color: Theme.of(context).hintColor,
                              ),
                              Text(widget.extra.qty.toString(),
                                  style: Theme.of(context).textTheme.subtitle1),
                              IconButton(
                                onPressed: () {
                                  incrementQuantity();
                                },
                                iconSize: 20,
                                padding: EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 0),
                                icon: Icon(Icons.add_circle_outline),
                                color: Theme.of(context).hintColor,
                              )
                            ],
                          ),
                        ],
                      )
                    : Container(),
              ],
            ),
          )
        ],
      ),
    );
  }
}
