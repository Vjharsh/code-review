import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../helpers/helper.dart';
import '../models/food.dart';
import '../models/route_argument.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as config;
import '../../generated/l10n.dart';

//ignore: must_be_immutable
class MenuFoodItemWidget extends StatelessWidget {
  final String heroTag;
  final Food food;
  bool isForCategories;
  MenuFoodItemWidget({Key? key,
    required this.food,
    required this.heroTag,
    required this.isForCategories})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Theme.of(context).secondaryHeaderColor,
      focusColor: Theme.of(context).secondaryHeaderColor,
      highlightColor: Theme.of(context).primaryColor,
      onTap: () {
        Navigator.of(context).pushNamed('/Food',
            arguments: RouteArgument(id: food.id, heroTag: this.heroTag));
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 25, vertical: 10),
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(0.9),
          boxShadow: [
            BoxShadow(
                color: Theme.of(context).focusColor.withOpacity(0.1),
                blurRadius: 5,
                offset: Offset(0, 2)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          mainAxisSize: MainAxisSize.max,
          children: <Widget>[
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Flexible(
                        child: Text(
                          food.name,
                          style: Theme.of(context)
                              .textTheme
                              .headline4!
                              .merge(TextStyle(fontSize: 20)),
                        ),
                      ),
                    ],
                  ),
                  // if(foo.description.isNotEmpty && food.description == '<p style=\"direction: rtl; \"><br><\/p>') SizedBox(height: 5),
                  if(food.description == "") SizedBox(height: 5,),
                  // if(food.description == '<p style=\"direction: rtl; \"><br><\/p>') SizedBox(height: 5,),
                  if(food.description.isNotEmpty) Text(Helper.skipHtml(
                      food.description),
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium!
                        .merge(TextStyle(fontSize: 16)),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  /*SizedBox(height: 5),
                  Text(
                    food.restaurant.name,
                    style: Theme.of(context)
                        .textTheme
                        .headline3
                        .merge(TextStyle(fontSize: 21)),
                  ),*/
                  SizedBox(height: 10),
                  if (food.discountPrice > 0)
                    Container(
                      padding: EdgeInsets.only(
                          left: 20, right: 20, top: 5, bottom: 5),
                      decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.all(Radius.circular(50))),
                      child: Text(
                        S.of(context).sale,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.headline4!.merge(
                            TextStyle(color: Theme.of(context).primaryColor)),
                      ),
                    ),
                  if (food.discountPrice > 0)
                    SizedBox(
                      height: 5,
                    ),
                  Helper.getPrice(food.price, context,
                      style: Theme.of(context)
                          .textTheme
                          .headline5!
                          .merge(TextStyle(fontSize: 20))),
                ],
              ),
            ),
            SizedBox(width: 15),
            Hero(
              tag: heroTag + food.id,
              child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                child: CachedNetworkImage(
                  height: 100,
                  width: 100,
                  fit: isForCategories ? BoxFit.fill : BoxFit.cover,
                  imageUrl: food.image.thumb,
                  placeholder: (context, url) => Image.asset(
                    'assets/img/loading.gif',
                    fit: BoxFit.cover,
                    height: 120,
                    width: 120,
                  ),
                  errorWidget: (context, url, error) => Icon(Icons.error),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
