import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/models/category_with_foods.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'FoodItemWidget.dart';
import 'GridWidgetRestaurantCuisines.dart';
import 'RestaurantsWithCuisinesCardWidget.dart';

class RestaurantsWithCuisinesItemWidget extends StatelessWidget {
  final String heroTag;
  final Cuisine cuisine;

  const RestaurantsWithCuisinesItemWidget({Key? key,
    required this.cuisine,
    required this.heroTag})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('cuisine res size:${cuisine.restaurants.length}');
    return cuisine.restaurants.length > 0 ? Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 10,
        ),
        Padding(
          padding: EdgeInsets.only(left: 20, right: 20),
          child: Text(
            '${cuisine.name}:',
            overflow: TextOverflow.ellipsis,
            maxLines: 2,
            style: Theme.of(context)
                .textTheme
                .headline2!
                .merge(TextStyle(fontSize: 23)),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: GridWidgetRestaurantCuisines(
              heroTag: 'grid_widget_restaurant_cuisines_tag',
              restaurantsList: cuisine.restaurants,
              isForAppMapDirection: false,
              onDirectionPress: (){

              },
            )),
      ],
    ): Container();
  }
}
