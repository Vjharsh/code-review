import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../helpers/helper.dart';
import '../models/food.dart';
import '../models/route_argument.dart';

class FoodsCarouselItemWidget extends StatefulWidget {
  final double marginLeft;
  final Food food;
  final String heroTag;

  FoodsCarouselItemWidget({Key? key,
    required this.heroTag,
    required this.marginLeft,
    required this.food})
      : super(key: key);

  @override
  FoodsCarouselItemWidgetState createState() => FoodsCarouselItemWidgetState();
}

class FoodsCarouselItemWidgetState extends State<FoodsCarouselItemWidget>
    with TickerProviderStateMixin {
  late double marginLeft;
  late Food food;
  late String heroTag;
   late AnimationController _controller;
  Tween<double> _selectedTween = Tween(begin: 1, end: 1.15);

  @override
  void initState() {
    super.initState();
    this.marginLeft = widget.marginLeft;
    this.food = widget.food;
    this.heroTag = widget.heroTag;
    /*_controller =
        AnimationController(duration: const Duration(seconds: 2), vsync: this);
    _controller
      ..addStatusListener((AnimationStatus status) {
        if (status == AnimationStatus.completed) {
          _controller.reverse();
        }
      });
    _controller.forward();*/
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.08),
      highlightColor: Colors.transparent,
      onTap: () {
        Navigator.of(context).pushNamed('/Food',
            arguments: RouteArgument(id: food.id, heroTag: heroTag));
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Stack(
            alignment: AlignmentDirectional.topEnd,
            children: <Widget>[
              Hero(
//                tag: heroTag + food.id,
                tag: Random().nextInt(10000),
                child: Container(
                  margin: EdgeInsetsDirectional.only(
                      start: this.marginLeft, end: 20),
                  width: 100,
                  height: 130,
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(5)),
                    child: CachedNetworkImage(
                      fit: BoxFit.cover,
                      imageUrl: food.image.thumb,
                      placeholder: (context, url) => Image.asset(
                        'assets/img/loading.gif',
                        fit: BoxFit.cover,
                      ),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsetsDirectional.only(end: 25, top: 5),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(100)),
                    color: Theme.of(context).secondaryHeaderColor),
                alignment: AlignmentDirectional.topEnd,
                child: Helper.getPrice(
                  food.price,
                  context,
                  style: Theme.of(context)
                      .textTheme
                      .bodyText1!
                      .merge(TextStyle(color: Theme.of(context).primaryColor)),
                ),
              ),
            ],
          ),
          SizedBox(height: 5),
          Container(
              width: 100,
              margin:
                  EdgeInsetsDirectional.only(start: this.marginLeft, end: 20),
              padding: EdgeInsets.symmetric(horizontal: 2),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  /*ScaleTransition(
                      scale: _selectedTween.animate(CurvedAnimation(
                          parent: _controller, curve: Curves.decelerate)),
                      child:*/ Text(
                        this.food.name,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        softWrap: true,
                        maxLines: 2,
                        style: Theme.of(context).textTheme.bodyText2,
//                      )
          ),
                  Text(
                    food.restaurant.name,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.visible,
                    softWrap: true,
                    maxLines: 2,
                    style: Theme.of(context).textTheme.caption,
                  ),
                ],
              )),
        ],
      ),
    );
  }
}
