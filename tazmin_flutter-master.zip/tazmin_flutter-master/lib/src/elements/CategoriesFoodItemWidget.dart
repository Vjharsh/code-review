import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/MenuFoodItemWidget.dart';
import 'package:food_delivery_app/src/models/category_with_foods.dart';

class CategoriesFoodItemWidget extends StatefulWidget {
  final String heroTag;
  final CategoryWithFoods categoryWithFoods;
  final int index;

  const CategoriesFoodItemWidget(
      {Key? key,
        required this.categoryWithFoods,
        required this.heroTag,
        required this.index})
      : super(key: key);

  @override
  CategoriesFoodItemWidgetState createState() =>
      CategoriesFoodItemWidgetState();
}

class CategoriesFoodItemWidgetState extends State<CategoriesFoodItemWidget>
    with TickerProviderStateMixin {
  late String heroTag;
  late CategoryWithFoods categoryWithFoods;

  @override
  void initState() {
    super.initState();
    this.categoryWithFoods = widget.categoryWithFoods;
    this.heroTag = widget.heroTag;
  }

  @override
  Widget build(BuildContext context) {
    return categoryWithFoods.foods!.length > 0
        ? Column(
            key: categoryWithFoods.key,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              SizedBox(
                height: 25,
              ),
              Padding(
                  padding: EdgeInsets.only(left: 20, right: 20),
                  child: Text(
                    categoryWithFoods.name,
                    style: Theme.of(context)
                        .textTheme
                        .headline4!
                        .merge(TextStyle(fontSize: 24)),
                  )),
              SizedBox(
                height: 20,
              ),
              ListView.separated(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                primary: false,
                itemCount: categoryWithFoods.foods!.length,
                separatorBuilder: (context, index) {
                  return SizedBox(height: 10);
                },
                itemBuilder: (context, index) {
                  return MenuFoodItemWidget(
                    heroTag: 'menu_food_item_widget',
                    food: categoryWithFoods.foods!.elementAt(index),
                    isForCategories: true,
                  );
                },
              ),
            ],
          )
        : Container();
  }
}
