import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/CuisineCategorieslItemWidget.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import '../elements/CircularLoadingWidget.dart';

// ignore: must_be_immutable
class CuisineCategoriesWidget extends StatelessWidget {
  List<Cuisine> cuisines;

  CuisineCategoriesWidget({
    Key? key,
    required this.cuisines}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return this.cuisines.isEmpty
        ? CircularLoadingWidget(height: 200)
        : Container(
            height: 140,
            padding: EdgeInsets.symmetric(vertical: 10),
            child: ListView.builder(
              itemCount: this.cuisines.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                double _marginLeft = 0;
                (index == 0) ? _marginLeft = 20 : _marginLeft = 0;
                return new CuisineCategoriesItemWidget(
                  marginLeft: _marginLeft,
                  cuisine: this.cuisines.elementAt(index),
                );
              },
            ));
  }
}
