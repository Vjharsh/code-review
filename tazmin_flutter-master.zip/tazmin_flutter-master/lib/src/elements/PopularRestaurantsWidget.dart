import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/CardHorizontalWidget.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../models/restaurant.dart';
import '../repository/settings_repository.dart' as settingRepo;

class PopularRestaurantsWidget extends StatefulWidget {
  final List<Restaurant> restaurantsList;
  final String heroTag;
  final VoidCallback callback;
  bool isDeliveryTime;

  PopularRestaurantsWidget(
      {Key? key,
        required this.restaurantsList,
        required this.heroTag,
        required this.callback,
        required this.isDeliveryTime});

  @override
  State<StatefulWidget> createState() => PopularRestaurantsWidgetState();
}

class PopularRestaurantsWidgetState extends StateMVC<PopularRestaurantsWidget> {
  @override
  void initState() {
    super.initState();
    print('widget.restaurantsList.length:${widget.restaurantsList.length}');
    settingRepo.animationLooper.value = 0;
  }

  @override
  Widget build(BuildContext context) {
    //print('GridWidgetState BuildContext');
    return Container(
        height: 270,
        child: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        removeBottom: true,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: widget.restaurantsList.length,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Navigator.of(context).pushNamed('/Details',
                    arguments: RouteArgument(
                      id: widget.restaurantsList.elementAt(index).id,
                      heroTag: widget.heroTag,
                    ));
              },
              child: CardHorizontalWidget(
                restaurant: widget.restaurantsList.elementAt(index),
                heroTag: widget.heroTag,
                isForAppMapDirection: false,
                onDirectionPress: () {},
                isDeliveryTime: widget.isDeliveryTime,
              ),
            );
          },
        )));
  }
}
