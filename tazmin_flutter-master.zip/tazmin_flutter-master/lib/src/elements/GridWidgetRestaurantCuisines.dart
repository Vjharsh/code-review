import 'package:flutter/material.dart';
import '../models/restaurant.dart';
import 'RestaurantsWithCuisinesCardWidget.dart';

//ignore: must_be_immutable
class GridWidgetRestaurantCuisines extends StatelessWidget {
  final List<Restaurant> restaurantsList;
  final String heroTag;
  bool isForAppMapDirection;
  VoidCallback onDirectionPress;
  GridWidgetRestaurantCuisines({
    Key? key,
    required this.restaurantsList,
    required this.heroTag,
    required this.isForAppMapDirection,
    required this.onDirectionPress});

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      scrollDirection: Axis.vertical,
      shrinkWrap: true,
      primary: false,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      padding: EdgeInsets.symmetric(horizontal: 5),
      crossAxisCount: 3,
      childAspectRatio: 1/1.6,
      //rows
      children: List.generate(restaurantsList.length, (index) {
        return RestaurantsWithCuisinesCardWidget(
          heroTag: heroTag,
          restaurant: restaurantsList.elementAt(index),
        );
      }),
    ); /*ListView.builder(
      shrinkWrap: true,
      primary: false,
      physics: NeverScrollableScrollPhysics(),
      scrollDirection: Axis.vertical,
      itemCount: restaurantsList.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            Navigator.of(context).pushNamed('/Details',
                arguments: RouteArgument(
                  id: restaurantsList.elementAt(index).id,
                  heroTag: heroTag,
                ));
          },
          child: CardWidget(
            restaurant: restaurantsList.elementAt(index),
            heroTag: heroTag,
            isForAppMapDirection: isForAppMapDirection,
            onDirectionPress: () {
              onDirectionPress();
            },
          ),
        );
      },
    );*/
    /*StaggeredGridView.countBuilder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        crossAxisCount: 6,
        itemCount: restaurantsList.length,
        itemBuilder: (BuildContext context, int index) =>
            RestaurantsWithCuisinesCardWidget(
              heroTag: heroTag,
              restaurant: restaurantsList.elementAt(index),
            ),
        staggeredTileBuilder: (int index) => StaggeredTile.count(2,2),//, index.isEven ? 2 : 1),
        mainAxisSpacing: 5.0,
        crossAxisSpacing: 5.0,
      );*/
  }
}
