import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/elements/google_places_flutter.dart';
import 'package:food_delivery_app/src/models/prediction.dart';
import 'package:geolocator/geolocator.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import '../../generated/l10n.dart';
import '../helpers/checkbox_form_field.dart';
import '../models/addresses.dart';
import '../repository/settings_repository.dart';

// ignore: must_be_immutable
class DeliveryAddressDialog {
  BuildContext context;
  Addresses? address;
  ValueChanged<Addresses> onChanged;
  final searchStringController = new TextEditingController();
  GlobalKey<FormState> _deliveryAddressFormKey = new GlobalKey<FormState>();
  bool isForCurrentLocation = false;
  bool isNewAddress = false;
  String lat;
  String long;

  DeliveryAddressDialog({
      required this.context,
      required this.address,
      required this.onChanged,
      required this.isForCurrentLocation,
      required this.lat,
      required this.long,
      required this.isNewAddress}) {
    if(!isNewAddress){
      print("not new address");
    showDialog(
        context: context,
        builder: (context) {
          return SimpleDialog(
            titlePadding: EdgeInsets.fromLTRB(16, 25, 16, 0),
            title: Row(
              children: <Widget>[
                Icon(
                  Icons.place,
                  color: Theme.of(context).hintColor,
                ),
                SizedBox(width: 10),
                Text(
                  S.of(context).add_delivery_address,
                  style: Theme.of(context).textTheme.bodyText1,
                )
              ],
            ),
            children: <Widget>[
              Form(
                key: _deliveryAddressFormKey,
                child: Column(
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: new TextFormField(
                        style: TextStyle(color: Theme.of(context).hintColor),
                        keyboardType: TextInputType.text,
                        decoration: getInputDecoration(
                            hintText: S.of(context).home_address,
                            labelText: S.of(context).description),
                        initialValue: address!.description.isEmpty
                            ? ''
                            : address!.description,
                        validator: (input) => input?.trim().length == 0
                            ? 'Not valid address description'
                            : null,
                        onSaved: (input) => address!.description = input!,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: isForCurrentLocation
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  S.of(context).full_address,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 3,
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1!
                                      .merge(TextStyle(fontSize: 12)),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Text(
                                  address!.address,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 3,
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1!
                                      .merge(TextStyle(fontSize: 13)),
                                )
                              ],
                            )
                          : new TextFormField(
                              style:
                                  TextStyle(color: Theme.of(context).hintColor),
                              keyboardType: TextInputType.text,
                              decoration: getInputDecoration(
                                  hintText: S.of(context).hint_full_address,
                                  labelText: S.of(context).full_address),
                              initialValue: address!.address.isEmpty
                                  ? ''
                                  : address!.address,
                              validator: (input) => input?.trim().length == 0
                                  ? 'Not valid address'
                                  : null,
                              onSaved: (input) => address!.address = input!,
                            ),
                      // : GooglePlaceAutoCompleteTextField(
                      //     textEditingController: searchStringController,
                      //     googleAPIKey:
                      //     "AIzaSyAK4kgheqF6rqWiRJQ8TUfdwdDNMFMTxrY",
                      //     inputDecoration: InputDecoration(
                      //         hintText: "Search your location"),
                      //     debounceTime: 800,
                      //     countries: ["isr"],
                      //     isLatLngRequired: true,
                      //     getPlaceDetailWithLatLng:
                      //         (Prediction prediction) {
                      //       print(
                      //           "placeDetails" + prediction.lng.toString());
                      //     },
                      //     initialValue: address!.address.isEmpty
                      //         ? ''
                      //         : address!.address,
                      //     validator: (input) => input?.trim().length == 0
                      //         ? 'Not valid address'
                      //         : null,
                      //     onSaved: (input) => address!.address = input!,
                      //     itmClick: (Prediction prediction) {
                      //       searchStringController.text =
                      //       prediction.description!;
                      //
                      //       searchStringController.selection =
                      //           TextSelection.fromPosition(TextPosition(
                      //               offset:
                      //               prediction.description!.length));
                      //     }
                      //   // default 600 ms ,
                      // ),
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: CheckboxFormField(
                        context: context,
                        initialValue: address!.isDefault,
                        onSaved: (input) => address!.isDefault = input!,
                        title: Text(S.of(context).make_it_default),
                      ),
                    )
                  ],
                ),
              ),
              Row(
                children: <Widget>[
                  MaterialButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      S.of(context).cancel,
                      style: TextStyle(color: Theme.of(context).hintColor),
                    ),
                  ),
                  MaterialButton(
                    onPressed: () => _submit(context),
                    child: Text(
                      S.of(context).save,
                      style: TextStyle(color: Theme.of(context).secondaryHeaderColor),
                    ),
                  ),
                ],
                mainAxisAlignment: MainAxisAlignment.end,
              ),
              SizedBox(height: 10),
            ],
          );
        });
    } else {
      print("new address");
      showGeneralDialog(
          barrierColor: Colors.black.withOpacity(0.5),
          transitionBuilder: (context, a1, a2, widget) {
            return Transform.scale(
              scale: a1.value,
              child: SimpleDialog(
                titlePadding: EdgeInsets.fromLTRB(16, 25, 16, 0),
                title: Row(
                  children: <Widget>[
                    Icon(
                      Icons.place,
                      color: Theme.of(context).secondaryHeaderColor,
                    ),
                    SizedBox(width: 10),
                    Text(
                      S.of(context).add_delivery_address,
                      style: TextStyle(
                          color: Theme.of(context).secondaryHeaderColor,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                children: <Widget>[
                  Form(
                    key: _deliveryAddressFormKey,
                    child: Column(
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: isForCurrentLocation
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      S.of(context).full_address,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 3,
                                      style: Theme.of(context)
                                          .textTheme
                                          .subtitle1!
                                          .merge(TextStyle(fontSize: 13)),
                                    ),
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Text(
                                      address!.address,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 3,
                                      style: Theme.of(context)
                                          .textTheme
                                          .subtitle1!
                                          .merge(TextStyle(fontSize: 13)),
                                    )
                                  ],
                                )
                              // : new TextFormField(
                              //     style: TextStyle(
                              //         color: Theme.of(context).hintColor),
                              //     keyboardType: TextInputType.text,
                              //     decoration: getInputDecoration(
                              //         hintText: S.of(context).hint_full_address,
                              //         labelText: S.of(context).full_address),
                              //     initialValue: address!.address.isEmpty
                              //         ? ''
                              //         : address!.address,
                              //     validator: (input) =>
                              //         input?.trim().length == 0
                              //             ? 'Not valid address'
                              //             : null,
                              //     onSaved: (input) => address!.address = input!,
                              //   ),
                          : new TextFormField(
                             style:
                                 TextStyle(color: Theme.of(context).hintColor),
                             keyboardType: TextInputType.text,
                             decoration: getInputDecoration(
                                 hintText: S.of(context).description,
                                 labelText: S.of(context).description),
                             /*initialValue: address.description?.isNotEmpty ?? false
                             ? address.description
                             : null,*/
                             validator: (input) => input?.trim().length == 0
                                 ? 'Not valid address description'
                                 : null,
                             onSaved: (input) => address!.description = input!,
                           ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          // child: new TextFormField(
                          //   controller: searchStringController,
                          //   style:
                          //       TextStyle(color: Theme.of(context).hintColor),
                          //   keyboardType: TextInputType.text,
                          //   decoration: getInputDecoration(
                          //       hintText: S.of(context).home_address,
                          //       labelText: S.of(context).description),
                          //   /*initialValue: address.description?.isNotEmpty ?? false
                          //   ? address.description
                          //   : null,*/
                          //   validator: (input) => input?.trim().length == 0
                          //       ? 'Not valid address description'
                          //       : null,
                          //   onSaved: (input) => address!.description = input!,
                          // ),
                          child: GooglePlaceAutoCompleteTextField(
                              textEditingController: searchStringController,
                              googleAPIKey:
                                  "AIzaSyAK4kgheqF6rqWiRJQ8TUfdwdDNMFMTxrY",
                              // inputDecoration: InputDecoration(
                              //     hintText: "Search your location"),
                              inputDecoration: getInputDecoration(
                                  hintText: S.of(context).full_address,
                                  labelText: S.of(context).full_address),
                              debounceTime: 800,
                              countries: ["isr"],
                              textStyle: TextStyle(color: Theme.of(context).hintColor),
                              isLatLngRequired: true,
                              getPlaceDetailWithLatLng:
                                  (Prediction prediction) {
                                print(
                                    "placeDetails" + prediction.lng.toString());
                              },
                              validator: (input) => input?.trim().length == 0
                                  ? 'Not valid address'
                                  : null,
                              onSaved: (input) => address!.address = input!,
                              itmClick: (Prediction prediction) {
                                searchStringController.text =
                                    prediction.description!;

                                searchStringController.selection =
                                    TextSelection.fromPosition(TextPosition(
                                        offset:
                                            prediction.description!.length));
                              },
                            lat: lat,
                            long: long,
                              ),
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: CheckboxFormField(
                            context: context,
                            initialValue: address!.isDefault,
                            onSaved: (input) => address!.isDefault = input!,
                            title: Text(S.of(context).make_it_default),
                          ),
                        )
                      ],
                    ),
                  ),
                  Row(
                    children: <Widget>[
                      MaterialButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          S.of(context).cancel,
                          style: TextStyle(color: Theme.of(context).hintColor),
                        ),
                      ),
                      MaterialButton(
                        onPressed: () => _submit(context),
                        child: Text(
                          S.of(context).save,
                          style: TextStyle(
                              color: Theme.of(context).secondaryHeaderColor),
                        ),
                      ),
                    ],
                    mainAxisAlignment: MainAxisAlignment.end,
                  ),
                  SizedBox(height: 10),
                ],
              ),
            );
          },
          transitionDuration: Duration(milliseconds: 400),
          barrierDismissible: true,
          barrierLabel: '',
          context: context,
          pageBuilder: (context, animation1, animation2) {
            return null!;
          });
    }
  }
  void outOfTownAreaAlert(BuildContext currentContext) {
    Alert(
      context: currentContext,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,
          titleStyle: Theme.of(currentContext)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(currentContext)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      type: AlertType.warning,
      title: S.of(currentContext).out_of_town_area_title,
      desc: setting.value.town_area_message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(currentContext).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(currentContext);
          },
          width: 120,
        )
      ],
    ).show();
  }
  InputDecoration getInputDecoration({String? hintText, String? labelText}) {
    return new InputDecoration(
      hintText: hintText,
      labelText: labelText,
      hintStyle: Theme.of(context).textTheme.bodyText2?.merge(
            TextStyle(color: Theme.of(context).focusColor),
          ),
      enabledBorder: UnderlineInputBorder(
          borderSide:
              BorderSide(color: Theme.of(context).hintColor.withOpacity(0.2))),
      focusedBorder: UnderlineInputBorder(
          borderSide: BorderSide(color: Theme.of(context).hintColor)),
      floatingLabelBehavior: FloatingLabelBehavior.auto,
      labelStyle: Theme.of(context).textTheme.bodyText2?.merge(
            TextStyle(color: Theme.of(context).hintColor),
          ),
    );
  }

  void _submit(BuildContext context) {
    if (_deliveryAddressFormKey.currentState!.validate()) {
      _deliveryAddressFormKey.currentState?.save();
      onChanged(address!);
      print('before pop');
      Navigator.pop(context);
    }
  }
}
