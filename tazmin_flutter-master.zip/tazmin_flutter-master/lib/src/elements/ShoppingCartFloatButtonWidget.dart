import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_broadcast_receiver/flutter_broadcast_receiver.dart';
import 'package:food_delivery_app/src/helpers/app_config.dart' as app_config;
import 'package:mvc_pattern/mvc_pattern.dart';
import '../controllers/cart_controller.dart';
import '../models/food.dart';
import '../models/route_argument.dart';
import '../repository/user_repository.dart';

class ShoppingCartFloatButtonWidget extends StatefulWidget {

  const ShoppingCartFloatButtonWidget({
    required this.iconColor,
    required this.backIconColor,
    required this.labelColor,
    required this.food,
    Key? key,
  }) : super(key: key);

  final Color iconColor;
  final Color backIconColor;
  final Color labelColor;
  final Food food;

  @override
  _ShoppingCartFloatButtonWidgetState createState() =>
      _ShoppingCartFloatButtonWidgetState();
}

class _ShoppingCartFloatButtonWidgetState
    extends StateMVC<ShoppingCartFloatButtonWidget> {
  late CartController _con;

  _ShoppingCartFloatButtonWidgetState() : super(CartController()) {
    _con = controller as CartController;
  }

  @override
  void initState() {
    super.initState();
    _con.listenForCartsCount();
    /*FBroadcast.instance().register('cart_count', (value, __) {
      setState(() {
        _con.cartCount = value;
      });
    }, context: this);*/
    BroadcastReceiver().subscribe<String>('cart_count', (value) {
      setState(() {
        _con.cartCount = int.parse(value);
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Padding(
          padding: EdgeInsets.only(left: 20,right: 20),
          child: Row(
            children: <Widget>[
              InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Icon(
                  Icons.arrow_back,
                  color: widget.backIconColor,
                  size: 35,
                ),
              ),
              Expanded(child: SizedBox(height: 5,)),
              SizedBox(
                width: 60,
                height: 60,
                child: RaisedButton(
                  padding: EdgeInsets.all(0),
                  color: Theme.of(context).secondaryHeaderColor,
                  shape: StadiumBorder(),
                  onPressed: () {
                    if (currentUser.value.apiToken.isNotEmpty) {
//            Navigator.of(context).pushNamed('/Cart', arguments: RouteArgument(param: '/Food', id: widget.food.id));
                      Navigator.of(context).pushNamed('/Cart',
                          arguments:
                          RouteArgument(param: '/Pages', id: '2'));
                    } else {
                      Navigator.of(context).pushNamed('/Login');
                    }
                  },
                  child: Stack(
                    alignment: AlignmentDirectional.bottomEnd,
                    children: <Widget>[
                      Icon(
                        Icons.shopping_cart,
                        color: this.widget.iconColor,
                        size: 28,
                      ),
                      Container(
                        child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              _con.cartCount.toString(),
                              textAlign: TextAlign.center,
                              style: Theme.of(context)
                                  .textTheme
                                  .caption!
                                  .merge(
                                TextStyle(
                                    color:
                                    Theme.of(context).primaryColor,
                                    fontSize: 9),
                              ),
                            )),
                        padding: EdgeInsets.all(0),
                        decoration: BoxDecoration(
                            color: this.widget.labelColor,
                            borderRadius:
                            BorderRadius.all(Radius.circular(10))),
                        constraints: BoxConstraints(
                            minWidth: 15,
                            maxWidth: 15,
                            minHeight: 15,
                            maxHeight: 15),
                      ),
                    ],
                  ),
                ),
              )
            ],
          )),
    );
  }
}
