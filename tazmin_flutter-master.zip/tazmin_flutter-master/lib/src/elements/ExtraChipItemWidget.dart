import 'package:flutter/material.dart';
import '../models/extra.dart';
import '../repository/user_repository.dart';
import '../repository/settings_repository.dart' as settingRepo;

class ExtraChipItemWidget extends StatefulWidget {
  final Extra extra;
  final int index;
  final Function(int, bool) onChanged;
  final Function(String limitQty) onQtyAlert;

  ExtraChipItemWidget(
      {Key? key,
        required this.extra,
        required this.index,
        required this.onChanged,
        required this.onQtyAlert})
      : super(key: key);

  @override
  ExtraChipItemWidgetState createState() => ExtraChipItemWidgetState();
}

class ExtraChipItemWidgetState extends State<ExtraChipItemWidget> {
  @override
  void initState() {
    super.initState();
    setState(() {
      widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  incrementQuantity() {
    if (widget.extra.qtyEnable == '1') {
      if (int.parse('${widget.extra.qty.toStringAsFixed(0)}') <
          int.parse(widget.extra.limitQty)) {
        setState(() {
          ++widget.extra.qty;
          widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
          widget.onChanged(widget.index, false);
        });
        //calculateSubtotal();
      } else {
        widget.onQtyAlert(widget.extra.limitQty);
      }
    } else {
      setState(() {
        ++widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged(widget.index, false);
      });
    }
  }

  decrementQuantity() {
    if (widget.extra.qty > 1) {
      setState(() {
        --widget.extra.qty;
        widget.extra.totalPrice = widget.extra.price * widget.extra.qty;
        widget.onChanged(widget.index, false);
      });
      //calculateSubtotal();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if((/*(int.parse(widget.extra.limitQty) > 1 && widget.extra.qtyEnable == '1') || */widget.extra.extra_group_is_active == '1') && widget.extra.checked)Padding(
          padding: const EdgeInsets.only(left: 10),
          child: InkWell(
            onTap: () {
              decrementQuantity();
            },
            child: Icon(
              Icons.remove_circle_outline,
              size: 30,
              color: Theme.of(context).hintColor,
            ),
          ),
        ),
        RawChip(
          elevation: 0,
          label: widget.extra.totalPrice > 0?  Text(widget.extra.qty>1 ? '(${settingRepo.setting.value.defaultCurrency}${widget.extra.price.toStringAsFixed(0)}*${widget.extra.qty.toStringAsFixed(0)}) ${widget.extra.name}' : '(${settingRepo.setting.value.defaultCurrency}${widget.extra.totalPrice.toStringAsFixed(0)}+) ${widget.extra.name}') : widget.extra.qty>1 && widget.extra.qtyEnable == '1' ?Text('(${widget.extra.qty.toStringAsFixed(0)}) ${widget.extra.name}'):Text(widget.extra.name),
          labelStyle: widget.extra.checked
              ? Theme.of(context)
                  .textTheme
                  .bodyText2!
                  .merge(TextStyle(color: Theme.of(context).primaryColor))
              : Theme.of(context)
                  .textTheme
                  .bodyText2!
                  .merge(TextStyle(color: Theme.of(context).primaryColor)),
          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          backgroundColor: Theme.of(context).hintColor,
          selectedColor: Theme.of(context).secondaryHeaderColor,
          selected: widget.extra.checked,
          showCheckmark: false,
          onSelected: (bool value) {
            if (currentUser.value.apiToken.isNotEmpty) {
              widget.extra.checked = !widget.extra.checked;
            }
            if(!widget.extra.checked)
            {
              widget.extra.qty = 0;
            }else{
              widget.extra.qty = 1;
            }
            widget.onChanged(widget.index, widget.extra.checked);
          },
        ),
        if((/*(int.parse(widget.extra.limitQty) > 1 && widget.extra.qtyEnable == '1') || */widget.extra.extra_group_is_active == '1') && widget.extra.checked)Padding(
          padding: const EdgeInsets.only(right: 10),
          child: InkWell(
            onTap: () {
              incrementQuantity();
            },
            child: Icon(
              Icons.add_circle_outline,
              size: 30,
              color: Theme.of(context).hintColor,
            ),
          ),
        ),
        if((/*(int.parse(widget.extra.limitQty) > 1 && widget.extra.qtyEnable == '1') || */widget.extra.extra_group_is_active == '1') && widget.extra.checked)SizedBox(width: 10),
      ],
    );
  }
}
// if(int.parse(widget.extra.limitQty) > 1 || (widget.extra.qtyEnable == '1' && widget.extra.checked))