import 'package:flutter/material.dart';
import 'package:flutter_broadcast_receiver/flutter_broadcast_receiver.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../controllers/cart_controller.dart';
import '../models/route_argument.dart';
import '../repository/user_repository.dart';
import '../repository/settings_repository.dart' as settingsRepo;

class ShoppingCartButtonWidget extends StatefulWidget {
  const ShoppingCartButtonWidget({
    required this.iconColor,
    required this.labelColor,
    Key? key,
  }) : super(key: key);

  final Color iconColor;
  final Color labelColor;

  @override
  _ShoppingCartButtonWidgetState createState() =>
      _ShoppingCartButtonWidgetState();
}

class _ShoppingCartButtonWidgetState extends StateMVC<ShoppingCartButtonWidget> {
  late CartController _con;

  _ShoppingCartButtonWidgetState() : super(CartController()) {
    _con = controller as CartController;
  }

  @override
  void initState() {
    super.initState();
    _con.listenForCartsCount();
    /*FBroadcast.instance().register('cart_count', (value, __) {
      setState(() {
        _con.cartCount = value;
      });
    }, context: this);*/
    BroadcastReceiver().subscribe<String>('cart_count', (value) {
      setState(() {
        _con.cartCount = int.parse(value);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
          onTap: () {
            if (currentUser.value.apiToken.isNotEmpty) {
              Navigator.of(context).pushNamed('/Cart',
                  arguments: RouteArgument(param: '/Pages', id: '2'));
            } else {
              Navigator.of(context).pushNamed('/Login');
            }
          },
          child: Stack(
            alignment: AlignmentDirectional.bottomEnd,
            children: <Widget>[
              Icon(
                Icons.shopping_cart,
                color: this.widget.iconColor,
                size: 28,
              ),
              Container(
                child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      _con.cartCount.toString(),
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headline2!.merge(
                            TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontSize: 10),
                          ),
                    )),
                padding: EdgeInsets.all(0),
                decoration: BoxDecoration(
                    color: this.widget.labelColor,
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                constraints: BoxConstraints(
                    minWidth: 15, maxWidth: 15, minHeight: 15, maxHeight: 15),
              ),
            ],
          )),
    );
  }
}
