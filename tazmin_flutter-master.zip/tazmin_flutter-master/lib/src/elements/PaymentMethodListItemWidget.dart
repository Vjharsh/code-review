import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/elements/CircularLoadingWidget.dart';
import 'package:food_delivery_app/src/models/credit_card.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:food_delivery_app/src/repository/user_repository.dart'
as userRepo;
import '../helpers/custom_trace.dart';
import '../models/payment_method.dart';
import 'package:food_delivery_app/constants.dart' as Constants;

// ignore: must_be_immutable
class PaymentMethodListItemWidget extends StatelessWidget {
  late String heroTag;
  PaymentMethod? paymentMethod;
  late BuildContext context;
  final Function(bool)? onclick;
  bool? isLoading;

  PaymentMethodListItemWidget({
    Key? key,
     this.paymentMethod,
     this.onclick,
     this.isLoading}) : super(key: key);
  void payAlert(CreditCard creditCard) {
    Alert(
      context: context,
      type: AlertType.none,
      title: S.of(context).pay_alert_title,
      desc: S.of(context).pay_alert_message(creditCard.number),
      style: AlertStyle(
          titleStyle: Theme.of(context)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          descStyle: Theme.of(context)
              .textTheme
              .caption!
              .merge(TextStyle(fontSize: 20, fontWeight: FontWeight.w500))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(context).alert_yes,
            style: TextStyle(color: Colors.white, fontSize: 15),
          ),
          onPressed: () {
            Navigator.pop(context);
            Navigator.of(context).pushReplacementNamed('/PayWithToken',
                arguments: new RouteArgument(param: 'Pay with Token'));
          },
          width: 120,
        ),
        DialogButton(
          child: Text(
            S.of(context).alert_no,
            style: TextStyle(color: Colors.white, fontSize: 15),
          ),
          onPressed: () {
            Navigator.pop(context);
            goToPayment(true);
          },
          width: 50,
        ),
      ],
    ).show();
  }

  void goToPayment(bool isForCreditCard) {
    if(isForCreditCard) {
      onclick!(true);
    }else{
      onclick!(false);
      Navigator.of(context).pushNamed(this.paymentMethod!.route);
    }
    //print(CustomTrace(StackTrace.current, message: this.paymentMethod.name));
  }

  @override
  Widget build(BuildContext context) {
    if(isLoading == null)
    {
      isLoading = false;
    }
    this.context = context;
    return InkWell(
      splashColor: Theme.of(context).secondaryHeaderColor,
      focusColor: Theme.of(context).secondaryHeaderColor,
      highlightColor: Theme.of(context).primaryColor,
      onTap: () {
        if (this.paymentMethod!.name == Constants.PAYMENT_METHOD_YAADPAY || this.paymentMethod!.name == Constants.PAYMENT_METHOD_YAADPAY_ON_PICKUP) {
          userRepo.getCreditCard().then((creditCard) {
            print('creditCard:${creditCard.toMap()}');
            print('creditCard.token:${creditCard.token}');
            if (creditCard.token.toString() == '') {
              goToPayment(true);
            } else {
              payAlert(creditCard);
            }
          });
        } else {
          goToPayment(false);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(0.9),
          boxShadow: [
            BoxShadow(color: Theme.of(context).focusColor.withOpacity(0.1), blurRadius: 5, offset: Offset(0, 2)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Container(
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(5)),
                image: DecorationImage(image: AssetImage(paymentMethod!.logo), fit: BoxFit.fill),
              ),
            ),
            SizedBox(width: 15),
            Flexible(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          paymentMethod!.title,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: Theme.of(context).textTheme.subtitle1,
                        ),
                        Text(
                          paymentMethod!.description,
                          overflow: TextOverflow.fade,
                          softWrap: false,
                          style: Theme.of(context).textTheme.caption,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 8),
                  isLoading! ? Container(
                    height: 50,
                    width: 50,
                    child: Center(
                      child: CircularProgressIndicator(backgroundColor: Theme.of(context).secondaryHeaderColor,),
                    ),
                  ):Icon(
                    Icons.keyboard_arrow_right,
                    color: Theme.of(context).focusColor,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
