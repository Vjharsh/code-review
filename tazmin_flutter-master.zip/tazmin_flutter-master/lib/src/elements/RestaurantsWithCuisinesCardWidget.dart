import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/models/restaurant.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';

// ignore: must_be_immutable
class RestaurantsWithCuisinesCardWidget extends StatefulWidget {
  Restaurant restaurant;
  String heroTag;

  RestaurantsWithCuisinesCardWidget({Key? key,
    required this.restaurant,
    required this.heroTag})
      : super(key: key);

  @override
  RestaurantsWithCuisinesCardWidgetState createState() =>
      RestaurantsWithCuisinesCardWidgetState();
}

class RestaurantsWithCuisinesCardWidgetState
    extends State<RestaurantsWithCuisinesCardWidget> {
  late Restaurant restaurant;

  @override
  void initState() {
    super.initState();
    this.restaurant = widget.restaurant;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
        highlightColor: Colors.transparent,
        splashColor: Theme.of(context).secondaryHeaderColor.withOpacity(0.08),
        onTap: () {
          Navigator.of(context).pushNamed('/Details',
              arguments:
                  RouteArgument(id: restaurant.id, heroTag: widget.heroTag));
        },
        child: Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // Image of the card
              Stack(
                fit: StackFit.loose,
                children: <Widget>[
                  Hero(
//                    tag: widget.heroTag + restaurant.id,
                    tag: Random().nextInt(10000),
                    child: ClipRRect(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(5),
                          topRight: Radius.circular(5),
                          ),
                      child: CachedNetworkImage(
                        width: double.infinity,
                        height: 100,
                        fit: BoxFit.cover,
                        imageUrl: restaurant.image.url,
                        placeholder: (context, url) => Image.asset(
                          'assets/img/loading.gif',
                          fit: BoxFit.fill,
                          width: double.infinity,
                          height: 100,
                        ),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      ),
                    ),
                  ),
                  Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        margin:
                            EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                        padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                        decoration: BoxDecoration(
                            color: !restaurant.resOpeningStatus
                                ? Colors.grey
                                : Colors.green,
                            borderRadius: BorderRadius.circular(24)),
                        child: !restaurant.resOpeningStatus
                            ? Text(
                                S.of(context).closed,
                                style: Theme.of(context)
                                    .textTheme
                                    .caption!
                                    .merge(TextStyle(
                                        color: Theme.of(context).primaryColor)),
                              )
                            : Text(
                                S.of(context).open,
                                style: Theme.of(context)
                                    .textTheme
                                    .caption!
                                    .merge(TextStyle(
                                        color: Theme.of(context).primaryColor)),
                              ),
                      )),
                ],
              ),
              Expanded(
                  child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(5),
                        child: Text(
                restaurant.name,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.subtitle1,
              ),
                      ))),
              // SizedBox(height: 5),
            ],
          ),
        ));
  }
}
