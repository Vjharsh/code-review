import 'dart:convert';
import 'package:flutter_broadcast_receiver/flutter_broadcast_receiver.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:flutter/material.dart';
import 'package:food_delivery_app/main.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/helpers/maps_util.dart';
import 'package:food_delivery_app/src/models/apply_coupon_code.dart';
import 'package:food_delivery_app/src/models/delivery_time.dart';
import 'package:food_delivery_app/src/models/extra.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:food_delivery_app/src/pages/delivery_addresses.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import '../../generated/l10n.dart';
import '../models/ResetMenu.dart';
import '../models/cart.dart';
import '../repository/cart_repository.dart';
import 'package:food_delivery_app/src/repository/user_repository.dart'
    as userRepo;
import 'package:food_delivery_app/src/repository/settings_repository.dart'
    as settingRepo;
import 'package:app_settings/app_settings.dart';
import 'package:geolocator/geolocator.dart';
import 'package:food_delivery_app/src/repository/user_repository.dart'
    as userRepo;

class CartController extends ControllerMVC {
  List<Cart> carts = <Cart>[];
  late DeliveryTime deliveryTime;
  bool isDeliveryTime = false;

  //double taxAmount = 0.0;
  double deliveryFee = 0.0;
  String deliveryFeeName = '';
  int cartCount = 0;
  double subTotal = 0.0;
  double total = 0.0;
  var appliedDiscount = false;
  var couponType = 0;
  double discount = 0;
  int discountPercentage = 0;
  var isCouponCodeLoading = false;
  bool isRunning = false;
  int orderOption = 0; //0 by default hide 1 for pickup 2 for delivery
  bool isGettingDistance = false;
  late GlobalKey<ScaffoldState> scaffoldKey;
  bool disablePickUp = false;
  bool isForPickUp = false;

  CartController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }
  void getCountOfTotalQty()
  {
    double counter= 0;
    carts.forEach((cartElement) {
      counter = counter + cartElement.quantity;
    });
    settingRepo.setting.value.cartCounter = int.parse(counter.toStringAsFixed(0));
  }
  void listenForCarts({String? message}) async {
    carts.clear();
    final Stream<Cart> stream = await getCart();
    stream.listen((Cart _cart) {
      if (!carts.contains(_cart)) {
        setState(() {
          print('listenForCarts');
          carts.add(_cart);
        });
      }
    }, onError: (a) {
      print(a);
      if (message != Constants.RETRY) {
        listenForCarts(message: Constants.RETRY);
      }
      /*ScaffoldMessenger.of(scaffoldKey.currentContext?).showSnackBar(SnackBar(
        content: Text(S.of(context).verify_your_internet_connection),
      ));*/
    }, onDone: () async {
      print('onDone listenForCarts');
      if (carts.isNotEmpty) {
        // deliveryFee = carts[0].food.restaurant.deliveryFee;
        getCountOfTotalQty();
        try {
          if (MyApp.addressDTO != null) {
            print('MyApp.addressDTO:${MyApp.addressDTO?.latitude}');
            print('MyApp.addressDTO:${MyApp.addressDTO?.longitude}');
            double distance = Geolocator.distanceBetween(
                double.parse(carts.elementAt(0).food.restaurant.latitude),
                double.parse(carts.elementAt(0).food.restaurant.longitude),
                MyApp.addressDTO!.latitude,
                MyApp.addressDTO!.longitude);
            distance = distance / 1000;
            print('distance:$distance');
            print('restaurant.deliveryRange:${carts.elementAt(0).food.restaurant.deliveryRange}');
            if (distance > carts.elementAt(0).food.restaurant.deliveryRange &&
                distance > carts.elementAt(0).food.restaurant.deliveryRange2 &&
                distance > carts.elementAt(0).food.restaurant.deliveryRange3 &&
                distance > carts.elementAt(0).food.restaurant.deliveryRange4 &&
                distance > carts.elementAt(0).food.restaurant.deliveryRange5) {
              print('farDeliveryFee');
              deliveryFee = double.parse(settingRepo.setting.value.farDeliveryFee);
              deliveryFeeName = 'Far Delivery Fees';
            } else {
              if (distance <= carts.elementAt(0).food.restaurant.deliveryRange && distance >= 0) {
                print('normalDeliveryFee');
                deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee);
                deliveryFeeName = 'Normal Delivery Fees';
              } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange2 && distance > carts.elementAt(0).food.restaurant.deliveryRange) {
                print('normalDeliveryFee2');
                deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee2);
                deliveryFeeName = 'Normal Delivery Fees 2';
              } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange3 && distance > carts.elementAt(0).food.restaurant.deliveryRange2) {
                print('normalDeliveryFee3');
                deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee3);
                deliveryFeeName = 'Normal Delivery Fees 3';
              } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange4 && distance > carts.elementAt(0).food.restaurant.deliveryRange3) {
                print('normalDeliveryFee4');
                deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee4);
                deliveryFeeName = 'Normal Delivery Fees 4';
              } else {
                print('normalDeliveryFee5');
                deliveryFee =
                    double.parse(settingRepo.setting.value.normalDeliveryFee5);
                deliveryFeeName = 'Normal Delivery Fees 5';
              }
            }
          } else {
            deliveryFee = double.parse(settingRepo.setting.value.farDeliveryFee);
            deliveryFeeName = 'Far Delivery Fees';
          }
        } catch (e) {
          print('deliveryRange Error:${e.toString()}');
          deliveryFee = double.parse(settingRepo.setting.value.farDeliveryFee);
          deliveryFeeName = 'Far Delivery Fees';
        }
        print('deliveryFee:$deliveryFee');
        print('deliveryFeeName: $deliveryFeeName');
        settingRepo.setting.value.deliveryFee = deliveryFee;
        settingRepo.setting.value.deliveryFeeName = deliveryFeeName;
        disablePickUp = carts.elementAt(0).food.restaurant.disablePickup;
        print('disablePickUp:$disablePickUp');
        calculateSubtotal();
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void listenForDeliveryTime({String? message}) async {
    deliveryTime = DeliveryTime();
    final Stream<DeliveryTime> stream = await getDeliveryTime();
    stream.listen((DeliveryTime _deliveryTime) {
      if (deliveryTime != _deliveryTime) {
        setState(() {
          print('listenForDeliveryTime');
          deliveryTime = _deliveryTime;
        });
      }
    }, onError: (a) {
      print(a);
      if (message != Constants.RETRY) {
        listenForDeliveryTime(message: Constants.RETRY);
      }
    }, onDone: () async {
      print('onDone listenForDeliveryTime');
      if (deliveryTime != DeliveryTime()) {
        isDeliveryTime = deliveryTime.getDriverDeliveryStatus();
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void calculationDeliveryFeeBaseOnSelectedLocation(
      double selectedAddresslatitude, double selectedAddresslongitude) async {
    print('settingRepo.setting.value.is_used:${settingRepo.setting.value.is_used}');
    print('settingRepo.setting.value.couponType:${settingRepo.setting.value.couponType}');
    if(couponType != 1) {
      if (carts.isNotEmpty) {
        setState(() {
          isGettingDistance = true;
        });
        try {
          /*double distance = await Geolocator().distanceBetween(
            double.parse(carts.elementAt(0).food.restaurant.latitude),
            double.parse(carts.elementAt(0).food.restaurant.longitude),
            selectedAddresslatitude,
            selectedAddresslongitude);*/
          MapsUtil mapsUtil = MapsUtil();
          double distance = await mapsUtil.getAccurateDistance(
              LatLng(selectedAddresslatitude, selectedAddresslongitude),
              LatLng(double.parse(carts.elementAt(0).food.restaurant.latitude), double.parse(carts.elementAt(0).food.restaurant.longitude)));
          distance = (distance / 1000);
          print('distance1:$distance');
          distance = distance;
          print('distance2:$distance');
          print('restaurant.deliveryRange:${carts.elementAt(0).food.restaurant.deliveryRange}');
          if (distance > carts.elementAt(0).food.restaurant.deliveryRange &&
              distance > carts.elementAt(0).food.restaurant.deliveryRange2 &&
              distance > carts.elementAt(0).food.restaurant.deliveryRange3 &&
              distance > carts.elementAt(0).food.restaurant.deliveryRange4 &&
              distance > carts.elementAt(0).food.restaurant.deliveryRange5) {
            print('farDeliveryFee');
            deliveryFee = double.parse(settingRepo.setting.value.farDeliveryFee);
            deliveryFeeName = 'Far Delivery Fees';
          } else {
            if (distance <= carts.elementAt(0).food.restaurant.deliveryRange && distance >= 0) {
              print('normalDeliveryFee');
              deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee);
              deliveryFeeName = 'Normal Delivery Fees';
            } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange2 && distance > carts.elementAt(0).food.restaurant.deliveryRange) {
              print('normalDeliveryFee2');
              deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee2);
              deliveryFeeName = 'Normal Delivery Fees 2';
            } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange3 && distance > carts.elementAt(0).food.restaurant.deliveryRange2) {
              print('normalDeliveryFee3');
              deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee3);
              deliveryFeeName = 'Normal Delivery Fees 3';
            } else if (distance <= carts.elementAt(0).food.restaurant.deliveryRange4 && distance > carts.elementAt(0).food.restaurant.deliveryRange3) {
              print('normalDeliveryFee4');
              deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee4);
              deliveryFeeName = 'Normal Delivery Fees 4';
            } else {
              print('normalDeliveryFee5');
              deliveryFee = double.parse(settingRepo.setting.value.normalDeliveryFee5);
              deliveryFeeName = 'Normal Delivery Fees 5';
            }
          }
        } catch (e) {
          print('deliveryRange Error:${e.toString()}');
          deliveryFee = double.parse(settingRepo.setting.value.farDeliveryFee);
          deliveryFeeName = 'Far Delivery Fees';
        }
        print('deliveryFee: $deliveryFee');
        print('deliveryFeeName: $deliveryFeeName');
        settingRepo.setting.value.deliveryFee = deliveryFee;
        settingRepo.setting.value.deliveryFeeName = deliveryFeeName;
        calculateSubtotal();
        setState(() {
          isGettingDistance = false;
        });
      }
    }
  }

  void resetCouponCode() {
    setState(() {
      appliedDiscount = false;
      discount = 0;
      // deliveryFee = carts[0].food.restaurant.deliveryFee;
      deliveryFee = settingRepo.setting.value.deliveryFee;
      deliveryFeeName = settingRepo.setting.value.deliveryFeeName;
      print('deliveryFee: $deliveryFee');
      /*taxAmount =
          (subTotal + deliveryFee) * carts[0].food.restaurant.defaultTax / 100;*/
//      total = subTotal + taxAmount + deliveryFee;
      total = subTotal + deliveryFee;
    });
  }

  void listenForCartsCount({String? message}) async {
    final Stream<int> stream = await getCartCount();
    stream.listen((int _count) {
      // FBroadcast.instance().stickyBroadcast('cart_count', value: _count);
      BroadcastReceiver().publish<String>('cart_count',
          arguments: (_count).toString());
      setState(() {
        // print('cartCount:$_count');
        this.cartCount = _count;
      });
    }, onError: (e) {
      // print(e);
      // print('hello');
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message ?? '', error: e.toString())) {
        listenForCartsCount(message: Constants.RETRY);
      }
      /*scaffoldKey?.currentState?.showSnackBar(SnackBar(
        content: Text(S.of(context).verify_your_internet_connection),
      ));*/
    },onDone: (){
      settingRepo.setting.value.cartCounter = cartCount;
    });
  }

  void applyNewCouponCode(String couponCode) async {
    setState(() {
      isCouponCodeLoading = true;
    });
    final Stream<ApplyCouponCode> stream = await applyCouponCode(couponCode);
    stream.listen((ApplyCouponCode applyCouponCodeValue) {
      setState(() {
        isCouponCodeLoading = false;
      });
      print('ApplyCouponCode:${applyCouponCodeValue.toMap()}');
      if (applyCouponCodeValue.success) {
        print('success:${applyCouponCodeValue.success}');
        print('coupon_type:${applyCouponCodeValue.coupon_type_id}');
        couponType = applyCouponCodeValue.coupon_type_id;
        appliedDiscount = true;
        if (couponType == 1) {
          setState(() {
            deliveryFee = 0;
            deliveryFeeName = '';
            //taxAmount = (subTotal) * carts[0].food.restaurant.defaultTax / 100;
//            total = subTotal + taxAmount;
            total = subTotal;
          });
        } else if (couponType == 3) {
          setState(() {
            discountPercentage =
                int.parse('${applyCouponCodeValue.coupon_discount}');
            discount = subTotal * discountPercentage / 100;
            total -= discount;
          });
        } else {
          setState(() {
            discount = double.parse('${applyCouponCodeValue.coupon_discount}');
            total -= discount;
          });
        }
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(scaffoldKey.currentContext!).applied_coupon_code),
        ));
      } else {
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(applyCouponCodeValue.message),
        ));
      }
    }, onError: (a) {}, onDone: () {});
  }

  Future<void> refreshCarts() async {
    listenForCarts(message: S.of(scaffoldKey.currentContext!).carts_refreshed_successfuly);
  }

  void removeFromCart(Cart _cart) async {
    setState(() {
      this.carts.remove(_cart);
      isRunning = true;
    });
    removeCart(_cart).then((value) {
      if (carts.isNotEmpty) {

      }
      setState(() {
        isRunning = false;
      });
      calculateSubtotal();
      getCountOfTotalQty();
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(
            S.of(scaffoldKey.currentContext!).the_food_was_removed_from_your_cart(_cart.food.name)),
      ));
    });
  }

  void calculateSubtotal() async {
    subTotal = 0;
    carts.forEach((cart) {
      double cartItemTotal = 0;
      cartItemTotal += cart.food.price;
      cart.extras.forEach((Extra extra) {
        double extraPrice = extra.extraPivot.extra_price;
        double extraQty =
            extra.extraPivot.extra_qty != 0 ? extra.extraPivot.extra_qty : 0;
        cartItemTotal += extraPrice * extraQty;
      });
      cartItemTotal *= cart.quantity;
      subTotal += cartItemTotal;
    });

    /*taxAmount =
        (subTotal + deliveryFee) * carts[0].food.restaurant.defaultTax / 100;*/
    if (appliedDiscount && couponType == 3) {
      discount = subTotal * discountPercentage / 100;
    }

//    total = subTotal + taxAmount + deliveryFee - discount;

    if (orderOption == 2) {
      total = subTotal + deliveryFee - discount;
    } else {
      total = subTotal - discount;
    }
    setState(() {});
  }

  incrementQuantity(Cart cart) {
    if (cart.quantity <= 99) {
      ++cart.quantity;
      getCountOfTotalQty();
      updateCart(cart);
      calculateSubtotal();
    }
  }

  decrementQuantity(Cart cart) {
    if (cart.quantity > 1) {
      --cart.quantity;
      getCountOfTotalQty();
      updateCart(cart);
      calculateSubtotal();
    }
  }

  void goToDeliveryAddress() {
    List<Map> params = carts.map((element) => element.toMap(true)).toList();
    String orderItams = json.encode(params);
    print('orderItams:$orderItams');
    print('_con.total:$total');
    userRepo.setOrderJsonArray(orderItams);
    Navigator.of(scaffoldKey.currentContext!)
        .push(MaterialPageRoute(builder: (context) => DeliveryAddressesWidget(lat: carts[0].food.restaurant.latitude,long: carts[0].food.restaurant.longitude,),))
        .then((value) {
      setState(() {
        orderOption = 2;
        calculateSubtotal();
      });
      if(carts.length > 0) {
        if(carts
            .elementAt(0)
            .food
            .restaurant.freeShipping) {
          deliveryFee = 0;
          deliveryFeeName = '';
          settingRepo.setting.value.deliveryFee = deliveryFee;
          settingRepo.setting.value.deliveryFeeName = deliveryFeeName;
          calculateSubtotal();
        } else{
          calculationDeliveryFeeBaseOnSelectedLocation(
              settingRepo.deliveryAddress.value.latitude,
              settingRepo.deliveryAddress.value.longitude);
        }
      }
    });
//            param: [carts, total, settingRepo.setting.value.defaultTax]));
  }

  void goCheckout(BuildContext context) {
    if (!userRepo.currentUser.value.profileCompleted()) {
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text('Complete your profile details to continue'),
        action: SnackBarAction(
          label: S.of(context).settings,
          textColor: Theme.of(context).secondaryHeaderColor,
          onPressed: () {
            Navigator.of(context).pushNamed('/Settings');
          },
        ),
      ));
    } else {
      if (carts[0].food.restaurant.closed) {
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(context).this_restaurant_is_closed_),
        ));
      } else {
        Navigator.of(context).pushNamed('/DeliveryPickup');
      }
    }
  }

  void checkoutAlert(String message) {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).checkout,
      desc: message,
      style: AlertStyle(
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 20)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 21),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }

  void minOrderAlert(double minOrderPrice) {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.info,
      title: S.of(scaffoldKey.currentContext!).alert_title_min_order,
      desc: S.of(scaffoldKey.currentContext!).alert_message_min_order(
          minOrderPrice, settingRepo.setting.value.defaultCurrency),
      style: AlertStyle(
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 20)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 21),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }

  void locationEnableAlert() {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).alert_location_service_title,
      desc: S.of(scaffoldKey.currentContext!).alert_location_service_message,
      style: AlertStyle(
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
            //LocationPermissions().openAppSettings();
            AppSettings.openLocationSettings();
          },
        )
      ],
    ).show();
  }

  void checkLocationPermission(bool isForDeliveryBtn) async {

    var geolocationStatus =
        await Geolocator.checkPermission();
    print('geolocationStatus.value:$geolocationStatus');
    if (geolocationStatus != LocationPermission.whileInUse) {
      requestLocationPermission(isForDeliveryBtn);
    } else {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        if(isForDeliveryBtn) {
          setState(() {
            orderOption = 2;
            calculateSubtotal();
          });
          goToDeliveryAddress();
        }else{
          goToPaymentMethodPage();
        }
      } else {
        locationEnableAlert();
      }
    }
  }

  Future<bool> requestLocationPermission(bool isForDeliveryBtn) async {
    return _requestPermission(isForDeliveryBtn);
  }

  Future<bool> _requestPermission(bool isForDeliveryBtn) async {
    print('_requestPermission');
    var result = await Geolocator.requestPermission();
    if (result == LocationPermission.whileInUse) {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        if(isForDeliveryBtn) {
          goToDeliveryAddress();
        }else{
          goToPaymentMethodPage();
        }
      } else {

        locationEnableAlert();
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      var serviceStatus = await Geolocator.isLocationServiceEnabled();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus) {
        locationEnableAlert();
      } else {
        Alert(
          context: scaffoldKey.currentContext!,
          type: AlertType.warning,
          title: S.of(scaffoldKey.currentContext!).alert_location_service_permission_title,
          desc: S.of(scaffoldKey.currentContext!).alert_location_service_permission_message,
          style: AlertStyle(
              titleStyle: Theme.of(scaffoldKey.currentContext!)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 18)),
              descStyle: Theme.of(scaffoldKey.currentContext!)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 16))),
          buttons: [
            DialogButton(
              child: Text(
                S.of(scaffoldKey.currentContext!).alert_location_service_btn,
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
              onPressed: () {
                Navigator.pop(scaffoldKey.currentContext!);
                Geolocator.openAppSettings();
              },
            )
          ],
        ).show();
      }
      //}
    }
    return false;
  }

  void goToPaymentMethodPage() {
    bool isDeliverable = true;
    for (int i = 0; i < carts.length; i++) {
      if (!carts[i].food.deliverable) {
        isDeliverable = false;
        break;
      }
    }
    List<Map> params = carts.map((element) => element.toMap(true)).toList();
    String orderItams = json.encode(params);
    print('orderItams:$orderItams');
    print('_con.total:$total');
    userRepo.setOrderJsonArray(orderItams);
    Navigator.of(scaffoldKey.currentContext!).pushNamed('/PaymentMethod',arguments: RouteArgument(param: isForPickUp));
  }
}
