import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:food_delivery_app/src/models/user.dart';
import 'package:food_delivery_app/src/repository/settings_repository.dart'
    as settingRepo;
import 'package:food_delivery_app/src/repository/user_repository.dart'
    as userRepo;
import 'package:food_delivery_app/src/repository/yaadpay_repository.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:webview_flutter/webview_flutter.dart';

class YaadPayController extends ControllerMVC {
  late GlobalKey<ScaffoldState> scaffoldKey;
  String webViewUrl = "";
  double progress = 10;
  String amount = "0";
  String del = "0";
  String heshDesc = "";
  String orderId = "12345678910";
  bool isLoading = false;
  late WebViewController webViewController;

  //heshDesc=[0~Item 1~1~8][0~Item 2~2~1]
  String orderItems = "";
  late UserModel user;

  YaadPayController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    heshDesc = "";
    amount = "0";
    user = userRepo.currentUser.value;
    //getOrderJsonArray();
  }

  void getOrderJsonArray(bool isForPickUp) async {
    Future<String> future = userRepo.getOrderJsonArray();
    future.then((jsonArray) {
      print('OrderjsonArray:$jsonArray');
      List<dynamic>? decodedJSON = null;
      try {
        decodedJSON = json.decode(jsonArray) as List<dynamic>;
        print('decodedJSON:$decodedJSON');
        double total_amount = settingRepo.setting.value.orderAmount;
        double deliveryFee = settingRepo.setting.value.deliveryFee;
        if ((settingRepo.setting.value.is_used == 1 && settingRepo.setting.value.couponType == 1) || isForPickUp) {
          deliveryFee = 0.0;
        }
        total_amount += deliveryFee;
        if (settingRepo.setting.value.is_used == 1) {
          total_amount = total_amount - settingRepo.setting.value.discount;
        }
        amount = '$total_amount';
        heshDesc = "[0~סה׳׳כ הזמנה~1~$total_amount]";
        print('heshDesc:$heshDesc');
        getSignatureFromYaadPayApi();
      } on FormatException catch (e) {
        print("The provided string is not valid JSON addCart:$e");
      }
    });
  }

  void getSignatureFromYaadPayApi() async {
    String url =
        "https://icom.yaad.net/p3/?action=APISign&What=SIGN&KEY=${Constants.YAADPAY_KEY}&PassP=${Constants.YAADPAY_PASS}&Masof=${Constants.YAADPAY_MASOF}"
        "&Order=$orderId&Info=&Amount=$amount&UTF8=True&UTF8out=True&UserId=&ClientLName=&ClientName=${user.name}}&street=&city=&zip=&phone=${user.phone}&cell=&email=${user.email}&Tash=1&FixTash=False&ShowEngTashText=False&Coin=1&Postpone=False&J5=False&Sign=True&MoreData=True&sendemail=True&SendHesh=True"
        "&heshDesc=$heshDesc&Pritim=True&PageLang=HEB&tmp=${Constants.YAADPAY_TMP}";
    print('ApiSign:$url');
    final Stream<String> stream = await getSignature(url);
    stream.listen((String response) {
      print("ApiSign response:$response");
      setState(() {
        this.webViewUrl = "https://icom.yaad.net/p3/?action=pay&$response";
        print("Payment url:${this.webViewUrl}");
        //webViewController.loadUrl(this.webViewUrl);
      });
    }, onError: (a) {
      print(a);
      setState(() {
        isLoading = false;
      });
      /*scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.current.verify_your_internet_connection),
      ));*/
    }, onDone: () {
      Navigator.of(scaffoldKey.currentContext!).pushNamed('/YaadPay',
          arguments: new RouteArgument(param: this.webViewUrl));
      setState(() {
        isLoading = false;
      });
    });
  }
}
