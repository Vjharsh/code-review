import 'dart:async';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/extra.dart';
import 'package:mvc_pattern/mvc_pattern.dart';

import '../../generated/l10n.dart';
import '../models/cart.dart';
import '../models/credit_card.dart';
import '../models/food_order.dart';
import '../models/order.dart';
import '../models/order_status.dart';
import '../models/payment.dart';
import '../repository/cart_repository.dart';
import '../repository/order_repository.dart' as orderRepo;
import '../repository/settings_repository.dart' as settingRepo;
import '../repository/user_repository.dart' as userRepo;

class CheckoutController extends ControllerMVC {
  List<Cart> carts = <Cart>[];
  late Payment payment;
  //double taxAmount = 0.0;
  double deliveryFee = 0.0;
  double subTotal = 0.0;
  double discount = 0.0;
  double total = 0.0;
  CreditCard creditCard = new CreditCard();
  bool loading = true;
  late GlobalKey<ScaffoldState> scaffoldKey;

  CheckoutController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForCreditCard();
  }

  void listenForCreditCard() async {
    creditCard = await userRepo.getCreditCard();
    setState(() {});
  }

  void listenForCarts({String? message, required bool withAddOrder}) async {
    final Stream<Cart> stream = await getCart();
    stream.listen((Cart _cart) {
      /*_cart.extras.forEach((_extras){
        print('Cart Extras pivot1: ${_extras.extraPivot.toMap()}');
      });*/

      if (!carts.contains(_cart)) {
        setState(() {
          carts.add(_cart);
        });
      }
    }, onError: (e) {
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForCarts(message: Constants.RETRY, withAddOrder: withAddOrder);
      }
      /*ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      calculateSubtotal();
      if (withAddOrder) {
        print('WithAddOrder:$withAddOrder  ||  listenForCarts called');
        addOrder(carts);
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void addOrder(List<Cart> carts) async {
    Order _order = new Order();
    _order.foodOrders = <FoodOrder>[];
    _order.tax = 0; //carts[0].food.restaurant.defaultTax;
    _order.deliveryFee = payment.method == Constants.PAYMENT_METHOD_PICKUP
        ? 0
        : settingRepo
            .setting.value.deliveryFee; //carts[0].food.restaurant.deliveryFee;
    _order.deliveryFeeName = payment.method == Constants.PAYMENT_METHOD_PICKUP
        ? ''
        : settingRepo
        .setting.value.deliveryFeeName;
    if (settingRepo.setting.value.is_used == 1 && settingRepo.setting.value.couponType == 1) {
      _order.deliveryFee = 0.0;
    }
    print('_order.deliveryFee:${_order.deliveryFee}');
    OrderStatus _orderStatus = new OrderStatus();
    _orderStatus.id = '1'; // TODO default order status Id
    _order.orderStatus = _orderStatus;
    _order.deliveryAddress = settingRepo.deliveryAddress.value;
    carts.forEach((_cart) {
      _cart.extras.forEach((_extras) {
        print('Cart Extras pivot2: ${_extras.extraPivot.toMap()}');
      });
      FoodOrder _foodOrder = new FoodOrder();
      _foodOrder.quantity = _cart.quantity;
      _foodOrder.price = _cart.food.price;
      _foodOrder.price_with_extra = _cart.food.priceWithExtra;
      _foodOrder.food = _cart.food;

      _foodOrder.extras = _cart.extras;
      for (int i = 0; i < _foodOrder.extras.length; i++) {
        Extra extra = _foodOrder.extras[i];
        extra.id = _foodOrder.extras[i].extraPivot.extra_id;
        extra.price = _foodOrder.extras[i].extraPivot.extra_price;
        extra.qty = _foodOrder.extras[i].extraPivot.extra_qty;
        extra.pizzaStatus =
            int.parse(_foodOrder.extras[i].extraPivot.pizza_status);
        extra.pizzaType = _foodOrder.extras[i].extraPivot.pizza_type;
        extra.fullPrice = _foodOrder.extras[i].extraPivot.full_price;
        extra.halfPrice = _foodOrder.extras[i].extraPivot.half_price;
      }
      _order.foodOrders.add(_foodOrder);
    });
    print("orderrrrsssss:::-->>> ${_order.toMap()}");
    settingRepo.getDeliveryOption().then((isForDelivery){
      print('getDeliveryOption: $isForDelivery');
      if(isForDelivery){
        orderRepo.addOrder(_order, this.payment, isForDelivery).then((value) {
          if (value == "1") {
            setState(() {
              loading = false;
            });
          }
        });
      } else{
        orderRepo.addOrder(_order, this.payment, isForDelivery).then((value) {
          print('else called checkout');
          if (value == "1") {
            setState(() {
              loading = false;
            });
          }
        });
      }
    });
  }

  void calculateSubtotal() async {
    subTotal = 0;
    deliveryFee = 0;
    if (carts.isNotEmpty) {
      //deliveryFee = carts[0].food.restaurant.deliveryFee;
      deliveryFee = payment.method == Constants.PAYMENT_METHOD_PICKUP
          ? 0
          : settingRepo.setting.value
              .deliveryFee; //carts[0].food.restaurant.deliveryFee;
    }

    if (settingRepo.setting.value.is_used == 1 && settingRepo.setting.value.couponType == 1) {
      deliveryFee = 0.0;
    }
    carts.forEach((cart) {
      double cartItemTotal = 0;
      cartItemTotal += cart.food.price;
      cart.extras.forEach((Extra extra) {
        double extraPrice = extra.extraPivot.extra_price != 0
            ? extra.extraPivot.extra_price
            : 0;
        double extraQty =
            extra.extraPivot.extra_qty != 0 ? extra.extraPivot.extra_qty : 0;
        cartItemTotal += extraPrice * extraQty;
      });
      cartItemTotal *= cart.quantity;
      subTotal += cartItemTotal;
    });
    total = subTotal + deliveryFee;
    if (settingRepo.setting.value.is_used == 1 &&
        (settingRepo.setting.value.couponType == 2 ||
            settingRepo.setting.value.couponType == 3)) {
      discount = settingRepo.setting.value.discount;
      total = total - settingRepo.setting.value.discount;
    }
    setState(() {});
  }

  void updateCreditCard(CreditCard creditCard) {
    userRepo.setCreditCard(creditCard).then((value) {
      setState(() {});
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext!).payment_card_updated_successfully),
      ));
    });
  }
}
