import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/main.dart';
import 'package:food_delivery_app/src/helpers/maps_util.dart';
import 'package:food_delivery_app/src/models/all_restaurants_with_menu.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/models/delivery_time.dart';
import 'package:food_delivery_app/src/models/filter.dart';
import 'package:food_delivery_app/src/repository/cart_repository.dart';
import 'package:geocode/geocode.dart';

import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../generated/l10n.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:package_info/package_info.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:url_launcher/url_launcher.dart';

import '../helpers/helper.dart';
import '../models/app_banner.dart';
import '../models/food.dart';
import '../models/offer.dart';
import '../models/restaurant.dart';
import '../models/review.dart';
import '../repository/food_repository.dart';
import '../repository/restaurant_repository.dart';
import '../repository/settings_repository.dart';
import 'package:lottie/lottie.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import '../repository/cuisine_repository.dart';
import 'dart:math' show cos, sqrt, asin;
import '../helpers/sqlite_helper.dart';
import 'package:http/http.dart' as http;

class HomeController extends ControllerMVC {
  //List<Category> categories = <Category>[];
  List<Restaurant> topRestaurants = <Restaurant>[];
  List<Restaurant> popularRestaurants = <Restaurant>[];
  List<Review> recentReviews = <Review>[];
  List<Food> trendingFoods = <Food>[];
  List<String> bannerList = <String>[];
  List<AppBanner> bannerAppList = <AppBanner>[];
  List<Offer> OfferData = <Offer>[];
  List<Cuisine> cuisines = <Cuisine>[];
  bool isOpen = false;
  bool isReviewLoading = false;
  bool isFirsTime = true;
  int openRestaurantsCount = 0;
  late GlobalKey<ScaffoldState> scaffoldKey;
  late DeliveryTime deliveryTime;
  bool isDeliveryTime = false;

  HomeController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    if (setting.value.appVersion != '') {
      getFilter().then((value) {
        isOpen = value;

        listenForDeliveryTime();
        listenForAllRestaurants();
        listenForBanner();
        listenForTopRestaurants();
        listenForTrendingFoods();
        listenForCuisines();
        listenForPopularRestaurants();
        listenForRecentReviews();
        requestForCurrentLocationWithoutContext();
      });
    }
  }

  Future<bool> getFilter() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    Filter filter =
        Filter.fromJSON(json.decode(prefs.getString('filter') ?? '{}'));
    return filter.open;
  }

  void addCurrentLocation(double latitude, double longitude) async {
    print('locationData.latitude:${latitude}');
    print('locationData.longitude:${longitude}');
    try {
     // final coordinates = new Coordinates(latitude, longitude);
      final coordinates = new Coordinates(latitude:latitude, longitude:longitude);
     // var addressesByLatLong =
      var addresses = await GeoCode().reverseGeocoding(latitude: coordinates.latitude!, longitude: coordinates.longitude!);
      var first = addresses.streetAddress;
     // var first = addressesByLatLong.first;
      print("addressLine : $first");
    } catch (e) {
      print(e);
    }
  }

  void getAppVersion() {
    PackageInfo.fromPlatform().then((PackageInfo packageInfo) {
      String appName = packageInfo.appName;
      String packageName = packageInfo.packageName;
      String packageVersion = packageInfo.version;
      String buildNumber = packageInfo.buildNumber;
      print('packageName:$packageName');
      print('appName:$appName');
      print('version:$packageVersion');
      print('buildNumber:$buildNumber');
      print('setting.value.appVersion:${setting.value.appVersion}');
      print('compareTo:${packageVersion.compareTo(setting.value.appVersion)}');
      if (packageVersion.compareTo(setting.value.appVersion) < 0) {
        appVersionAlert();
      }
    });
  }

  void appVersionAlert() {
    print('appVersionAlert');
    Alert(
      context: scaffoldKey.currentContext!,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).alert_update_app_version_title,
      desc: S.of(scaffoldKey.currentContext!).alert_update_app_version_message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).update_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            //Navigator.pop(context);
            /*Navigator.of(context).pushNamed('/Web',
                arguments: RouteArgument(id: "https://tazmin.net/download"));*/
            goToExternalBrowser();
          },
          width: 120,
        )
      ],
    ).show();
  }

  void goToExternalBrowser() async {
    String url = "https://tazmin.net/download";
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  void offerAlert(Offer offer) {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.none,
      title: offer.title,
//      desc: Helper.skipHtml(offer.description),
//      image: Lottie.asset('assets/LottieLogo1.json'),
      content: Column(
        children: <Widget>[
          SizedBox(
            height: 5,
          ),
          Lottie.asset('assets/img/offer_animation.json',
              width: 150, height: 150, fit: BoxFit.fill),
          /*SizedBox(height: 5,),
          Text(
            offer.title,
            style: Theme.of(context)
                .textTheme
                .subtitle1,
          ),*/
          SizedBox(
            height: 10,
          ),
          Text(
            Helper.skipHtml(offer.description),
            style: Theme.of(scaffoldKey.currentContext!)
                .textTheme
                .headline1!
                .merge(TextStyle(fontSize: 23)),
          ),
        ],
      ),
      style: AlertStyle(
          isCloseButton: false,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 20, fontWeight: FontWeight.w500))),
      buttons: [
        if (offer.type_id != '5')
          DialogButton(
            child: Text(
              S.of(scaffoldKey.currentContext!).go_to_offer,
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            onPressed: () {
              Navigator.pop(scaffoldKey.currentContext!);
              setting.value.offerFirstTime = false;
              print('offerType_id:${offer.type_id}');
              print('offerRedirectUrl:${offer.redirect_url}');

              if (offer.type_id == '1') {
                //Restaurant
                Navigator.of(scaffoldKey.currentContext!).pushNamed('/Details',
                    arguments: RouteArgument(
                      id: offer.redirect_url,
                      heroTag: "",
                    ));
              } else if (offer.type_id == '2') {
                //Category
                Navigator.of(scaffoldKey.currentContext!).pushNamed('/Category',
                    arguments: RouteArgument(id: offer.redirect_url));
              } else if (offer.type_id == '3') {
                //Food
                Navigator.of(scaffoldKey.currentContext!).pushNamed('/Food',
                    arguments:
                        RouteArgument(id: offer.redirect_url, heroTag: ""));
              } else if (offer.type_id == '4') {
                //Custom URL
                Navigator.of(scaffoldKey.currentContext!).pushNamed('/Web',
                    arguments: RouteArgument(id: offer.redirect_url));
              }
            },
            width: 120,
          ),
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 15),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
            setting.value.offerFirstTime = false;
          },
        ),
      ],
    ).show();
  }

  void listenForOffers({String? message}) async {
    final Stream<Offer> stream = await getOffer();
    stream.listen((Offer offer) {
      OfferData.add(offer);
    }, onError: (a) {
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForOffers(message: Constants.RETRY);
      }*/
    }, onDone: () {
      print('offerlenght:${OfferData.length}');
      if (OfferData.isNotEmpty) {
        for (int i = 0; i < OfferData.length; i++) {
          if (OfferData[i].is_active == '1') {
            offerAlert(OfferData[i]);
            break;
          }
        }
      }
    });
  }

  void listenForBanner({String? message}) async {
    bannerAppList.clear();
    bannerList.clear();
    final Stream<AppBanner> stream = await getBanner();
    stream.listen((AppBanner _banner) {
      bannerAppList.add(_banner);
    }, onError: (a) {
      print('onError listenForBanner():${a.toString()}');
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForBanner(message: Constants.RETRY);
      }*/
    }, onDone: () {
      for (int i = 0; i < bannerAppList.length; i++) {
        bannerList.add(bannerAppList[i].image.url);
      }
      setState(() {});
      print('onDone listenForBanner()');
      print('Banner List:${bannerList.length}');
    });
  }

  /* Future<void> listenForCategories({String message}) async {
    categories = <Category>[];
    final Stream<Category> stream = await getCategories();
    stream.listen((Category _category) {
      setState(() => categories.add(_category));
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(context, message)) {
        listenForCategories(message: Constants.RETRY);
      }
    }, onDone: () {});
  }*/
  void listenForCuisines({String? message}) async {
    cuisines.clear();
    final Stream<Cuisine> stream = await getCuisines();
    stream.listen((Cuisine _cuisine) {
      setState(() {
        cuisines.add(_cuisine);
      });
    }, onError: (a) {
      print(a);
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForCuisines(message: Constants.RETRY);
      }*/
    }, onDone: () {
      print('call offer');
      if (setting.value.offerFirstTime) {
        listenForOffers();
      }
      getAppVersion();
    });
  }

  double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
    var p = 0.017453292519943295;
    var c = cos;
    var a = 0.5 -
        c((lat2 - lat1) * p) / 2 +
        c(lat1 * p) * c(lat2 * p) * (1 - c((lon2 - lon1) * p)) / 2;
    return 12742 * asin(sqrt(a));
  }

  Future<void> listenForAllRestaurants({String? message}) async {
    http.Response response = await getAllRestaurantsWithMenu();
    if (response.statusCode == 200) {
      String responseStr = response.body.toString();
      responseStr = responseStr.replaceAll("\\\"", "");
      List<AllRestaurantsWithMenu> jsonList =
          List.from(json.decode(responseStr)['data'])
              .map((element) => AllRestaurantsWithMenu.fromJSON(element))
              .toList();
      print("allRestaurantsWithMenu jsonList:${jsonList.length}");
      if (jsonList.length > 0) {
        await SQLiteHelper().deleteAllRecord();
      }
      jsonList.forEach((allRestaurantsWithMenu) async {
        int id = await SQLiteHelper().addItemInDataBase(
            allRestaurantsWithMenu.id, allRestaurantsWithMenu.menu);
        if (id > 0) {
          //print("Record added");
        } else {
          //print("Failed to insert record");
        }
      });
    }
  }

  Future<void> listenForTopRestaurants({String? message}) async {
    topRestaurants.clear();
    openRestaurantsCount = 0;
    final Stream<Restaurant> stream =
        await getNearRestaurants(deliveryAddress.value, deliveryAddress.value);
    stream.listen((Restaurant _restaurant) async {
      print('restaurant name: ${_restaurant.name}');
      print('restaurant resOpeningStatus: ${_restaurant.resOpeningStatus}');
      print('videoURL: ${_restaurant.videoURL}');
      print('video: ${_restaurant.video}');

      if (_restaurant.resOpeningStatus == true) {
        bool isDuplicate = false;

        for (int i = 0; i < topRestaurants.length; i++) {
          if (topRestaurants.elementAt(i).id == _restaurant.id) {
            isDuplicate = true;
            break;
          }
        }
        if (!isDuplicate) {
          setState(() => topRestaurants.add(_restaurant));
        }
      }
    }, onError: (a) {
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForTopRestaurants(message: Constants.RETRY);
      }*/
    }, onDone: () {
      setState(() {
        openRestaurantsCount = topRestaurants.length;
        print('openRestaurantsCount: $openRestaurantsCount');
      });
    });
  }

  Future<void> listenForPopularRestaurants({String? message}) async {
    popularRestaurants.clear();
    final Stream<Restaurant> stream =
        await getPopularRestaurants(deliveryAddress.value);
    stream.listen((Restaurant _restaurant) {
      if (isOpen) {
        if (_restaurant.resOpeningStatus) {
          setState(() => popularRestaurants.add(_restaurant));
        }
      } else {
        setState(() => popularRestaurants.add(_restaurant));
      }
    }, onError: (a) {
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForPopularRestaurants(message: Constants.RETRY);
      }*/
    }, onDone: () {});
  }

  Future<void> listenForRecentReviews({String? message}) async {
    recentReviews.clear();
    setState(() {
      isReviewLoading = true;
    });
    final Stream<Review> stream = await getRecentReviews();
    stream.listen((Review _review) {
      setState(() => recentReviews.add(_review));
    }, onError: (a) {
      setState(() {
        isReviewLoading = false;
      });
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForRecentReviews(message: Constants.RETRY);
      }*/
    }, onDone: () {
      setState(() {
        isReviewLoading = false;
      });
    });
  }

  Future<void> listenForTrendingFoods({String? message}) async {
    trendingFoods.clear();
    final Stream<Food> stream = await getTrendingFoods(deliveryAddress.value);
    stream.listen((Food _food) {
      if (isOpen) {
        if (_food.restaurant.resOpeningStatus == true) {
          setState(() => trendingFoods.add(_food));
        }
      } else {
        setState(() => trendingFoods.add(_food));
      }
    }, onError: (a) {
      print(a);
      /*if (Helper.checkRetryMessage(context, message, error: a.toString())) {
        listenForTrendingFoods(message: Constants.RETRY);
      }*/
    }, onDone: () {});
  }

  void requestForCurrentLocation(BuildContext context) async {
    OverlayEntry loader = Helper.overlayLoader(context);
    Overlay.of(context)?.insert(loader);
    /*setCurrentLocation().then((_address) async {
      loader.remove();
      setState(() {
        if(_address != null) {
          deliveryAddress.value = _address;
          MyApp.address = _address.address;
          print('MyApp.address:${MyApp.address}');
          deliveryAddress.notifyListeners();
        }
      });
      //await refreshHome();
    }).catchError((e) {
      loader.remove();
    });*/
    Geolocator
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
        .then((position) async {
      if (position != null) {
        print('requestForCurrentLocation position');
        try {
          MapsUtil mapsUtil = MapsUtil();
          String _addressName = await mapsUtil.getAddressName(
              new LatLng(position.latitude, position.longitude));
          print('requestForCurrentLocation _addressName:$_addressName');
          print('requestForCurrentLocation latitude:${position.latitude}');
          print('requestForCurrentLocation longitude:${position.longitude}');
          loader.remove();
          if (_addressName != null) {
            print('requestForCurrentLocation _addressName');

            setState(() {
              deliveryAddress.value.address = _addressName;
              deliveryAddress.value.latitude = position.latitude;
              deliveryAddress.value.longitude = position.longitude;
              if (deliveryAddress.value != null) {
                MyApp.addressDTO = deliveryAddress.value;
                print('MyApp.address:${MyApp.addressDTO?.address}');
                deliveryAddress.notifyListeners();
              }
            });
          }
        } catch (e) {
          print('requestForCurrentLocation Error:${e.toString()}');
          loader.remove();
          print(e);
        }
      } else {
        loader.remove();
      }
    });
  }

  void requestForCurrentLocationWithoutContext() async {
    try {
      MapsUtil mapsUtil = MapsUtil();
      String _addressName = await mapsUtil.getAddressName(new LatLng(
          deliveryAddress.value.latitude, deliveryAddress.value.longitude));
      if (_addressName != null) {
        setState(() {
          deliveryAddress.value.address = _addressName;
          if (deliveryAddress.value != null) {
            MyApp.addressDTO = deliveryAddress.value;
            print('MyApp.address:${MyApp.addressDTO?.address}');
            deliveryAddress.notifyListeners();
          }
        });
      }
    } catch (e) {
      print(e);
    }
  }

  Future<void> refreshHome() async {
    setState(() {
      //categories = <Category>[];
      cuisines.clear();
      topRestaurants.clear();
      popularRestaurants.clear();
      recentReviews.clear();
      trendingFoods.clear();
    });
    listenForDeliveryTime();
    await listenForTopRestaurants();
    await listenForTrendingFoods();
    //await listenForCategories();
    await listenForCuisines;
    await listenForPopularRestaurants();
    await listenForRecentReviews();
  }



  void listenForDeliveryTime({String? message}) async {
    deliveryTime = DeliveryTime();
    final Stream<DeliveryTime> stream = await getDeliveryTime();
    stream.listen((DeliveryTime _deliveryTime) {
      if (deliveryTime != _deliveryTime) {
        setState(() {
          print('listenForDeliveryTime');
          deliveryTime = _deliveryTime;
        });
      }
    }, onError: (a) {
      print(a);
      if (message != Constants.RETRY) {
        listenForDeliveryTime(message: Constants.RETRY);
      }
    }, onDone: () async {
      print('onDone listenForDeliveryTime');
      if (deliveryTime != null) {
        isDeliveryTime = deliveryTime.getDriverDeliveryStatus();
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }
}
