

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import '../models/faq_category.dart';
import '../repository/faq_repository.dart';

class FaqController extends ControllerMVC {
  List<FaqCategory> faqs = <FaqCategory>[];
  late GlobalKey<ScaffoldState> scaffoldKey;

  FaqController() {
    scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForFaqs();
  }

  void listenForFaqs({String? message}) async {
    final Stream<FaqCategory> stream = await getFaqCategories();
    stream.listen((FaqCategory _faq) {
      setState(() {
        faqs.add(_faq);
      });
    }, onError: (e) {
      print(e);
      if(Helper.checkRetryMessage(scaffoldKey.currentContext, message!,error: e.toString())) {
        listenForFaqs(message: Constants.RETRY);
      }
      /* scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (message != null) {
        if(Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  Future<void> refreshFaqs() async {
    faqs.clear();
    listenForFaqs(message: 'Faqs refreshed successfuly');
  }
}
