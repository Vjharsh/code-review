import 'dart:convert';


import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/cart.dart';
import 'package:food_delivery_app/src/models/extra.dart';
import 'package:food_delivery_app/src/models/food.dart';
import 'package:food_delivery_app/src/models/food_order.dart';
import 'package:lottie/lottie.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:rflutter_alert/rflutter_alert.dart';
import '../../generated/l10n.dart';
import '../models/order.dart';
import '../repository/order_repository.dart';
import '../repository/cart_repository.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:http/http.dart' as http;

class OrderController extends ControllerMVC {
  late http.Response response;
  List<Order> orders = <Order>[];
  late GlobalKey<ScaffoldState> scaffoldKey;
  bool isLoading = false;
  int selectedIndex = -2;
  List<FoodOrder> foodOrders = <FoodOrder>[];
  int counter = 0;

  OrderController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForOrders();
  }

  void listenForOrders({String? message}) async {
    final Stream<Order> stream = await getOrders();
    stream.listen((Order _order) {
      //print('getOrder :${_order.toMap()}');
      setState(() {
        orders.add(_order);
      });
    }, onError: (e) {
      print(e);
      // if(Helper.checkRetryMessage(scaffoldKey.currentContext, message!,error: e.toString())) {
        listenForOrders(message: Constants.RETRY);
      // }
     /* scaffoldKey?.currentState?.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (message != null) {
        if(Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }
  void addToCartFromFoodArray()
  {
    print('foodOrders Counter:$counter');
    addToCart(foodOrders.elementAt(counter).food, foodOrders.elementAt(counter).extras, foodOrders.elementAt(counter).quantity);
  }
  void addToCart(Food food,List<Extra> extras,double quantity) async {
    if(counter == 0)
    {
      setState((){
        isLoading = true;
      });
    }
    print('addToCart');
    var _newCart = new Cart();
    _newCart.food = food;
    // _newCart.extras = extra;
    List<Extra> newExtras = <Extra>[];
    for (int i = 0; i < extras.length; i++) {
        Extra extra =  extras[i];
        if(extra.extraPivot.pizza_status == '1') {
          extra.pizzaStatus = 1;
          extra.pizzaType = extra.extraPivot.pizza_type;
          extra.fullPrice = extra.extraPivot.full_price;
          extra.halfPrice = extra.extraPivot.half_price;
          extra.price = extra.extraPivot.extra_price;
          newExtras.add(extra);
        } else{
          extra.price = extra.extraPivot.extra_price;
          newExtras.add(extra);
        }
    }
    _newCart.extras = newExtras;
    _newCart.quantity = quantity;
    print('_newCart');
    addCartForReorder(_newCart, counter==0 ? true:false).then((value) {
      this.response = value;

      /*try {
        decodedJSON = json.decode(response.body)['data'] as Map<String, dynamic>;
      } on FormatException catch (e) {
        print(CustomTrace(StackTrace.current, message: e.toString()));
      }
      Cart.fromJSON(decodedJSON);*/

    }).whenComplete(() {
      Map<String, dynamic> decodedJSON = {};
      decodedJSON = json.decode(response.body) as Map<String, dynamic>;
      if(response.statusCode == 200)
      {
        if(counter == foodOrders.length-1) {
          setState((){
            isLoading = false;
          });
          counter = 0;
          Navigator.of(scaffoldKey.currentContext!).pushNamed('/Cart',arguments: RouteArgument(id: '1'));
        } else {
          counter++;
          addToCartFromFoodArray();
        }
      } else {
        setState((){
          isLoading = false;
        });
        counter = 0;
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(decodedJSON['message']),
        ));
      }

    });
  }
  void doCancelOrder(Order order) {
    cancelOrder(order).then((value) {
      setState(() {
        order.active = false;
      });
    }).catchError((e) {
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(e),
      ));
    }).whenComplete(() {
      refreshOrders();
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext!).orderThisorderidHasBeenCanceled(order.id)),
      ));
    });
  }

  Future<void> refreshOrders() async {
    orders.clear();
    listenForOrders(message: S.of(scaffoldKey.currentContext!).order_refreshed_successfuly);
  }
  void addToCartAlert(Food food) {
    Dialog addToCartAlertDialog = Dialog(
      insetPadding: EdgeInsets.all(0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      //this right here
      child: Container(
        height: 250,
        width: 250,
        child: Column(
          children: <Widget>[
            Lottie.asset('assets/img/success_animation.json',
                width: 150, height: 150, fit: BoxFit.fill),
            Text(
              S.of(scaffoldKey.currentContext!).add_to_cart_popup_message(food.name),
              style: Theme.of(scaffoldKey.currentContext!)
                  .textTheme
                  .headline1!
                  .merge(TextStyle(fontSize: 16)),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                      child: DialogButton(
                        child: Text(
                          S.of(scaffoldKey.currentContext!).checkout_add_to_cart,
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        ),
                        onPressed: () {
                          Navigator.pop(scaffoldKey.currentContext!);
                          Navigator.of(scaffoldKey.currentContext!).pushNamed('/Cart');
                        },
                      )),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: DialogButton(
                        child: Text(
                          S.of(scaffoldKey.currentContext!).continue_order,
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        ),
                        onPressed: () {
                          Navigator.pop(scaffoldKey.currentContext!);
                          Navigator.pop(scaffoldKey.currentContext!);
                          //refreshFood();
                        },
                      )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: scaffoldKey.currentContext!,
        barrierDismissible: false,
        builder: (BuildContext context) => addToCartAlertDialog);
  }

}
