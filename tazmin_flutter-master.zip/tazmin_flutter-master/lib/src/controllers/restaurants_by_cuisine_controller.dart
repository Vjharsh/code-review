import 'package:flutter/material.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/models/delivery_time.dart';
import 'package:food_delivery_app/src/repository/cart_repository.dart';
import 'package:food_delivery_app/src/repository/cuisine_repository.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
class RestaurantsByCuisineController extends ControllerMVC {
  late GlobalKey<ScaffoldState> scaffoldKey;
  late Cuisine cuisine;
  bool isLoading = true;
  late DeliveryTime deliveryTime;
  bool isDeliveryTime = false;

  RestaurantsByCuisineController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  void listenForCuisines(String id,{String? message}) async {
    cuisine= new Cuisine();
    final Stream<Cuisine> stream = await getCuisinesByID(id);
    stream.listen((Cuisine _cuisine) {
      setState(() {
        cuisine=_cuisine;
      });
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!,error: a.toString())) {
        listenForCuisines(id, message: Constants.RETRY);
      }
    }, onDone: () {
      setState(() {
        isLoading = false;
      });
    });
  }

  void listenForDeliveryTime({String? message}) async {
    deliveryTime = DeliveryTime();
    final Stream<DeliveryTime> stream = await getDeliveryTime();
    stream.listen((DeliveryTime _deliveryTime) {
      if (deliveryTime != _deliveryTime) {
        setState(() {
          print('listenForDeliveryTime');
          deliveryTime = _deliveryTime;
        });
      }
    }, onError: (a) {
      print(a);
      if (message != Constants.RETRY) {
        listenForDeliveryTime(message: Constants.RETRY);
      }
    }, onDone: () async {
      print('onDone listenForDeliveryTime');
      if (deliveryTime != null) {
        isDeliveryTime = deliveryTime.getDriverDeliveryStatus();
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message)) {
          scaffoldKey.currentState?.showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }
}
