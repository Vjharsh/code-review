

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import '../../generated/l10n.dart';
import '../models/cart.dart';
import '../models/category.dart';
import '../models/food.dart';
import '../repository/cart_repository.dart';
import '../repository/category_repository.dart';
import '../repository/food_repository.dart';

class CategoryController extends ControllerMVC {
  List<Food> foods = <Food>[];
  late GlobalKey<ScaffoldState> scaffoldKey;
  late Category category;
  bool loadCart = false;
  bool isDataEmpty = false;
  List<Cart> carts = [];

  CategoryController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  void listenForFoodsByCategory({String? id, String? message}) async {
    final Stream<Food> stream = await getFoodsByCategory(id);
    stream.listen((Food _food) {
      setState(() {
        foods.add(_food);
      });
    }, onError: (e) {
      if(Helper.checkRetryMessage(scaffoldKey.currentContext, message!,error: e.toString())) {
        listenForFoodsByCategory(id:id,message: Constants.RETRY);
      }
      /*scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if(foods.length == 0) {
        setState(() {
          isDataEmpty = true;
        });
      }else{
        setState(() {
          isDataEmpty = false;
        });
      }
      if (message != null) {
        if(Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void listenForCategory({String? id, String? message}) async {
    final Stream<Category> stream = await getCategory(id!);
    stream.listen((Category _category) {
      setState(() => category = _category);
    }, onError: (e) {
      print(e);
      if(Helper.checkRetryMessage(scaffoldKey.currentContext, message!,error: e.toString())) {
        listenForCategory(id:id,message: Constants.RETRY);
      }
      /*scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (message != null) {
        if(Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  Future<void> listenForCart() async {
    final Stream<Cart> stream = await getCart();
    stream.listen((Cart _cart) {
      carts.add(_cart);
    });
  }

  bool isSameRestaurants(Food food) {
    if (carts.isNotEmpty) {
      return carts[0].food.restaurant.id == food.restaurant.id;
    }
    return true;
  }

  void addToCart(Food food, {bool reset = false}) async {
    setState(() {
      this.loadCart = true;
    });
    var _newCart = new Cart();
    _newCart.food = food;
    _newCart.extras = [];
    _newCart.quantity = 1;
    // if food exist in the cart then increment quantity
    var _oldCart = isExistInCart(_newCart);
    if (_oldCart != Cart()) {
      _oldCart.quantity++;
      updateCart(_oldCart).then((value) {
        setState(() {
          this.loadCart = false;
        });
      }).whenComplete(() {
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(scaffoldKey.currentContext!).this_food_was_added_to_cart),
        ));
      });
    } else {
      // the food doesnt exist in the cart add new one
      addCart(_newCart, reset).then((value) {
        setState(() {
          this.loadCart = false;
        });
      }).whenComplete(() {
        if (reset) carts.clear();
        carts.add(_newCart);
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(scaffoldKey.currentContext!).this_food_was_added_to_cart),
        ));
      });
    }
  }

  Cart isExistInCart(Cart _cart) {
    return carts.firstWhere((Cart oldCart) => _cart.isSame(oldCart), orElse: () => Cart());
  }

  Future<void> refreshCategory() async {
    foods.clear();
    category = new Category();
    listenForFoodsByCategory(message: S.of(scaffoldKey.currentContext!).category_refreshed_successfuly);
    listenForCategory(message: S.of(scaffoldKey.currentContext!).category_refreshed_successfuly);
  }
}
