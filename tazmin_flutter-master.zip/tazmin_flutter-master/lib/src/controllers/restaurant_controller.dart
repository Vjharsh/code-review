import 'dart:convert';

// import 'package:cached_video_player/cached_video_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:food_delivery_app/main.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/ResetMenu.dart';
import 'package:food_delivery_app/src/models/all_restaurants_with_menu.dart';
import 'package:food_delivery_app/src/models/categoris_tab.dart';
import 'package:food_delivery_app/src/models/category_with_foods.dart';
import 'package:food_delivery_app/src/models/delivery_time.dart';
import 'package:food_delivery_app/src/repository/cart_repository.dart';
import 'package:http/http.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:food_delivery_app/src/repository/category_repository.dart';
import '../../generated/l10n.dart';
import '../models/food.dart';
import '../models/gallery.dart';
import '../models/restaurant.dart';
import '../models/review.dart';
import '../repository/food_repository.dart';
import '../repository/gallery_repository.dart';
import '../repository/restaurant_repository.dart';
import '../repository/settings_repository.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:video_player/video_player.dart';
import '../helpers/sqlite_helper.dart';
import 'package:location/location.dart' as LatLong;
import 'package:geolocator/geolocator.dart';
import 'package:map_launcher/map_launcher.dart';
import 'dart:io' show Platform;
import 'package:android_intent/android_intent.dart';
import 'package:app_settings/app_settings.dart';
import 'package:url_launcher/url_launcher.dart';

class RestaurantController extends ControllerMVC {
  Restaurant restaurant = Restaurant();
  DeliveryTime deliveryTime = DeliveryTime();
  bool isDeliveryTime = false;
  List<Gallery> galleries = <Gallery>[];
  List<Food> foods = <Food>[];
  List<Food> trendingFoods = <Food>[];
  List<Food> featuredFoods = <Food>[];
  List<Review> reviews = <Review>[];
  List<CategoryWithFoods> categoriesWithFoods = <CategoryWithFoods>[];
  List<CategoryWithFoods> tempCategoriesWithFoods = <CategoryWithFoods>[];
  List<CategoriesTab> categoriesTabList = <CategoriesTab>[];
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  bool isOpeningRestaurantStatus = false;
  bool isReviewLoading = false;
  bool isLoadedCategoriesWithFoods = false;
  VideoPlayerController? videoPlayerController;
  //CachedVideoPlayerController videoPlayerController;
  List<Restaurant> allRestaurant = [];
  late LatLong.LocationData currentLocation;
  bool isLoadingCurrentLocation = false;
  bool isFeaturedFoods = false;
  bool isLoadedAllMenu = false;
  bool isLoadedAllMenuLoading = false;
  bool isLoadedDetail = false;
  bool isLoadedGalleries = false;
  bool isLoadedFeaturedFoods = false;
  var restaurantId;

  RestaurantController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
  }

  bool isLoading = true;

  void resetMenuApi(String restaurantId) async {
    print("reset api called rest controller");
    resetMenu().then((value){
      print("value data $value");
      if(value == ResetMenu()){
        print('valueeee message ${value.message}');
      } else {
        print('valueeee isResetValue ${value.data!.isReset}');
        if (value.data?.isReset == 1) {
          listenForAllRestaurantsWithMenu(restaurantId);
        } else {
          listenRestaurantMenuFromDB(restaurantId);
          listenForRestaurant(id: restaurantId);
          listenForGalleries(restaurantId);
          listenForFeaturedFoods(restaurantId);
          setState((){});
        }
      }
    });
  }

  void listenRestaurantMenuFromDB(String resId) {
    Future.delayed(const Duration(milliseconds: 500), () async {
      int? totalData = await SQLiteHelper().getCountRecords();
      if (totalData! > 0) {
        listenRestaurantMenuReadyFromDB(resId);
      } else {
        listenRestaurantMenuFromDB(resId);
      }
    });
  }

  void listenRestaurantMenuReadyFromDB(String resId) async {
    isLoadedAllMenuLoading = false;
    Map jsonMap =
        await SQLiteHelper().getRecordById(int.parse(resId));
    //print('menu:${jsonMap.toString()}');
    print('jsonMap menu:${jsonMap['res_menu'].toString()}');
    categoriesTabList.clear();
    categoriesWithFoods.clear();
    tempCategoriesWithFoods.clear();

    String encodeString = jsonMap['res_menu'].toString().replaceAll("\\\"", "\"");
    encodeString = encodeString.replaceAll("=\"", "='");
    Iterable l = json.decode(encodeString);
    tempCategoriesWithFoods = List<CategoryWithFoods>.from(l.map((model) => CategoryWithFoods.fromJSON(model)));
    print('tempCategoriesWithFoods size:${tempCategoriesWithFoods.length}');
    tempCategoriesWithFoods.forEach((element) {
      CategoriesTab categoriesTab = CategoriesTab();
      categoriesTab.name = element.name;
      categoriesTab.isSelected = false;
      List<Food> foods = <Food>[];
      element.foods?.forEach((foodElement) {
        if (foodElement.foodStatus) {
          foods.add(foodElement);
        }
      });
      element.foods = foods;
      if (element.foods!.length > 0) {
        element.key =
            GlobalKey(debugLabel: 'item_${categoriesWithFoods.length + 1}');
        element.tabKey =
            GlobalKey(debugLabel: 'tab_item_${categoriesWithFoods.length + 1}');
        categoriesTabList.add(categoriesTab);
        categoriesWithFoods.add(element);
      }
    });

    print('categoriesTabList size:${categoriesTabList.length}');
    print('categoriesWithFoods size:${categoriesWithFoods.length}');
    isLoadedAllMenu = true;
    listenForRestaurantReviews(id: resId);
    // Future.delayed(const Duration(minutes: 1), () {
      setState((){
        isLoadedAllMenuLoading = true;
      });
    // });
    print('Menu loaded:$isLoadedAllMenuLoading');
  }

  void listenForRestaurant({String? id, String? message}) async {
    final Stream<Restaurant> stream = await getRestaurant(id!, MyApp.addressDTO!);
    stream.listen((Restaurant _restaurant) {
      print('_restaurant: ${_restaurant.toMap2()}');
      setState(() => restaurant = _restaurant);
    }, onError: (e) {
      print('$e');
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForRestaurant(id: id, message: Constants.RETRY);
      }
      /*scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.of(context).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (restaurant != Restaurant()) {
        isLoadedDetail = true;
        print('videoUrl:${Uri.encodeFull(restaurant.video)}');
        if (restaurant.video.isNotEmpty) {
          print('video go to initialize');
          videoPlayerController = VideoPlayerController.network(
            restaurant.video,
          );

          videoPlayerController?.addListener(() {
            setState(() {
              videoPlayerController?.play();
            });
          });
          videoPlayerController?.setLooping(true);
          videoPlayerController?.initialize();
          videoPlayerController =
              VideoPlayerController.network(Uri.encodeFull(restaurant.video))
                ..addListener(() => null)
                ..setLooping(true)
                ..setVolume(0.0)
                ..initialize().then((_) {
                  print('initialize done');
                    videoPlayerController?.play();
                }).catchError(
                    (dynamic error) => print('Video player error: $error'));

          /*var videoPlayerController = CachedVideoPlayerController.network(Uri.encodeFull(restaurant.video))
            ..addListener(() => setState(() {}))
            ..setLooping(true)
            ..setVolume(0.0)
            ..initialize().then((_) {
              print('initialize done');
              videoPlayerController.play();
            }).catchError(
                    (dynamic error) => print('Video player error: $error'));*/

          /*videoPlayerController.setVolume(0.0);
          videoPlayerController.setLooping(true);*/
        }
        print('listenForRestaurant Done:${restaurant.toMap2()}');
        Helper.getResOpeningStatus(restaurant.res_opening_hours,
                restaurant.res_onoff_date, restaurant.res_onoff)
            .then((resOpeningStatus) {
          print('resOpeningStatus:$resOpeningStatus');
          setState(() {
            isOpeningRestaurantStatus = resOpeningStatus;
          });
          if (!resOpeningStatus) {
            closeRestaurantAlert(setting.value.messageClose);
          }
        });
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void closeRestaurantAlert(String message) {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).closed,
      style: AlertStyle(
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 20)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18))),
      desc: message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 21),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }

  void listenForGalleries(String idRestaurant) async {
    final Stream<Gallery> stream = await getGalleries(idRestaurant);
    stream.listen(
        (Gallery _gallery) {
          setState(() => galleries.add(_gallery));
        },
        onError: (a) {},
        onDone: () {
          isLoadedGalleries = true;
        });
  }

  void listenForRestaurantReviews({String? id, String? message}) async {
    setState(() {
      isReviewLoading = true;
    });
    final Stream<Review> stream = await getRestaurantReviews(id!);
    stream.listen((Review _review) {
      setState(() => reviews.add(_review));
    }, onError: (e) {
      setState(() {
        isReviewLoading = false;
      });
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForRestaurantReviews(id: id, message: Constants.RETRY);
      }
    }, onDone: () {
      setState(() {
        isReviewLoading = false;
      });
    });
  }

  void listenForFoods(String idRestaurant, {String? message}) async {
    final Stream<Food> stream = await getFoodsOfRestaurant(idRestaurant);
    stream.listen((Food _food) {
      setState(() => foods.add(_food));
    }, onError: (e) {
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForFoods(idRestaurant, message: Constants.RETRY);
      }
    }, onDone: () {});
  }

  void listenForTrendingFoods(String idRestaurant, {String? message}) async {
    final Stream<Food> stream =
        await getTrendingFoodsOfRestaurant(idRestaurant);
    stream.listen((Food _food) {
      setState(() => trendingFoods.add(_food));
    }, onError: (e) {
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForTrendingFoods(idRestaurant, message: Constants.RETRY);
      }
    }, onDone: () {});
  }

  void listenForFeaturedFoods(String idRestaurant, {String? message}) async {
    setState(() {
      isFeaturedFoods = true;
    });
    final Stream<Food> stream =
        await getFeaturedFoodsOfRestaurant(idRestaurant);
    stream.listen((Food _food) {
      setState(() => featuredFoods.add(_food));
    }, onError: (e) {
      setState(() {
        isFeaturedFoods = false;
      });
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        listenForFeaturedFoods(idRestaurant, message: Constants.RETRY);
      }
    }, onDone: () {
      isLoadedFeaturedFoods = true;
      setState(() {
        isFeaturedFoods = false;
      });
    });
  }

  void listenForCategoriesWithFoods(String id, {String? message}) async {
    categoriesTabList.clear();
    categoriesWithFoods.clear();
    final Stream<CategoryWithFoods> stream = await getCategoriesWithFoods(id);
    stream.listen((CategoryWithFoods _category) {
      setState(() {
        CategoriesTab categoriesTab = CategoriesTab();
        categoriesTab.name = _category.name;
        categoriesTab.isSelected = false;
        if (_category.foods!.length > 0) {
          _category.key =
              GlobalKey(debugLabel: 'item_${categoriesWithFoods.length + 1}');
          _category.tabKey = GlobalKey(
              debugLabel: 'tab_item_${categoriesWithFoods.length + 1}');
          categoriesWithFoods.add(_category);
          categoriesTabList.add(categoriesTab);
          print('categoriesWithFoodsList1111:${categoriesWithFoods.length}');
        }
      });
    }, onError: (e) {
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: e.toString())) {
        categoriesTabList.clear();
        categoriesWithFoods.clear();
        listenForCategoriesWithFoods(id, message: Constants.RETRY);
      }
    }, onDone: () {
      print('categoriesWithFoodsList22222:${categoriesWithFoods.length}');
      print('categoriesTabList:${categoriesTabList.length}');
      if (categoriesWithFoods.length > 0) {
        isLoadedCategoriesWithFoods = true;
      }
    });
  }

  Future<void> refreshRestaurant() async {
    var _id = restaurant.id;
    restaurant = new Restaurant();
    galleries.clear();
    reviews.clear();
    featuredFoods.clear();
    listenForRestaurant(
        id: _id, message: S.of(scaffoldKey.currentContext!).restaurant_refreshed_successfuly);
    listenForRestaurantReviews(id: _id);
    listenForGalleries(_id);
    listenForFeaturedFoods(_id);
  }

  void listenForAllRestaurant({String? message}) async {
    print('allRestaurant:$allRestaurant');
    allRestaurant.clear();
    final Stream<Restaurant> stream = await getAllRestaurants();
    stream.listen((Restaurant _restaurant) {
      setState(() {
        allRestaurant.add(_restaurant);
      });
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!, error: a.toString())) {
        listenForAllRestaurant(message: Constants.RETRY);
      }
    }, onDone: () {
      setState(() {
        isLoading = false;
      });
    });
  }

  Future<void> listenForAllRestaurantsWithMenu(String restaurantId, {String? message}) async {
    print("status 1 called");
    Response response = await getAllRestaurantsWithMenu();
    if (response.statusCode == 200) {
      String responseStr = response.body.toString();
      responseStr = responseStr.replaceAll("\\\"", "");
      List<AllRestaurantsWithMenu> jsonList =
      List.from(json.decode(responseStr)['data'])
          .map((element) => AllRestaurantsWithMenu.fromJSON(element))
          .toList();
      print("allRestaurantsWithMenu jsonList:${jsonList.length}");
      if (jsonList.length > 0) {
        await SQLiteHelper().deleteAllRecord();
      }
      jsonList.forEach((allRestaurantsWithMenu) async {
        int id = await SQLiteHelper().addItemInDataBase(
            allRestaurantsWithMenu.id, allRestaurantsWithMenu.menu);
        if (id > 0) {
          //print("Record added");
        } else {
          //print("Failed to insert record");
        }

        resetMenuPost().then((value){
          if(value.data == 1){
            print("Api called from status 1 all restaurant");
            listenRestaurantMenuFromDB(restaurantId);
            listenForRestaurant(id: restaurantId);
            listenForGalleries(restaurantId);
            listenForFeaturedFoods(restaurantId);
            setState((){});
          }
        });
      });
    }
  }

  void getCurrentLocation() async {
    try {
      setState(() {
        isLoadingCurrentLocation = true;
      });
      Geolocator
          .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
          .then((position) async {
        if (position != null) {
          setState(() {
            isLoadingCurrentLocation = false;
          });
          currentLocation = LatLong.LocationData.fromMap(
              {"latitude": position.latitude, "longitude": position.longitude});
          deliveryAddress.value.latitude = position.latitude;
          deliveryAddress.value.longitude = position.longitude;
          if (currentLocation != null) {
            goToMapExplore();
          }
        }
      });
    } on Exception catch (e) {
      setState(() {
        isLoadingCurrentLocation = false;
      });
      print('Permission denied:${e}');
    }
  }

  void locationEnableAlert() {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).alert_location_service_title,
      desc: S.of(scaffoldKey.currentContext!).alert_location_service_message,
      style: AlertStyle(
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 20)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
            //LocationPermissions().openAppSettings();
            AppSettings.openLocationSettings();
          },
        )
      ],
    ).show();
  }

  void checkLocationPermission() async {
    var geolocationStatus =
        //await Geolocator().checkGeolocationPermissionStatus();
        await Geolocator.checkPermission();
    print('geolocationStatus.value:${geolocationStatus}');
    if (geolocationStatus != LocationPermission.whileInUse) {
      requestLocationPermission();
    } else {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      } else {
        locationEnableAlert();
      }
    }
  }

  Future<bool> requestLocationPermission() async {
    return _requestPermission();
  }

  Future<bool> _requestPermission() async {
    print('_requestPermission');
    var result = await Geolocator.requestPermission();
    if (result == LocationPermission.whileInUse) {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        getCurrentLocation();
      } else {
        locationEnableAlert();
      }
      return true;
    } else {
      print('PermissionStatus not granted');
      //if (Platform.isIOS) {
      var serviceStatus = await Geolocator.checkPermission();
      print('serviceStatus:$serviceStatus');
      if (serviceStatus == LocationPermission.whileInUse) {
        locationEnableAlert();
      } else {
        Alert(
          context: scaffoldKey.currentContext!,
          type: AlertType.warning,
          title: S.of(scaffoldKey.currentContext!).alert_location_service_permission_title,
          desc: S.of(scaffoldKey.currentContext!).alert_location_service_permission_message,
          style: AlertStyle(
              titleStyle: Theme.of(scaffoldKey.currentContext!)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 20)),
              descStyle: Theme.of(scaffoldKey.currentContext!)
                  .textTheme
                  .bodyText1!
                  .merge(TextStyle(fontSize: 18))),
          buttons: [
            DialogButton(
              child: Text(
                S.of(scaffoldKey.currentContext!).alert_location_service_btn,
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
              onPressed: () {
                Navigator.pop(scaffoldKey.currentContext!);
                Geolocator.openAppSettings();
              },
            )
          ],
        ).show();
      }
      //}
    }
    return false;
  }

  void goToMapExplore() async {
    if (Platform.isAndroid) {
      AndroidIntent intent = AndroidIntent(
          action: 'action_view',
          data: Uri.encodeFull(
              "https://www.google.com/maps/dir/?api=1&origin=" +
                  "${currentLocation.latitude},${currentLocation.longitude}" +
                  "&destination=" +
                  restaurant.latitude +
                  "," +
                  restaurant.longitude +
                  "&travelmode=driving&dir_action=navigate"),
          package: 'com.google.android.apps.maps');
      intent.launch();
    } else {
      String url = "https://www.google.com/maps/dir/?api=1&origin=" +
          "${currentLocation.latitude},${currentLocation.longitude}" +
          "&destination=" +
          restaurant.latitude +
          "," +
          restaurant.longitude +
          "&travelmode=driving&dir_action=navigate";
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }
  }

  openMapsSheet(context, lat, long, title) async {
    try {
      final coords = Coords(lat, long);
      final availableMaps = await MapLauncher.installedMaps;

      showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
            child: SingleChildScrollView(
              child: Container(
                child: Wrap(
                  children: <Widget>[
                    for (var map in availableMaps)
                      ListTile(
                        onTap: () => map.showMarker(
                          coords: coords,
                          title: title,
                        ),
                        title: Text(map.mapName),
                        leading: SvgPicture.asset(
                           map.icon,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          );
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void listenForDeliveryTime({String? message}) async {
    deliveryTime = DeliveryTime();
    final Stream<DeliveryTime> stream = await getDeliveryTime();
    stream.listen((DeliveryTime _deliveryTime) {
      setState(() {
        print('listenForDeliveryTime Response: ${_deliveryTime.toJson().toString()}');
        deliveryTime = _deliveryTime;
      });
    }, onError: (a) {
      print(a);
      if (message != Constants.RETRY) {
        listenForDeliveryTime(message: Constants.RETRY);
      }
    }, onDone: () async {
      print('onDone listenForDeliveryTime');
      print('isDeliveryTime: $isDeliveryTime');
      if (deliveryTime != null) {
        setState((){
          isDeliveryTime = deliveryTime.getDriverDeliveryStatus();
        });
      }
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }
}





