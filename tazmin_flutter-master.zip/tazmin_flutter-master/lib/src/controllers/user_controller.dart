import 'package:firebase_auth/firebase_auth.dart' as auth;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import '../../generated/l10n.dart';
import '../helpers/helper.dart';
import '../models/user.dart';
import '../repository/user_repository.dart' as repository;
import '../repository/settings_repository.dart' as settingRepo;

class UserController extends ControllerMVC {
  UserModel user = new UserModel();
  UserModel userForRegister = new UserModel();
  bool hidePassword = true;
  bool hideConfirmPassword = true;
  int withEmail = 0;
  late GlobalKey<FormState> loginFormKey;
  GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  late FirebaseMessaging _firebaseMessaging;

  late OverlayEntry loader;
  FirebaseAuth _auth = FirebaseAuth.instance;
  String? otp;
  String? verificationId;
  bool isLoading = false;
  bool isFetchingData = false;
  int isFor = 1;
  //1 email 2 both password & confirm password 3 phone

  UserController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    loginFormKey = new GlobalKey<FormState>();
    loader = Helper.overlayLoader(scaffoldKey.currentContext);
    /*_firebaseMessaging = FirebaseMessaging.instance;
    _firebaseMessaging.getToken().then((String? _deviceToken) {
      print('Firebase_deviceToken: ${_deviceToken}');
      user.deviceToken = _deviceToken!;
      settingRepo.setting.value.deviceToken = _deviceToken;
    }).catchError((e) {
      print('Notification not configured');
    });*/
  }

  void checkNumberWithLogin() async {
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      print('checkNumberWithLogin User: ${user.toMap().toString()}');
      setState(() {
        isLoading = true;
      });
      if ((user.phone != '' && user.phone.trim() != "") &&
          (user.email == '' || user.email.trim() == "")) {
        userForRegister = UserModel();
        userForRegister.isForEmail = false;
        userForRegister.phone = user.phone;
        addCountryCode();
        repository.login(user, true, false, false).then((value) {
          user = value;
          print('checkNumberWithLogin() user: ${value.toString()}');
          if (value.apiToken != '') {
            sendOTP();
          } else {
            setState(() {
              isLoading = false;
            });
            print('RegisterUserData: $user');
            appLoginFailAlert(S.of(scaffoldKey.currentContext!).phone_not_registered,false);
          }
        });
      } else {
        login();
      }
    }
  }

  void checkNumberWithRegister(bool isChecked) async {
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      print('User: ${user.toMap().toString()}');
      if (isChecked) {
        setState(() {
          isLoading = true;
        });
        addCountryCode();
        repository.login(user, true, true, false).then((value) {
          print('user:${value.toMap()}');
          if (value.apiToken != null) {
            user = value;
            setState(() {
              isLoading = false;
            });
            ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
              content: Text(S.of(scaffoldKey.currentContext!).user_already_exist),
            ));
          } else {
            setState(() {
              isLoading = false;
            });
            //appLoginFailAlert(value.message);
            sendOTP();
          }
        });
      } else {
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(scaffoldKey.currentContext!).agree_with_terms),
        ));
      }
    }
  }

  void checkForEmailAlreadyExists() {
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      FocusScope.of(scaffoldKey.currentContext!).unfocus();
      isFetchingData = true;
      setState(() {});
      UserModel checkForEmail;
      if(user.email.isEmpty){
        checkForEmail = User as UserModel;
      }else {
        checkForEmail = UserModel();
      }
      checkForEmail.email = user.email;
      repository.login(checkForEmail, false, false, true).then((value) {
        setState(() {
          isFetchingData = false;
        });
        if (value.isForNewUser) {
          setState(() {
            isFor++;
          });
        } else {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(S.of(scaffoldKey.currentContext!).email_already_exists),
          ));
          repository.logout();
        }
      });
    }
  }

  void checkForNumberAlreadyExists() {
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      FocusScope.of(scaffoldKey.currentContext!).unfocus();
      addCountryCode();
      isFetchingData = true;
      setState(() {});
      UserModel checkForNumber;
      if(user.phone.isEmpty){
        checkForNumber = User as UserModel;
      } else {
        checkForNumber = UserModel();
      }
      checkForNumber.phone = user.phone;
      repository.login(checkForNumber, true, false, false).then((value) {
        setState(() {
          isFetchingData = false;
        });
        if (value.isForNewUser) {
          sendOTP();
          /*Navigator.of(scaffoldKey
              .currentContext)
              .pushNamed('/OTP',
              arguments: RouteArgument(
                  id: verificationId,
                  heroTag:
                  'otpHeroTag',
                  param: user));*/
        } else {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(S.of(scaffoldKey.currentContext!).phone_already_exists),
          ));
          repository.logout();
        }
      });
    }
  }
  void login() async {
    FocusScope.of(scaffoldKey.currentContext!).unfocus();
    addCountryCode();
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      //Overlay.of(context).insert(loader);
      print('login(user, false, false)');
      print('UserModel: ${user.toMap().toString()}');
      userForRegister = UserModel();
      userForRegister.isForEmail = true;
      userForRegister.email = user.email;
      userForRegister.password = user.password;
      repository.login(user, false, false, false).then((value) {
        print('login(): ${value.isForNewUser}');
        if (value.isForNewUser) {
          Navigator.of(scaffoldKey.currentContext!).pushReplacementNamed('/RegisterNew',
              arguments: RouteArgument(param: userForRegister));
          print('User: ${user.toMap().toString()}');
        } else {
          if (value != UserModel() && value.apiToken != '') {
            setState(() {
              isLoading = false;
            });
            ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
              content: Text(S.of(scaffoldKey.currentContext!).welcome + value.name),
            ));
            goToDashboard();
          } else {
            print('login() else: ${value.message}');
            setState(() {
              isLoading = false;
            });
            /*scaffoldKey.currentState.showSnackBar(SnackBar(
              content: Text(value.message),
            ));*/
            appLoginFailAlert(S.of(scaffoldKey.currentContext!).emailOrPasswordIsNotValid,true);
          }
        }
      });
    }
  }

  void appLoginFailAlert(String message, bool isforEmail) {
    Alert(
      context: scaffoldKey.currentContext!,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,

          titleStyle: Theme.of(scaffoldKey.currentContext!).textTheme.bodyText1!.merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!).textTheme.bodyText1!.merge(TextStyle(fontSize: 16))),
      type: AlertType.info,
      title: S.of(scaffoldKey.currentContext!).alert_title_login_fail,
      desc: message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
            //Navigator.of(context).pop();
            if(!isforEmail) {
              Navigator.of(scaffoldKey.currentContext!).pushReplacementNamed('/RegisterNew',
                  arguments: RouteArgument(param: userForRegister));
            }
            print('RegisterUserData: $user');
          },
          width: 120,
        )
      ],
    ).show();
  }

  void register() async {
    FocusScope.of(scaffoldKey.currentContext!).unfocus();
    if (loginFormKey.currentState!.validate()) {
      //loginFormKey.currentState.save();
      setState(() {
        isLoading = true;
      });
      repository.register(user).then((value) {
        if (value != null && value.apiToken != null) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(S.of(scaffoldKey.currentContext!).welcome + value.name),
          ));
          goToDashboard();
        } else {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(value.message),
          ));
        }
      }).catchError((e) {
        setState(() {
          isLoading = false;
        });
      }).whenComplete(() {
        setState(() {
          isLoading = false;
        });
      });
    }
  }

  void goToDashboard() {
    Navigator.of(scaffoldKey.currentContext!)
        .pushReplacementNamed('/Pages', arguments: 2);
  }

  void resetPassword() {
    FocusScope.of(scaffoldKey.currentContext!).unfocus();
    if (loginFormKey.currentState!.validate()) {
      loginFormKey.currentState!.save();
      Overlay.of(scaffoldKey.currentContext!)!.insert(loader);
      repository.resetPassword(user).then((value) {
        if (value != null && value == true) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content:
                Text(S.of(scaffoldKey.currentContext!).your_reset_link_has_been_sent_to_your_email),
            action: SnackBarAction(
              label: S.of(scaffoldKey.currentContext!).login,
              onPressed: () {
                Navigator.of(scaffoldKey.currentContext!)
                    .pushReplacementNamed('/Login');
              },
            ),
            duration: Duration(seconds: 10),
          ));
        } else {
          loader.remove();
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(S.of(scaffoldKey.currentContext!).error_verify_email_settings),
          ));
        }
      }).whenComplete(() {
        Helper.hideLoader(loader);
      });
    }
  }

  void sendOTP() async {
    print('SendOTP() user1:${user.toMap()}');
    addCountryCode();
    final PhoneCodeSent smsOTPSent = (String? verId, [int? forceCodeResend]) {
      /*setState(() {
        isLoading = false;
      });*/
      verificationId = verId;
      print('SendOTP() verId: ${verificationId}');
      print('SendOTP() User: ${user.toMap()}');
      Navigator.of(scaffoldKey.currentContext!).pushNamed('/OTP',
          arguments:
              RouteArgument(id: verificationId, heroTag: null, param: user));
    };
    try {
      print('SendOTP() user2:${user.toMap()}');
      await _auth.verifyPhoneNumber(
          phoneNumber: user.phone,
          // PHONE NUMBER TO SEND OTP
          codeAutoRetrievalTimeout: (String verId) {
            //Starts the phone number verification process for the given phone number.
            //Either sends an SMS with a 6 digit code to the phone number specified, or sign's the user in and [verificationCompleted] is called.
            this.verificationId = verId;
            print('SendOTP() verificationId 2: ${verificationId.toString()}');
          },
          // WHEN CODE SENT THEN WE OPEN DIALOG TO ENTER OTP.
          codeSent: smsOTPSent,
          timeout: const Duration(seconds: 60),
          verificationCompleted: (AuthCredential phoneAuthCredential) {
            //onVerified(false);
          },
          verificationFailed: (exception) {
            print('verificationFailed: ${exception.message}');
            repository.logout();
            setState(() {
              isLoading = false;
            });
            showErrorAndGoBack(exception.message, false);
          });
    } catch (e) {
      repository.logout();
      setState(() {
        isLoading = false;
      });
      print('print message');

      showErrorAndGoBack(e.toString(), false);
    }
  }

  verify(bool isFromProfile) async {
    if (loginFormKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });
      print('Verify() VerificationId 1: ${verificationId.toString()}');
      final AuthCredential credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: otp!,
      );
      print('Verify() VerificationId 2: $verificationId');
      FirebaseAuth.instance.signInWithCredential(credential).then((user) {
        print('Verify() User Response1: ${user.toString()}');
        setState(() {
          isLoading = false;
        });
        onVerified(isFromProfile);
        print('Verify() VerificationId 3: ${verificationId}');
        print('Verify() User Response2: ${user.toString()}');
      }).catchError((error) {
        setState(() {
          isLoading = false;
        });
        repository.logout();
        print('Verify() VerificationId 4: ${verificationId}');
        print('Verify() User Response3: ${user.toMap()}');
        print('Verify() Error Message: ${error.toString()}');
        showErrorAndGoBack(error.message, true);
      });
    }
  }

  showErrorAndGoBack(error, shouldGoBack) {
    print('showErrorAndGoBack: ${error.toString()}');
    showDialog(
        context: scaffoldKey.currentContext!,
        builder: (context) => AlertDialog(
              title: Text(S.of(context).request_failed),
              content: Text(error),
              actions: <Widget>[
                FlatButton(
                  child: Text('Ok'),
                  onPressed: () {
                    otp = "";
                    verificationId = "";
                    Navigator.of(context).pop();
                    if (shouldGoBack) Navigator.of(context).pop();
                  },
                ),
              ],
            ).build(context));
  }

  void onVerified(bool isFromProfile) {
    if (!isFromProfile) {
      if (user.isForLogin) {
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(S.of(scaffoldKey.currentContext!).welcome + user.name),
        ));
        goToDashboard();
      } else {
        register();
      }
    } else {
//      Navigator.of(context).pop();
      Navigator.pop(scaffoldKey.currentContext!, true);
    }
  }

  void addCountryCode() {
    if (this.user.phone != '' && this.user.phone != "") {
      var code = "+972";
     // var code = "+91";
      this.user.phone =
          (this.user.phone.contains(code) ? "" : code) + this.user.phone;
    }
  }
}
