import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/cuisine.dart';
import 'package:food_delivery_app/src/models/restaurant.dart';
import 'package:food_delivery_app/src/repository/cuisine_repository.dart';
import 'package:food_delivery_app/src/repository/restaurant_repository.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
class RestaurantsWithCuisinesController extends ControllerMVC {
  late GlobalKey<ScaffoldState> scaffoldKey;
  List<Cuisine> restaurantsWithCuisines = [];
  List<Restaurant> restaurants = [];
  late bool isLoading = true;

  RestaurantsWithCuisinesController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForCuisines();
  }

  void listenForCuisines({String? message}) async {
    restaurantsWithCuisines.clear();
    final Stream<Cuisine> stream = await getCuisines();
    stream.listen((Cuisine _cuisine) {
      setState(() {
        restaurantsWithCuisines.add(_cuisine);
      });
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext!, message!,error: a.toString())) {
        listenForCuisines(message: Constants.RETRY);
      }
    }, onDone: () {
      setState(() {
        isLoading = false;
      });
     /* if (message != null) {
        if (Helper.checkRetryMessage(context, message)) {
          scaffoldKey.currentState.showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }*/
    });
  }
}
