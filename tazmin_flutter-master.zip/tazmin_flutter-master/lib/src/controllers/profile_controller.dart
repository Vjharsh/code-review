import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/models/cart.dart';
import 'package:food_delivery_app/src/models/extra.dart';
import 'package:food_delivery_app/src/models/food.dart';
import 'package:food_delivery_app/src/models/food_order.dart';
import 'package:food_delivery_app/src/models/user.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../../generated/l10n.dart';
import '../models/order.dart';
import '../repository/order_repository.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import '../repository/user_repository.dart';
import '../repository/user_repository.dart' as repository;
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:http/http.dart' as http;
import '../repository/cart_repository.dart';

class ProfileController extends ControllerMVC {
  List<Order> recentOrders = [];
  late GlobalKey<ScaffoldState> scaffoldKey;
  late OverlayEntry loader;
  FirebaseAuth _auth = FirebaseAuth.instance;
  late String otp;
  late String verificationId;
  late User user;
  int selectedIndex = -2;
  bool isLoading = false;
  int counter = 0;
  List<FoodOrder> foodOrders = <FoodOrder>[];
  late http.Response response;

  ProfileController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    loader = Helper.overlayLoader(scaffoldKey.currentContext);
    getUserProfile();
    listenForRecentOrders();
  }

  void getUserProfile() {
    repository.login(currentUser.value, true, false, true).then((value) {
      setState(() {});
    });
  }

  void listenForRecentOrders({String? message}) async {
    final Stream<Order> stream = await getRecentOrders();
    stream.listen((Order _order) {
      setState(() {
        recentOrders.add(_order);
      });
    }, onError: (e) {
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!, error: e.toString())) {
        listenForRecentOrders(message: Constants.RETRY);
      }
      /*scaffoldKey?.currentState?.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  Future<void> refreshProfile() async {
    recentOrders.clear();
    listenForRecentOrders(message: S.of(scaffoldKey.currentContext!).orders_refreshed_successfuly);
  }

  void sendOTP(UserModel user) async {
    Overlay.of(scaffoldKey.currentContext!)!.insert(loader);
    if (user.phone != null && user.phone != "") {
//      var code = "+91";
      var code = "+972";
      user.phone = (user.phone.contains(code) ? "" : code) + user.phone;
    }
    final PhoneCodeSent smsOTPSent = (String verId, [int? forceCodeResend]) {
      loader.remove();
      this.verificationId = verId;
      Navigator.of(scaffoldKey.currentContext!)
          .pushNamed('/OTP',
              arguments: RouteArgument(
                  id: verificationId, heroTag: "fromProfile", param: user))
          .then((value) {
        if (value != null) {
          //if  (value) {
            Navigator.pop(scaffoldKey.currentContext!);
            if (user != null) {
              update(user).then((value) {
                setState(() {});
              });
            }
        //  }
        }
      });
    };
    try {
      print('user:${user}');
      await _auth.verifyPhoneNumber(
          phoneNumber: user.phone,
          // PHONE NUMBER TO SEND OTP
          codeAutoRetrievalTimeout: (String verId) {
            //Starts the phone number verification process for the given phone number.
            //Either sends an SMS with a 6 digit code to the phone number specified, or sign's the user in and [verificationCompleted] is called.
            this.verificationId = verId;
          },
          // WHEN CODE SENT THEN WE OPEN DIALOG TO ENTER OTP.
          codeSent: smsOTPSent,
          timeout: const Duration(seconds: 60),
          verificationCompleted: (AuthCredential phoneAuthCredential) {
            onVerified();
          },
          verificationFailed: (exception) {
            showErrorAndGoBack(exception.message, false);
          });
    } catch (e) {
      showErrorAndGoBack(e.toString(), false);
    }
  }

  verify() async {
    final AuthCredential credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: this.otp,
    );
    FirebaseAuth.instance.signInWithCredential(credential).then((user) {
      onVerified();
    }).catchError((error) {
      showErrorAndGoBack(error.message, true);
    });
  }

  showErrorAndGoBack(error, shouldGoBack) {
    showDialog(
        context: scaffoldKey.currentContext!,
        builder: (context) => AlertDialog(
              title: Text(S.of(context).request_failed),
              content: Text(error),
              actions: <Widget>[
                FlatButton(
                  child: Text('Ok'),
                  onPressed: () {
                    otp = "";
                    verificationId = "";
                    Navigator.of(context).pop();
                    if (shouldGoBack) Navigator.of(context).pop();
                  },
                ),
              ],
            ).build(context));
  }

  void addToCartFromFoodArray() {
    print('foodOrders Counter:$counter');
    addToCart(
        foodOrders.elementAt(counter).food,
        foodOrders.elementAt(counter).extras,
        foodOrders.elementAt(counter).quantity);
  }

  void addToCart(Food food, List<Extra> extras, double quantity) async {
    if (counter == 0) {
      setState(() {
        isLoading = true;
      });
    }
    print('addToCart');
    var _newCart = new Cart();
    _newCart.food = food;
    // _newCart.extras = extra;
    List<Extra> newExtras = <Extra>[];
    for (int i = 0; i < extras.length; i++) {
      Extra extra = extras[i];
      if (extra.extraPivot.pizza_status == '1') {
        extra.pizzaStatus = 1;
        extra.pizzaType = extra.extraPivot.pizza_type;
        extra.fullPrice = extra.extraPivot.full_price;
        extra.halfPrice = extra.extraPivot.half_price;
        extra.price = extra.extraPivot.extra_price;
        newExtras.add(extra);
      } else {
        extra.price = extra.extraPivot.extra_price;
        newExtras.add(extra);
      }
    }
    _newCart.extras = newExtras;
    _newCart.quantity = quantity;
    print('_newCart');
    addCartForReorder(_newCart, counter == 0 ? true : false).then((value) {
      this.response = value;
    }).whenComplete(() {
      Map<String, dynamic> decodedJSON = {};
      decodedJSON = json.decode(response.body) as Map<String, dynamic>;
      if (response.statusCode == 200) {
        if (counter == foodOrders.length - 1) {
          setState(() {
            isLoading = false;
          });
          counter = 0;
          Navigator.of(scaffoldKey.currentContext!).pushNamed('/Cart',arguments: RouteArgument(id: '1'));
        } else {
          counter++;
          addToCartFromFoodArray();
        }
      } else {  
        setState(() {
          isLoading = false;
        });
        counter = 0;
        ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
          content: Text(decodedJSON['message']),
        ));
      }
    });
  }

  void doCancelOrder(Order order) {
    setState(() {
      recentOrders.clear();
    });
    cancelOrder(order).then((value) {
      setState(() {
        order.active = false;
      });
    }).catchError((e) {
      /*scaffoldKey?.currentState?.showSnackBar(SnackBar(
        content: Text(e),
      ));*/
    }).whenComplete(() {
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext!).orderThisorderidHasBeenCanceled(order.id)),
      ));
      refreshProfile();
    });
  }

  void onVerified() {}
}
