import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/models/extra_group.dart';
import 'package:food_delivery_app/src/models/route_argument.dart';
import 'package:geolocator/geolocator.dart';
import 'package:lottie/lottie.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import '../../generated/l10n.dart';
import '../elements/AddToCartAlertDialog.dart';
import '../models/cart.dart';
import '../models/extra.dart';
import '../models/favorite.dart';
import '../models/food.dart';
import '../repository/cart_repository.dart';
import '../repository/food_repository.dart';
import '../repository/settings_repository.dart';

class FoodController extends ControllerMVC {
  Food? food;
  List<ExtraGroup> extraGroupList = <ExtraGroup>[];
  int extraGroupIndex = 0;
  List<Extra> extraItemList = <Extra>[];
  double quantity = 1;
  double total = 0;
  int totalExtras = 0;
  int maxItem = 10;
  List<Cart> carts = [];
  Favorite? favorite;
  bool loadCart = false;
  double pizzaExtra = 0;
  late GlobalKey<ScaffoldState> scaffoldKey;
  bool isEnableAddToCart = false;
  bool isFoodLoading = false;
  bool isForEdit = false;
  late Cart cart;
  int page = 1;
  bool isForPaging = true;
  bool isForShimmer = true;
  bool isForNextGroup = false;
  bool isLoadingPaging = false;

  FoodController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    food =Food();
  }

  void listenForFood({String? foodId, String? message}) async {
    setState(() {
      isFoodLoading = true;
    });
    final Stream<Food> stream = await getFoodWithoutExtraGroup(foodId!);
    stream.listen((Food _food) {
      print('getFood:${_food.toMap().toString()}');
      setState(() => food = _food);
    }, onError: (a) {
      print(a);
      setState(() {
        isFoodLoading = false;
      });
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!)) {
        listenForFood(foodId: foodId, message: Constants.RETRY);
      }
      /*scaffoldKey.currentState?.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      setState(() {
        isFoodLoading = false;
      });
      calculateTotal();
      Helper.getResOpeningStatus(food!.restaurant.res_opening_hours,
              food!.restaurant.res_onoff_date, food!.restaurant.res_onoff)
          .then((resOpeningStatus) {
        setState(() {
          isEnableAddToCart = resOpeningStatus;
        });
      });
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void listenForExtraGroup({String? foodId, String? message}) async {
    setState(() {
      isFoodLoading = true;
      isForShimmer = true;
      extraGroupList.clear();
    });
    final Stream<ExtraGroup> stream = await getExtraGroup(foodId!);
    stream.listen((ExtraGroup _extraGroup) {
      print('getExtraGroup:${_extraGroup.toMap().toString()}');
      setState(() {
        extraGroupList.add(_extraGroup);
      });
    }, onError: (a) {
      print('getExtraGroup onError:$a');
      setState(() {
        isFoodLoading = false;
      });
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!)) {
        listenForExtraGroup(foodId: foodId, message: Constants.RETRY);
      }
      /*scaffoldKey.currentState?.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      print('extraGroupList.length: ${extraGroupList.length}');
      if (extraGroupList.length > 0) {
        listenForExtra(foodId: foodId);
      } else {
        setState(() {
          isForShimmer = false;
        });
      }
    });
  }

  void listenForExtra({String? foodId, String? message}) async {
    print('page:$page');
    setState(() {
      isForShimmer = true;
      isLoadingPaging = true;
      if (page == 1) extraItemList = <Extra>[];
    });
    final Stream<Extra> stream = await getExtraItems(
        foodId!, page.toString(), extraGroupList[extraGroupIndex].id);
    stream.listen((Extra _extra) {
      print('_extra: ${_extra.name}');
      extraItemList.add(_extra);
    }, onError: (a) {
      setState(() {
        isLoadingPaging = false;
      });
      print('a: $a');
    }, onDone: () {
      isLoadingPaging = false;
      print('extraItemList size: ${extraItemList.length}');
      print('extraGroupIndex: $extraGroupIndex');
      if (extraItemList.length > 0) {
        ExtraGroup extraGroup = extraGroupList.elementAt(extraGroupIndex);
        extraGroup.extras = extraItemList;
        if (isForEdit) {
          print('isForEdit');
          quantity = cart.quantity;
          print('quantity:${cart.quantity}');
          if (cart.extras.isNotEmpty) {
            for (int k = 0; k < cart.extras.length; k++) {
              for (int i = 0; i < extraGroupList.length; i++) {
                for (int j = 0;
                    j < extraGroupList.elementAt(i).extras.length;
                    j++) {
                  Extra extra = extraGroupList.elementAt(i).extras.elementAt(j);
                  if (extra.id == cart.extras[k].extraPivot.extra_id) {
                    extra.checked = true;
                    extra.qty = cart.extras[k].extraPivot.extra_qty;
                    extra.price = cart.extras[k].extraPivot.extra_price;
                    extraGroupList[i].extras[j] = extra;
                  }
                }
              }
            }
          }
        }
      }
      if (extraItemList.length < maxItem) {
        print('extraItemList.length: ${extraItemList.length}');
        if (extraGroupIndex == extraGroupList.length - 1) {
          maxItem = 10;
          isForPaging = false;
          isForNextGroup = false;
          print('isForPaging false');
        } else {
          maxItem = 10;
          print('isForNextGroup true');
          isForNextGroup = true;
          page = 1;
          ++extraGroupIndex;
        }
      } else {
        maxItem = maxItem + 10;
        isForPaging = true;
        isForNextGroup = false;
        ++page;
        print('isForPaging true');
      }
      setState(() {});

      if (isForPaging) {
        listenForExtra(foodId: foodId);
      } else {
        setState((){
          isForShimmer = false;
        });
      }
    });
  }

  void listenForFavorite({String? foodId}) async {
    final Stream<Favorite> stream = await isFavoriteFood(foodId!);
    stream.listen((Favorite _favorite) {
      setState(() => favorite = _favorite);
    }, onError: (a) {
      print(a);
    });
  }

  void listenForCart() async {
    final Stream<Cart> stream = await getCart();
    stream.listen((Cart _cart) {
      carts.add(_cart);
    });
  }

  bool isSameRestaurants(Food food) {
    if (carts.isNotEmpty) {
      return carts[0].food.restaurant.id == food.restaurant.id;
    }
    return true;
  }

  void addToCart(Food food, {bool reset = false}) async {
    print('addToCart');
    setState(() {
      this.loadCart = true;
    });
    var _newCart = new Cart();
    _newCart.food = food;
    extraGroupList.forEach((extraGroupElement) {
      extraGroupElement.extras.forEach((extraElement) {
        if (extraElement.checked) {
          food.extras.add(extraElement);
        }
      });
    });
    _newCart.extras = food.extras.where((element) => element.checked).toList();
    _newCart.quantity = this.quantity;
    print('_newCart');
    addCart(_newCart, reset).then((value) {
      setState(() {
        this.loadCart = false;
      });
    }).whenComplete(() {
      addToCartAlert(food);
    });
  }

  void updateFoodToCart() {
    this.cart.food = this.food!;
    this.cart.quantity = this.quantity;
    food!.extras.clear();
    extraGroupList.forEach((extraGroupElement) {
      extraGroupElement.extras.forEach((extraElement) {
        if (extraElement.checked) {
          food!.extras.add(extraElement);
        }
      });
    });
    this.cart.extras = food!.extras.where((element) => element.checked).toList();
    updateCartForFood(this.cart).then((value) {
      Navigator.of(scaffoldKey.currentContext!).pushNamed('/Cart',
          arguments: RouteArgument(param: '/Pages', id: '2'));
    });
  }

  void addToCartAlert(Food food) {
    Dialog addToCartAlertDialog = Dialog(
      insetPadding: EdgeInsets.all(0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      //this right here
      child: Container(
        width: 370,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Lottie.asset('assets/img/success_animation.json',
                width: 200, height: 200, fit: BoxFit.fill),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Text(
                S.of(scaffoldKey.currentContext!).add_to_cart_popup_message(food.name),
                style: Theme.of(scaffoldKey.currentContext!)
                    .textTheme
                    .headline6!
                    .merge(TextStyle(fontSize: 20)),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                      child: DialogButton(
                    child: Text(
                      S.of(scaffoldKey.currentContext!).checkout_add_to_cart,
                      style: TextStyle(color: Colors.white, fontSize: 19),
                    ),
                    color: Theme.of(scaffoldKey.currentContext!).secondaryHeaderColor,
                    onPressed: () {
                      Navigator.pop(scaffoldKey.currentContext!);
                      Navigator.of(scaffoldKey.currentContext!).pushNamed('/Cart',
                          arguments: RouteArgument(param: '/Pages', id: '2'));
                    },
                  )),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: DialogButton(
                    child: Text(
                      S.of(scaffoldKey.currentContext!).continue_order,
                      style: TextStyle(color: Colors.white, fontSize: 19),
                    ), color: Theme.of(scaffoldKey.currentContext!).secondaryHeaderColor,
                    onPressed: () {
                      Navigator.pop(scaffoldKey.currentContext!);
                      Navigator.pop(scaffoldKey.currentContext!);
                      //refreshFood();
                    },
                  )),
                ],
              ),
            ),
            SizedBox(
              height: 5,
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: scaffoldKey.currentContext!,
        barrierDismissible: false,
        builder: (BuildContext context) => addToCartAlertDialog);
  }

  void pizzaTypeAlert(String alertTitle, int extraGroupIndex, int extraIndex) {
    WillPopScope pizzaTypeAlertDialog =  WillPopScope(
        onWillPop:() {
          setState((){
            pizzaExtra = 0;
            pizzaExtra = extraGroupList[extraGroupIndex].extras[extraIndex].price;
            extraGroupList.elementAt(extraGroupIndex).selectedQty -= 1;
            extraGroupList[extraGroupIndex].extras[extraIndex].checked = false;
            total = total - pizzaExtra;
            totalExtras -= 1;
          });
          Navigator.pop(scaffoldKey.currentContext!);
          return Future.value(true);
        },
        child:Dialog(
      insetPadding: EdgeInsets.all(0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      //this right here
      child: Container(
        height: 250,
        width: 350,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                alertTitle,
                style: Theme.of(scaffoldKey.currentContext!)
                    .textTheme
                    .headline6!
                    .merge(TextStyle(fontSize: 20)),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(scaffoldKey.currentContext!);
                        /*for (int i = 0; i < food.extras.length; i++) {
                          if (extra.id == extra.id) {*/
                        extraGroupList[extraGroupIndex]
                            .extras[extraIndex]
                            .pizzaStatus = 1;
                        extraGroupList[extraGroupIndex]
                            .extras[extraIndex]
                            .pizzaType = 'whole';
                        extraGroupList[extraGroupIndex]
                                .extras[extraIndex]
                                .fullPrice =
                            extraGroupList[extraGroupIndex].fullPrice;
                        extraGroupList[extraGroupIndex]
                                .extras[extraIndex]
                                .halfPrice =
                            extraGroupList[extraGroupIndex].halfPrice;
                        extraGroupList[extraGroupIndex]
                                .extras[extraIndex]
                                .price =
                            double.parse(
                                extraGroupList[extraGroupIndex].fullPrice);
                        /*break;
                          }
                        }*/
                        setState(() {
                          extraGroupList[extraGroupIndex].extras[extraIndex].checked = true;
                          calculateTotal();
                        });
                        print("pizza ni typeeee ${extraGroupList[extraGroupIndex].extras[extraIndex].pizzaType}");
                      },
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(5),
                            child: Text(
                              S.of(scaffoldKey.currentContext!).whole_pizza,
                              style: Theme.of(scaffoldKey.currentContext!)
                                  .textTheme
                                  .headline5!
                                  .merge(TextStyle(fontSize: 17)),
                            ),
                          ),
                          Container(
                              width: 60,
                              height: 60,
                              child: Image.asset('assets/img/whole_pizza.jpg')),
                          Padding(
                              padding: const EdgeInsets.all(5),
                              child: Helper.getPrice(
                                double.parse(
                                    extraGroupList[extraGroupIndex].fullPrice),
                                scaffoldKey.currentContext!,
                                style: Theme.of(scaffoldKey.currentContext!)
                                    .textTheme
                                    .subtitle1!
                                    .merge(TextStyle(fontSize: 15)),
                              )),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: InkWell(
                    onTap: () {
                      Navigator.pop(scaffoldKey.currentContext!);
                      /*for (int i = 0; i < food.extras.length; i++) {
                        if (food.extras[i].id == extra.id) {*/
                      extraGroupList[extraGroupIndex]
                          .extras[extraIndex]
                          .pizzaStatus = 1;
                      extraGroupList[extraGroupIndex]
                          .extras[extraIndex]
                          .pizzaType = 'right';
                      extraGroupList[extraGroupIndex]
                              .extras[extraIndex]
                              .fullPrice =
                          extraGroupList[extraGroupIndex].fullPrice;
                      extraGroupList[extraGroupIndex]
                              .extras[extraIndex]
                              .halfPrice =
                          extraGroupList[extraGroupIndex].halfPrice;
                      extraGroupList[extraGroupIndex].extras[extraIndex].price =
                          double.parse(
                              extraGroupList[extraGroupIndex].halfPrice);
                      /*break;
                        }
                      }*/
                      setState(() {
                        extraGroupList[extraGroupIndex]
                            .extras[extraIndex]
                            .checked = true;
                        calculateTotal();
                      });
                    },
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5),
                          child: Text(
                            S.of(scaffoldKey.currentContext!).right_pizza,
                            style: Theme.of(scaffoldKey.currentContext!)
                                .textTheme
                                .headline5!
                                .merge(TextStyle(fontSize: 17)),
                          ),
                        ),
                        Container(
                            width: 60,
                            height: 60,
                            child: Image.asset('assets/img/right_pizza.jpg')),
                        Padding(
                            padding: const EdgeInsets.all(5),
                            child: Helper.getPrice(
                              double.parse(
                                  extraGroupList[extraGroupIndex].halfPrice),
                              scaffoldKey.currentContext!,
                              style: Theme.of(scaffoldKey.currentContext!)
                                  .textTheme
                                  .subtitle1!
                                  .merge(TextStyle(fontSize: 15)),
                            )),
                      ],
                    ),
                  )),
                  SizedBox(
                    width: 10,
                  ),
                  Expanded(
                      child: InkWell(
                    onTap: () {
                      Navigator.pop(scaffoldKey.currentContext!);
                      /*for (int i = 0; i < food.extras.length; i++) {
                        if (food.extras[i].id == extra.id) {*/
                      extraGroupList[extraGroupIndex]
                          .extras[extraIndex]
                          .pizzaStatus = 1;
                      extraGroupList[extraGroupIndex]
                          .extras[extraIndex]
                          .pizzaType = 'left';
                      extraGroupList[extraGroupIndex]
                              .extras[extraIndex]
                              .fullPrice =
                          extraGroupList[extraGroupIndex].fullPrice;
                      extraGroupList[extraGroupIndex]
                              .extras[extraIndex]
                              .halfPrice =
                          extraGroupList[extraGroupIndex].halfPrice;
                      extraGroupList[extraGroupIndex].extras[extraIndex].price =
                          double.parse(
                              extraGroupList[extraGroupIndex].halfPrice);
                      /*break;
                        }
                      }*/
                      setState(() {
                        extraGroupList[extraGroupIndex]
                            .extras[extraIndex]
                            .checked = true;
                        calculateTotal();
                      });
                    },
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5),
                          child: Text(
                            S.of(scaffoldKey.currentContext!).left_pizza,
                            style: Theme.of(scaffoldKey.currentContext!)
                                .textTheme
                                .headline5!
                                .merge(TextStyle(fontSize: 17)),
                          ),
                        ),
                        Container(
                            width: 60,
                            height: 60,
                            child: Image.asset('assets/img/left_pizza.jpg')),
                        Padding(
                            padding: const EdgeInsets.all(5),
                            child: Helper.getPrice(
                              double.parse(
                                  extraGroupList[extraGroupIndex].halfPrice),
                              scaffoldKey.currentContext!,
                              style: Theme.of(scaffoldKey.currentContext!)
                                  .textTheme
                                  .subtitle1!
                                  .merge(TextStyle(fontSize: 15)),
                            )),
                      ],
                    ),
                  )),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    ));
    showDialog(
            context: scaffoldKey.currentContext!,
            barrierDismissible: true,
            builder: (BuildContext context) => pizzaTypeAlertDialog)
        .then((value) {});
  }

  Cart isExistInCart(Cart _cart) {
    return carts.firstWhere((Cart oldCart) => _cart.isSame(oldCart),
        orElse: () => Cart());
  }

  void addToFavorite(Food food) async {
    var _favorite = new Favorite();
    _favorite.food = food;
    _favorite.extras = food.extras.where((Extra _extra) {
      return _extra.checked;
    }).toList();
    addFavorite(_favorite).then((value) {
      setState(() {
        this.favorite = value;
      });
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text('מאכל זה נוסף למועדפים'),
      ));
    });
  }

  void removeFromFavorite(Favorite _favorite) async {
    removeFavorite(_favorite).then((value) {
      setState(() {
        this.favorite = new Favorite();
      });
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text('מאכל זה הוסר מהמועדפים'),
      ));
    });
  }

  Future<void> refreshFood() async {
    var _id = food!.id;
    food = new Food();
    listenForFavorite(foodId: _id);
    listenForFood(foodId: _id, message: S.of(scaffoldKey.currentContext!).food_refresh_message);
  }

  void calculateTotal() {
    total = food!.price;
    /*food?.extras?.forEach((extra) {
      if (extra.checked) {
        total += extra.price * extra.qty;
      }
    });*/
    extraGroupList.forEach((extraGroupsElement) {
      extraGroupsElement.extras.forEach((extraElement) {
        if (extraElement.checked) {
          total += extraElement.price * extraElement.qty;
        }
      });
    });
    total *= quantity;
    setState(() {});
  }

  incrementQuantity() {
    if (this.quantity <= 99) {
      ++this.quantity;
      calculateTotal();
    }
  }

  decrementQuantity() {
    if (this.quantity > 1) {
      --this.quantity;
      calculateTotal();
    }
  }

  void permissionGranted() {
   // LocationPermissions().checkServiceStatus().then((locationServiceStatus) {
    Geolocator.isLocationServiceEnabled().then((locationServiceStatus) {
      print('serviceStatus:$locationServiceStatus');
      if (locationServiceStatus) {
        goToCheckOutTownArea();
      } else {
        locationEnableAlert();
      }
    });
  }

  void checkLocationPermission() async {
    Geolocator
        .checkPermission()
        .then((geolocationStatus) async {
      print('geolocationStatus.value:$geolocationStatus');
      //if (geolocationStatus.value != 2) {
     // LocationPermissions().requestPermissions().then((result) async {
      Geolocator.requestPermission().then((result) async {
        if (result == LocationPermission.whileInUse) {
          print('PermissionStatus granted');
          permissionGranted();
        } else {
          print('PermissionStatus not granted');
          //waitingForGrantPermission();
          locationEnableAlert();
        }
      });
      //}
    });
  }

  void locationEnableAlert() {
    Alert(
      context: scaffoldKey.currentContext!,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).alert_location_service_title,
      desc: S.of(scaffoldKey.currentContext!).alert_location_service_message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_location_service_btn,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
            //waitingForServiceEnableLocation();
            //LocationPermissions().openAppSettings();
            AppSettings.openLocationSettings();
          },
        )
      ],
    ).show();
  }

  void goToCheckOutTownArea() {
    checkAppIsOutOfTownArea();
  }

  void checkLatLongWithTown(double newLatitude, double newLongitude) async {
    deliveryAddress.value.latitude = newLatitude;
    deliveryAddress.value.longitude = newLongitude;
    print('setting lat:${setting.value.town_area_lat}');
    print('setting long:${setting.value.town_area_long}');
    double distance = Geolocator.distanceBetween(
        setting.value.town_area_lat,
        setting.value.town_area_long,
        newLatitude,
        newLongitude);
    distance = distance / 1000;
    print('distance:$distance');
    print('setting.town_area_distance:${setting.value.town_area_distance}');
    if (distance > double.parse(setting.value.town_area_distance)) {
      outOfTownAreaAlert();
    } else {
      goToItemAddInCart();
    }
  }

  void goToItemAddInCart() {
    bool isRequireNotChecked = false;
    var extraNotCheckedName = "";

    if (extraGroupList.isNotEmpty) {
      for (int i = 0; i < extraGroupList.length; i++) {
        if (extraGroupList.elementAt(i).requireField) {
          bool isExtraChecked = false;
          for (int j = 0; j < extraGroupList.elementAt(i).extras.length; j++) {
            if (extraGroupList.elementAt(i).extras.elementAt(j).checked) {
              isExtraChecked = true;
              break;
            }
          }
          if (!isExtraChecked) {
            extraNotCheckedName = extraGroupList.elementAt(i).name;
            isRequireNotChecked = true;
            break;
          }
        }
      }
    }

    if (isRequireNotChecked) {
      showDialog(
        context: scaffoldKey.currentContext!,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Wrap(
              spacing: 10,
              children: <Widget>[
                Icon(Icons.report, color: Colors.orange),
                Text(
                  'לא נבחרו מספיק אופציות להזמנה',
                  style: TextStyle(color: Colors.orange),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 3),
                    child: Text(S.of(context).pleaseSelectAtleastOneItemFrom)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.of(context).pop();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5,horizontal: 15),
                        child: Text('אוקי', style: TextStyle(color: Colors.orange),
                        ),
                      ),
                    )
                  ],
                )
              ],
            ),
            contentPadding:
                EdgeInsets.only(left: 30, right: 30, top: 25, bottom: 25),
          );
        },
      );
    } else {
      if (isSameRestaurants(food!)) {
        addToCart(food!);
      } else {
        showDialog(
          context: scaffoldKey.currentContext!,
          builder: (BuildContext context) {
            // return object of type Dialog
            return AddToCartAlertDialogWidget(
                oldFood: carts.elementAt(0).food,
                newFood: food!,
                onPressed: (food, {reset: true}) {
                  return addToCart(food, reset: true);
                });
          },
        );
      }
    }
  }

  void outOfTownAreaAlert() {
    Alert(
      context: scaffoldKey.currentContext!,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).out_of_town_area_title,
      desc: setting.value.town_area_message,
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }

  void outOfStockQtyAlert(String limitQty) {
    Alert(
      context: scaffoldKey.currentContext!,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: false,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .headline4!
              .merge(TextStyle(fontSize: 16))),
      type: AlertType.warning,
      title: S.of(scaffoldKey.currentContext!).limited_quantity,
      desc: S.of(scaffoldKey.currentContext!).limit_qty_message(limitQty),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }

  void checkAppIsOutOfTownArea() async {
 Geolocator
        .getLastKnownPosition(forceAndroidLocationManager: true,)
        .then((position) async {
      if (position != null) {
        print('last new lat:${position.latitude}');
        print('last new long:${position.longitude}');
        checkLatLongWithTown(position.latitude, position.longitude);
      } else {
        print('last position null');
        Geolocator
            .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
            .then((position) async {
          print('new lat:${position.latitude}');
          print('new long:${position.longitude}');
          checkLatLongWithTown(position.latitude, position.longitude);
        });
      }
    });
  }

  void busyRestaurantsAlert() {
    Alert(
      context: scaffoldKey.currentContext!,
      type: AlertType.info,
      title: S.of(scaffoldKey.currentContext!).busy,
      desc: setting.value.busyModeMessage,
      style: AlertStyle(
          isCloseButton: false,
          isOverlayTapDismiss: true,
          titleStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 18)),
          descStyle: Theme.of(scaffoldKey.currentContext!)
              .textTheme
              .bodyText1!
              .merge(TextStyle(fontSize: 16))),
      buttons: [
        DialogButton(
          child: Text(
            S.of(scaffoldKey.currentContext!).alert_ok,
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          onPressed: () {
            Navigator.pop(scaffoldKey.currentContext!);
          },
          width: 120,
        )
      ],
    ).show();
  }
}
