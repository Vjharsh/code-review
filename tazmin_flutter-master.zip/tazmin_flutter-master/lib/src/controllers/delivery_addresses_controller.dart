import 'package:flutter/material.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:food_delivery_app/src/helpers/maps_util.dart';
import 'package:food_delivery_app/src/models/addresses.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import '../../generated/l10n.dart';
import '../models/addresses.dart';
import '../models/cart.dart';
import '../repository/cart_repository.dart';
import '../repository/settings_repository.dart' as settingRepo;
import '../repository/user_repository.dart' as userRepo;

class DeliveryAddressesController extends ControllerMVC with ChangeNotifier {
  List<Addresses> addresses = <Addresses>[];
  late GlobalKey<ScaffoldState> scaffoldKey;
  late Cart cart;
  bool isLoadingData = false;
  bool isReceivedCurrentLocation = false;
  bool isReceivedLocationList = false;

  DeliveryAddressesController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForCart();
    getCurrentLocation();
  }

  void getCurrentLocation() async {
    addresses.clear();
    isReceivedCurrentLocation = false;
    isReceivedLocationList = false;
    setState(() {
      isLoadingData = true;
    });
    var geolocationStatus =
        await Geolocator.checkPermission();
    print('geolocationStatus.value:$geolocationStatus');
    if (geolocationStatus == LocationPermission.whileInUse) {
      //for granted
      print('permission granted');
      Geolocator
          .getLastKnownPosition(forceAndroidLocationManager: true,)
          .then((position) async {
        if (position != null) {
          addCurrentLocation(position.latitude, position.longitude);
        } else {
          print('last position null');
          Geolocator
              .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
              .then((position) async {
            addCurrentLocation(position.latitude, position.longitude);
          });
        }
      });
    }
    listenForAddresses();
  }

  void addCurrentLocation(double latitude, double longitude) async {
    print('locationData.latitude:$latitude');
    print('locationData.longitude:$longitude');
    //final coordinates = new Coordinates(latitude, longitude);
    //var addressesByLatLong =
    //await Geocoder.local.findAddressesFromCoordinates(coordinates);
    //var first = addressesByLatLong.first;
    //print("featureName:${first.featureName} /addressLine : ${first.addressLine}");
    MapsUtil mapsUtil = new MapsUtil();
    String _addressName =
        await mapsUtil.getAddressName(LatLng(latitude, longitude));

    Addresses address = new Addresses();
    address.id = "0";
    address.isDefault = false;
    address.description = S.of(scaffoldKey.currentContext!).current_location;
//    address.address = "${first.addressLine}";
    address.address = "$_addressName";
    address.latitude = latitude;
    address.longitude = longitude;
    print('address.latitude:${address.latitude}');
    print('address.longitude:${address.longitude}');
    settingRepo.deliveryAddress.value.latitude = latitude;
    settingRepo.deliveryAddress.value.longitude = longitude;
    setState(() {
      isReceivedCurrentLocation = true;
      addresses.insert(0, address);
      if (isReceivedCurrentLocation || isReceivedLocationList) {
        isLoadingData = false;
      }
      setState(() {});
    });
  }

  void listenForAddresses({String? message}) async {
    Addresses newAddress = Addresses();
    final Stream<Addresses> stream = await userRepo.getAddresses();
    stream.listen((Addresses _address) {
      setState(() {
        newAddress = _address;
        addresses.insert(addresses.length > 0 ? 1 : 0, _address);
      });
    }, onError: (e) {
      isReceivedLocationList = true;
      print(e);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!, error: e.toString())) {
        getCurrentLocation();
      }
      /*scaffoldKey.currentState.showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext).verify_your_internet_connection),
      ));*/
    }, onDone: () {
      if (newAddress != Addresses()) {
        isReceivedLocationList = true;
      }
      if (isReceivedCurrentLocation || isReceivedLocationList) {
        isLoadingData = false;
      }
      setState(() {});
      if (message != null) {
        if (Helper.checkRetryMessage(scaffoldKey.currentContext, message)) {
          ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
            content: Text(message),
          ));
        }
      }
    });
  }

  void listenForCart() async {
    final Stream<Cart> stream = await getCart();
    stream.listen((Cart _cart) {
      cart = _cart;
    });
  }

  Future<void> refreshAddresses() async {
    addresses.clear();
    listenForAddresses(message: S.of(scaffoldKey.currentContext!).addresses_refreshed_successfuly);
  }

  Future<void> changeDeliveryAddress(Addresses address) async {
    await settingRepo.changeCurrentLocation(address);
    setState(() {
      settingRepo.deliveryAddress.value = address;
    });
    settingRepo.deliveryAddress.notifyListeners();
  }

  Future<void> changeDeliveryAddressToCurrentLocation() async {
    Addresses _address = await settingRepo.setCurrentLocation();
    setState(() {
      settingRepo.deliveryAddress.value = _address;
    });
    settingRepo.deliveryAddress.notifyListeners();
  }

  void addAddress(Addresses address) {
    setState(() {
      isLoadingData = true;
    });
    userRepo.addAddress(address).then((value) {
      /*setState(() {
        this.addresses.insert(0, value);
      });*/
      addresses.clear();
      getCurrentLocation();
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext!).new_address_added_successfully),
      ));
    });
  }

  void chooseDeliveryAddress(Addresses address) {
    setState(() {
      settingRepo.deliveryAddress.value = address;
    });
    settingRepo.deliveryAddress.notifyListeners();
  }

  void updateAddress(Addresses address) {
    userRepo.updateAddress(address).then((value) {
      setState(() {});
      addresses.clear();
      getCurrentLocation();
      //listenForAddresses(message: S.of(scaffoldKey.currentContext).the_address_updated_successfully);
    });
  }

  void removeDeliveryAddress(Addresses address) async {
    userRepo.removeDeliveryAddress(address).then((value) {
      setState(() {
        this.addresses.remove(address);
      });
      ScaffoldMessenger.of(scaffoldKey.currentContext!).showSnackBar(SnackBar(
        content: Text(S.of(scaffoldKey.currentContext!).delivery_address_removed_successfully),
      ));
    });
  }
}
