

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:food_delivery_app/generated/l10n.dart';
import 'package:food_delivery_app/src/helpers/helper.dart';
import 'package:mvc_pattern/mvc_pattern.dart';
import 'package:food_delivery_app/constants.dart' as Constants;
import '../models/addresses.dart';
import '../models/food.dart';
import '../models/restaurant.dart';
import '../repository/food_repository.dart';
import '../repository/restaurant_repository.dart';
import '../repository/search_repository.dart';
import '../repository/settings_repository.dart';

class SearchController extends ControllerMVC {
  List<Restaurant> restaurants = <Restaurant>[];
  List<Food> foods = <Food>[];
  late GlobalKey<ScaffoldState> scaffoldKey;

  SearchController() {
    this.scaffoldKey = new GlobalKey<ScaffoldState>();
    listenForRestaurants();
    listenForFoods();
  }

  void listenForRestaurants({String? search,String? message}) async {
    if (search == null) {
      search = await getRecentSearch();
    }
    Addresses _address = deliveryAddress.value;
    final Stream<Restaurant> stream = await searchRestaurants(search, _address);
    stream.listen((Restaurant _restaurant) {
      setState(() => restaurants.add(_restaurant));
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!)) {
        listenForRestaurants(search: search,message: Constants.RETRY);
      }
    }, onDone: () {});
  }

  void listenForFoods({String? search,String? message}) async {
    if (search == null) {
      search = await getRecentSearch();
    }
    Addresses _address = deliveryAddress.value;
    final Stream<Food> stream = await searchFoods(search, _address);
    stream.listen((Food _food) {
      setState(() => foods.add(_food));
    }, onError: (a) {
      print(a);
      if (Helper.checkRetryMessage(scaffoldKey.currentContext, message!)) {
        listenForFoods(search: search,message: Constants.RETRY);
      }
    }, onDone: () {});
  }

  Future<void> refreshSearch(search) async {
    setState(() {
      restaurants = <Restaurant>[];
      foods = <Food>[];
    });
    listenForRestaurants(search: search);
    listenForFoods(search: search);
  }

  void saveSearch(String search) {
    setRecentSearch(search);
  }
}
