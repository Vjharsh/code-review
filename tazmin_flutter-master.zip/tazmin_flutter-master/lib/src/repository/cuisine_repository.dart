import 'dart:convert';

import 'package:global_configuration/global_configuration.dart';
import 'package:http/http.dart' as http;

import '../helpers/helper.dart';
import '../models/cuisine.dart';

Future<Stream<Cuisine>> getCuisines() async {
  final String url = '${GlobalConfiguration().getValue('api_base_url')}cuisines?orderBy=updated_at&sortedBy=desc';
  print('getCuisines:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));
  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map((data) => Helper.getData(data as Map<String,dynamic>)).expand((data) => (data as List)).map((data) {
    //print('Cuisine data:$data');
    return Cuisine.fromJSON(data);
  });
}

Future<Stream<Cuisine>> getCuisinesByID(String id) async {
  final String url = '${GlobalConfiguration().getValue('api_base_url')}cuisines/$id?orderBy=updated_at&sortedBy=desc';
  print('getCuisines:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));
  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map((data) => Helper.getObjectData(data as Map<String,dynamic>)).map((data) => Cuisine.fromJSON(data));
}
