import 'dart:convert';
import 'dart:io';

import 'package:food_delivery_app/src/models/ResetMenu.dart';
import 'package:food_delivery_app/src/models/apply_coupon_code.dart';
import 'package:food_delivery_app/src/models/delivery_time.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:http/http.dart' as http;

import '../helpers/custom_trace.dart';
import '../helpers/helper.dart';
import '../models/cart.dart';
import '../models/user.dart';
import '../repository/user_repository.dart' as userRepo;

Future<Stream<Cart>> getCart() async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return new Stream.value(null!);
  }
  final String _apiToken = 'api_token=${_user.apiToken}&';
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}carts?${_apiToken}with=food;food.restaurant;extras&search=user_id:${_user.id}&searchFields=user_id:=';
   print('get cart:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));
  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map((data) =>
      Helper.getData(data as Map<String,dynamic>)).expand((data) => (data as List)).map((data) {
    //print('get cart data:${data.toString()}');
    return Cart.fromJSON(data);
  });
}



Future<Stream<int>> getCartCount() async {
  UserModel _user = userRepo.currentUser.value;
  if (_user.apiToken == '') {
    return new Stream.value(0);
  }
  final String _apiToken = 'api_token=${_user.apiToken}&';
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts/count?${_apiToken}search=user_id:${_user.id}&searchFields=user_id:=';
  print('getCartCount:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map(
        (data){
          try{
            if(data != null){
              return Helper.getIntData(data as Map<String,dynamic>);
            } else {
              return 0;
            }
          }catch(e){
            return 0;
          }
        },
      );
}

Future<Stream<DeliveryTime>> getDeliveryTime() async {
  // User _user = userRepo.currentUser.value;
  // if (_user.apiToken == null) {
  //   return new Stream.value(null);
  // }
  final String url = '${GlobalConfiguration().getValue('api_base_url')}get_delivery_time';
  print('get Delivery Time:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));
  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map((data) =>
      Helper.getData(data as Map<String,dynamic>)).map((data) {
    print('get Delivery Time data:${data.toString()}');
    return DeliveryTime.fromJson(data);
  });
}

Future<Cart> addCart(Cart cart, bool reset) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return new Cart();
  }
  Map<String, dynamic> decodedJSON = {};
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String _resetParam = 'reset=${reset ? 1 : 0}';
  cart.userId = _user.id;
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts?$_apiToken&$_resetParam';
  print('AddToCart:$url');
  print('AddToCartParams:${cart.toMap(true)}');
  final client = new http.Client();

  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(cart.toMap(true)),
  );
  print('AddToCartParams response:${response.body}');
  print('AddToCartParams response statusCode:${response.statusCode}');
  try {
    decodedJSON = json.decode(response.body)['data'] as Map<String, dynamic>;
  } on FormatException catch (e) {
    print(CustomTrace(StackTrace.current, message: e.toString()));
  }
  return Cart.fromJSON(decodedJSON);
}
Future<http.Response> addCartForReorder(Cart cart, bool reset) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String _resetParam = 'reset=${reset ? 1 : 0}';
  cart.userId = _user.id;
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts?$_apiToken&$_resetParam';
  print('AddToCart:$url');
  print('AddToCartParams:${cart.toMap(true)}');
  final client = new http.Client();

  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(cart.toMap(true)),
  );
  print('AddToCartParams response:${response.body}');
  print('AddToCartParams response statusCode:${response.statusCode}');

  return response;
}
Future<Cart> updateCart(Cart cart) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return new Cart();
  }
  final String _apiToken = 'api_token=${_user.apiToken}';
  cart.userId = _user.id;
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts/${cart.id}?$_apiToken';
  final client = new http.Client();
  cart.extras.forEach((_extras){
    print('updateCart Extras pivot2: ${_extras.extraPivot.toMap()}');
  });
  print('updateCart Cart url: ${url}');
  print('updateCart Cart params: ${cart.toMap(false)}');
  final response = await client.put(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(cart.toMap(false)),
  );
  return Cart.fromJSON(json.decode(response.body)['data']);
}
Future<Cart> updateCartForFood(Cart cart) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return new Cart();
  }
  final String _apiToken = 'api_token=${_user.apiToken}';
  cart.userId = _user.id;
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts/${cart.id}?$_apiToken';
  final client = new http.Client();
  /*cart.extras.forEach((_extras){
    print('updateCart Extras pivot2: ${_extras.extraPivot.toMap()}');
  });*/
  print('updateCart Cart url: ${url}');
  print('updateCart Cart params: ${cart.toMap(true)}');
  final response = await client.put(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(cart.toMap(true)),
  );
  return Cart.fromJSON(json.decode(response.body)['data']);
}

Future<Stream<ApplyCouponCode>> applyCouponCode(couponCode) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  final String url = '${GlobalConfiguration().getValue('api_base_url')}applyCoupon?user_id=${_user.id}&coupon_code=$couponCode';
  print('applyCouponCode Url:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));
  return streamedRest.stream.transform(utf8.decoder).transform(json.decoder).map((data) => ApplyCouponCode.fromJSON(data as Map<String,dynamic>));
}
Future<bool> removeCart(Cart cart) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return false;
  }
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String url = '${GlobalConfiguration().getValue('api_base_url')}carts/${cart.id}?$_apiToken';
  final client = new http.Client();
  final response = await client.delete(
   Uri.parse(url) ,
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
  );
  return Helper.getBoolData(json.decode(response.body));
}
