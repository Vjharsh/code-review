import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../helpers/custom_trace.dart';
import '../helpers/helper.dart';
import '../models/addresses.dart';
import '../models/credit_card.dart';
import '../models/user.dart';
import '../repository/user_repository.dart' as userRepo;
import 'package:firebase_auth/firebase_auth.dart'  ;

ValueNotifier<UserModel> currentUser = new ValueNotifier(UserModel());

Future<UserModel> login(
    UserModel user, bool isVerified, bool isForRegister, bool isForProfile) async {
  user.isOtpVerified = isVerified;
  user.isForRegister = isForRegister;
  user.isForProfile = isForProfile;
  user.email = (user.email != '' ? user.email.replaceAll(" ", "") : user.email);
  print('user.email:${user.email}');
  final String url = '${GlobalConfiguration().getValue('api_base_url')}login';
  print('login url:$url');
  print('login params:${user.toMap()}');
  final client = new http.Client();
  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(user.toMap()),
  );
  print('login Response 1: ${response.body}');
  if (response.statusCode == 200) {
    print('login response 2:${(json.decode(response.body)['data'])}');
    if (json.decode(response.body)['data'] != null) {
      Map<String, dynamic> jsonMap = json.decode(response.body)['data'];
      String isNewUser = jsonMap['isNewUser'].toString();
      print('isNewUser:$isNewUser');
      if (isNewUser == 'true') {
        print('isNewUser true');
        currentUser.value = UserModel() ;
        currentUser.value.isForNewUser = true;
      } else {
        print('isNewUser false');


        // if (!user.isForRegister && !user.isOtpVerified) {
        if (!user.isForRegister) {
          setCurrentUser(response.body);
          print('setCurrentUser() user.isForLogin: ${response.body}');
        }

        try {
          currentUser.value = UserModel.fromJSON(json.decode(response.body)['data']);
          getCurrentUser().then((value){
            // print('currentUser.value: ${value.toMap()}');
          });
        } catch (e) {
          print('error:${e.toString()}');
        }
      }
    } else {
      currentUser.value = UserModel() ;
      currentUser.value.message = jsonDecode(response.body)['message'];
    }
  } else {
    currentUser.value = UserModel() ;
    currentUser.value.message = jsonDecode(response.body)['message'];
//    print(CustomTrace(StackTrace.current, message: response.body).toString());
//    throw new Exception(response.body);
  }
  print('currentUser.value:${currentUser.value.toMap()}');
  return currentUser.value;
}

Future<UserModel> register(UserModel user) async {
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}register';
  print('Register Request: ${url}');
  final client = new http.Client();
  print('User: ${user.toMap()}');
  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(user.toMap()),
  );
  print('RegisterResponse:${response.body}');
  if (response.statusCode == 200) {
    setCurrentUser(response.body);
    currentUser.value = UserModel.fromJSON(json.decode(response.body)['data']);
  } else {
    currentUser.value.message = jsonDecode(response.body)['message'];
    print('currentUser error:${currentUser.value.message}');
  }
  return currentUser.value;
}

Future<bool> resetPassword(UserModel user) async {
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}send_reset_link_email';
  final client = new http.Client();
  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(user.toMap()),
  );
  if (response.statusCode == 200) {
    return true;
  } else {
    print(CustomTrace(StackTrace.current, message: response.body).toString());
    throw new Exception(response.body);
  }
}

Future<void> logout() async {
  FirebaseAuth.instance.signOut();
  currentUser.value = new UserModel();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  await prefs.remove('current_user');
}

void setCurrentUser(jsonString) async {
  print('setCurrentUser: ${jsonString.toString()}');
  if (json.decode(jsonString)['data'] != null) {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user', json.encode(json.decode(jsonString)['data']));
  }
}

Future<UserModel> getCurrentUser() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //prefs.clear();
  if (prefs.containsKey('current_user')) {
    print('User set1: ${json.decode(prefs.getString('current_user')!)}');
    var user = UserModel.fromJSON(json.decode(prefs.getString('current_user')!));
    print('User set2: ${user.toMap()}');
    currentUser.value = user;

    currentUser.value.auth = true;
  } else {
    currentUser.value.auth = false;
  }
  // ignore: invalid_use_of_visible_for_testing_member, invalid_use_of_protected_member
  currentUser.notifyListeners();
  return currentUser.value;
}

Future<void> setCreditCard(CreditCard creditCard) async {
  if (creditCard != null) {
    print('setCreditCard:${json.encode(creditCard.toMap())}');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('credit_card', json.encode(creditCard.toMap()));
  }
}

Future<CreditCard> getCreditCard() async {
  CreditCard _creditCard = new CreditCard();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  if (prefs.containsKey('credit_card')) {
    _creditCard = CreditCard.fromJSON(json.decode(prefs.get('credit_card').toString()));
  }
  print('getCreditCard:${_creditCard.toMap()}');
  return _creditCard;
}

Future<Object?> getLanguage() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  Object? code = await prefs.get('language_code');
  print('language_code:$code');
  return code;
}

void setLanguage(String code) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  print('language_code:$code');
  await prefs.setString('language_code', code);
}

void setOrderJsonArray(String jsonArray) async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  //print('Set order_json_array:$jsonArray');
  await prefs.setString('order_json_array', jsonArray);
}

Future<String> getOrderJsonArray() async {
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? jsonArray = await prefs.getString('order_json_array');
  //print('Get order_json_array:$jsonArray');
  return jsonArray!;
}

Future<UserModel> update(UserModel user) async {
  final String _apiToken = 'api_token=${currentUser.value.apiToken}';
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}users/${currentUser.value.id}?$_apiToken';
  final client = new http.Client();
  print('Edit Profile:$url');
  print('user.toMap:${user.toMap()}');
  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(user.toMap()),
  );
  print('user response:${json.decode(response.body)['data']}');
  setCurrentUser(response.body);
  currentUser.value = UserModel.fromJSON(json.decode(response.body)['data']);
  return currentUser.value;
}

Future<Stream<Addresses>> getAddresses() async {
  UserModel _user = currentUser.value;
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}delivery_addresses?$_apiToken&search=user_id:${_user.id}&searchFields=user_id:=&orderBy=updated_at&sortedBy=desc';
  print('getAddresses:$url');
  try {
    final client = new http.Client();
    final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

    return streamedRest.stream
        .transform(utf8.decoder)
        .transform(json.decoder)
        .map((data) => Helper.getData(data as Map<String,dynamic>))
        .expand((data) => (data as List))
        .map((data) {
      return Addresses.fromJSON(data);
    });
  } catch (e) {
    print('getAddresses error:$e');
    print(CustomTrace(StackTrace.current, message: url));
    return new Stream.value(new Addresses.fromJSON({}));
  }
}

Future<Addresses> addAddress(Addresses address) async {
  UserModel _user = userRepo.currentUser.value;
  final String _apiToken = 'api_token=${_user.apiToken}';
  address.userId = _user.id;
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}delivery_addresses?$_apiToken';
  print('addAddress:$url');
  print('addAddress params:${address.toMap()}');
  final client = new http.Client();
  try {
    final response = await client.post(
      Uri.parse(url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode(address.toMap()),
    );
    print('addAddress Response:${json.decode(response.body)['data']}');
    return Addresses.fromJSON(json.decode(response.body)['data']);
  } catch (e) {
    print(CustomTrace(StackTrace.current, message: url));
    return new Addresses.fromJSON({});
  }
}

Future<Addresses> updateAddress(Addresses address) async {
  UserModel _user = userRepo.currentUser.value;
  final String _apiToken = 'api_token=${_user.apiToken}';
  address.userId = _user.id;
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}delivery_addresses/${address.id}?$_apiToken';
  print('updateAddress:$url');
  print('updateAddress params:${address.toMap()}');
  final client = new http.Client();
  try {
    final response = await client.put(
      Uri.parse(url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode(address.toMap()),
    );
    return Addresses.fromJSON(json.decode(response.body)['data']);
  } catch (e) {
    print(CustomTrace(StackTrace.current, message: url));
    return new Addresses.fromJSON({});
  }
}

Future<Addresses> removeDeliveryAddress(Addresses address) async {
  UserModel _user = userRepo.currentUser.value;
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}delivery_addresses/${address.id}?$_apiToken';
  final client = new http.Client();
  try {
    final response = await client.delete(
      Uri.parse(url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    );
    return Addresses.fromJSON(json.decode(response.body)['data']);
  } catch (e) {
    print(CustomTrace(StackTrace.current, message: url));
    return new Addresses.fromJSON({});
  }
}
