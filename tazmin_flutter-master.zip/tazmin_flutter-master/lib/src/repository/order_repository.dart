import 'dart:convert';
import 'dart:io';

import 'package:global_configuration/global_configuration.dart';
import 'package:http/http.dart' as http;

import '../helpers/helper.dart';
import '../models/credit_card.dart';
import '../models/order.dart';
import '../models/order_status.dart';
import '../models/payment.dart';
import '../models/user.dart';
import '../repository/user_repository.dart' as userRepo;
import 'package:food_delivery_app/src/repository/settings_repository.dart' as settingRepo;
import 'package:food_delivery_app/src/repository/settings_repository.dart'
as settingRepo;
import 'package:food_delivery_app/constants.dart' as Constants;

Future<Stream<Order>> getOrders() async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  if (_user.apiToken == null) {
    return new Stream.value(null!);
  }
  final String _apiToken = 'api_token=${_user.apiToken}&';
  final String url =
      '${GlobalConfiguration().getValue(
      'api_base_url')}orders?${_apiToken}with=user;foodOrders;foodOrders.food;orderStatus;payment&search=user.id:${_user
      .id}&searchFields=user.id:=&orderBy=id&sortedBy=desc';
  // print('getOrder orderApi:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

  return streamedRest.stream
      .transform(utf8.decoder)
      .transform(json.decoder)
      .map((data) => Helper.getData(data as Map<String,dynamic>))
      .expand((data) => (data as List))
      .map((data) {
    return Order.fromJSON(data);
  });
}

Future<Stream<Order>> getOrder(orderId) async {
  UserModel _user = userRepo.currentUser.value;
  if (_user.apiToken == '') {
    return new Stream.value(Order());
  }
  final String _apiToken = 'api_token=${_user.apiToken}&';
  final String url =
      '${GlobalConfiguration().getValue(
      'api_base_url')}orders/$orderId?${_apiToken}with=user;foodOrders;foodOrders.food;orderStatus;payment;deliveryAddress';
  // print('getOrder orderApi:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

  return streamedRest.stream
      .transform(utf8.decoder)
      .transform(json.decoder)
      .map((data) => Helper.getData(data as Map<String,dynamic>))
      .map((data) {
    return Order.fromJSON(data);
  });
}

Future<Stream<Order>> getRecentOrders() async {
  UserModel _user = userRepo.currentUser.value;
  if (_user.apiToken == '') {
    return new Stream.value(null!);
  }
  final String _apiToken = 'api_token=${_user.apiToken}&';
  final String url =
      '${GlobalConfiguration().getValue(
      'api_base_url')}orders?${_apiToken}with=user;foodOrders;foodOrders.food;orderStatus;payment&search=user.id:${_user
      .id}&searchFields=user.id:=&orderBy=updated_at&sortedBy=desc&limit=3';
  print('getRecentOrders orderApi:$url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

  return streamedRest.stream
      .transform(utf8.decoder)
      .transform(json.decoder)
      .map((data) => Helper.getData(data as Map<String,dynamic>))
      .expand((data) => (data as List))
      .map((data) {
    return Order.fromJSON(data);
  });
}

Future<Stream<OrderStatus>> getOrderStatus() async {
  UserModel _user = userRepo.currentUser.value;
  if (_user.apiToken == '') {
    return new Stream.value(null!);
  }
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String url =
      '${GlobalConfiguration().getValue(
      'api_base_url')}order_statuses?$_apiToken';
  print('getOrderStatus Url : $url');
  final client = new http.Client();
  final streamedRest = await client.send(http.Request('get', Uri.parse(url)));

  return streamedRest.stream
      .transform(utf8.decoder)
      .transform(json.decoder)
      .map((data) => Helper.getData(data as Map<String,dynamic>))
      .expand((data) => (data as List))
      .map((data) {
    return OrderStatus.fromJSON(data);
  });
}

Future<String> addOrder(Order order, Payment payment, bool isForPickup) async {
  UserModel _user = userRepo.currentUser.value;
  if (_user.apiToken == '') {
    return '';
  }
  CreditCard _creditCard = await userRepo.getCreditCard();
  order.user = _user;
  print('payment.method:${payment.method}');
  if (payment.method.toLowerCase() == "Pay with Token".toLowerCase()) {
    if (!isForPickup) {
      print('isForPickup1:$isForPickup');
      payment.method = Constants.PAYMENT_METHOD_YAADPAY_ON_PICKUP;
    } else {
      print('isForPickup2:$isForPickup');
      payment.method = Constants.PAYMENT_METHOD_YAADPAY;
    }
  }
  order.payment = payment;
  order.is_used = settingRepo.setting.value.is_used;
  order.orderNote = settingRepo.setting.value.orderNote;
  order.coupon_code = settingRepo.setting.value.coupon_code;

  final String _apiToken = 'api_token=${_user.apiToken}';
  final String url =
      '${GlobalConfiguration().getValue('api_base_url')}orders?$_apiToken';
  // print('orderApi jsonArray:${settingRepo.setting.value.jsonArray}');
  print('orderApi:$url');
  print('orderParams:${json.encode(order.toMap())}');
  print('orderParams:${order.toMap()}');
  final client = new http.Client();
  Map params = order.toMap();
  params.addAll(_creditCard.toMap());
  final response = await client.post(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(params),
  );
  print('orderResponse:${json.encode(params)}');
  print('orderResponse:${json.decode(response.body)['data']}');
  return '${json.decode(response.body)['data']['order_status_id']}';
}

Future<Order> cancelOrder(Order order) async {
  UserModel _user = userRepo.currentUser.value as UserModel;
  final String _apiToken = 'api_token=${_user.apiToken}';
  final String _order_status_id = 'order_status_id=${order.orderStatus.id}';
  final String url = '${GlobalConfiguration().getValue('api_base_url')}orders/${order.id}?$_apiToken&$_order_status_id&is_cancel_order=1';
  print('cancelOrder API:$url');
  print('cancelOrder : ${order.toMap()}');
  final client = new http.Client();
  final response = await client.put(
    Uri.parse(url),
    headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    body: json.encode(order.cancelMap()),
  );
  if (response.statusCode == 200) {
    print('cancelOrder response: ${json.decode(response.body)}');
    return Order.fromJSON(json.decode(response.body)['data']);
  } else {
    print('cancelOrder error: ${response.body}');
    throw new Exception(response.body);
  }
}
