import 'package:sqflite/sqflite.dart';
const String DATA_BASE_NAME= "order.db";
const String TABLE_NAME= "Restaurants";
const String RES_ID_COLUMN= "res_id";
const String RES_MENU_COLUMN= "res_menu";

class SQLiteHelper {
  Future<Database> getDatabase() async {
    return await openDatabase(DATA_BASE_NAME, version: 1,
        onCreate: (Database db, int version) async {
      // When creating the db, create the table
      await db
          .execute('CREATE TABLE $TABLE_NAME (id INTEGER PRIMARY KEY,$RES_ID_COLUMN TEXT,$RES_MENU_COLUMN TEXT)');
    });
  }
  Future<List<Map>> getListRecords() async {
    Database database = await getDatabase();
    return await database.rawQuery('SELECT * FROM $TABLE_NAME');
  }
  Future<int?> getCountRecords() async {
    Database database = await getDatabase();
    return  Sqflite.firstIntValue(await database.rawQuery('SELECT COUNT(*) FROM $TABLE_NAME'));
  }
  Future<Map> getRecordById(int id) async {
    print('resId:$id');
    Database database = await getDatabase();
    List<Map> mapList = await database.rawQuery('SELECT $RES_MENU_COLUMN FROM $TABLE_NAME WHERE $RES_ID_COLUMN=$id');
    return mapList[0];
  }

  Future<int> deleteAllRecord() async {
    Database database = await getDatabase();
    return await database.rawDelete('DELETE FROM $TABLE_NAME');
  }

  Future<int> addItemInDataBase(String resId,String resData) async {
    int id = 0;
    Database database = await getDatabase();
    try {
      final values = <String, dynamic>{
        '$RES_ID_COLUMN': resId,
        '$RES_MENU_COLUMN': resData,
      };
      id = await database.insert(TABLE_NAME, values, conflictAlgorithm: ConflictAlgorithm.ignore);
    }catch(e)
    {
      print("fail to connect database");
    }
    return id;
  }
}
