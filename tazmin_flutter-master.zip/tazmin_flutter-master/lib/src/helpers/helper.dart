import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:food_delivery_app/src/models/res_opening_hours.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart';
import 'package:intl/intl.dart';

import '../../generated/l10n.dart';
import '../elements/CircularLoadingWidget.dart';
import '../models/cart.dart';
import '../models/food_order.dart';
import '../models/order.dart';
import '../models/restaurant.dart';
import '../repository/settings_repository.dart';
import 'custom_trace.dart';
import 'package:food_delivery_app/constants.dart' as Constants;

class Helper {
  late BuildContext context;

  Helper.of(BuildContext _context) {
    this.context = _context;
  }

  // for mapping data retrieved form json array
  static getData(Map<String, dynamic> data) {
    return data['data'] ?? [];
  }

  static int getIntData(Map<String, dynamic> data) {
    return (data['data'] as int);
  }

  static bool getBoolData(Map<String, dynamic> data) {
    return (data['data'] as bool);
  }

  static getObjectData(Map<String, dynamic> data) {
    return data['data'] ?? new Map<String, dynamic>();
  }

  static Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))
        !.buffer
        .asUint8List();
  }

  static Future<Marker> getMarker(Map<String, dynamic> res) async {
    final Uint8List markerIcon =
        await getBytesFromAsset('assets/img/marker.png', 120);
    final Marker marker = Marker(
        markerId: MarkerId(res['id']),
        icon: BitmapDescriptor.fromBytes(markerIcon),
//        onTap: () {
//          //print(res.name);
//        },
        anchor: Offset(0.5, 0.5),
        infoWindow: InfoWindow(
            title: res['name'],
            snippet: getDistance(
                res['distance'].toDouble(), setting.value.distanceUnit),
            onTap: () {
              print(CustomTrace(StackTrace.current, message: 'Info Window'));
            }),
        position: LatLng(
            double.parse(res['latitude']), double.parse(res['longitude'])));

    return marker;
  }

  static Future<Marker> getMyPositionMarker(
      double latitude, double longitude) async {
    final Uint8List markerIcon =
        await getBytesFromAsset('assets/img/my_marker.png', 120);
    final Marker marker = Marker(
        markerId: MarkerId(Random().nextInt(100).toString()),
        icon: BitmapDescriptor.fromBytes(markerIcon),
        anchor: Offset(0.5, 0.5),
        position: LatLng(latitude, longitude));

    return marker;
  }

  static List<Icon> getStarsList(double rate, {double size = 18}) {
    var list = <Icon>[];
    list = List.generate(rate.floor(), (index) {
      return Icon(Icons.star, size: size, color: Color(0xFFFFB24D));
    });
    if (rate - rate.floor() > 0) {
      list.add(Icon(Icons.star_half, size: size, color: Color(0xFFFFB24D)));
    }
    list.addAll(
        List.generate(5 - rate.floor() - (rate - rate.floor()).ceil(), (index) {
      return Icon(Icons.star_border, size: size, color: Color(0xFFFFB24D));
    }));
    return list;
  }

//  static Future<List> getPriceWithCurrency(double myPrice) async {
//    final Setting _settings = await getCurrentSettings();
//    List result = [];
//    if (myPrice != null) {
//      result.add('${myPrice.toStringAsFixed(2)}');
//      if (_settings.currencyRight) {
//        return '${myPrice.toStringAsFixed(2)} ' + _settings.defaultCurrency;
//      } else {
//        return _settings.defaultCurrency + ' ${myPrice.toStringAsFixed(2)}';
//      }
//    }
//    if (_settings.currencyRight) {
//      return '0.00 ' + _settings.defaultCurrency;
//    } else {
//      return _settings.defaultCurrency + ' 0.00';
//    }
//  }

  static Widget getPrice(double myPrice, BuildContext context,
      {TextStyle? style}) {
    if (style != null) {
      style = style.merge(TextStyle(fontSize: style.fontSize! + 2));
    }
    try {
      /*if (myPrice == 0) {
        return Text('-', style: style ?? Theme.of(context).textTheme.subtitle1);
      }*/
      return RichText(
        softWrap: false,
        overflow: TextOverflow.fade,
        maxLines: 1,
        text: !setting.value.currencyRight
            ? TextSpan(
                text: setting.value.defaultCurrency,
                style: style ?? Theme.of(context).textTheme.subtitle1,
                children: <TextSpan>[
                  TextSpan(
                      text: myPrice.toStringAsFixed(2),
                      style: style ?? Theme.of(context).textTheme.subtitle1),
                ],
              )
            : TextSpan(
                text: myPrice.toStringAsFixed(2),
                style: style ?? Theme.of(context).textTheme.subtitle1,
                children: <TextSpan>[
                  TextSpan(
                      text: setting.value.defaultCurrency,
                      style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: style != null
                              ? style.fontSize! - 4
                              : Theme.of(context).textTheme.subtitle1!.fontSize !-
                                  4)),
                ],
              ),
      );
    } catch (e) {
      return Text('');
    }
  }

  static double getTotalOrderPrice(FoodOrder foodOrder) {
    // double total = foodOrder.price * foodOrder.quantity;
    double total = foodOrder.price;
    // print('foodOrder.price:${foodOrder.price}');
    // print('foodOrder.quantity:${foodOrder.quantity}');
    // print('total111:$total');
    foodOrder.extras.forEach((extra) {
      // total += extra.price != null ? extra.price : 0;
      total += extra.extraPivot.extra_price * extra.extraPivot.extra_qty;
    });
    total *= foodOrder.quantity;
    // print('total222:$total');
    return total;
  }

  static double getTotalCartPrice(Cart cart) {
    double total = cart.food.price;
    cart.extraGroup.forEach((extraGroupElement) {
      extraGroupElement.extras.forEach((extraElement) {
        total += extraElement.extraPivot.extra_price *
            extraElement.extraPivot.extra_qty;
      });
    });
    total *= cart.quantity;
    return total;
  }

  static double getTotalCartExtraPrice(Cart cart) {
    double total = 0;
    cart.extraGroup.forEach((extraGroupElement) {
      extraGroupElement.extras.forEach((extraElement) {
        total += extraElement.extraPivot.extra_price *
            extraElement.extraPivot.extra_qty;
      });
    });
    return total;
  }

  static double getTotalExtras(FoodOrder foodOrder) {
    double total = 0;
    foodOrder.extras.forEach((extra) {
      total += extra.extraPivot.extra_price * extra.extraPivot.extra_qty;
    });
    return total;
  }

  static double getOrderPrice(FoodOrder foodOrder) {
    double total = foodOrder.price;
    foodOrder.extras.forEach((extra) {
      // total += extra.price != null ? extra.price : 0;
      total += extra.extraPivot.extra_price * extra.extraPivot.extra_qty;
    });
    return total;
  }

  static double getTaxOrder(Order order) {
    double total = 0;
    order.foodOrders.forEach((foodOrder) {
      total += getTotalOrderPrice(foodOrder);
    });
    return order.tax * total / 100;
  }

  static double getTotalOrdersPrice(Order order) {
    double total = 0;
    double subTotal = 0;
    double discount = 0;
    order.foodOrders.forEach((foodOrder) {
      total += getTotalOrderPrice(foodOrder);
    });
    subTotal = total;
    total += order.deliveryFee;
    total += order.tax * total / 100;
    // print('order.couponDiscount11:${order.couponDiscount}');
    // print('order.couponTypeId:${order.couponTypeId}');
    if (order.couponTypeId == 3) {
      discount = subTotal * order.couponDiscount / 100;
    } else {
      discount = order.couponDiscount;
    }
    // print('subTotal:$subTotal');
    // print('order.couponDiscount22:${order.couponDiscount}');
    total -= discount;
    return total;
  }

  static String getDistance(double distance, String unit) {
    String _unit = setting.value.distanceUnit;
    if (_unit == 'km') {
      distance *= 1.60934;
    }
    print('getDistance:$distance');
    return distance != null ? distance.toStringAsFixed(2) + " " + unit : "";
  }

  /*static bool canDelivery(Restaurant _restaurant, {List<Cart> carts}) {
    bool _can = _restaurant.availableForDelivery &&
        (_restaurant.distance <= _restaurant.deliveryRange ||
            _restaurant.distance <= _restaurant.deliveryRange2 ||
            _restaurant.distance <= _restaurant.deliveryRange3 ||
            _restaurant.distance <= _restaurant.deliveryRange4 ||
            _restaurant.distance <= _restaurant.deliveryRange5);
    return _can;
  }*/

  static String skipHtml(String htmlString) {
    try {
      var document = parse(htmlString);
      String parsedString = parse(document.body!.text).documentElement!.text;
      if (parsedString == null || parsedString == "null") {
        parsedString = "";
      }
      return parsedString;
    } catch (e) {
      return '';
    }
  }

  static Html applyHtml(context, String html, {TextStyle? style}) {
    return Html(
      //blockSpacing: 0,
      //data: html ?? '',
      data: html,
      // style: {"style": style ?? Theme.of(context).textTheme.bodyText1!.merge(TextStyle(fontSize: 14))},
     // useRichText: false,
      customRender: {
        "br": (context, child){
          return SizedBox(height: 0);
        },
        "p": (context, child){
          return Padding(
            padding: EdgeInsets.only(top: 0, bottom: 0),
            child: Container(
              width: double.infinity,
              child: Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                alignment: WrapAlignment.start,
                children: [child],
              ),
            ),
          );
        },
        "" : (context, child){
          return null;
        }
      },
      /*customRender: (node, children) {
        if (node is dom.Element) {
          switch (node.localName) {
            case "br":
              return SizedBox(
                height: 0,
              );
            case "p":
              return Padding(
                padding: EdgeInsets.only(top: 0, bottom: 0),
                child: Container(
                  width: double.infinity,
                  child: Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    alignment: WrapAlignment.start,
                    children: children,
                  ),
                ),
              );
          }
        }
        return null;
      },*/
    );
  }

  static OverlayEntry overlayLoader(context) {
    OverlayEntry loader = OverlayEntry(builder: (context) {
      final size = MediaQuery.of(context).size;
      return Positioned(
        height: size.height,
        width: size.width,
        top: 0,
        left: 0,
        child: Material(
          color: Theme.of(context).primaryColor.withOpacity(0.85),
          child: CircularLoadingWidget(height: 200),
        ),
      );
    });
    return loader;
  }

  static hideLoader(OverlayEntry loader) {
    Timer(Duration(milliseconds: 500), () {
      try {
        loader.remove();
      } catch (e) {}
    });
  }

  static String limitString(String text,
      {int limit = 24, String hiddenText = "..."}) {
    return text.substring(0, min<int>(limit, text.length)) +
        (text.length > limit ? hiddenText : '');
  }

  static String getCreditCardNumber(String number) {
    String result = '';
    if (number != null && number.isNotEmpty && number.length == 16) {
      result = number.substring(0, 4);
      result += ' ' + number.substring(4, 8);
      result += ' ' + number.substring(8, 12);
      result += ' ' + number.substring(12, 16);
    }
    return result;
  }

  static Uri getUri(String path) {
    String _path = Uri.parse(GlobalConfiguration().getValue('base_url')).path;
    if (!_path.endsWith('/')) {
      _path += '/';
    }
    Uri uri = Uri(
        scheme: Uri.parse(GlobalConfiguration().getValue('base_url')).scheme,
        host: Uri.parse(GlobalConfiguration().getValue('base_url')).host,
        port: Uri.parse(GlobalConfiguration().getValue('base_url')).port,
        path: _path + path);
    return uri;
  }

  String trans(String text) {
    switch (text) {
      case "App\\Notifications\\StatusChangedOrder":
        return S.of(context).order_status_changed;
      case "App\\Notifications\\NewOrder":
        return S.of(context).new_order_from_client;
      case "km":
        return S.of(context).km;
      case "mi":
        return S.of(context).mi;
      default:
        return "";
    }
  }

  static Future<bool> getResOpeningStatus(
      List<ResOpeningHours> resOpeningHoursList,
      String res_onoff_date,
      bool res_onoff) async {
    print('getResOpeningStatus');
    bool resOpeningStatus = false;
    if (resOpeningHoursList.isNotEmpty) {
      DateTime date = DateTime.now();
      String currentWeekOfDay = DateFormat.EEEE('en_US').format(date);
      print('currentWeekOfDay:$currentWeekOfDay');
      for (int i = 0; i < resOpeningHoursList.length; i++) {
        ResOpeningHours resOpeningHours = resOpeningHoursList[i];
        if (currentWeekOfDay == resOpeningHours.week) {
          if (resOpeningHours.isOpen == "1") {
            print('ResOpeningHours:${resOpeningHours.toMap()}');
            final currentTime = DateTime.now();
            final startTime = DateTime(
                currentTime.year,
                currentTime.month,
                currentTime.day,
                int.parse(resOpeningHours.startHours),
                int.parse(resOpeningHours.startMinutes),
                0);
            final endTime = DateTime(
                currentTime.year,
                currentTime.month,
                currentTime.day,
                int.parse(resOpeningHours.endHours),
                int.parse(resOpeningHours.endMinutes),
                0);

            print('startTime:$startTime');
            print('endTime:$endTime');
            if (currentTime.isAfter(startTime) &&
                currentTime.isBefore(endTime)) {
              // do something
              resOpeningStatus = true;
            }
          }
          break;
        }
      }

      DateTime newDateTime = DateTime.now();
      String newDate = DateFormat("yyyy-MM-dd").format(newDateTime);
      // print('newDate:$newDate');
      // print('res_onoff_date:${res_onoff_date.toString()}');
      DateTime resonoffdateTime =
          DateFormat("yyyy-MM-dd hh:mm:ss").parse(res_onoff_date);
      String resonoffdateNew =
          DateFormat("yyyy-MM-dd").format(resonoffdateTime);
      // print('res_onoff_date:$resonoffdateNew');
      if (newDate.toString().toLowerCase() ==
          resonoffdateNew.toString().toLowerCase()) {
        if (!res_onoff) {
          resOpeningStatus = false;
          print('match date');
        }
      } else {
        print('not match date');
      }
    }
    print('resOpeningStatus:$resOpeningStatus');
    return resOpeningStatus;
  }

  static String getRandomAvatar() {
    List<String> listOfAvatar = [];
    listOfAvatar.add("assets/img/avatar_1.png");
    listOfAvatar.add("assets/img/avatar_2.png");
    listOfAvatar.add("assets/img/avatar_3.png");
    listOfAvatar.add("assets/img/avatar_4.png");
    listOfAvatar.add("assets/img/avatar_5.png");
    listOfAvatar.add("assets/img/avatar_6.png");
    listOfAvatar.add("assets/img/avatar_7.png");
    listOfAvatar.add("assets/img/avatar_8.png");
    listOfAvatar.add("assets/img/avatar_9.png");
    listOfAvatar.add("assets/img/avatar_10.png");
    listOfAvatar.add("assets/img/avatar_11.png");
    listOfAvatar.add("assets/img/avatar_12.png");
    listOfAvatar.add("assets/img/avatar_13.png");
    listOfAvatar.add("assets/img/avatar_14.png");
    listOfAvatar.add("assets/img/avatar_15.png");
    listOfAvatar.add("assets/img/avatar_16.png");
    listOfAvatar.add("assets/img/avatar_17.png");
    int min = 0;
    int max = 16;
    Random rnd = new Random();
    int randomNumber = min + rnd.nextInt(max - min);
//    print('random Number:$randomNumber');
    return listOfAvatar[randomNumber];
  }

  static bool checkRetryMessage(context, String message, {String? error}) {
    bool isReturn = true;
    if (message != null) {
      if (message == Constants.RETRY) {
        isReturn = false;
      }
    }
    print('error:$error');
    if (error != null) {
      if (error.toString().contains('subtype of type')) {
        isReturn = false;
      }
    }
    return isReturn;
  }
}
