import 'dart:async';
import 'dart:convert';
import 'package:food_delivery_app/src/models/current_location.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../helpers/custom_trace.dart';
import '../models/Step.dart';
import '../repository/settings_repository.dart';

class MapsUtil {
   static const BASE_URL =
      "https://maps.googleapis.com/maps/api/directions/json?";

  static MapsUtil _instance = new MapsUtil.internal();

  MapsUtil.internal();

  factory MapsUtil() => _instance;
  final JsonDecoder _decoder = new JsonDecoder();

  Future<dynamic> get(String url) {
    return http.get(Uri.parse(BASE_URL + url)).then((http.Response response) {
      String res = response.body;
      int statusCode = response.statusCode;
//      print("API Response: " + res);
      if (statusCode < 200 || statusCode > 400 || json == null) {
        res = "{\"status\":" +
            statusCode.toString() +
            ",\"message\":\"error\",\"response\":" +
            res +
            "}";
        throw new Exception(res);
      }

      List<LatLng> steps = [];
      try {
        steps =
            parseSteps(_decoder.convert(res)["routes"][0]["legs"][0]["steps"]);
      } catch (e) {
        print(CustomTrace(StackTrace.current, message: e.toString()));
        // throw new Exception(e);
      }
      return steps;
    });
  }

  List<LatLng> parseSteps(final responseBody) {
    List<Step> _steps = responseBody.map<Step>((json) {
      return new Step.fromJson(json);
    }).toList();
    List<LatLng> _latLang =
        _steps.map((Step step) => step.startLatLng).toList();
    return _latLang;
  }

  Future<double> getAccurateDistance(LatLng fromLocation, LatLng toLocation) async {
    try {
      var endPoint =
          'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=${fromLocation.latitude},${fromLocation.longitude}&destinations=${toLocation.latitude},${toLocation.longitude}&language=he&key=${setting.value.googleMapsKey}';
      print("getAccurateDistance endPoint: $endPoint");
      var response = jsonDecode((await http.get(Uri.parse(endPoint))).body);
      print("getAccurateDistance Response : $response");
      var distance = 0;
      if (response['rows'][0]['elements'][0]['status'] == 'OK') {
        distance = response['rows'][0]['elements'][0]['distance']['value'];
      }
      return distance.toDouble();
    } catch (e) {
      print("getAccurateDistance Error : $e");
      return 0;
    }
  }

  Future<String> getAddressName(LatLng location) async {
    try {
      var endPoint =
          'https://maps.googleapis.com/maps/api/geocode/json?latlng=${location.latitude},${location.longitude}&language=he&key=${setting.value.googleMapsKey}';
//          'https://maps.googleapis.com/maps/api/geocode/json?latlng= 32.693380,35.046830&language=he&key=AIzaSyAK4kgheqF6rqWiRJQ8TUfdwdDNMFMTxrY';
      print("getAddressName endPoint: $endPoint");
      var response = jsonDecode((await http.get(Uri.parse(endPoint))).body);
      print("getAddressName Response : ${response['results']}");
//      return response['results'][0]['formatted_address'];
      /*
      "דאלית אל כרמל" = Daliyat Al-Karmel
      "עספיא" = Isfiya
       */
      var cityName =
          response['results'][0]['address_components'][4]['long_name'];
      if (cityName.toString().toLowerCase() ==
          'Daliyat Al-Karmel'.toLowerCase()) {
        cityName = 'דאלית אל כרמל';
      } else if (cityName.toString().toLowerCase() == 'Isfiya'.toLowerCase()) {
        cityName = 'עספיא';
      }
      var address =
          '${response['results'][0]['address_components'][0]['long_name']},${response['results'][0]['address_components'][1]['long_name']},${response['results'][0]['address_components'][2]['long_name']},${response['results'][0]['address_components'][3]['long_name']},$cityName}';
      print('mapsUtil getAddressName : $address');
//      return address;
      var formatted_address = response['results'][0]['formatted_address'];
      print('formatted_address : $formatted_address');
      var pos = formatted_address.lastIndexOf(',');
      String result =
          (pos != -1) ? formatted_address.substring(0, pos) : formatted_address;
      print('formatted_result : $result');
      //formatted_address
      List<CurrentLocationDTO> currentLocationList =
          response['results'][0]['address_components'] != null
              ? List.from(response['results'][0]['address_components'])
                  .map((element) => CurrentLocationDTO.fromJSON(element))
                  .toList()
              : [];
      print('currentLocationList result : ${currentLocationList.length}');
      String currentLocationAddress = '';
      for (int i = 0; i < currentLocationList.length; i++) {
        CurrentLocationDTO currentLocationDTO = currentLocationList[i];
        //print('location name: ${currentLocationDTO.long_name}');
        // print('location type: ${currentLocationDTO.types.length}');
        //print('location type 0: ${currentLocationDTO.types[0]}');
        try {
          if ('country'.toLowerCase() !=
                  currentLocationDTO.types[0].toString().toLowerCase() &&
              'postal_code'.toLowerCase() !=
                  currentLocationDTO.types[0].toLowerCase() &&
              'administrative_area_level_2'.toLowerCase() !=
                  currentLocationDTO.types[0].toLowerCase() &&
              'administrative_area_level_1'.toLowerCase() !=
                  currentLocationDTO.types[0].toLowerCase()) {
            if (currentLocationAddress.isEmpty) {
              currentLocationAddress = currentLocationDTO.long_name;
            } else {
              currentLocationAddress =
                  '$currentLocationAddress, ${currentLocationDTO.long_name}';
            }
          }
        } catch (e) {
          print("mapsUtil Error : $e");
        }
      }
      print('currentLocationAddress: $currentLocationAddress');
      return currentLocationAddress;
//      return response['results'][0]['formatted_address'];

    } catch (e) {
      //print(CustomTrace(StackTrace.current, message: e));
      print("mapsUtil getAddressName Error : $e");
      return null!;
    }
  }

  // Future<AutoCompleteLocation> getSearchedLocation(String input) async {
  //   try{
  //     var endPoint = 'https://maps.googleapis.com/maps/api/place/autocomplete/json?types=address&key=AIzaSyAK4kgheqF6rqWiRJQ8TUfdwdDNMFMTxrY&input=$input';
  //     var response = jsonDecode((await http.get(Uri.parse(endPoint))).body);
  //     print("getAddressName predictions : ${response['predictions']}");
  //     print("getAddressName status : ${response['status']}");
  //     return AutoCompleteLocation.fromJson(response);
  //   } catch(e) {
  //     print("mapsUtil getAddressName Error : $e");
  //     return null!;
  //   }
  // }

}
