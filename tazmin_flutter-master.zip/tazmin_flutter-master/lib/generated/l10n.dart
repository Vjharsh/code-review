// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Search for restaurants or foods`
  String get search_for_restaurants_or_foods {
    return Intl.message(
      'Search for restaurants or foods',
      name: 'search_for_restaurants_or_foods',
      desc: '',
      args: [],
    );
  }

  /// `Top Restaurants`
  String get top_restaurants {
    return Intl.message(
      'Top Restaurants',
      name: 'top_restaurants',
      desc: '',
      args: [],
    );
  }

  /// `Ordered by Nearby first`
  String get ordered_by_nearby_first {
    return Intl.message(
      'Ordered by Nearby first',
      name: 'ordered_by_nearby_first',
      desc: '',
      args: [],
    );
  }

  /// `Trending This Week`
  String get trending_this_week {
    return Intl.message(
      'Trending This Week',
      name: 'trending_this_week',
      desc: '',
      args: [],
    );
  }

  /// `Double click on the food to add it to the cart`
  String get double_click_on_the_food_to_add_it_to_the {
    return Intl.message(
      'Double click on the food to add it to the cart',
      name: 'double_click_on_the_food_to_add_it_to_the',
      desc: '',
      args: [],
    );
  }

  /// `Food Categories`
  String get food_categories {
    return Intl.message(
      'Food Categories',
      name: 'food_categories',
      desc: '',
      args: [],
    );
  }

  /// `Most Popular`
  String get most_popular {
    return Intl.message(
      'Most Popular',
      name: 'most_popular',
      desc: '',
      args: [],
    );
  }

  /// `Recent Reviews`
  String get recent_reviews {
    return Intl.message(
      'Recent Reviews',
      name: 'recent_reviews',
      desc: '',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  /// `Skip`
  String get skip {
    return Intl.message(
      'Skip',
      name: 'skip',
      desc: '',
      args: [],
    );
  }

  /// `About`
  String get about {
    return Intl.message(
      'About',
      name: 'about',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message(
      'Submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: '',
      args: [],
    );
  }

  /// `Select your preferred languages`
  String get select_your_preferred_languages {
    return Intl.message(
      'Select your preferred languages',
      name: 'select_your_preferred_languages',
      desc: '',
      args: [],
    );
  }

  /// `Order Id`
  String get order_id {
    return Intl.message(
      'Order Id',
      name: 'order_id',
      desc: '',
      args: [],
    );
  }

  /// `Category`
  String get category {
    return Intl.message(
      'Category',
      name: 'category',
      desc: '',
      args: [],
    );
  }

  /// `Checkout`
  String get checkout {
    return Intl.message(
      'Checkout',
      name: 'checkout',
      desc: '',
      args: [],
    );
  }

  /// `Payment Mode`
  String get payment_mode {
    return Intl.message(
      'Payment Mode',
      name: 'payment_mode',
      desc: '',
      args: [],
    );
  }

  /// `Select your preferred payment mode`
  String get select_your_preferred_payment_mode {
    return Intl.message(
      'Select your preferred payment mode',
      name: 'select_your_preferred_payment_mode',
      desc: '',
      args: [],
    );
  }

  /// `Or Checkout With`
  String get or_checkout_with {
    return Intl.message(
      'Or Checkout With',
      name: 'or_checkout_with',
      desc: '',
      args: [],
    );
  }

  /// `Subtotal`
  String get subtotal {
    return Intl.message(
      'Subtotal',
      name: 'subtotal',
      desc: '',
      args: [],
    );
  }

  /// `Total`
  String get total {
    return Intl.message(
      'Total',
      name: 'total',
      desc: '',
      args: [],
    );
  }

  /// `Confirm Payment`
  String get confirm_payment {
    return Intl.message(
      'Confirm Payment',
      name: 'confirm_payment',
      desc: '',
      args: [],
    );
  }

  /// `Menu`
  String get menu {
    return Intl.message(
      'Menu',
      name: 'menu',
      desc: '',
      args: [],
    );
  }

  /// `Information`
  String get information {
    return Intl.message(
      'Information',
      name: 'information',
      desc: '',
      args: [],
    );
  }

  /// `Featured Foods`
  String get featured_foods {
    return Intl.message(
      'Featured Foods',
      name: 'featured_foods',
      desc: '',
      args: [],
    );
  }

  /// `What They Say ?`
  String get what_they_say {
    return Intl.message(
      'What They Say ?',
      name: 'what_they_say',
      desc: '',
      args: [],
    );
  }

  /// `Favorite Foods`
  String get favorite_foods {
    return Intl.message(
      'Favorite Foods',
      name: 'favorite_foods',
      desc: '',
      args: [],
    );
  }

  /// `g`
  String get g {
    return Intl.message(
      'g',
      name: 'g',
      desc: '',
      args: [],
    );
  }

  /// `Extras`
  String get extras {
    return Intl.message(
      'Extras',
      name: 'extras',
      desc: '',
      args: [],
    );
  }

  /// `Select extras to add them on the food`
  String get select_extras_to_add_them_on_the_food {
    return Intl.message(
      'Select extras to add them on the food',
      name: 'select_extras_to_add_them_on_the_food',
      desc: '',
      args: [],
    );
  }

  /// `Ingredients`
  String get ingredients {
    return Intl.message(
      'Ingredients',
      name: 'ingredients',
      desc: '',
      args: [],
    );
  }

  /// `Nutrition`
  String get nutrition {
    return Intl.message(
      'Nutrition',
      name: 'nutrition',
      desc: '',
      args: [],
    );
  }

  /// `Reviews`
  String get reviews {
    return Intl.message(
      'Reviews',
      name: 'reviews',
      desc: '',
      args: [],
    );
  }

  /// `Quantity`
  String get quantity {
    return Intl.message(
      'Quantity',
      name: 'quantity',
      desc: '',
      args: [],
    );
  }

  /// `Add to Cart`
  String get add_to_cart {
    return Intl.message(
      'Add to Cart',
      name: 'add_to_cart',
      desc: '',
      args: [],
    );
  }

  /// `Faq`
  String get faq {
    return Intl.message(
      'Faq',
      name: 'faq',
      desc: '',
      args: [],
    );
  }

  /// `Help & Supports`
  String get help_supports {
    return Intl.message(
      'Help & Supports',
      name: 'help_supports',
      desc: '',
      args: [],
    );
  }

  /// `App Language`
  String get app_language {
    return Intl.message(
      'App Language',
      name: 'app_language',
      desc: '',
      args: [],
    );
  }

  /// `I forgot password ?`
  String get i_forgot_password {
    return Intl.message(
      'I forgot password ?',
      name: 'i_forgot_password',
      desc: '',
      args: [],
    );
  }

  /// `I don't have an account?`
  String get i_dont_have_an_account {
    return Intl.message(
      'I don\'t have an account?',
      name: 'i_dont_have_an_account',
      desc: '',
      args: [],
    );
  }

  /// `Maps Explorer`
  String get maps_explorer {
    return Intl.message(
      'Maps Explorer',
      name: 'maps_explorer',
      desc: '',
      args: [],
    );
  }

  /// `All Menu`
  String get all_menu {
    return Intl.message(
      'All Menu',
      name: 'all_menu',
      desc: '',
      args: [],
    );
  }

  /// `Longpress on the food to add suplements`
  String get longpress_on_the_food_to_add_suplements {
    return Intl.message(
      'Longpress on the food to add suplements',
      name: 'longpress_on_the_food_to_add_suplements',
      desc: '',
      args: [],
    );
  }

  /// `Notifications`
  String get notifications {
    return Intl.message(
      'Notifications',
      name: 'notifications',
      desc: '',
      args: [],
    );
  }

  /// `Confirmation`
  String get confirmation {
    return Intl.message(
      'Confirmation',
      name: 'confirmation',
      desc: '',
      args: [],
    );
  }

  /// `Your order has been successfully submitted!`
  String get your_order_has_been_successfully_submitted {
    return Intl.message(
      'Your order has been successfully submitted!',
      name: 'your_order_has_been_successfully_submitted',
      desc: '',
      args: [],
    );
  }

  /// `TAX`
  String get tax {
    return Intl.message(
      'TAX',
      name: 'tax',
      desc: '',
      args: [],
    );
  }

  /// `My Orders`
  String get my_orders {
    return Intl.message(
      'My Orders',
      name: 'my_orders',
      desc: '',
      args: [],
    );
  }

  /// `Profile`
  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: '',
      args: [],
    );
  }

  /// `Favorites`
  String get favorites {
    return Intl.message(
      'Favorites',
      name: 'favorites',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Payment Options`
  String get payment_options {
    return Intl.message(
      'Payment Options',
      name: 'payment_options',
      desc: '',
      args: [],
    );
  }

  /// `Cash on delivery`
  String get cash_on_delivery {
    return Intl.message(
      'Cash on delivery',
      name: 'cash_on_delivery',
      desc: '',
      args: [],
    );
  }

  /// `PayPal Payment`
  String get paypal_payment {
    return Intl.message(
      'PayPal Payment',
      name: 'paypal_payment',
      desc: '',
      args: [],
    );
  }

  /// `Recent Orders`
  String get recent_orders {
    return Intl.message(
      'Recent Orders',
      name: 'recent_orders',
      desc: '',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: '',
      args: [],
    );
  }

  /// `Profile Settings`
  String get profile_settings {
    return Intl.message(
      'Profile Settings',
      name: 'profile_settings',
      desc: '',
      args: [],
    );
  }

  /// `Full name`
  String get full_name {
    return Intl.message(
      'Full name',
      name: 'full_name',
      desc: '',
      args: [],
    );
  }

  /// `Email`
  String get email {
    return Intl.message(
      'Email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  /// `Phone`
  String get phone {
    return Intl.message(
      'Phone',
      name: 'phone',
      desc: '',
      args: [],
    );
  }

  /// `Address`
  String get address {
    return Intl.message(
      'Address',
      name: 'address',
      desc: '',
      args: [],
    );
  }

  /// `Payments Settings`
  String get payments_settings {
    return Intl.message(
      'Payments Settings',
      name: 'payments_settings',
      desc: '',
      args: [],
    );
  }

  /// `Default Credit Card`
  String get default_credit_card {
    return Intl.message(
      'Default Credit Card',
      name: 'default_credit_card',
      desc: '',
      args: [],
    );
  }

  /// `App Settings`
  String get app_settings {
    return Intl.message(
      'App Settings',
      name: 'app_settings',
      desc: '',
      args: [],
    );
  }

  /// `Languages`
  String get languages {
    return Intl.message(
      'Languages',
      name: 'languages',
      desc: '',
      args: [],
    );
  }

  /// `English`
  String get english {
    return Intl.message(
      'English',
      name: 'english',
      desc: '',
      args: [],
    );
  }

  /// `Help & Support`
  String get help_support {
    return Intl.message(
      'Help & Support',
      name: 'help_support',
      desc: '',
      args: [],
    );
  }

  /// `Register`
  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: '',
      args: [],
    );
  }

  /// `Let's Start with register!`
  String get lets_start_with_register {
    return Intl.message(
      'Let\'s Start with register!',
      name: 'lets_start_with_register',
      desc: '',
      args: [],
    );
  }

  /// `Should be more than 3 letters`
  String get should_be_more_than_3_letters {
    return Intl.message(
      'Should be more than 3 letters',
      name: 'should_be_more_than_3_letters',
      desc: '',
      args: [],
    );
  }

  /// `John Doe`
  String get john_doe {
    return Intl.message(
      'John Doe',
      name: 'john_doe',
      desc: '',
      args: [],
    );
  }

  /// `Should be a valid email`
  String get should_be_a_valid_email {
    return Intl.message(
      'Should be a valid email',
      name: 'should_be_a_valid_email',
      desc: '',
      args: [],
    );
  }

  /// `Should be more than 6 letters`
  String get should_be_more_than_6_letters {
    return Intl.message(
      'Should be more than 6 letters',
      name: 'should_be_more_than_6_letters',
      desc: '',
      args: [],
    );
  }

  /// `Password`
  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `I have account? Back to login`
  String get i_have_account_back_to_login {
    return Intl.message(
      'I have account? Back to login',
      name: 'i_have_account_back_to_login',
      desc: '',
      args: [],
    );
  }

  /// `Multi-Restaurants`
  String get multirestaurants {
    return Intl.message(
      'Multi-Restaurants',
      name: 'multirestaurants',
      desc: '',
      args: [],
    );
  }

  /// `Tracking Order`
  String get tracking_order {
    return Intl.message(
      'Tracking Order',
      name: 'tracking_order',
      desc: '',
      args: [],
    );
  }

  /// `Discover & Explorer`
  String get discover__explorer {
    return Intl.message(
      'Discover & Explorer',
      name: 'discover__explorer',
      desc: '',
      args: [],
    );
  }

  /// `You can discover restaurants & fastfood arround you and choose you best meal after few minutes we prepare and delivere it for you`
  String get you_can_discover_restaurants {
    return Intl.message(
      'You can discover restaurants & fastfood arround you and choose you best meal after few minutes we prepare and delivere it for you',
      name: 'you_can_discover_restaurants',
      desc: '',
      args: [],
    );
  }

  /// `Reset Cart?`
  String get reset_cart {
    return Intl.message(
      'Reset Cart?',
      name: 'reset_cart',
      desc: '',
      args: [],
    );
  }

  /// `Cart`
  String get cart {
    return Intl.message(
      'Cart',
      name: 'cart',
      desc: '',
      args: [],
    );
  }

  /// `Shopping Cart`
  String get shopping_cart {
    return Intl.message(
      'Shopping Cart',
      name: 'shopping_cart',
      desc: '',
      args: [],
    );
  }

  /// `Verify your quantity and click checkout`
  String get verify_your_quantity_and_click_checkout {
    return Intl.message(
      'Verify your quantity and click checkout',
      name: 'verify_your_quantity_and_click_checkout',
      desc: '',
      args: [],
    );
  }

  /// `Let's Start with Login!`
  String get lets_start_with_login {
    return Intl.message(
      'Let\'s Start with Login!',
      name: 'lets_start_with_login',
      desc: '',
      args: [],
    );
  }

  /// `Should be more than 3 characters`
  String get should_be_more_than_3_characters {
    return Intl.message(
      'Should be more than 3 characters',
      name: 'should_be_more_than_3_characters',
      desc: '',
      args: [],
    );
  }

  /// `You must add foods of the same restaurants choose one restaurants only!`
  String get you_must_add_foods_of_the_same_restaurants_choose_one {
    return Intl.message(
      'You must add foods of the same restaurants choose one restaurants only!',
      name: 'you_must_add_foods_of_the_same_restaurants_choose_one',
      desc: '',
      args: [],
    );
  }

  /// `Reset your cart and order meals form this restaurant`
  String get reset_your_cart_and_order_meals_form_this_restaurant {
    return Intl.message(
      'Reset your cart and order meals form this restaurant',
      name: 'reset_your_cart_and_order_meals_form_this_restaurant',
      desc: '',
      args: [],
    );
  }

  /// `Keep your old meals of this restaurant`
  String get keep_your_old_meals_of_this_restaurant {
    return Intl.message(
      'Keep your old meals of this restaurant',
      name: 'keep_your_old_meals_of_this_restaurant',
      desc: '',
      args: [],
    );
  }

  /// `Reset`
  String get reset {
    return Intl.message(
      'Reset',
      name: 'reset',
      desc: '',
      args: [],
    );
  }

  /// `Close`
  String get close {
    return Intl.message(
      'Close',
      name: 'close',
      desc: '',
      args: [],
    );
  }

  /// `Application Preferences`
  String get application_preferences {
    return Intl.message(
      'Application Preferences',
      name: 'application_preferences',
      desc: '',
      args: [],
    );
  }

  /// `Help & Support`
  String get help__support {
    return Intl.message(
      'Help & Support',
      name: 'help__support',
      desc: '',
      args: [],
    );
  }

  /// `Light Mode`
  String get light_mode {
    return Intl.message(
      'Light Mode',
      name: 'light_mode',
      desc: '',
      args: [],
    );
  }

  /// `Dark Mode`
  String get dark_mode {
    return Intl.message(
      'Dark Mode',
      name: 'dark_mode',
      desc: '',
      args: [],
    );
  }

  /// `Log out`
  String get log_out {
    return Intl.message(
      'Log out',
      name: 'log_out',
      desc: '',
      args: [],
    );
  }

  /// `Version`
  String get version {
    return Intl.message(
      'Version',
      name: 'version',
      desc: '',
      args: [],
    );
  }

  /// `D'ont have any item in your cart`
  String get dont_have_any_item_in_your_cart {
    return Intl.message(
      'D\'ont have any item in your cart',
      name: 'dont_have_any_item_in_your_cart',
      desc: '',
      args: [],
    );
  }

  /// `Start Exploring`
  String get start_exploring {
    return Intl.message(
      'Start Exploring',
      name: 'start_exploring',
      desc: '',
      args: [],
    );
  }

  /// `D'ont have any item in the notification list`
  String get dont_have_any_item_in_the_notification_list {
    return Intl.message(
      'D\'ont have any item in the notification list',
      name: 'dont_have_any_item_in_the_notification_list',
      desc: '',
      args: [],
    );
  }

  /// `Payment Settings`
  String get payment_settings {
    return Intl.message(
      'Payment Settings',
      name: 'payment_settings',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid number`
  String get not_a_valid_number {
    return Intl.message(
      'Not a valid number',
      name: 'not_a_valid_number',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid date`
  String get not_a_valid_date {
    return Intl.message(
      'Not a valid date',
      name: 'not_a_valid_date',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid CVC`
  String get not_a_valid_cvc {
    return Intl.message(
      'Not a valid CVC',
      name: 'not_a_valid_cvc',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message(
      'Edit',
      name: 'edit',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid full name`
  String get not_a_valid_full_name {
    return Intl.message(
      'Not a valid full name',
      name: 'not_a_valid_full_name',
      desc: '',
      args: [],
    );
  }

  /// `Email Address`
  String get email_address {
    return Intl.message(
      'Email Address',
      name: 'email_address',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid email`
  String get not_a_valid_email {
    return Intl.message(
      'Not a valid email',
      name: 'not_a_valid_email',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid phone`
  String get not_a_valid_phone {
    return Intl.message(
      'Not a valid phone',
      name: 'not_a_valid_phone',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid address`
  String get not_a_valid_address {
    return Intl.message(
      'Not a valid address',
      name: 'not_a_valid_address',
      desc: '',
      args: [],
    );
  }

  /// `Not a valid biography`
  String get not_a_valid_biography {
    return Intl.message(
      'Not a valid biography',
      name: 'not_a_valid_biography',
      desc: '',
      args: [],
    );
  }

  /// `Your biography`
  String get your_biography {
    return Intl.message(
      'Your biography',
      name: 'your_biography',
      desc: '',
      args: [],
    );
  }

  /// `Your Address`
  String get your_address {
    return Intl.message(
      'Your Address',
      name: 'your_address',
      desc: '',
      args: [],
    );
  }

  /// `Search`
  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Recents Search`
  String get recents_search {
    return Intl.message(
      'Recents Search',
      name: 'recents_search',
      desc: '',
      args: [],
    );
  }

  /// `Verify your internet connection`
  String get verify_your_internet_connection {
    return Intl.message(
      'Verify your internet connection',
      name: 'verify_your_internet_connection',
      desc: '',
      args: [],
    );
  }

  /// `Carts refreshed successfully`
  String get carts_refreshed_successfuly {
    return Intl.message(
      'Carts refreshed successfully',
      name: 'carts_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `The {foodname} was removed from your cart`
  String the_food_was_removed_from_your_cart(Object foodname) {
    return Intl.message(
      'The $foodname was removed from your cart',
      name: 'the_food_was_removed_from_your_cart',
      desc: '',
      args: [foodname],
    );
  }

  /// `Category refreshed successfully`
  String get category_refreshed_successfuly {
    return Intl.message(
      'Category refreshed successfully',
      name: 'category_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Notifications refreshed successfully`
  String get notifications_refreshed_successfuly {
    return Intl.message(
      'Notifications refreshed successfully',
      name: 'notifications_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Order refreshed successfully`
  String get order_refreshed_successfuly {
    return Intl.message(
      'Order refreshed successfully',
      name: 'order_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Orders refreshed successfully`
  String get orders_refreshed_successfuly {
    return Intl.message(
      'Orders refreshed successfully',
      name: 'orders_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Restaurant refreshed successfully`
  String get restaurant_refreshed_successfuly {
    return Intl.message(
      'Restaurant refreshed successfully',
      name: 'restaurant_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Profile settings updated successfully`
  String get profile_settings_updated_successfully {
    return Intl.message(
      'Profile settings updated successfully',
      name: 'profile_settings_updated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Payment settings updated successfully`
  String get payment_settings_updated_successfully {
    return Intl.message(
      'Payment settings updated successfully',
      name: 'payment_settings_updated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Tracking refreshed successfully`
  String get tracking_refreshed_successfuly {
    return Intl.message(
      'Tracking refreshed successfully',
      name: 'tracking_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Welcome`
  String get welcome {
    return Intl.message(
      'Welcome',
      name: 'welcome',
      desc: '',
      args: [],
    );
  }

  /// `Wrong email or password`
  String get wrong_email_or_password {
    return Intl.message(
      'Wrong email or password',
      name: 'wrong_email_or_password',
      desc: '',
      args: [],
    );
  }

  /// `Addresses refreshed successfuly`
  String get addresses_refreshed_successfuly {
    return Intl.message(
      'Addresses refreshed successfuly',
      name: 'addresses_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Delivery Addresses`
  String get delivery_addresses {
    return Intl.message(
      'Delivery Addresses',
      name: 'delivery_addresses',
      desc: '',
      args: [],
    );
  }

  /// `Add`
  String get add {
    return Intl.message(
      'Add',
      name: 'add',
      desc: '',
      args: [],
    );
  }

  /// `New Address added successfully`
  String get new_address_added_successfully {
    return Intl.message(
      'New Address added successfully',
      name: 'new_address_added_successfully',
      desc: '',
      args: [],
    );
  }

  /// `The address updated successfully`
  String get the_address_updated_successfully {
    return Intl.message(
      'The address updated successfully',
      name: 'the_address_updated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Long press to edit item, swipe item to delete it`
  String get long_press_to_edit_item_swipe_item_to_delete_it {
    return Intl.message(
      'Long press to edit item, swipe item to delete it',
      name: 'long_press_to_edit_item_swipe_item_to_delete_it',
      desc: '',
      args: [],
    );
  }

  /// `Add Delivery Address`
  String get add_delivery_address {
    return Intl.message(
      'Add Delivery Address',
      name: 'add_delivery_address',
      desc: '',
      args: [],
    );
  }

  /// `Home Address`
  String get home_address {
    return Intl.message(
      'Home Address',
      name: 'home_address',
      desc: '',
      args: [],
    );
  }

  /// `Description`
  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  /// `12 Street, City 21663, Country`
  String get hint_full_address {
    return Intl.message(
      '12 Street, City 21663, Country',
      name: 'hint_full_address',
      desc: '',
      args: [],
    );
  }

  /// `Full Address`
  String get full_address {
    return Intl.message(
      'Full Address',
      name: 'full_address',
      desc: '',
      args: [],
    );
  }

  /// `Email to reset password`
  String get email_to_reset_password {
    return Intl.message(
      'Email to reset password',
      name: 'email_to_reset_password',
      desc: '',
      args: [],
    );
  }

  /// `Send link`
  String get send_password_reset_link {
    return Intl.message(
      'Send link',
      name: 'send_password_reset_link',
      desc: '',
      args: [],
    );
  }

  /// `I remember my password return to login`
  String get i_remember_my_password_return_to_login {
    return Intl.message(
      'I remember my password return to login',
      name: 'i_remember_my_password_return_to_login',
      desc: '',
      args: [],
    );
  }

  /// `Your reset link has been sent to your email`
  String get your_reset_link_has_been_sent_to_your_email {
    return Intl.message(
      'Your reset link has been sent to your email',
      name: 'your_reset_link_has_been_sent_to_your_email',
      desc: '',
      args: [],
    );
  }

  /// `Error! Verify email settings`
  String get error_verify_email_settings {
    return Intl.message(
      'Error! Verify email settings',
      name: 'error_verify_email_settings',
      desc: '',
      args: [],
    );
  }

  /// `Guest`
  String get guest {
    return Intl.message(
      'Guest',
      name: 'guest',
      desc: '',
      args: [],
    );
  }

  /// `You must sign-in to access to this section`
  String get you_must_signin_to_access_to_this_section {
    return Intl.message(
      'You must sign-in to access to this section',
      name: 'you_must_signin_to_access_to_this_section',
      desc: '',
      args: [],
    );
  }

  /// `Tell us about this restaurant`
  String get tell_us_about_this_restaurant {
    return Intl.message(
      'Tell us about this restaurant',
      name: 'tell_us_about_this_restaurant',
      desc: '',
      args: [],
    );
  }

  /// `How would you rate this restaurant ?`
  String get how_would_you_rate_this_restaurant_ {
    return Intl.message(
      'How would you rate this restaurant ?',
      name: 'how_would_you_rate_this_restaurant_',
      desc: '',
      args: [],
    );
  }

  /// `Tell us about this food`
  String get tell_us_about_this_food {
    return Intl.message(
      'Tell us about this food',
      name: 'tell_us_about_this_food',
      desc: '',
      args: [],
    );
  }

  /// `The restaurant has been rated successfully`
  String get the_restaurant_has_been_rated_successfully {
    return Intl.message(
      'The restaurant has been rated successfully',
      name: 'the_restaurant_has_been_rated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `The food has been rated successfully`
  String get the_food_has_been_rated_successfully {
    return Intl.message(
      'The food has been rated successfully',
      name: 'the_food_has_been_rated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Reviews refreshed successfully!`
  String get reviews_refreshed_successfully {
    return Intl.message(
      'Reviews refreshed successfully!',
      name: 'reviews_refreshed_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Delivery Fee`
  String get delivery_fee {
    return Intl.message(
      'Delivery Fee',
      name: 'delivery_fee',
      desc: '',
      args: [],
    );
  }

  /// `Order status changed`
  String get order_status_changed {
    return Intl.message(
      'Order status changed',
      name: 'order_status_changed',
      desc: '',
      args: [],
    );
  }

  /// `New order from client`
  String get new_order_from_client {
    return Intl.message(
      'New order from client',
      name: 'new_order_from_client',
      desc: '',
      args: [],
    );
  }

  /// `Shopping`
  String get shopping {
    return Intl.message(
      'Shopping',
      name: 'shopping',
      desc: '',
      args: [],
    );
  }

  /// `Delivery or Pickup`
  String get delivery_or_pickup {
    return Intl.message(
      'Delivery or Pickup',
      name: 'delivery_or_pickup',
      desc: '',
      args: [],
    );
  }

  /// `Payment card updated successfully`
  String get payment_card_updated_successfully {
    return Intl.message(
      'Payment card updated successfully',
      name: 'payment_card_updated_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Deliverable`
  String get deliverable {
    return Intl.message(
      'Deliverable',
      name: 'deliverable',
      desc: '',
      args: [],
    );
  }

  /// `Not Deliverable`
  String get not_deliverable {
    return Intl.message(
      'Not Deliverable',
      name: 'not_deliverable',
      desc: '',
      args: [],
    );
  }

  /// `Items`
  String get items {
    return Intl.message(
      'Items',
      name: 'items',
      desc: '',
      args: [],
    );
  }

  /// `Delivery`
  String get delivery {
    return Intl.message(
      'Delivery',
      name: 'delivery',
      desc: '',
      args: [],
    );
  }

  /// `Pickup`
  String get pickup {
    return Intl.message(
      'Pickup',
      name: 'pickup',
      desc: '',
      args: [],
    );
  }

  /// `Closed`
  String get closed {
    return Intl.message(
      'Closed',
      name: 'closed',
      desc: '',
      args: [],
    );
  }

  /// `Open`
  String get open {
    return Intl.message(
      'Open',
      name: 'open',
      desc: '',
      args: [],
    );
  }

  /// `Km`
  String get km {
    return Intl.message(
      'Km',
      name: 'km',
      desc: '',
      args: [],
    );
  }

  /// `mi`
  String get mi {
    return Intl.message(
      'mi',
      name: 'mi',
      desc: '',
      args: [],
    );
  }

  /// `Delivery Address`
  String get delivery_address {
    return Intl.message(
      'Delivery Address',
      name: 'delivery_address',
      desc: '',
      args: [],
    );
  }

  /// `Current location`
  String get current_location {
    return Intl.message(
      'Current location',
      name: 'current_location',
      desc: '',
      args: [],
    );
  }

  /// `Delivery Address removed successfully`
  String get delivery_address_removed_successfully {
    return Intl.message(
      'Delivery Address removed successfully',
      name: 'delivery_address_removed_successfully',
      desc: '',
      args: [],
    );
  }

  /// `Add new delivery address`
  String get add_new_delivery_address {
    return Intl.message(
      'Add new delivery address',
      name: 'add_new_delivery_address',
      desc: '',
      args: [],
    );
  }

  /// `Restaurants near to your current location`
  String get restaurants_near_to_your_current_location {
    return Intl.message(
      'Restaurants near to your current location',
      name: 'restaurants_near_to_your_current_location',
      desc: '',
      args: [],
    );
  }

  /// `Restaurants near to`
  String get restaurants_near_to {
    return Intl.message(
      'Restaurants near to',
      name: 'restaurants_near_to',
      desc: '',
      args: [],
    );
  }

  /// `Near to`
  String get near_to {
    return Intl.message(
      'Near to',
      name: 'near_to',
      desc: '',
      args: [],
    );
  }

  /// `Near to your current location`
  String get near_to_your_current_location {
    return Intl.message(
      'Near to your current location',
      name: 'near_to_your_current_location',
      desc: '',
      args: [],
    );
  }

  /// `Pickup your food from the restaurant`
  String get pickup_your_food_from_the_restaurant {
    return Intl.message(
      'Pickup your food from the restaurant',
      name: 'pickup_your_food_from_the_restaurant',
      desc: '',
      args: [],
    );
  }

  /// `Confirm your delivery address`
  String get confirm_your_delivery_address {
    return Intl.message(
      'Confirm your delivery address',
      name: 'confirm_your_delivery_address',
      desc: '',
      args: [],
    );
  }

  /// `Filter`
  String get filter {
    return Intl.message(
      'Filter',
      name: 'filter',
      desc: '',
      args: [],
    );
  }

  /// `Clear`
  String get clear {
    return Intl.message(
      'Clear',
      name: 'clear',
      desc: '',
      args: [],
    );
  }

  /// `Apply Filters`
  String get apply_filters {
    return Intl.message(
      'Apply Filters',
      name: 'apply_filters',
      desc: '',
      args: [],
    );
  }

  /// `Opened Restaurants`
  String get opened_restaurants {
    return Intl.message(
      'Opened Restaurants',
      name: 'opened_restaurants',
      desc: '',
      args: [],
    );
  }

  /// `Fields`
  String get fields {
    return Intl.message(
      'Fields',
      name: 'fields',
      desc: '',
      args: [],
    );
  }

  /// `This food was added to cart`
  String get this_food_was_added_to_cart {
    return Intl.message(
      'This food was added to cart',
      name: 'this_food_was_added_to_cart',
      desc: '',
      args: [],
    );
  }

  /// `Foods result`
  String get foods_result {
    return Intl.message(
      'Foods result',
      name: 'foods_result',
      desc: '',
      args: [],
    );
  }

  /// `Foods Results`
  String get foods_results {
    return Intl.message(
      'Foods Results',
      name: 'foods_results',
      desc: '',
      args: [],
    );
  }

  /// `Restaurants Results`
  String get restaurants_results {
    return Intl.message(
      'Restaurants Results',
      name: 'restaurants_results',
      desc: '',
      args: [],
    );
  }

  /// `All`
  String get all {
    return Intl.message(
      'All',
      name: 'all',
      desc: '',
      args: [],
    );
  }

  /// `This restaurant is closed !`
  String get this_restaurant_is_closed_ {
    return Intl.message(
      'This restaurant is closed !',
      name: 'this_restaurant_is_closed_',
      desc: '',
      args: [],
    );
  }

  /// `Unknown`
  String get unknown {
    return Intl.message(
      'Unknown',
      name: 'unknown',
      desc: '',
      args: [],
    );
  }

  /// `How would you rate this restaurant ?`
  String get how_would_you_rate_this_restaurant {
    return Intl.message(
      'How would you rate this restaurant ?',
      name: 'how_would_you_rate_this_restaurant',
      desc: '',
      args: [],
    );
  }

  /// `Click on the stars below to leave comments`
  String get click_on_the_stars_below_to_leave_comments {
    return Intl.message(
      'Click on the stars below to leave comments',
      name: 'click_on_the_stars_below_to_leave_comments',
      desc: '',
      args: [],
    );
  }

  /// `Click to confirm your address and pay or Long press to edit your address`
  String get click_to_confirm_your_address_and_pay_or_long_press {
    return Intl.message(
      'Click to confirm your address and pay or Long press to edit your address',
      name: 'click_to_confirm_your_address_and_pay_or_long_press',
      desc: '',
      args: [],
    );
  }

  /// `Visa Card`
  String get visa_card {
    return Intl.message(
      'Visa Card',
      name: 'visa_card',
      desc: '',
      args: [],
    );
  }

  /// `MasterCard`
  String get mastercard {
    return Intl.message(
      'MasterCard',
      name: 'mastercard',
      desc: '',
      args: [],
    );
  }

  /// `PayPal`
  String get paypal {
    return Intl.message(
      'PayPal',
      name: 'paypal',
      desc: '',
      args: [],
    );
  }

  /// `Pay on Pickup`
  String get pay_on_pickup {
    return Intl.message(
      'Pay on Pickup',
      name: 'pay_on_pickup',
      desc: '',
      args: [],
    );
  }

  /// `Click to pay with your Visa Card`
  String get click_to_pay_with_your_visa_card {
    return Intl.message(
      'Click to pay with your Visa Card',
      name: 'click_to_pay_with_your_visa_card',
      desc: '',
      args: [],
    );
  }

  /// `Click to pay with your MasterCard`
  String get click_to_pay_with_your_mastercard {
    return Intl.message(
      'Click to pay with your MasterCard',
      name: 'click_to_pay_with_your_mastercard',
      desc: '',
      args: [],
    );
  }

  /// `Click to pay with your PayPal account`
  String get click_to_pay_with_your_paypal_account {
    return Intl.message(
      'Click to pay with your PayPal account',
      name: 'click_to_pay_with_your_paypal_account',
      desc: '',
      args: [],
    );
  }

  /// `Click to pay cash on delivery`
  String get click_to_pay_cash_on_delivery {
    return Intl.message(
      'Click to pay cash on delivery',
      name: 'click_to_pay_cash_on_delivery',
      desc: '',
      args: [],
    );
  }

  /// `Click to pay on pickup`
  String get click_to_pay_on_pickup {
    return Intl.message(
      'Click to pay on pickup',
      name: 'click_to_pay_on_pickup',
      desc: '',
      args: [],
    );
  }

  /// `This email account exists`
  String get this_email_account_exists {
    return Intl.message(
      'This email account exists',
      name: 'this_email_account_exists',
      desc: '',
      args: [],
    );
  }

  /// `This account not exist`
  String get this_account_not_exist {
    return Intl.message(
      'This account not exist',
      name: 'this_account_not_exist',
      desc: '',
      args: [],
    );
  }

  /// `CARD NUMBER`
  String get card_number {
    return Intl.message(
      'CARD NUMBER',
      name: 'card_number',
      desc: '',
      args: [],
    );
  }

  /// `EXPIRY DATE`
  String get expiry_date {
    return Intl.message(
      'EXPIRY DATE',
      name: 'expiry_date',
      desc: '',
      args: [],
    );
  }

  /// `CVV`
  String get cvv {
    return Intl.message(
      'CVV',
      name: 'cvv',
      desc: '',
      args: [],
    );
  }

  /// `Your credit card not valid`
  String get your_credit_card_not_valid {
    return Intl.message(
      'Your credit card not valid',
      name: 'your_credit_card_not_valid',
      desc: '',
      args: [],
    );
  }

  /// `Number`
  String get number {
    return Intl.message(
      'Number',
      name: 'number',
      desc: '',
      args: [],
    );
  }

  /// `Exp Date`
  String get exp_date {
    return Intl.message(
      'Exp Date',
      name: 'exp_date',
      desc: '',
      args: [],
    );
  }

  /// `CVC`
  String get cvc {
    return Intl.message(
      'CVC',
      name: 'cvc',
      desc: '',
      args: [],
    );
  }

  /// `Cuisines`
  String get cuisines {
    return Intl.message(
      'Cuisines',
      name: 'cuisines',
      desc: '',
      args: [],
    );
  }

  /// `Favorites refreshed successfuly`
  String get favorites_refreshed_successfuly {
    return Intl.message(
      'Favorites refreshed successfuly',
      name: 'favorites_refreshed_successfuly',
      desc: '',
      args: [],
    );
  }

  /// `Email or Phone`
  String get email_phone {
    return Intl.message(
      'Email or Phone',
      name: 'email_phone',
      desc: '',
      args: [],
    );
  }

  /// `YaadPay Payment`
  String get yaadpay_payment {
    return Intl.message(
      'YaadPay Payment',
      name: 'yaadpay_payment',
      desc: '',
      args: [],
    );
  }

  /// `Should be a valid email or phone number`
  String get should_be_a_valid_email_phone {
    return Intl.message(
      'Should be a valid email or phone number',
      name: 'should_be_a_valid_email_phone',
      desc: '',
      args: [],
    );
  }

  /// `You have nothing here`
  String get empty_data {
    return Intl.message(
      'You have nothing here',
      name: 'empty_data',
      desc: '',
      args: [],
    );
  }

  /// `Enter valid OTP`
  String get enter_valid_otp {
    return Intl.message(
      'Enter valid OTP',
      name: 'enter_valid_otp',
      desc: '',
      args: [],
    );
  }

  /// `OTP`
  String get otp {
    return Intl.message(
      'OTP',
      name: 'otp',
      desc: '',
      args: [],
    );
  }

  /// `Back`
  String get back {
    return Intl.message(
      'Back',
      name: 'back',
      desc: '',
      args: [],
    );
  }

  /// `Request failed`
  String get request_failed {
    return Intl.message(
      'Request failed',
      name: 'request_failed',
      desc: '',
      args: [],
    );
  }

  /// `One Time Password`
  String get one_time_password {
    return Intl.message(
      'One Time Password',
      name: 'one_time_password',
      desc: '',
      args: [],
    );
  }

  /// `Please enter phone or email & password`
  String get enter_email_or_phone {
    return Intl.message(
      'Please enter phone or email & password',
      name: 'enter_email_or_phone',
      desc: '',
      args: [],
    );
  }

  /// `Restaurants Categories`
  String get res_categories_title {
    return Intl.message(
      'Restaurants Categories',
      name: 'res_categories_title',
      desc: '',
      args: [],
    );
  }

  /// `Update Required`
  String get alert_update_app_version_title {
    return Intl.message(
      'Update Required',
      name: 'alert_update_app_version_title',
      desc: '',
      args: [],
    );
  }

  /// `The app is outdated , Please update it to the latest version.`
  String get alert_update_app_version_message {
    return Intl.message(
      'The app is outdated , Please update it to the latest version.',
      name: 'alert_update_app_version_message',
      desc: '',
      args: [],
    );
  }

  /// `Setting`
  String get alert_location_service_btn {
    return Intl.message(
      'Setting',
      name: 'alert_location_service_btn',
      desc: '',
      args: [],
    );
  }

  /// `Location Service Disabled`
  String get alert_location_service_title {
    return Intl.message(
      'Location Service Disabled',
      name: 'alert_location_service_title',
      desc: '',
      args: [],
    );
  }

  /// `Please turn on location service.`
  String get alert_location_service_message {
    return Intl.message(
      'Please turn on location service.',
      name: 'alert_location_service_message',
      desc: '',
      args: [],
    );
  }

  /// `Location Service Permission Denied`
  String get alert_location_service_permission_title {
    return Intl.message(
      'Location Service Permission Denied',
      name: 'alert_location_service_permission_title',
      desc: '',
      args: [],
    );
  }

  /// `Please allow location service permission.`
  String get alert_location_service_permission_message {
    return Intl.message(
      'Please allow location service permission.',
      name: 'alert_location_service_permission_message',
      desc: '',
      args: [],
    );
  }

  /// `Ok`
  String get alert_ok {
    return Intl.message(
      'Ok',
      name: 'alert_ok',
      desc: '',
      args: [],
    );
  }

  /// `Search Items`
  String get search_items {
    return Intl.message(
      'Search Items',
      name: 'search_items',
      desc: '',
      args: [],
    );
  }

  /// ``
  String get web_page_title {
    return Intl.message(
      '',
      name: 'web_page_title',
      desc: '',
      args: [],
    );
  }

  /// `Update`
  String get update_btn {
    return Intl.message(
      'Update',
      name: 'update_btn',
      desc: '',
      args: [],
    );
  }

  /// `GO TO OFFER`
  String get go_to_offer {
    return Intl.message(
      'GO TO OFFER',
      name: 'go_to_offer',
      desc: '',
      args: [],
    );
  }

  /// `I agree to the`
  String get i_agree_txt {
    return Intl.message(
      'I agree to the',
      name: 'i_agree_txt',
      desc: '',
      args: [],
    );
  }

  /// `Terms Of Service`
  String get terms_of_service_txt {
    return Intl.message(
      'Terms Of Service',
      name: 'terms_of_service_txt',
      desc: '',
      args: [],
    );
  }

  /// `Please follow Terms Of Service`
  String get select_terms_of_service_txt {
    return Intl.message(
      'Please follow Terms Of Service',
      name: 'select_terms_of_service_txt',
      desc: '',
      args: [],
    );
  }

  /// `Save CreditCard`
  String get saving_card_alert_title {
    return Intl.message(
      'Save CreditCard',
      name: 'saving_card_alert_title',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get alert_yes {
    return Intl.message(
      'Yes',
      name: 'alert_yes',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get alert_no {
    return Intl.message(
      'No',
      name: 'alert_no',
      desc: '',
      args: [],
    );
  }

  /// `Pay`
  String get pay_alert_title {
    return Intl.message(
      'Pay',
      name: 'pay_alert_title',
      desc: '',
      args: [],
    );
  }

  /// `Are you want pay with saved {ccLast4Digit} Credit Card?`
  String pay_alert_message(Object ccLast4Digit) {
    return Intl.message(
      'Are you want pay with saved $ccLast4Digit Credit Card?',
      name: 'pay_alert_message',
      desc: '',
      args: [ccLast4Digit],
    );
  }

  /// `Minimum Order`
  String get alert_title_min_order {
    return Intl.message(
      'Minimum Order',
      name: 'alert_title_min_order',
      desc: '',
      args: [],
    );
  }

  /// `Save Current Location Address`
  String get alert_title_save_address {
    return Intl.message(
      'Save Current Location Address',
      name: 'alert_title_save_address',
      desc: '',
      args: [],
    );
  }

  /// `Are you want save this current location address?`
  String get alert_message_save_address {
    return Intl.message(
      'Are you want save this current location address?',
      name: 'alert_message_save_address',
      desc: '',
      args: [],
    );
  }

  /// `Login Fail`
  String get alert_title_login_fail {
    return Intl.message(
      'Login Fail',
      name: 'alert_title_login_fail',
      desc: '',
      args: [],
    );
  }

  /// `Minimum Order:`
  String get min_order {
    return Intl.message(
      'Minimum Order:',
      name: 'min_order',
      desc: '',
      args: [],
    );
  }

  /// `Please indicate that you have read and agree to the Terms of Service`
  String get agree_with_terms {
    return Intl.message(
      'Please indicate that you have read and agree to the Terms of Service',
      name: 'agree_with_terms',
      desc: '',
      args: [],
    );
  }

  /// `User already exists with phone number or email`
  String get user_already_exist {
    return Intl.message(
      'User already exists with phone number or email',
      name: 'user_already_exist',
      desc: '',
      args: [],
    );
  }

  /// `This phone is not registered`
  String get phone_not_registered {
    return Intl.message(
      'This phone is not registered',
      name: 'phone_not_registered',
      desc: '',
      args: [],
    );
  }

  /// `Should be minimum order {currency}{minOrderPrice}`
  String alert_message_min_order(Object currency, Object minOrderPrice) {
    return Intl.message(
      'Should be minimum order $currency$minOrderPrice',
      name: 'alert_message_min_order',
      desc: '',
      args: [currency, minOrderPrice],
    );
  }

  /// `Are you want save this {ccLast4Digit} Credit Card?`
  String saving_card_alert_message(Object ccLast4Digit) {
    return Intl.message(
      'Are you want save this $ccLast4Digit Credit Card?',
      name: 'saving_card_alert_message',
      desc: '',
      args: [ccLast4Digit],
    );
  }

  /// `Please select order payment option`
  String get payment_option_message {
    return Intl.message(
      'Please select order payment option',
      name: 'payment_option_message',
      desc: '',
      args: [],
    );
  }

  /// `Out Of Town Area`
  String get out_of_town_area_title {
    return Intl.message(
      'Out Of Town Area',
      name: 'out_of_town_area_title',
      desc: '',
      args: [],
    );
  }

  /// `--OR--`
  String get or {
    return Intl.message(
      '--OR--',
      name: 'or',
      desc: '',
      args: [],
    );
  }

  /// `Make it default`
  String get make_it_default {
    return Intl.message(
      'Make it default',
      name: 'make_it_default',
      desc: '',
      args: [],
    );
  }

  /// `Coupon Code`
  String get coupon_code {
    return Intl.message(
      'Coupon Code',
      name: 'coupon_code',
      desc: '',
      args: [],
    );
  }

  /// `Do you have a coupon code?`
  String get have_a_coupon {
    return Intl.message(
      'Do you have a coupon code?',
      name: 'have_a_coupon',
      desc: '',
      args: [],
    );
  }

  /// `Insert here`
  String get insert_here {
    return Intl.message(
      'Insert here',
      name: 'insert_here',
      desc: '',
      args: [],
    );
  }

  /// `Apply`
  String get apply {
    return Intl.message(
      'Apply',
      name: 'apply',
      desc: '',
      args: [],
    );
  }

  /// `Applied Coupon Code`
  String get applied_coupon_code {
    return Intl.message(
      'Applied Coupon Code',
      name: 'applied_coupon_code',
      desc: '',
      args: [],
    );
  }

  /// `Discount`
  String get discount {
    return Intl.message(
      'Discount',
      name: 'discount',
      desc: '',
      args: [],
    );
  }

  /// `You do not  have any order`
  String get youDontHaveAnyOrder {
    return Intl.message(
      'You do not  have any order',
      name: 'youDontHaveAnyOrder',
      desc: '',
      args: [],
    );
  }

  /// `Canceled`
  String get canceled {
    return Intl.message(
      'Canceled',
      name: 'canceled',
      desc: '',
      args: [],
    );
  }

  /// `Cancel Order`
  String get cancelOrder {
    return Intl.message(
      'Cancel Order',
      name: 'cancelOrder',
      desc: '',
      args: [],
    );
  }

  /// `View`
  String get view {
    return Intl.message(
      'View',
      name: 'view',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to cancel this order?`
  String get areYouSureYouWantToCancelThisOrder {
    return Intl.message(
      'Are you sure you want to cancel this order?',
      name: 'areYouSureYouWantToCancelThisOrder',
      desc: '',
      args: [],
    );
  }

  /// `Order: #{id} has been canceled`
  String orderThisorderidHasBeenCanceled(Object id) {
    return Intl.message(
      'Order: #$id has been canceled',
      name: 'orderThisorderidHasBeenCanceled',
      desc: '',
      args: [id],
    );
  }

  /// `Order Details`
  String get orderDetails {
    return Intl.message(
      'Order Details',
      name: 'orderDetails',
      desc: '',
      args: [],
    );
  }

  /// `Details`
  String get details {
    return Intl.message(
      'Details',
      name: 'details',
      desc: '',
      args: [],
    );
  }

  /// `Done`
  String get done {
    return Intl.message(
      'Done',
      name: 'done',
      desc: '',
      args: [],
    );
  }

  /// `Show All`
  String get show_all {
    return Intl.message(
      'Show All',
      name: 'show_all',
      desc: '',
      args: [],
    );
  }

  /// `Food refreshed successfully`
  String get food_refresh_message {
    return Intl.message(
      'Food refreshed successfully',
      name: 'food_refresh_message',
      desc: '',
      args: [],
    );
  }

  /// `One or more of the foods are not deliverable`
  String get not_deliverable_message {
    return Intl.message(
      'One or more of the foods are not deliverable',
      name: 'not_deliverable_message',
      desc: '',
      args: [],
    );
  }

  /// `Order Note`
  String get order_note {
    return Intl.message(
      'Order Note',
      name: 'order_note',
      desc: '',
      args: [],
    );
  }

  /// `Busy`
  String get busy {
    return Intl.message(
      'Busy',
      name: 'busy',
      desc: '',
      args: [],
    );
  }

  /// `Search Place`
  String get search_place {
    return Intl.message(
      'Search Place',
      name: 'search_place',
      desc: '',
      args: [],
    );
  }

  /// `Click Here`
  String get click_here {
    return Intl.message(
      'Click Here',
      name: 'click_here',
      desc: '',
      args: [],
    );
  }

  /// `Cash Only`
  String get cash_only {
    return Intl.message(
      'Cash Only',
      name: 'cash_only',
      desc: '',
      args: [],
    );
  }

  /// `This restaurants does not support pickup`
  String get does_not_support_pickup {
    return Intl.message(
      'This restaurants does not support pickup',
      name: 'does_not_support_pickup',
      desc: '',
      args: [],
    );
  }

  /// `See Menu`
  String get see_menu {
    return Intl.message(
      'See Menu',
      name: 'see_menu',
      desc: '',
      args: [],
    );
  }

  /// `האוכל נוסף בהצלחה!`
  String get added_to_cart {
    return Intl.message(
      'האוכל נוסף בהצלחה!',
      name: 'added_to_cart',
      desc: '',
      args: [],
    );
  }

  /// `{foodName} נוסף להזמנה!`
  String add_to_cart_popup_message(Object foodName) {
    return Intl.message(
      '$foodName נוסף להזמנה!',
      name: 'add_to_cart_popup_message',
      desc: '',
      args: [foodName],
    );
  }

  /// `המשך בהזמנה`
  String get continue_order {
    return Intl.message(
      'המשך בהזמנה',
      name: 'continue_order',
      desc: '',
      args: [],
    );
  }

  /// `נסה שוב`
  String get retry {
    return Intl.message(
      'נסה שוב',
      name: 'retry',
      desc: '',
      args: [],
    );
  }

  /// `לקופה`
  String get checkout_add_to_cart {
    return Intl.message(
      'לקופה',
      name: 'checkout_add_to_cart',
      desc: '',
      args: [],
    );
  }

  /// `Out of Stock`
  String get out_of_stock {
    return Intl.message(
      'Out of Stock',
      name: 'out_of_stock',
      desc: '',
      args: [],
    );
  }

  /// `InStock`
  String get in_stock {
    return Intl.message(
      'InStock',
      name: 'in_stock',
      desc: '',
      args: [],
    );
  }

  /// `PizzaType`
  String get pizza_type {
    return Intl.message(
      'PizzaType',
      name: 'pizza_type',
      desc: '',
      args: [],
    );
  }

  /// `Left Pizza`
  String get left_pizza {
    return Intl.message(
      'Left Pizza',
      name: 'left_pizza',
      desc: '',
      args: [],
    );
  }

  /// `Right Pizza`
  String get right_pizza {
    return Intl.message(
      'Right Pizza',
      name: 'right_pizza',
      desc: '',
      args: [],
    );
  }

  /// `Whole Pizza`
  String get whole_pizza {
    return Intl.message(
      'Whole Pizza',
      name: 'whole_pizza',
      desc: '',
      args: [],
    );
  }

  /// `ReOrder`
  String get re_order {
    return Intl.message(
      'ReOrder',
      name: 're_order',
      desc: '',
      args: [],
    );
  }

  /// `The Carmel delivery app`
  String get splash_subtext {
    return Intl.message(
      'The Carmel delivery app',
      name: 'splash_subtext',
      desc: '',
      args: [],
    );
  }

  /// `OTP`
  String get otp_tab {
    return Intl.message(
      'OTP',
      name: 'otp_tab',
      desc: '',
      args: [],
    );
  }

  /// `Email`
  String get email_tab {
    return Intl.message(
      'Email',
      name: 'email_tab',
      desc: '',
      args: [],
    );
  }

  /// `Finish Order`
  String get finish_order {
    return Intl.message(
      'Finish Order',
      name: 'finish_order',
      desc: '',
      args: [],
    );
  }

  /// `You can only choose {limitQty} times`
  String limit_qty_message(Object limitQty) {
    return Intl.message(
      'You can only choose $limitQty times',
      name: 'limit_qty_message',
      desc: '',
      args: [limitQty],
    );
  }

  /// `Limited quantity`
  String get limited_quantity {
    return Intl.message(
      'Limited quantity',
      name: 'limited_quantity',
      desc: '',
      args: [],
    );
  }

  /// `Sale!`
  String get sale {
    return Intl.message(
      'Sale!',
      name: 'sale',
      desc: '',
      args: [],
    );
  }

  /// `Change Address`
  String get change_address {
    return Intl.message(
      'Change Address',
      name: 'change_address',
      desc: '',
      args: [],
    );
  }

  /// `All Restaurants`
  String get all_restaurants {
    return Intl.message(
      'All Restaurants',
      name: 'all_restaurants',
      desc: '',
      args: [],
    );
  }

  /// `{counter} open restaurants right now`
  String open_restaurants_right_now(Object counter) {
    return Intl.message(
      '$counter open restaurants right now',
      name: 'open_restaurants_right_now',
      desc: '',
      args: [counter],
    );
  }

  /// `Next`
  String get next {
    return Intl.message(
      'Next',
      name: 'next',
      desc: '',
      args: [],
    );
  }

  /// `ConfirmPassword`
  String get confirmpassword {
    return Intl.message(
      'ConfirmPassword',
      name: 'confirmpassword',
      desc: '',
      args: [],
    );
  }

  /// `Location Permission`
  String get location_permission {
    return Intl.message(
      'Location Permission',
      name: 'location_permission',
      desc: '',
      args: [],
    );
  }

  /// `Pickup`
  String get pickup_btn {
    return Intl.message(
      'Pickup',
      name: 'pickup_btn',
      desc: '',
      args: [],
    );
  }

  /// `Location Permission`
  String get location_permission_title {
    return Intl.message(
      'Location Permission',
      name: 'location_permission_title',
      desc: '',
      args: [],
    );
  }

  /// `Total Extras`
  String get total_extras {
    return Intl.message(
      'Total Extras',
      name: 'total_extras',
      desc: '',
      args: [],
    );
  }

  /// `I will pay with credit card`
  String get i_will_pay_with_credit_card {
    return Intl.message(
      'I will pay with credit card',
      name: 'i_will_pay_with_credit_card',
      desc: '',
      args: [],
    );
  }

  /// `I will pay in store`
  String get i_will_pay_in_store {
    return Intl.message(
      'I will pay in store',
      name: 'i_will_pay_in_store',
      desc: '',
      args: [],
    );
  }

  /// `None`
  String get none {
    return Intl.message(
      'None',
      name: 'none',
      desc: '',
      args: [],
    );
  }

  /// `Select all`
  String get select_all {
    return Intl.message(
      'Select all',
      name: 'select_all',
      desc: '',
      args: [],
    );
  }

  /// `We will send invoices to this email`
  String get register_email_description {
    return Intl.message(
      'We will send invoices to this email',
      name: 'register_email_description',
      desc: '',
      args: [],
    );
  }

  /// `Please choose a strong password`
  String get register_password_description {
    return Intl.message(
      'Please choose a strong password',
      name: 'register_password_description',
      desc: '',
      args: [],
    );
  }

  /// `please enter username`
  String get register_username_description {
    return Intl.message(
      'please enter username',
      name: 'register_username_description',
      desc: '',
      args: [],
    );
  }

  /// `please enter number`
  String get register_number_description {
    return Intl.message(
      'please enter number',
      name: 'register_number_description',
      desc: '',
      args: [],
    );
  }

  /// `Email already exists.`
  String get email_already_exists {
    return Intl.message(
      'Email already exists.',
      name: 'email_already_exists',
      desc: '',
      args: [],
    );
  }

  /// `Phone number already exists.`
  String get phone_already_exists {
    return Intl.message(
      'Phone number already exists.',
      name: 'phone_already_exists',
      desc: '',
      args: [],
    );
  }

  /// `Pickup - credit card`
  String get pickupCreditCard {
    return Intl.message(
      'Pickup - credit card',
      name: 'pickupCreditCard',
      desc: '',
      args: [],
    );
  }

  /// `אימייל או סיסמה אינם נכונים`
  String get emailOrPasswordIsNotValid {
    return Intl.message(
      'אימייל או סיסמה אינם נכונים',
      name: 'emailOrPasswordIsNotValid',
      desc: '',
      args: [],
    );
  }

  /// `Please select atleast one item from `
  String get pleaseSelectAtleastOneItemFrom {
    return Intl.message(
      'Please select atleast one item from ',
      name: 'pleaseSelectAtleastOneItemFrom',
      desc: '',
      args: [],
    );
  }

  /// `Add to order`
  String get addToOrder {
    return Intl.message(
      'Add to order',
      name: 'addToOrder',
      desc: '',
      args: [],
    );
  }

  /// `Open for deliveries`
  String get openForDeliveries {
    return Intl.message(
      'Open for deliveries',
      name: 'openForDeliveries',
      desc: '',
      args: [],
    );
  }

  /// `Closed for deliveries`
  String get closedForDeliveries {
    return Intl.message(
      'Closed for deliveries',
      name: 'closedForDeliveries',
      desc: '',
      args: [],
    );
  }

  /// `test`
  String get test {
    return Intl.message(
      'test',
      name: 'test',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
      Locale.fromSubtags(languageCode: 'es'),
      Locale.fromSubtags(languageCode: 'fr'),
      Locale.fromSubtags(languageCode: 'he'),
      Locale.fromSubtags(languageCode: 'in'),
      Locale.fromSubtags(languageCode: 'ko'),
      Locale.fromSubtags(languageCode: 'pt'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
