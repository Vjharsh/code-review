// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  static String m0(foodName) => "${foodName} נוסף להזמנה!";

  static String m1(currency, minOrderPrice) =>
      "Should be minimum order ${currency}${minOrderPrice}";

  static String m2(limitQty) => "You can only choose ${limitQty} times";

  static String m3(counter) => "${counter} open restaurants right now";

  static String m4(id) => "Order: #${id} has been canceled";

  static String m5(ccLast4Digit) =>
      "Are you want save this ${ccLast4Digit} Credit Card?";

  static String m6(foodname) => "تمت إزالة ${foodname} من سلة التسوق";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "about": MessageLookupByLibrary.simpleMessage("نبذة"),
        "add": MessageLookupByLibrary.simpleMessage("اضافة"),
        "addToOrder": MessageLookupByLibrary.simpleMessage("Add to order"),
        "add_delivery_address":
            MessageLookupByLibrary.simpleMessage("اضافة عنوان للتوصيل"),
        "add_to_cart":
            MessageLookupByLibrary.simpleMessage("أضف إلى سلة التسوق"),
        "add_to_cart_popup_message": m0,
        "added_to_cart":
            MessageLookupByLibrary.simpleMessage("האוכל נוסף בהצלחה!"),
        "address": MessageLookupByLibrary.simpleMessage("العنوان"),
        "addresses_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث العناوين بنجاح"),
        "agree_with_terms": MessageLookupByLibrary.simpleMessage(
            "Please indicate that you have read and agree to the Terms of Service"),
        "alert_location_service_btn":
            MessageLookupByLibrary.simpleMessage("Setting"),
        "alert_location_service_message": MessageLookupByLibrary.simpleMessage(
            "Please turn on location service."),
        "alert_location_service_permission_message":
            MessageLookupByLibrary.simpleMessage(
                "Please allow location service permission."),
        "alert_location_service_permission_title":
            MessageLookupByLibrary.simpleMessage(
                "Location Service Permission Denied"),
        "alert_location_service_title":
            MessageLookupByLibrary.simpleMessage("Location Service Disabled"),
        "alert_message_min_order": m1,
        "alert_message_save_address": MessageLookupByLibrary.simpleMessage(
            "Are you want save this current location address?"),
        "alert_no": MessageLookupByLibrary.simpleMessage("No"),
        "alert_ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "alert_title_login_fail":
            MessageLookupByLibrary.simpleMessage("Login Fail"),
        "alert_title_min_order":
            MessageLookupByLibrary.simpleMessage("Minimum Order"),
        "alert_title_save_address": MessageLookupByLibrary.simpleMessage(
            "Save Current Location Address"),
        "alert_update_app_version_message": MessageLookupByLibrary.simpleMessage(
            "The app is outdated , Please update it to the latest version."),
        "alert_update_app_version_title":
            MessageLookupByLibrary.simpleMessage("Update Required"),
        "alert_yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "all_menu": MessageLookupByLibrary.simpleMessage("كل المينو"),
        "all_restaurants":
            MessageLookupByLibrary.simpleMessage("All Restaurants"),
        "app_language": MessageLookupByLibrary.simpleMessage("لغة التطبيق"),
        "app_settings": MessageLookupByLibrary.simpleMessage("إعدادات التطبيق"),
        "application_preferences":
            MessageLookupByLibrary.simpleMessage("تفضيلات التطبيق"),
        "applied_coupon_code":
            MessageLookupByLibrary.simpleMessage("Applied Coupon Code"),
        "apply": MessageLookupByLibrary.simpleMessage("Apply"),
        "areYouSureYouWantToCancelThisOrder":
            MessageLookupByLibrary.simpleMessage(
                "Are you sure you want to cancel this order?"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "busy": MessageLookupByLibrary.simpleMessage("Busy"),
        "cancel": MessageLookupByLibrary.simpleMessage("إلغاء"),
        "cancelOrder": MessageLookupByLibrary.simpleMessage("Cancel Order"),
        "canceled": MessageLookupByLibrary.simpleMessage("Canceled"),
        "cart": MessageLookupByLibrary.simpleMessage("سلة التسوق"),
        "carts_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث العربة بنجاح"),
        "cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("الدفع عن الاستلام"),
        "cash_only": MessageLookupByLibrary.simpleMessage("Cash Only"),
        "category": MessageLookupByLibrary.simpleMessage("الفئة"),
        "category_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث الفئة بنجاح"),
        "change_address":
            MessageLookupByLibrary.simpleMessage("Change Address"),
        "checkout": MessageLookupByLibrary.simpleMessage("الدفع"),
        "checkout_add_to_cart": MessageLookupByLibrary.simpleMessage("לקופה"),
        "click_here": MessageLookupByLibrary.simpleMessage("Click Here"),
        "click_on_the_stars_below_to_leave_comments":
            MessageLookupByLibrary.simpleMessage(
                "Click on the stars below to leave comments"),
        "close": MessageLookupByLibrary.simpleMessage("اغلاق"),
        "closedForDeliveries":
            MessageLookupByLibrary.simpleMessage("Closed for deliveries"),
        "confirm_payment": MessageLookupByLibrary.simpleMessage("تأكيد الدفع"),
        "confirmation": MessageLookupByLibrary.simpleMessage("التأكيد"),
        "confirmpassword":
            MessageLookupByLibrary.simpleMessage("ConfirmPassword"),
        "continue_order": MessageLookupByLibrary.simpleMessage("המשך בהזמנה"),
        "coupon_code": MessageLookupByLibrary.simpleMessage("Coupon Code"),
        "cuisines": MessageLookupByLibrary.simpleMessage("Cuisines"),
        "dark_mode": MessageLookupByLibrary.simpleMessage("الوضع الداكن"),
        "default_credit_card":
            MessageLookupByLibrary.simpleMessage("بطاقة الائتمان الافتراضية"),
        "delivery_addresses":
            MessageLookupByLibrary.simpleMessage("عناوين التوصيل"),
        "delivery_fee": MessageLookupByLibrary.simpleMessage("Delivery Fee"),
        "description": MessageLookupByLibrary.simpleMessage("الوصف"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Discount"),
        "discover__explorer": MessageLookupByLibrary.simpleMessage("استكشاف"),
        "does_not_support_pickup": MessageLookupByLibrary.simpleMessage(
            "This restaurants does not support pickup"),
        "done": MessageLookupByLibrary.simpleMessage("Done"),
        "dont_have_any_item_in_the_notification_list":
            MessageLookupByLibrary.simpleMessage("قائمة الاشعارات فارغة"),
        "dont_have_any_item_in_your_cart":
            MessageLookupByLibrary.simpleMessage("سلة التسوق فارغة"),
        "double_click_on_the_food_to_add_it_to_the":
            MessageLookupByLibrary.simpleMessage(
                "انقر مرتين على المنتج لإضافته إلى سلة التسوق"),
        "edit": MessageLookupByLibrary.simpleMessage("تعديل"),
        "email": MessageLookupByLibrary.simpleMessage("البريد الإلكتروني"),
        "emailOrPasswordIsNotValid":
            MessageLookupByLibrary.simpleMessage("אימייל או סיסמה אינם נכונים"),
        "email_address":
            MessageLookupByLibrary.simpleMessage("البريد الإلكتروني"),
        "email_already_exists":
            MessageLookupByLibrary.simpleMessage("Email already exists."),
        "email_phone": MessageLookupByLibrary.simpleMessage("Email or Phone"),
        "email_tab": MessageLookupByLibrary.simpleMessage("Email"),
        "email_to_reset_password": MessageLookupByLibrary.simpleMessage(
            "استعادة كلمة المرور بالبريد الالكتروني"),
        "empty_data":
            MessageLookupByLibrary.simpleMessage("You have nothing here"),
        "english": MessageLookupByLibrary.simpleMessage("الإنجليزية"),
        "enter_email_or_phone": MessageLookupByLibrary.simpleMessage(
            "Please enter phone or email & password"),
        "enter_valid_otp":
            MessageLookupByLibrary.simpleMessage("Enter valid OTP"),
        "error_verify_email_settings": MessageLookupByLibrary.simpleMessage(
            "البريد الالكتروني غير مسجل لدينا"),
        "extras": MessageLookupByLibrary.simpleMessage("إضافات"),
        "faq": MessageLookupByLibrary.simpleMessage("الاسئلة الشائعة"),
        "favorite_foods":
            MessageLookupByLibrary.simpleMessage("المنتجات المفضلة"),
        "favorites": MessageLookupByLibrary.simpleMessage("المفضلة"),
        "favorites_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Favorites refreshed successfuly"),
        "featured_foods":
            MessageLookupByLibrary.simpleMessage("المنتجات المميزة"),
        "finish_order": MessageLookupByLibrary.simpleMessage("Finish Order"),
        "food_categories": MessageLookupByLibrary.simpleMessage("الفئات"),
        "food_refresh_message":
            MessageLookupByLibrary.simpleMessage("Food refreshed successfully"),
        "full_address": MessageLookupByLibrary.simpleMessage("العنوان بالكامل"),
        "full_name": MessageLookupByLibrary.simpleMessage("الاسم الكامل"),
        "g": MessageLookupByLibrary.simpleMessage("جم"),
        "go_to_offer": MessageLookupByLibrary.simpleMessage("GO TO OFFER"),
        "guest": MessageLookupByLibrary.simpleMessage("زائر"),
        "have_a_coupon":
            MessageLookupByLibrary.simpleMessage("Do you have a coupon code?"),
        "help__support": MessageLookupByLibrary.simpleMessage("المساعدة"),
        "help_support": MessageLookupByLibrary.simpleMessage("المساعدة"),
        "help_supports": MessageLookupByLibrary.simpleMessage("المساعدة"),
        "hint_full_address": MessageLookupByLibrary.simpleMessage(
            "المدينة المنورة ، حي الازهري ، الشارع العام ، خلف مكتبة الحرمين"),
        "home": MessageLookupByLibrary.simpleMessage("الرئيسية"),
        "home_address": MessageLookupByLibrary.simpleMessage("المنزل"),
        "how_would_you_rate_this_restaurant_":
            MessageLookupByLibrary.simpleMessage(
                "How would you rate this restaurant ?"),
        "i_agree_txt": MessageLookupByLibrary.simpleMessage("I agree to the"),
        "i_dont_have_an_account":
            MessageLookupByLibrary.simpleMessage("ليس لدي حساب"),
        "i_forgot_password":
            MessageLookupByLibrary.simpleMessage("نسيت كلمة المرور؟"),
        "i_have_account_back_to_login": MessageLookupByLibrary.simpleMessage(
            "لدي حساب، العودة لتسجيل الدخول"),
        "i_remember_my_password_return_to_login":
            MessageLookupByLibrary.simpleMessage(
                "تذكرت كلمة المرور، ارجع لشاشة الدخول"),
        "i_will_pay_in_store":
            MessageLookupByLibrary.simpleMessage("I will pay in store"),
        "i_will_pay_with_credit_card":
            MessageLookupByLibrary.simpleMessage("I will pay with credit card"),
        "in_stock": MessageLookupByLibrary.simpleMessage("InStock"),
        "information": MessageLookupByLibrary.simpleMessage("معلومات"),
        "ingredients": MessageLookupByLibrary.simpleMessage("المكونات"),
        "insert_here": MessageLookupByLibrary.simpleMessage("Insert here"),
        "john_doe": MessageLookupByLibrary.simpleMessage("فلان الفلاني"),
        "keep_your_old_meals_of_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "لا تفرغ السلة واحتفظ باختياراتي السابقة"),
        "languages": MessageLookupByLibrary.simpleMessage("اللغات"),
        "left_pizza": MessageLookupByLibrary.simpleMessage("Left Pizza"),
        "lets_start_with_login":
            MessageLookupByLibrary.simpleMessage("لنبدأ بتسجيل الدخول!"),
        "lets_start_with_register":
            MessageLookupByLibrary.simpleMessage("لنبدأ بالتسجيل!"),
        "light_mode": MessageLookupByLibrary.simpleMessage("الوضع الفاتح"),
        "limit_qty_message": m2,
        "limited_quantity":
            MessageLookupByLibrary.simpleMessage("Limited quantity"),
        "location_permission":
            MessageLookupByLibrary.simpleMessage("Location Permission"),
        "location_permission_title":
            MessageLookupByLibrary.simpleMessage("Location Permission"),
        "log_out": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
        "login": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
        "long_press_to_edit_item_swipe_item_to_delete_it":
            MessageLookupByLibrary.simpleMessage(
                "اضغط مطولا لتحرير العنصر، اسحب الى الجنب لحذفه"),
        "longpress_on_the_food_to_add_suplements":
            MessageLookupByLibrary.simpleMessage(" إضغط على المنتج لإضافة"),
        "make_it_default":
            MessageLookupByLibrary.simpleMessage("Make it default"),
        "maps_explorer": MessageLookupByLibrary.simpleMessage("مستكشف الخرائط"),
        "menu": MessageLookupByLibrary.simpleMessage("المينيو"),
        "min_order": MessageLookupByLibrary.simpleMessage("Minimum Order:"),
        "most_popular": MessageLookupByLibrary.simpleMessage("الأكثر شعبية"),
        "multirestaurants": MessageLookupByLibrary.simpleMessage("عدة مطابخ"),
        "my_orders": MessageLookupByLibrary.simpleMessage("طلباتي"),
        "new_address_added_successfully": MessageLookupByLibrary.simpleMessage(
            "تمت اضافة العنوان الجديد بنجاح"),
        "new_order_from_client":
            MessageLookupByLibrary.simpleMessage("New order from client"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "none": MessageLookupByLibrary.simpleMessage("None"),
        "not_a_valid_address":
            MessageLookupByLibrary.simpleMessage("العنوان غير صالح"),
        "not_a_valid_biography":
            MessageLookupByLibrary.simpleMessage("نبذة غير صالحة"),
        "not_a_valid_cvc":
            MessageLookupByLibrary.simpleMessage("سيرة ذاتية غير صالحة"),
        "not_a_valid_date":
            MessageLookupByLibrary.simpleMessage("تاريخ غير صالح"),
        "not_a_valid_email":
            MessageLookupByLibrary.simpleMessage("بريد الكتروني غير صالح"),
        "not_a_valid_full_name":
            MessageLookupByLibrary.simpleMessage("اسم غير صالح"),
        "not_a_valid_number":
            MessageLookupByLibrary.simpleMessage("رقم غير صحيح"),
        "not_a_valid_phone":
            MessageLookupByLibrary.simpleMessage("رقم الجوال غير صالح"),
        "not_deliverable_message": MessageLookupByLibrary.simpleMessage(
            "One or more of the foods are not deliverable"),
        "notifications": MessageLookupByLibrary.simpleMessage("تنويهات"),
        "notifications_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث الإشعارات بنجاح"),
        "nutrition": MessageLookupByLibrary.simpleMessage("العناصر الغذائية"),
        "one_time_password":
            MessageLookupByLibrary.simpleMessage("One Time Password"),
        "openForDeliveries":
            MessageLookupByLibrary.simpleMessage("Open for deliveries"),
        "open_restaurants_right_now": m3,
        "or": MessageLookupByLibrary.simpleMessage("--OR--"),
        "or_checkout_with": MessageLookupByLibrary.simpleMessage("او ادفع مع"),
        "orderDetails": MessageLookupByLibrary.simpleMessage("Order Details"),
        "orderThisorderidHasBeenCanceled": m4,
        "order_id": MessageLookupByLibrary.simpleMessage("رمز الطلب"),
        "order_note": MessageLookupByLibrary.simpleMessage("Order Note"),
        "order_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث الطلب بنجاح"),
        "order_status_changed":
            MessageLookupByLibrary.simpleMessage("Order status changed"),
        "ordered_by_nearby_first":
            MessageLookupByLibrary.simpleMessage("مرتبة حسب الاقرب"),
        "orders_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث الطلبات بنجاح"),
        "otp": MessageLookupByLibrary.simpleMessage("OTP"),
        "otp_tab": MessageLookupByLibrary.simpleMessage("OTP"),
        "out_of_stock": MessageLookupByLibrary.simpleMessage("Out of Stock"),
        "password": MessageLookupByLibrary.simpleMessage("كلمه المرور"),
        "pay_alert_title": MessageLookupByLibrary.simpleMessage("Pay"),
        "payment_mode": MessageLookupByLibrary.simpleMessage("طريقة الدفع"),
        "payment_options": MessageLookupByLibrary.simpleMessage("خيارات الدفع"),
        "payment_settings":
            MessageLookupByLibrary.simpleMessage("إعدادات الدفع"),
        "payment_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "تم تحديث إعدادات الدفع بنجاح"),
        "payments_settings":
            MessageLookupByLibrary.simpleMessage("إعدادات الدفع"),
        "paypal_payment":
            MessageLookupByLibrary.simpleMessage("الدفع بواسطة Paypal"),
        "phone": MessageLookupByLibrary.simpleMessage("رقم الجوال"),
        "phone_already_exists": MessageLookupByLibrary.simpleMessage(
            "Phone number already exists."),
        "phone_not_registered": MessageLookupByLibrary.simpleMessage(
            "This phone is not registered"),
        "pickupCreditCard":
            MessageLookupByLibrary.simpleMessage("Pickup - credit card"),
        "pickup_btn": MessageLookupByLibrary.simpleMessage("Pickup"),
        "pizza_type": MessageLookupByLibrary.simpleMessage("PizzaType"),
        "pleaseSelectAtleastOneItemFrom": MessageLookupByLibrary.simpleMessage(
            "Please select atleast one item from "),
        "profile": MessageLookupByLibrary.simpleMessage("الملف الشخصي"),
        "profile_settings":
            MessageLookupByLibrary.simpleMessage("إعدادات الملف الشخصي"),
        "profile_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "تم تحديث إعدادات الملف الشخصي بنجاح"),
        "quantity": MessageLookupByLibrary.simpleMessage("الكمية"),
        "re_order": MessageLookupByLibrary.simpleMessage("ReOrder"),
        "recent_orders":
            MessageLookupByLibrary.simpleMessage("الطلبات الأخيرة"),
        "recent_reviews":
            MessageLookupByLibrary.simpleMessage("التعليقات الأخيرة"),
        "recents_search":
            MessageLookupByLibrary.simpleMessage("عمليات البحث الأخيرة"),
        "register": MessageLookupByLibrary.simpleMessage("تسجيل"),
        "register_email_description": MessageLookupByLibrary.simpleMessage(
            "We will send invoices to this email"),
        "register_number_description":
            MessageLookupByLibrary.simpleMessage("please enter number"),
        "register_password_description": MessageLookupByLibrary.simpleMessage(
            "Please choose a strong password"),
        "register_username_description":
            MessageLookupByLibrary.simpleMessage("please enter username"),
        "request_failed":
            MessageLookupByLibrary.simpleMessage("Request failed"),
        "res_categories_title":
            MessageLookupByLibrary.simpleMessage("Restaurants Categories"),
        "reset": MessageLookupByLibrary.simpleMessage("إعادة تعيين"),
        "reset_cart":
            MessageLookupByLibrary.simpleMessage("إعادة تعيين سلة التسوق"),
        "reset_your_cart_and_order_meals_form_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "افرغ سلة التسوق واضف اختياراتي من هذا المطبخ"),
        "restaurant_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث المطبخ بنجاح"),
        "retry": MessageLookupByLibrary.simpleMessage("נסה שוב"),
        "reviews": MessageLookupByLibrary.simpleMessage("التعليقات"),
        "reviews_refreshed_successfully": MessageLookupByLibrary.simpleMessage(
            "Reviews refreshed successfully!"),
        "right_pizza": MessageLookupByLibrary.simpleMessage("Right Pizza"),
        "sale": MessageLookupByLibrary.simpleMessage("Sale!"),
        "save": MessageLookupByLibrary.simpleMessage("حفظ"),
        "saving_card_alert_message": m5,
        "saving_card_alert_title":
            MessageLookupByLibrary.simpleMessage("Save CreditCard"),
        "search": MessageLookupByLibrary.simpleMessage("بحث"),
        "search_for_restaurants_or_foods":
            MessageLookupByLibrary.simpleMessage("البحث في المطابخ والمنتجات"),
        "search_items": MessageLookupByLibrary.simpleMessage("Search Items"),
        "search_place": MessageLookupByLibrary.simpleMessage("Search Place"),
        "see_menu": MessageLookupByLibrary.simpleMessage("See Menu"),
        "select_all": MessageLookupByLibrary.simpleMessage("Select all"),
        "select_extras_to_add_them_on_the_food":
            MessageLookupByLibrary.simpleMessage("اختر الاضافات"),
        "select_terms_of_service_txt": MessageLookupByLibrary.simpleMessage(
            "Please follow Terms Of Service"),
        "select_your_preferred_languages":
            MessageLookupByLibrary.simpleMessage("اختر لغتك المفضلة"),
        "select_your_preferred_payment_mode":
            MessageLookupByLibrary.simpleMessage("اختر طريقة الدفع المفضلة"),
        "send_password_reset_link": MessageLookupByLibrary.simpleMessage(
            "ارسل رابط استعادة كلمة المرور"),
        "settings": MessageLookupByLibrary.simpleMessage("الإعدادات"),
        "shopping_cart": MessageLookupByLibrary.simpleMessage("سلة التسوق"),
        "should_be_a_valid_email": MessageLookupByLibrary.simpleMessage(
            "يجب أن يكون بريد إلكتروني صالح"),
        "should_be_a_valid_email_phone": MessageLookupByLibrary.simpleMessage(
            "Should be a valid email or phone number"),
        "should_be_more_than_3_characters":
            MessageLookupByLibrary.simpleMessage("يجب أن يكون أكثر من 3 أحرف"),
        "should_be_more_than_3_letters":
            MessageLookupByLibrary.simpleMessage("يجب أن يكون أكثر من 3 أحرف"),
        "should_be_more_than_6_letters":
            MessageLookupByLibrary.simpleMessage("يجب أن يكون أكثر من 6 أحرف"),
        "show_all": MessageLookupByLibrary.simpleMessage("Show All"),
        "skip": MessageLookupByLibrary.simpleMessage("تخطى"),
        "splash_subtext":
            MessageLookupByLibrary.simpleMessage("The Carmel delivery app"),
        "start_exploring": MessageLookupByLibrary.simpleMessage("استكشف الآن"),
        "submit": MessageLookupByLibrary.simpleMessage("ارسال"),
        "subtotal": MessageLookupByLibrary.simpleMessage("مجموع الطلب"),
        "tax": MessageLookupByLibrary.simpleMessage("ضريبة"),
        "tell_us_about_this_food":
            MessageLookupByLibrary.simpleMessage("Tell us about this food"),
        "terms_of_service_txt":
            MessageLookupByLibrary.simpleMessage("Terms Of Service"),
        "test": MessageLookupByLibrary.simpleMessage("test"),
        "the_address_updated_successfully":
            MessageLookupByLibrary.simpleMessage("تم تحديث العنوان بنجاح"),
        "the_food_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The food has been rated successfully"),
        "the_food_was_removed_from_your_cart": m6,
        "the_restaurant_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The restaurant has been rated successfully"),
        "top_restaurants": MessageLookupByLibrary.simpleMessage("أفضل المطابخ"),
        "total": MessageLookupByLibrary.simpleMessage("المجموع"),
        "total_extras": MessageLookupByLibrary.simpleMessage("Total Extras"),
        "tracking_order": MessageLookupByLibrary.simpleMessage("تتبع الطلب"),
        "tracking_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("تم تحديث قائمة التتبع بنجاح"),
        "trending_this_week":
            MessageLookupByLibrary.simpleMessage("الاعلى هذا الأسبوع"),
        "unknown": MessageLookupByLibrary.simpleMessage("Unknown"),
        "update_btn": MessageLookupByLibrary.simpleMessage("Update"),
        "user_already_exist": MessageLookupByLibrary.simpleMessage(
            "User already exists with phone number or email"),
        "verify": MessageLookupByLibrary.simpleMessage("التحقق"),
        "verify_your_internet_connection":
            MessageLookupByLibrary.simpleMessage("تحقق من الاتصال"),
        "verify_your_quantity_and_click_checkout":
            MessageLookupByLibrary.simpleMessage(
                "تحقق من الكمية واضغط على الدفع"),
        "version": MessageLookupByLibrary.simpleMessage("الإصدار"),
        "view": MessageLookupByLibrary.simpleMessage("View"),
        "web_page_title": MessageLookupByLibrary.simpleMessage(""),
        "welcome": MessageLookupByLibrary.simpleMessage("مرحبا"),
        "what_they_say":
            MessageLookupByLibrary.simpleMessage("ماذا يقول عملائنا ؟"),
        "whole_pizza": MessageLookupByLibrary.simpleMessage("Whole Pizza"),
        "wrong_email_or_password": MessageLookupByLibrary.simpleMessage(
            "بريد إلكتروني أو كلمة مرور خاطئة"),
        "yaadpay_payment":
            MessageLookupByLibrary.simpleMessage("YaadPay Payment"),
        "youDontHaveAnyOrder":
            MessageLookupByLibrary.simpleMessage("You do not  have any order"),
        "you_can_discover_restaurants": MessageLookupByLibrary.simpleMessage(
            "يمكنك استكتشاف المطابخ المحيطة بك واختيار أفضل وجبة لك"),
        "you_must_add_foods_of_the_same_restaurants_choose_one":
            MessageLookupByLibrary.simpleMessage(
                "فضلا اختيار الاصناف من مطبخ واحد في كل طلب"),
        "you_must_signin_to_access_to_this_section":
            MessageLookupByLibrary.simpleMessage(
                "يجب تسجيل الدخول لمشاهدة هذه الصفحة"),
        "your_address": MessageLookupByLibrary.simpleMessage("عنوانك"),
        "your_biography": MessageLookupByLibrary.simpleMessage("نبذة عنك"),
        "your_order_has_been_successfully_submitted":
            MessageLookupByLibrary.simpleMessage("تم تقديم طلبك بنجاح!"),
        "your_reset_link_has_been_sent_to_your_email":
            MessageLookupByLibrary.simpleMessage(
                "تم ارسال رابط استعادة كلمة المرور الى البريد الالكتروني الخاص بك")
      };
}
