// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static String m0(foodName) => "${foodName} נוסף להזמנה!";

  static String m1(currency, minOrderPrice) =>
      "Should be minimum order ${currency}${minOrderPrice}";

  static String m2(limitQty) => "You can only choose ${limitQty} times";

  static String m3(counter) => "${counter} open restaurants right now";

  static String m4(id) => "Order: #${id} has been canceled";

  static String m7(ccLast4Digit) =>
      "Are you want pay with saved ${ccLast4Digit} Credit Card?";

  static String m5(ccLast4Digit) =>
      "Are you want save this ${ccLast4Digit} Credit Card?";

  static String m6(foodname) => "The ${foodname} was removed from your cart";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "about": MessageLookupByLibrary.simpleMessage("About"),
        "add": MessageLookupByLibrary.simpleMessage("Add"),
        "addToOrder": MessageLookupByLibrary.simpleMessage("Add to order"),
        "add_delivery_address":
            MessageLookupByLibrary.simpleMessage("Add Delivery Address"),
        "add_new_delivery_address":
            MessageLookupByLibrary.simpleMessage("Add new delivery address"),
        "add_to_cart": MessageLookupByLibrary.simpleMessage("Add to Cart"),
        "add_to_cart_popup_message": m0,
        "added_to_cart":
            MessageLookupByLibrary.simpleMessage("האוכל נוסף בהצלחה!"),
        "address": MessageLookupByLibrary.simpleMessage("Address"),
        "addresses_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Addresses refreshed successfuly"),
        "agree_with_terms": MessageLookupByLibrary.simpleMessage(
            "Please indicate that you have read and agree to the Terms of Service"),
        "alert_location_service_btn":
            MessageLookupByLibrary.simpleMessage("Setting"),
        "alert_location_service_message": MessageLookupByLibrary.simpleMessage(
            "Please turn on location service."),
        "alert_location_service_permission_message":
            MessageLookupByLibrary.simpleMessage(
                "Please allow location service permission."),
        "alert_location_service_permission_title":
            MessageLookupByLibrary.simpleMessage(
                "Location Service Permission Denied"),
        "alert_location_service_title":
            MessageLookupByLibrary.simpleMessage("Location Service Disabled"),
        "alert_message_min_order": m1,
        "alert_message_save_address": MessageLookupByLibrary.simpleMessage(
            "Are you want save this current location address?"),
        "alert_no": MessageLookupByLibrary.simpleMessage("No"),
        "alert_ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "alert_title_login_fail":
            MessageLookupByLibrary.simpleMessage("Login Fail"),
        "alert_title_min_order":
            MessageLookupByLibrary.simpleMessage("Minimum Order"),
        "alert_title_save_address": MessageLookupByLibrary.simpleMessage(
            "Save Current Location Address"),
        "alert_update_app_version_message": MessageLookupByLibrary.simpleMessage(
            "The app is outdated , Please update it to the latest version."),
        "alert_update_app_version_title":
            MessageLookupByLibrary.simpleMessage("Update Required"),
        "alert_yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "all": MessageLookupByLibrary.simpleMessage("All"),
        "all_menu": MessageLookupByLibrary.simpleMessage("All Menu"),
        "all_restaurants":
            MessageLookupByLibrary.simpleMessage("All Restaurants"),
        "app_language": MessageLookupByLibrary.simpleMessage("App Language"),
        "app_settings": MessageLookupByLibrary.simpleMessage("App Settings"),
        "application_preferences":
            MessageLookupByLibrary.simpleMessage("Application Preferences"),
        "applied_coupon_code":
            MessageLookupByLibrary.simpleMessage("Applied Coupon Code"),
        "apply": MessageLookupByLibrary.simpleMessage("Apply"),
        "apply_filters": MessageLookupByLibrary.simpleMessage("Apply Filters"),
        "areYouSureYouWantToCancelThisOrder":
            MessageLookupByLibrary.simpleMessage(
                "Are you sure you want to cancel this order?"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "busy": MessageLookupByLibrary.simpleMessage("Busy"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
        "cancelOrder": MessageLookupByLibrary.simpleMessage("Cancel Order"),
        "canceled": MessageLookupByLibrary.simpleMessage("Canceled"),
        "card_number": MessageLookupByLibrary.simpleMessage("CARD NUMBER"),
        "cart": MessageLookupByLibrary.simpleMessage("Cart"),
        "carts_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Carts refreshed successfully"),
        "cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("Cash on delivery"),
        "cash_only": MessageLookupByLibrary.simpleMessage("Cash Only"),
        "category": MessageLookupByLibrary.simpleMessage("Category"),
        "category_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Category refreshed successfully"),
        "change_address":
            MessageLookupByLibrary.simpleMessage("Change Address"),
        "checkout": MessageLookupByLibrary.simpleMessage("Checkout"),
        "checkout_add_to_cart": MessageLookupByLibrary.simpleMessage("לקופה"),
        "clear": MessageLookupByLibrary.simpleMessage("Clear"),
        "click_here": MessageLookupByLibrary.simpleMessage("Click Here"),
        "click_on_the_stars_below_to_leave_comments":
            MessageLookupByLibrary.simpleMessage(
                "Click on the stars below to leave comments"),
        "click_to_confirm_your_address_and_pay_or_long_press":
            MessageLookupByLibrary.simpleMessage(
                "Click to confirm your address and pay or Long press to edit your address"),
        "click_to_pay_cash_on_delivery": MessageLookupByLibrary.simpleMessage(
            "Click to pay cash on delivery"),
        "click_to_pay_on_pickup":
            MessageLookupByLibrary.simpleMessage("Click to pay on pickup"),
        "click_to_pay_with_your_mastercard":
            MessageLookupByLibrary.simpleMessage(
                "Click to pay with your MasterCard"),
        "click_to_pay_with_your_paypal_account":
            MessageLookupByLibrary.simpleMessage(
                "Click to pay with your PayPal account"),
        "click_to_pay_with_your_visa_card":
            MessageLookupByLibrary.simpleMessage(
                "Click to pay with your Visa Card"),
        "close": MessageLookupByLibrary.simpleMessage("Close"),
        "closed": MessageLookupByLibrary.simpleMessage("Closed"),
        "closedForDeliveries":
            MessageLookupByLibrary.simpleMessage("Closed for deliveries"),
        "confirm_payment":
            MessageLookupByLibrary.simpleMessage("Confirm Payment"),
        "confirm_your_delivery_address": MessageLookupByLibrary.simpleMessage(
            "Confirm your delivery address"),
        "confirmation": MessageLookupByLibrary.simpleMessage("Confirmation"),
        "confirmpassword":
            MessageLookupByLibrary.simpleMessage("ConfirmPassword"),
        "continue_order": MessageLookupByLibrary.simpleMessage("המשך בהזמנה"),
        "coupon_code": MessageLookupByLibrary.simpleMessage("Coupon Code"),
        "cuisines": MessageLookupByLibrary.simpleMessage("Cuisines"),
        "current_location":
            MessageLookupByLibrary.simpleMessage("Current location"),
        "cvc": MessageLookupByLibrary.simpleMessage("CVC"),
        "cvv": MessageLookupByLibrary.simpleMessage("CVV"),
        "dark_mode": MessageLookupByLibrary.simpleMessage("Dark Mode"),
        "default_credit_card":
            MessageLookupByLibrary.simpleMessage("Default Credit Card"),
        "deliverable": MessageLookupByLibrary.simpleMessage("Deliverable"),
        "delivery": MessageLookupByLibrary.simpleMessage("Delivery"),
        "delivery_address":
            MessageLookupByLibrary.simpleMessage("Delivery Address"),
        "delivery_address_removed_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Delivery Address removed successfully"),
        "delivery_addresses":
            MessageLookupByLibrary.simpleMessage("Delivery Addresses"),
        "delivery_fee": MessageLookupByLibrary.simpleMessage("Delivery Fee"),
        "delivery_or_pickup":
            MessageLookupByLibrary.simpleMessage("Delivery or Pickup"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "details": MessageLookupByLibrary.simpleMessage("Details"),
        "discount": MessageLookupByLibrary.simpleMessage("Discount"),
        "discover__explorer":
            MessageLookupByLibrary.simpleMessage("Discover & Explorer"),
        "does_not_support_pickup": MessageLookupByLibrary.simpleMessage(
            "This restaurants does not support pickup"),
        "done": MessageLookupByLibrary.simpleMessage("Done"),
        "dont_have_any_item_in_the_notification_list":
            MessageLookupByLibrary.simpleMessage(
                "D\'ont have any item in the notification list"),
        "dont_have_any_item_in_your_cart": MessageLookupByLibrary.simpleMessage(
            "D\'ont have any item in your cart"),
        "double_click_on_the_food_to_add_it_to_the":
            MessageLookupByLibrary.simpleMessage(
                "Double click on the food to add it to the cart"),
        "edit": MessageLookupByLibrary.simpleMessage("Edit"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "emailOrPasswordIsNotValid":
            MessageLookupByLibrary.simpleMessage("אימייל או סיסמה אינם נכונים"),
        "email_address": MessageLookupByLibrary.simpleMessage("Email Address"),
        "email_already_exists":
            MessageLookupByLibrary.simpleMessage("Email already exists."),
        "email_phone": MessageLookupByLibrary.simpleMessage("Email or Phone"),
        "email_tab": MessageLookupByLibrary.simpleMessage("Email"),
        "email_to_reset_password":
            MessageLookupByLibrary.simpleMessage("Email to reset password"),
        "empty_data":
            MessageLookupByLibrary.simpleMessage("You have nothing here"),
        "english": MessageLookupByLibrary.simpleMessage("English"),
        "enter_email_or_phone": MessageLookupByLibrary.simpleMessage(
            "Please enter phone or email & password"),
        "enter_valid_otp":
            MessageLookupByLibrary.simpleMessage("Enter valid OTP"),
        "error_verify_email_settings": MessageLookupByLibrary.simpleMessage(
            "Error! Verify email settings"),
        "exp_date": MessageLookupByLibrary.simpleMessage("Exp Date"),
        "expiry_date": MessageLookupByLibrary.simpleMessage("EXPIRY DATE"),
        "extras": MessageLookupByLibrary.simpleMessage("Extras"),
        "faq": MessageLookupByLibrary.simpleMessage("Faq"),
        "favorite_foods":
            MessageLookupByLibrary.simpleMessage("Favorite Foods"),
        "favorites": MessageLookupByLibrary.simpleMessage("Favorites"),
        "favorites_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Favorites refreshed successfuly"),
        "featured_foods":
            MessageLookupByLibrary.simpleMessage("Featured Foods"),
        "fields": MessageLookupByLibrary.simpleMessage("Fields"),
        "filter": MessageLookupByLibrary.simpleMessage("Filter"),
        "finish_order": MessageLookupByLibrary.simpleMessage("Finish Order"),
        "food_categories":
            MessageLookupByLibrary.simpleMessage("Food Categories"),
        "food_refresh_message":
            MessageLookupByLibrary.simpleMessage("Food refreshed successfully"),
        "foods_result": MessageLookupByLibrary.simpleMessage("Foods result"),
        "foods_results": MessageLookupByLibrary.simpleMessage("Foods Results"),
        "full_address": MessageLookupByLibrary.simpleMessage("Full Address"),
        "full_name": MessageLookupByLibrary.simpleMessage("Full name"),
        "g": MessageLookupByLibrary.simpleMessage("g"),
        "go_to_offer": MessageLookupByLibrary.simpleMessage("GO TO OFFER"),
        "guest": MessageLookupByLibrary.simpleMessage("Guest"),
        "have_a_coupon":
            MessageLookupByLibrary.simpleMessage("Do you have a coupon code?"),
        "help__support": MessageLookupByLibrary.simpleMessage("Help & Support"),
        "help_support": MessageLookupByLibrary.simpleMessage("Help & Support"),
        "help_supports":
            MessageLookupByLibrary.simpleMessage("Help & Supports"),
        "hint_full_address": MessageLookupByLibrary.simpleMessage(
            "12 Street, City 21663, Country"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "home_address": MessageLookupByLibrary.simpleMessage("Home Address"),
        "how_would_you_rate_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "How would you rate this restaurant ?"),
        "how_would_you_rate_this_restaurant_":
            MessageLookupByLibrary.simpleMessage(
                "How would you rate this restaurant ?"),
        "i_agree_txt": MessageLookupByLibrary.simpleMessage("I agree to the"),
        "i_dont_have_an_account":
            MessageLookupByLibrary.simpleMessage("I don\'t have an account?"),
        "i_forgot_password":
            MessageLookupByLibrary.simpleMessage("I forgot password ?"),
        "i_have_account_back_to_login": MessageLookupByLibrary.simpleMessage(
            "I have account? Back to login"),
        "i_remember_my_password_return_to_login":
            MessageLookupByLibrary.simpleMessage(
                "I remember my password return to login"),
        "i_will_pay_in_store":
            MessageLookupByLibrary.simpleMessage("I will pay in store"),
        "i_will_pay_with_credit_card":
            MessageLookupByLibrary.simpleMessage("I will pay with credit card"),
        "in_stock": MessageLookupByLibrary.simpleMessage("InStock"),
        "information": MessageLookupByLibrary.simpleMessage("Information"),
        "ingredients": MessageLookupByLibrary.simpleMessage("Ingredients"),
        "insert_here": MessageLookupByLibrary.simpleMessage("Insert here"),
        "items": MessageLookupByLibrary.simpleMessage("Items"),
        "john_doe": MessageLookupByLibrary.simpleMessage("John Doe"),
        "keep_your_old_meals_of_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Keep your old meals of this restaurant"),
        "km": MessageLookupByLibrary.simpleMessage("Km"),
        "languages": MessageLookupByLibrary.simpleMessage("Languages"),
        "left_pizza": MessageLookupByLibrary.simpleMessage("Left Pizza"),
        "lets_start_with_login":
            MessageLookupByLibrary.simpleMessage("Let\'s Start with Login!"),
        "lets_start_with_register":
            MessageLookupByLibrary.simpleMessage("Let\'s Start with register!"),
        "light_mode": MessageLookupByLibrary.simpleMessage("Light Mode"),
        "limit_qty_message": m2,
        "limited_quantity":
            MessageLookupByLibrary.simpleMessage("Limited quantity"),
        "location_permission":
            MessageLookupByLibrary.simpleMessage("Location Permission"),
        "location_permission_title":
            MessageLookupByLibrary.simpleMessage("Location Permission"),
        "log_out": MessageLookupByLibrary.simpleMessage("Log out"),
        "login": MessageLookupByLibrary.simpleMessage("Login"),
        "long_press_to_edit_item_swipe_item_to_delete_it":
            MessageLookupByLibrary.simpleMessage(
                "Long press to edit item, swipe item to delete it"),
        "longpress_on_the_food_to_add_suplements":
            MessageLookupByLibrary.simpleMessage(
                "Longpress on the food to add suplements"),
        "make_it_default":
            MessageLookupByLibrary.simpleMessage("Make it default"),
        "maps_explorer": MessageLookupByLibrary.simpleMessage("Maps Explorer"),
        "mastercard": MessageLookupByLibrary.simpleMessage("MasterCard"),
        "menu": MessageLookupByLibrary.simpleMessage("Menu"),
        "mi": MessageLookupByLibrary.simpleMessage("mi"),
        "min_order": MessageLookupByLibrary.simpleMessage("Minimum Order:"),
        "most_popular": MessageLookupByLibrary.simpleMessage("Most Popular"),
        "multirestaurants":
            MessageLookupByLibrary.simpleMessage("Multi-Restaurants"),
        "my_orders": MessageLookupByLibrary.simpleMessage("My Orders"),
        "near_to": MessageLookupByLibrary.simpleMessage("Near to"),
        "near_to_your_current_location": MessageLookupByLibrary.simpleMessage(
            "Near to your current location"),
        "new_address_added_successfully": MessageLookupByLibrary.simpleMessage(
            "New Address added successfully"),
        "new_order_from_client":
            MessageLookupByLibrary.simpleMessage("New order from client"),
        "next": MessageLookupByLibrary.simpleMessage("Next"),
        "none": MessageLookupByLibrary.simpleMessage("None"),
        "not_a_valid_address":
            MessageLookupByLibrary.simpleMessage("Not a valid address"),
        "not_a_valid_biography":
            MessageLookupByLibrary.simpleMessage("Not a valid biography"),
        "not_a_valid_cvc":
            MessageLookupByLibrary.simpleMessage("Not a valid CVC"),
        "not_a_valid_date":
            MessageLookupByLibrary.simpleMessage("Not a valid date"),
        "not_a_valid_email":
            MessageLookupByLibrary.simpleMessage("Not a valid email"),
        "not_a_valid_full_name":
            MessageLookupByLibrary.simpleMessage("Not a valid full name"),
        "not_a_valid_number":
            MessageLookupByLibrary.simpleMessage("Not a valid number"),
        "not_a_valid_phone":
            MessageLookupByLibrary.simpleMessage("Not a valid phone"),
        "not_deliverable":
            MessageLookupByLibrary.simpleMessage("Not Deliverable"),
        "not_deliverable_message": MessageLookupByLibrary.simpleMessage(
            "One or more of the foods are not deliverable"),
        "notifications": MessageLookupByLibrary.simpleMessage("Notifications"),
        "notifications_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Notifications refreshed successfully"),
        "number": MessageLookupByLibrary.simpleMessage("Number"),
        "nutrition": MessageLookupByLibrary.simpleMessage("Nutrition"),
        "one_time_password":
            MessageLookupByLibrary.simpleMessage("One Time Password"),
        "open": MessageLookupByLibrary.simpleMessage("Open"),
        "openForDeliveries":
            MessageLookupByLibrary.simpleMessage("Open for deliveries"),
        "open_restaurants_right_now": m3,
        "opened_restaurants":
            MessageLookupByLibrary.simpleMessage("Opened Restaurants"),
        "or": MessageLookupByLibrary.simpleMessage("--OR--"),
        "or_checkout_with":
            MessageLookupByLibrary.simpleMessage("Or Checkout With"),
        "orderDetails": MessageLookupByLibrary.simpleMessage("Order Details"),
        "orderThisorderidHasBeenCanceled": m4,
        "order_id": MessageLookupByLibrary.simpleMessage("Order Id"),
        "order_note": MessageLookupByLibrary.simpleMessage("Order Note"),
        "order_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Order refreshed successfully"),
        "order_status_changed":
            MessageLookupByLibrary.simpleMessage("Order status changed"),
        "ordered_by_nearby_first":
            MessageLookupByLibrary.simpleMessage("Ordered by Nearby first"),
        "orders_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Orders refreshed successfully"),
        "otp": MessageLookupByLibrary.simpleMessage("OTP"),
        "otp_tab": MessageLookupByLibrary.simpleMessage("OTP"),
        "out_of_stock": MessageLookupByLibrary.simpleMessage("Out of Stock"),
        "out_of_town_area_title":
            MessageLookupByLibrary.simpleMessage("Out Of Town Area"),
        "password": MessageLookupByLibrary.simpleMessage("Password"),
        "pay_alert_message": m7,
        "pay_alert_title": MessageLookupByLibrary.simpleMessage("Pay"),
        "pay_on_pickup": MessageLookupByLibrary.simpleMessage("Pay on Pickup"),
        "payment_card_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Payment card updated successfully"),
        "payment_mode": MessageLookupByLibrary.simpleMessage("Payment Mode"),
        "payment_option_message": MessageLookupByLibrary.simpleMessage(
            "Please select order payment option"),
        "payment_options":
            MessageLookupByLibrary.simpleMessage("Payment Options"),
        "payment_settings":
            MessageLookupByLibrary.simpleMessage("Payment Settings"),
        "payment_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Payment settings updated successfully"),
        "payments_settings":
            MessageLookupByLibrary.simpleMessage("Payments Settings"),
        "paypal": MessageLookupByLibrary.simpleMessage("PayPal"),
        "paypal_payment":
            MessageLookupByLibrary.simpleMessage("PayPal Payment"),
        "phone": MessageLookupByLibrary.simpleMessage("Phone"),
        "phone_already_exists": MessageLookupByLibrary.simpleMessage(
            "Phone number already exists."),
        "phone_not_registered": MessageLookupByLibrary.simpleMessage(
            "This phone is not registered"),
        "pickup": MessageLookupByLibrary.simpleMessage("Pickup"),
        "pickupCreditCard":
            MessageLookupByLibrary.simpleMessage("Pickup - credit card"),
        "pickup_btn": MessageLookupByLibrary.simpleMessage("Pickup"),
        "pickup_your_food_from_the_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Pickup your food from the restaurant"),
        "pizza_type": MessageLookupByLibrary.simpleMessage("PizzaType"),
        "pleaseSelectAtleastOneItemFrom": MessageLookupByLibrary.simpleMessage(
            "Please select atleast one item from "),
        "profile": MessageLookupByLibrary.simpleMessage("Profile"),
        "profile_settings":
            MessageLookupByLibrary.simpleMessage("Profile Settings"),
        "profile_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Profile settings updated successfully"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantity"),
        "re_order": MessageLookupByLibrary.simpleMessage("ReOrder"),
        "recent_orders": MessageLookupByLibrary.simpleMessage("Recent Orders"),
        "recent_reviews":
            MessageLookupByLibrary.simpleMessage("Recent Reviews"),
        "recents_search":
            MessageLookupByLibrary.simpleMessage("Recents Search"),
        "register": MessageLookupByLibrary.simpleMessage("Register"),
        "register_email_description": MessageLookupByLibrary.simpleMessage(
            "We will send invoices to this email"),
        "register_number_description":
            MessageLookupByLibrary.simpleMessage("please enter number"),
        "register_password_description": MessageLookupByLibrary.simpleMessage(
            "Please choose a strong password"),
        "register_username_description":
            MessageLookupByLibrary.simpleMessage("please enter username"),
        "request_failed":
            MessageLookupByLibrary.simpleMessage("Request failed"),
        "res_categories_title":
            MessageLookupByLibrary.simpleMessage("Restaurants Categories"),
        "reset": MessageLookupByLibrary.simpleMessage("Reset"),
        "reset_cart": MessageLookupByLibrary.simpleMessage("Reset Cart?"),
        "reset_your_cart_and_order_meals_form_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Reset your cart and order meals form this restaurant"),
        "restaurant_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Restaurant refreshed successfully"),
        "restaurants_near_to":
            MessageLookupByLibrary.simpleMessage("Restaurants near to"),
        "restaurants_near_to_your_current_location":
            MessageLookupByLibrary.simpleMessage(
                "Restaurants near to your current location"),
        "restaurants_results":
            MessageLookupByLibrary.simpleMessage("Restaurants Results"),
        "retry": MessageLookupByLibrary.simpleMessage("נסה שוב"),
        "reviews": MessageLookupByLibrary.simpleMessage("Reviews"),
        "reviews_refreshed_successfully": MessageLookupByLibrary.simpleMessage(
            "Reviews refreshed successfully!"),
        "right_pizza": MessageLookupByLibrary.simpleMessage("Right Pizza"),
        "sale": MessageLookupByLibrary.simpleMessage("Sale!"),
        "save": MessageLookupByLibrary.simpleMessage("Save"),
        "saving_card_alert_message": m5,
        "saving_card_alert_title":
            MessageLookupByLibrary.simpleMessage("Save CreditCard"),
        "search": MessageLookupByLibrary.simpleMessage("Search"),
        "search_for_restaurants_or_foods": MessageLookupByLibrary.simpleMessage(
            "Search for restaurants or foods"),
        "search_items": MessageLookupByLibrary.simpleMessage("Search Items"),
        "search_place": MessageLookupByLibrary.simpleMessage("Search Place"),
        "see_menu": MessageLookupByLibrary.simpleMessage("See Menu"),
        "select_all": MessageLookupByLibrary.simpleMessage("Select all"),
        "select_extras_to_add_them_on_the_food":
            MessageLookupByLibrary.simpleMessage(
                "Select extras to add them on the food"),
        "select_terms_of_service_txt": MessageLookupByLibrary.simpleMessage(
            "Please follow Terms Of Service"),
        "select_your_preferred_languages": MessageLookupByLibrary.simpleMessage(
            "Select your preferred languages"),
        "select_your_preferred_payment_mode":
            MessageLookupByLibrary.simpleMessage(
                "Select your preferred payment mode"),
        "send_password_reset_link":
            MessageLookupByLibrary.simpleMessage("Send link"),
        "settings": MessageLookupByLibrary.simpleMessage("Settings"),
        "shopping": MessageLookupByLibrary.simpleMessage("Shopping"),
        "shopping_cart": MessageLookupByLibrary.simpleMessage("Shopping Cart"),
        "should_be_a_valid_email":
            MessageLookupByLibrary.simpleMessage("Should be a valid email"),
        "should_be_a_valid_email_phone": MessageLookupByLibrary.simpleMessage(
            "Should be a valid email or phone number"),
        "should_be_more_than_3_characters":
            MessageLookupByLibrary.simpleMessage(
                "Should be more than 3 characters"),
        "should_be_more_than_3_letters": MessageLookupByLibrary.simpleMessage(
            "Should be more than 3 letters"),
        "should_be_more_than_6_letters": MessageLookupByLibrary.simpleMessage(
            "Should be more than 6 letters"),
        "show_all": MessageLookupByLibrary.simpleMessage("Show All"),
        "skip": MessageLookupByLibrary.simpleMessage("Skip"),
        "splash_subtext":
            MessageLookupByLibrary.simpleMessage("The Carmel delivery app"),
        "start_exploring":
            MessageLookupByLibrary.simpleMessage("Start Exploring"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "subtotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "tax": MessageLookupByLibrary.simpleMessage("TAX"),
        "tell_us_about_this_food":
            MessageLookupByLibrary.simpleMessage("Tell us about this food"),
        "tell_us_about_this_restaurant": MessageLookupByLibrary.simpleMessage(
            "Tell us about this restaurant"),
        "terms_of_service_txt":
            MessageLookupByLibrary.simpleMessage("Terms Of Service"),
        "test": MessageLookupByLibrary.simpleMessage("test"),
        "the_address_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The address updated successfully"),
        "the_food_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The food has been rated successfully"),
        "the_food_was_removed_from_your_cart": m6,
        "the_restaurant_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The restaurant has been rated successfully"),
        "this_account_not_exist":
            MessageLookupByLibrary.simpleMessage("This account not exist"),
        "this_email_account_exists":
            MessageLookupByLibrary.simpleMessage("This email account exists"),
        "this_food_was_added_to_cart":
            MessageLookupByLibrary.simpleMessage("This food was added to cart"),
        "this_restaurant_is_closed_":
            MessageLookupByLibrary.simpleMessage("This restaurant is closed !"),
        "top_restaurants":
            MessageLookupByLibrary.simpleMessage("Top Restaurants"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "total_extras": MessageLookupByLibrary.simpleMessage("Total Extras"),
        "tracking_order":
            MessageLookupByLibrary.simpleMessage("Tracking Order"),
        "tracking_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Tracking refreshed successfully"),
        "trending_this_week":
            MessageLookupByLibrary.simpleMessage("Trending This Week"),
        "unknown": MessageLookupByLibrary.simpleMessage("Unknown"),
        "update_btn": MessageLookupByLibrary.simpleMessage("Update"),
        "user_already_exist": MessageLookupByLibrary.simpleMessage(
            "User already exists with phone number or email"),
        "verify": MessageLookupByLibrary.simpleMessage("Verify"),
        "verify_your_internet_connection": MessageLookupByLibrary.simpleMessage(
            "Verify your internet connection"),
        "verify_your_quantity_and_click_checkout":
            MessageLookupByLibrary.simpleMessage(
                "Verify your quantity and click checkout"),
        "version": MessageLookupByLibrary.simpleMessage("Version"),
        "view": MessageLookupByLibrary.simpleMessage("View"),
        "visa_card": MessageLookupByLibrary.simpleMessage("Visa Card"),
        "web_page_title": MessageLookupByLibrary.simpleMessage(""),
        "welcome": MessageLookupByLibrary.simpleMessage("Welcome"),
        "what_they_say":
            MessageLookupByLibrary.simpleMessage("What They Say ?"),
        "whole_pizza": MessageLookupByLibrary.simpleMessage("Whole Pizza"),
        "wrong_email_or_password":
            MessageLookupByLibrary.simpleMessage("Wrong email or password"),
        "yaadpay_payment":
            MessageLookupByLibrary.simpleMessage("YaadPay Payment"),
        "youDontHaveAnyOrder":
            MessageLookupByLibrary.simpleMessage("You do not  have any order"),
        "you_can_discover_restaurants": MessageLookupByLibrary.simpleMessage(
            "You can discover restaurants & fastfood arround you and choose you best meal after few minutes we prepare and delivere it for you"),
        "you_must_add_foods_of_the_same_restaurants_choose_one":
            MessageLookupByLibrary.simpleMessage(
                "You must add foods of the same restaurants choose one restaurants only!"),
        "you_must_signin_to_access_to_this_section":
            MessageLookupByLibrary.simpleMessage(
                "You must sign-in to access to this section"),
        "your_address": MessageLookupByLibrary.simpleMessage("Your Address"),
        "your_biography":
            MessageLookupByLibrary.simpleMessage("Your biography"),
        "your_credit_card_not_valid":
            MessageLookupByLibrary.simpleMessage("Your credit card not valid"),
        "your_order_has_been_successfully_submitted":
            MessageLookupByLibrary.simpleMessage(
                "Your order has been successfully submitted!"),
        "your_reset_link_has_been_sent_to_your_email":
            MessageLookupByLibrary.simpleMessage(
                "Your reset link has been sent to your email")
      };
}
