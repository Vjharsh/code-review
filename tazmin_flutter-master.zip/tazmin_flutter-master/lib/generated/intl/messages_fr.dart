// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a fr locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fr';

  static String m1(currency, minOrderPrice) =>
      "Should be minimum order ${currency}${minOrderPrice}";

  static String m5(ccLast4Digit) =>
      "Are you want save this ${ccLast4Digit} Credit Card?";

  static String m6(foodname) => "Le ${foodname} a été retiré de votre panier";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "about": MessageLookupByLibrary.simpleMessage("Sur"),
        "add": MessageLookupByLibrary.simpleMessage("Add"),
        "add_delivery_address":
            MessageLookupByLibrary.simpleMessage("Add Delivery Address"),
        "add_to_cart":
            MessageLookupByLibrary.simpleMessage("Ajouter au panier"),
        "address": MessageLookupByLibrary.simpleMessage("Adresse"),
        "addresses_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Addresses refreshed successfuly"),
        "agree_with_terms": MessageLookupByLibrary.simpleMessage(
            "Please indicate that you have read and agree to the Terms of Service"),
        "alert_location_service_btn":
            MessageLookupByLibrary.simpleMessage("Setting"),
        "alert_location_service_message": MessageLookupByLibrary.simpleMessage(
            "Please turn on location service."),
        "alert_location_service_permission_message":
            MessageLookupByLibrary.simpleMessage(
                "Please allow location service permission."),
        "alert_location_service_permission_title":
            MessageLookupByLibrary.simpleMessage(
                "Location Service Permission Denied"),
        "alert_location_service_title":
            MessageLookupByLibrary.simpleMessage("Location Service Disabled"),
        "alert_message_min_order": m1,
        "alert_message_save_address": MessageLookupByLibrary.simpleMessage(
            "Are you want save this current location address?"),
        "alert_no": MessageLookupByLibrary.simpleMessage("No"),
        "alert_ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "alert_title_login_fail":
            MessageLookupByLibrary.simpleMessage("Login Fail"),
        "alert_title_min_order":
            MessageLookupByLibrary.simpleMessage("Minimum Order"),
        "alert_title_save_address": MessageLookupByLibrary.simpleMessage(
            "Save Current Location Address"),
        "alert_update_app_version_message": MessageLookupByLibrary.simpleMessage(
            "The app is outdated , Please update it to the latest version."),
        "alert_update_app_version_title":
            MessageLookupByLibrary.simpleMessage("Update Required"),
        "alert_yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "all_menu": MessageLookupByLibrary.simpleMessage("Tous les menus"),
        "app_language":
            MessageLookupByLibrary.simpleMessage("Langue de l\'application"),
        "app_settings": MessageLookupByLibrary.simpleMessage(
            "Paramètres de l\'application"),
        "application_preferences": MessageLookupByLibrary.simpleMessage(
            "Préférences de l\'application"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "cancel": MessageLookupByLibrary.simpleMessage("Annuler"),
        "cart": MessageLookupByLibrary.simpleMessage("Chariot"),
        "carts_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Paniers rafraîchis avec succès"),
        "cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("Paiement à la livraison"),
        "category": MessageLookupByLibrary.simpleMessage("Catégorie"),
        "category_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Catégorie actualisée avec succès"),
        "checkout": MessageLookupByLibrary.simpleMessage("Check-out"),
        "click_on_the_stars_below_to_leave_comments":
            MessageLookupByLibrary.simpleMessage(
                "Click on the stars below to leave comments"),
        "close": MessageLookupByLibrary.simpleMessage("proche"),
        "confirm_payment":
            MessageLookupByLibrary.simpleMessage("Confirmer le paiement"),
        "confirmation": MessageLookupByLibrary.simpleMessage("Confirmation"),
        "cuisines": MessageLookupByLibrary.simpleMessage("Cuisines"),
        "dark_mode": MessageLookupByLibrary.simpleMessage("Mode sombre"),
        "default_credit_card":
            MessageLookupByLibrary.simpleMessage("Carte de crédit par défaut"),
        "delivery_addresses":
            MessageLookupByLibrary.simpleMessage("Delivery Addresses"),
        "delivery_fee": MessageLookupByLibrary.simpleMessage("Delivery Fee"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "discover__explorer":
            MessageLookupByLibrary.simpleMessage("Découvrir et explorer"),
        "dont_have_any_item_in_the_notification_list":
            MessageLookupByLibrary.simpleMessage(
                "N\'a aucun article dans la liste de notification"),
        "dont_have_any_item_in_your_cart": MessageLookupByLibrary.simpleMessage(
            "N\'a aucun article dans votre panier"),
        "double_click_on_the_food_to_add_it_to_the":
            MessageLookupByLibrary.simpleMessage(
                "Double-cliquez sur la nourriture pour l\'ajouter au panier."),
        "edit": MessageLookupByLibrary.simpleMessage("modifier"),
        "email": MessageLookupByLibrary.simpleMessage("Email"),
        "email_address": MessageLookupByLibrary.simpleMessage("Adresse e-mail"),
        "email_phone": MessageLookupByLibrary.simpleMessage("Email or Phone"),
        "email_to_reset_password":
            MessageLookupByLibrary.simpleMessage("Email to reset password"),
        "empty_data":
            MessageLookupByLibrary.simpleMessage("You have nothing here"),
        "english": MessageLookupByLibrary.simpleMessage("Anglais"),
        "enter_email_or_phone": MessageLookupByLibrary.simpleMessage(
            "Please enter phone or email & password"),
        "enter_valid_otp":
            MessageLookupByLibrary.simpleMessage("Enter valid OTP"),
        "error_verify_email_settings": MessageLookupByLibrary.simpleMessage(
            "Error! Verify email settings"),
        "extras": MessageLookupByLibrary.simpleMessage("Extras"),
        "faq": MessageLookupByLibrary.simpleMessage("FAQ"),
        "favorite_foods":
            MessageLookupByLibrary.simpleMessage("Aliments préférés"),
        "favorites": MessageLookupByLibrary.simpleMessage("Favoris"),
        "favorites_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Favorites refreshed successfuly"),
        "featured_foods":
            MessageLookupByLibrary.simpleMessage("Aliments en vedette"),
        "food_categories":
            MessageLookupByLibrary.simpleMessage("Catégories d\'aliments"),
        "full_address": MessageLookupByLibrary.simpleMessage("Full Address"),
        "full_name": MessageLookupByLibrary.simpleMessage("Nom complet"),
        "g": MessageLookupByLibrary.simpleMessage("g"),
        "go_to_offer": MessageLookupByLibrary.simpleMessage("GO TO OFFER"),
        "guest": MessageLookupByLibrary.simpleMessage("Guest"),
        "help__support":
            MessageLookupByLibrary.simpleMessage("Support d\'aide"),
        "help_support": MessageLookupByLibrary.simpleMessage("Support d\'aide"),
        "help_supports":
            MessageLookupByLibrary.simpleMessage("Aide et soutien"),
        "hint_full_address": MessageLookupByLibrary.simpleMessage(
            "12 Street, City 21663, Country"),
        "home": MessageLookupByLibrary.simpleMessage("Accueil"),
        "home_address": MessageLookupByLibrary.simpleMessage("Home Address"),
        "how_would_you_rate_this_restaurant_":
            MessageLookupByLibrary.simpleMessage(
                "How would you rate this restaurant ?"),
        "i_agree_txt": MessageLookupByLibrary.simpleMessage("I agree to the"),
        "i_dont_have_an_account":
            MessageLookupByLibrary.simpleMessage("Je n\'ai pas de compte?"),
        "i_forgot_password": MessageLookupByLibrary.simpleMessage(
            "J\'ai oublié mon mot de passe?"),
        "i_have_account_back_to_login": MessageLookupByLibrary.simpleMessage(
            "J\'ai un compte? Retour connexion"),
        "i_remember_my_password_return_to_login":
            MessageLookupByLibrary.simpleMessage(
                "I remember my password return to login"),
        "information": MessageLookupByLibrary.simpleMessage("Information"),
        "ingredients": MessageLookupByLibrary.simpleMessage("Ingrédients"),
        "john_doe": MessageLookupByLibrary.simpleMessage("John Doe"),
        "keep_your_old_meals_of_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Gardez vos anciens repas de ce restaurant"),
        "languages": MessageLookupByLibrary.simpleMessage("Les langues"),
        "lets_start_with_login":
            MessageLookupByLibrary.simpleMessage("Commençons avec Login!"),
        "lets_start_with_register": MessageLookupByLibrary.simpleMessage(
            "Commençons par vous inscrire!"),
        "light_mode": MessageLookupByLibrary.simpleMessage("Mode lumière"),
        "log_out": MessageLookupByLibrary.simpleMessage("Connectez - Out"),
        "login": MessageLookupByLibrary.simpleMessage("S\'identifier"),
        "long_press_to_edit_item_swipe_item_to_delete_it":
            MessageLookupByLibrary.simpleMessage(
                "Long press to edit item, swipe item to delete it"),
        "longpress_on_the_food_to_add_suplements":
            MessageLookupByLibrary.simpleMessage(
                "Appuyez longuement sur la nourriture pour ajouter des suppléments"),
        "maps_explorer":
            MessageLookupByLibrary.simpleMessage("Explorateur de cartes"),
        "menu": MessageLookupByLibrary.simpleMessage("Menu"),
        "min_order": MessageLookupByLibrary.simpleMessage("Minimum Order:"),
        "most_popular":
            MessageLookupByLibrary.simpleMessage("Le plus populaire"),
        "multirestaurants":
            MessageLookupByLibrary.simpleMessage("Multi-Restaurants"),
        "my_orders": MessageLookupByLibrary.simpleMessage("Mes commandes"),
        "new_address_added_successfully": MessageLookupByLibrary.simpleMessage(
            "New Address added successfully"),
        "new_order_from_client":
            MessageLookupByLibrary.simpleMessage("New order from client"),
        "not_a_valid_address":
            MessageLookupByLibrary.simpleMessage("Adresse non valide"),
        "not_a_valid_biography":
            MessageLookupByLibrary.simpleMessage("Biographie non valide"),
        "not_a_valid_cvc":
            MessageLookupByLibrary.simpleMessage("CVC non valide"),
        "not_a_valid_date":
            MessageLookupByLibrary.simpleMessage("Date non valide"),
        "not_a_valid_email":
            MessageLookupByLibrary.simpleMessage("Email non valide"),
        "not_a_valid_full_name":
            MessageLookupByLibrary.simpleMessage("Nom complet non valide"),
        "not_a_valid_number":
            MessageLookupByLibrary.simpleMessage("Pas un numéro valide"),
        "not_a_valid_phone":
            MessageLookupByLibrary.simpleMessage("Pas un téléphone valide"),
        "notifications":
            MessageLookupByLibrary.simpleMessage("Les notifications"),
        "notifications_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Notifications actualisées avec succès"),
        "nutrition": MessageLookupByLibrary.simpleMessage("Nutrition"),
        "one_time_password":
            MessageLookupByLibrary.simpleMessage("One Time Password"),
        "or_checkout_with":
            MessageLookupByLibrary.simpleMessage("Ou commander avec"),
        "order_id": MessageLookupByLibrary.simpleMessage("Numéro de commande"),
        "order_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Commande rafraîchie avec succès"),
        "order_status_changed":
            MessageLookupByLibrary.simpleMessage("Order status changed"),
        "ordered_by_nearby_first": MessageLookupByLibrary.simpleMessage(
            "Commandé par proximité en premier"),
        "orders_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Commandes actualisées avec succès"),
        "otp": MessageLookupByLibrary.simpleMessage("OTP"),
        "password": MessageLookupByLibrary.simpleMessage("Mot de passe"),
        "pay_alert_title": MessageLookupByLibrary.simpleMessage("Pay"),
        "payment_mode":
            MessageLookupByLibrary.simpleMessage("Mode de paiement"),
        "payment_options":
            MessageLookupByLibrary.simpleMessage("Options de paiement"),
        "payment_settings":
            MessageLookupByLibrary.simpleMessage("Paramètres de paiement"),
        "payment_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Paramètres de paiement mis à jour avec succès"),
        "payments_settings":
            MessageLookupByLibrary.simpleMessage("Paramètres de paiement"),
        "paypal_payment":
            MessageLookupByLibrary.simpleMessage("Paiement PayPal"),
        "phone": MessageLookupByLibrary.simpleMessage("Téléphone"),
        "phone_not_registered": MessageLookupByLibrary.simpleMessage(
            "This phone is not registered"),
        "pickupCreditCard":
            MessageLookupByLibrary.simpleMessage("Pickup - credit card"),
        "profile": MessageLookupByLibrary.simpleMessage("Profil"),
        "profile_settings":
            MessageLookupByLibrary.simpleMessage("Paramètres de profil"),
        "profile_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Paramètres de profil mis à jour avec succès"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantité"),
        "recent_orders":
            MessageLookupByLibrary.simpleMessage("Dernières commandes"),
        "recent_reviews": MessageLookupByLibrary.simpleMessage("Avis récents"),
        "recents_search":
            MessageLookupByLibrary.simpleMessage("Recherche récente"),
        "register": MessageLookupByLibrary.simpleMessage("registre"),
        "request_failed":
            MessageLookupByLibrary.simpleMessage("Request failed"),
        "res_categories_title":
            MessageLookupByLibrary.simpleMessage("Restaurants Categories"),
        "reset": MessageLookupByLibrary.simpleMessage("Réinitialiser"),
        "reset_cart":
            MessageLookupByLibrary.simpleMessage("Réinitialiser le panier?"),
        "reset_your_cart_and_order_meals_form_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Réinitialiser votre panier et commander des repas dans ce restaurant"),
        "restaurant_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Restaurant rafraîchi avec succès"),
        "reviews": MessageLookupByLibrary.simpleMessage("Avis"),
        "reviews_refreshed_successfully": MessageLookupByLibrary.simpleMessage(
            "Reviews refreshed successfully!"),
        "save": MessageLookupByLibrary.simpleMessage("sauver"),
        "saving_card_alert_message": m5,
        "saving_card_alert_title":
            MessageLookupByLibrary.simpleMessage("Save CreditCard"),
        "search": MessageLookupByLibrary.simpleMessage("Chercher"),
        "search_for_restaurants_or_foods": MessageLookupByLibrary.simpleMessage(
            "Rechercher des restaurants ou des aliments"),
        "search_items": MessageLookupByLibrary.simpleMessage("Search Items"),
        "select_extras_to_add_them_on_the_food":
            MessageLookupByLibrary.simpleMessage(
                "Sélectionnez des extras pour les ajouter à la nourriture"),
        "select_terms_of_service_txt": MessageLookupByLibrary.simpleMessage(
            "Please follow Terms Of Service"),
        "select_your_preferred_languages": MessageLookupByLibrary.simpleMessage(
            "Sélectionnez vos langues préférées"),
        "select_your_preferred_payment_mode":
            MessageLookupByLibrary.simpleMessage(
                "Sélectionnez votre mode de paiement préféré"),
        "send_password_reset_link":
            MessageLookupByLibrary.simpleMessage("Send password reset link"),
        "settings": MessageLookupByLibrary.simpleMessage("Paramètres"),
        "shopping_cart": MessageLookupByLibrary.simpleMessage("Chariot"),
        "should_be_a_valid_email": MessageLookupByLibrary.simpleMessage(
            "Devrait être un email valide"),
        "should_be_a_valid_email_phone": MessageLookupByLibrary.simpleMessage(
            "Should be a valid email or phone number"),
        "should_be_more_than_3_characters":
            MessageLookupByLibrary.simpleMessage(
                "Devrait être plus de 3 caractères"),
        "should_be_more_than_3_letters": MessageLookupByLibrary.simpleMessage(
            "Devrait être plus de 3 lettres"),
        "should_be_more_than_6_letters": MessageLookupByLibrary.simpleMessage(
            "Devrait être plus de 6 lettres"),
        "skip": MessageLookupByLibrary.simpleMessage("Sauter"),
        "start_exploring":
            MessageLookupByLibrary.simpleMessage("Commencez à explorer"),
        "submit": MessageLookupByLibrary.simpleMessage("Soumettre"),
        "subtotal": MessageLookupByLibrary.simpleMessage("Total"),
        "tax": MessageLookupByLibrary.simpleMessage("IMPÔT"),
        "tell_us_about_this_food":
            MessageLookupByLibrary.simpleMessage("Tell us about this food"),
        "terms_of_service_txt":
            MessageLookupByLibrary.simpleMessage("Terms Of Service"),
        "the_address_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The address updated successfully"),
        "the_food_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The food has been rated successfully"),
        "the_food_was_removed_from_your_cart": m6,
        "the_restaurant_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The restaurant has been rated successfully"),
        "top_restaurants":
            MessageLookupByLibrary.simpleMessage("Meilleurs restaurants"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "tracking_order":
            MessageLookupByLibrary.simpleMessage("Suivi de commande"),
        "tracking_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("Suivi actualisé avec succès"),
        "trending_this_week":
            MessageLookupByLibrary.simpleMessage("Tendances cette semaine"),
        "unknown": MessageLookupByLibrary.simpleMessage("Unknown"),
        "update_btn": MessageLookupByLibrary.simpleMessage("Update"),
        "user_already_exist": MessageLookupByLibrary.simpleMessage(
            "User already exists with phone number or email"),
        "verify": MessageLookupByLibrary.simpleMessage("Vérifier"),
        "verify_your_internet_connection": MessageLookupByLibrary.simpleMessage(
            "Vérifiez votre connexion internet"),
        "verify_your_quantity_and_click_checkout":
            MessageLookupByLibrary.simpleMessage(
                "Vérifiez votre quantité et cliquez sur Valider"),
        "version": MessageLookupByLibrary.simpleMessage("Version"),
        "web_page_title": MessageLookupByLibrary.simpleMessage(""),
        "welcome": MessageLookupByLibrary.simpleMessage("Bienvenue"),
        "what_they_say":
            MessageLookupByLibrary.simpleMessage("Ce qu\'ils disent ?"),
        "wrong_email_or_password": MessageLookupByLibrary.simpleMessage(
            "Mauvais email ou mot de passe"),
        "yaadpay_payment":
            MessageLookupByLibrary.simpleMessage("YaadPay Payment"),
        "you_can_discover_restaurants": MessageLookupByLibrary.simpleMessage(
            "Vous pouvez découvrir les restaurants et les fastfoods autour de vous et choisir votre meilleur repas après quelques minutes, nous le préparons et vous le livrons"),
        "you_must_add_foods_of_the_same_restaurants_choose_one":
            MessageLookupByLibrary.simpleMessage(
                "Vous devez ajouter des aliments des mêmes restaurants, choisissez un seul restaurant!"),
        "you_must_signin_to_access_to_this_section":
            MessageLookupByLibrary.simpleMessage(
                "You must sign-in to access to this section"),
        "your_address": MessageLookupByLibrary.simpleMessage("Votre adresse"),
        "your_biography":
            MessageLookupByLibrary.simpleMessage("Votre biographie"),
        "your_order_has_been_successfully_submitted":
            MessageLookupByLibrary.simpleMessage(
                "Votre commande a été soumise avec succès!"),
        "your_reset_link_has_been_sent_to_your_email":
            MessageLookupByLibrary.simpleMessage(
                "Your reset link has been sent to your email")
      };
}
