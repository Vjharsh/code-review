// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a pt locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'pt';

  static String m1(currency, minOrderPrice) =>
      "Should be minimum order ${currency}${minOrderPrice}";

  static String m5(ccLast4Digit) =>
      "Are you want save this ${ccLast4Digit} Credit Card?";

  static String m6(foodname) => "O ${foodname} foi removido do seu carrinho";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "about": MessageLookupByLibrary.simpleMessage("Sobre"),
        "add": MessageLookupByLibrary.simpleMessage("Add"),
        "add_delivery_address":
            MessageLookupByLibrary.simpleMessage("Add Delivery Address"),
        "add_to_cart":
            MessageLookupByLibrary.simpleMessage("Adicionar ao carrinho"),
        "address": MessageLookupByLibrary.simpleMessage("Endereço"),
        "addresses_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Addresses refreshed successfuly"),
        "agree_with_terms": MessageLookupByLibrary.simpleMessage(
            "Please indicate that you have read and agree to the Terms of Service"),
        "alert_location_service_btn":
            MessageLookupByLibrary.simpleMessage("Setting"),
        "alert_location_service_message": MessageLookupByLibrary.simpleMessage(
            "Please turn on location service."),
        "alert_location_service_permission_message":
            MessageLookupByLibrary.simpleMessage(
                "Please allow location service permission."),
        "alert_location_service_permission_title":
            MessageLookupByLibrary.simpleMessage(
                "Location Service Permission Denied"),
        "alert_location_service_title":
            MessageLookupByLibrary.simpleMessage("Location Service Disabled"),
        "alert_message_min_order": m1,
        "alert_message_save_address": MessageLookupByLibrary.simpleMessage(
            "Are you want save this current location address?"),
        "alert_no": MessageLookupByLibrary.simpleMessage("No"),
        "alert_ok": MessageLookupByLibrary.simpleMessage("Ok"),
        "alert_title_login_fail":
            MessageLookupByLibrary.simpleMessage("Login Fail"),
        "alert_title_min_order":
            MessageLookupByLibrary.simpleMessage("Minimum Order"),
        "alert_title_save_address": MessageLookupByLibrary.simpleMessage(
            "Save Current Location Address"),
        "alert_update_app_version_message": MessageLookupByLibrary.simpleMessage(
            "The app is outdated , Please update it to the latest version."),
        "alert_update_app_version_title":
            MessageLookupByLibrary.simpleMessage("Update Required"),
        "alert_yes": MessageLookupByLibrary.simpleMessage("Yes"),
        "all_menu": MessageLookupByLibrary.simpleMessage("Todos os menus"),
        "app_language":
            MessageLookupByLibrary.simpleMessage("Idioma do aplicativo"),
        "app_settings":
            MessageLookupByLibrary.simpleMessage("Configurações do aplicativo"),
        "application_preferences":
            MessageLookupByLibrary.simpleMessage("Preferências do aplicativo"),
        "back": MessageLookupByLibrary.simpleMessage("Back"),
        "cancel": MessageLookupByLibrary.simpleMessage("Cancelar"),
        "cart": MessageLookupByLibrary.simpleMessage("Carrinho"),
        "carts_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Carrinhos atualizados com sucesso"),
        "cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("Dinheiro na entrega"),
        "category": MessageLookupByLibrary.simpleMessage("Categoria"),
        "category_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Categoria atualizada com sucesso"),
        "checkout": MessageLookupByLibrary.simpleMessage("Confira"),
        "click_on_the_stars_below_to_leave_comments":
            MessageLookupByLibrary.simpleMessage(
                "Click on the stars below to leave comments"),
        "close": MessageLookupByLibrary.simpleMessage("Fechar"),
        "confirm_payment":
            MessageLookupByLibrary.simpleMessage("Confirme o pagamento"),
        "confirmation": MessageLookupByLibrary.simpleMessage("Confirmação"),
        "cuisines": MessageLookupByLibrary.simpleMessage("Cuisines"),
        "dark_mode": MessageLookupByLibrary.simpleMessage("Modo escuro"),
        "default_credit_card":
            MessageLookupByLibrary.simpleMessage("Cartão de crédito padrão"),
        "delivery_addresses":
            MessageLookupByLibrary.simpleMessage("Delivery Addresses"),
        "delivery_fee": MessageLookupByLibrary.simpleMessage("Delivery Fee"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "discover__explorer":
            MessageLookupByLibrary.simpleMessage("Discover & Explorer"),
        "dont_have_any_item_in_the_notification_list":
            MessageLookupByLibrary.simpleMessage(
                "Não tem nenhum item na lista de notificações"),
        "dont_have_any_item_in_your_cart": MessageLookupByLibrary.simpleMessage(
            "Não tem nenhum item no seu carrinho"),
        "double_click_on_the_food_to_add_it_to_the":
            MessageLookupByLibrary.simpleMessage(
                "Clique duas vezes na comida para adicioná-la ao carrinho"),
        "edit": MessageLookupByLibrary.simpleMessage("Editar"),
        "email": MessageLookupByLibrary.simpleMessage("O email"),
        "email_address":
            MessageLookupByLibrary.simpleMessage("Endereço de e-mail"),
        "email_phone": MessageLookupByLibrary.simpleMessage("Email or Phone"),
        "email_to_reset_password":
            MessageLookupByLibrary.simpleMessage("Email to reset password"),
        "empty_data":
            MessageLookupByLibrary.simpleMessage("You have nothing here"),
        "english": MessageLookupByLibrary.simpleMessage("Inglês"),
        "enter_email_or_phone": MessageLookupByLibrary.simpleMessage(
            "Please enter phone or email & password"),
        "enter_valid_otp":
            MessageLookupByLibrary.simpleMessage("Enter valid OTP"),
        "error_verify_email_settings": MessageLookupByLibrary.simpleMessage(
            "Error! Verify email settings"),
        "extras": MessageLookupByLibrary.simpleMessage("Extras"),
        "faq": MessageLookupByLibrary.simpleMessage("Perguntas frequentes"),
        "favorite_foods":
            MessageLookupByLibrary.simpleMessage("Alimentos favoritos"),
        "favorites": MessageLookupByLibrary.simpleMessage("Favoritos"),
        "favorites_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Favorites refreshed successfuly"),
        "featured_foods":
            MessageLookupByLibrary.simpleMessage("Alimentos em destaque"),
        "food_categories":
            MessageLookupByLibrary.simpleMessage("Categorias de Alimentos"),
        "full_address": MessageLookupByLibrary.simpleMessage("Full Address"),
        "full_name": MessageLookupByLibrary.simpleMessage("Nome completo"),
        "g": MessageLookupByLibrary.simpleMessage("g"),
        "go_to_offer": MessageLookupByLibrary.simpleMessage("GO TO OFFER"),
        "guest": MessageLookupByLibrary.simpleMessage("Guest"),
        "help__support":
            MessageLookupByLibrary.simpleMessage("Ajuda e Suporte"),
        "help_support": MessageLookupByLibrary.simpleMessage("Ajuda e Suporte"),
        "help_supports":
            MessageLookupByLibrary.simpleMessage("Ajuda e Suporte"),
        "hint_full_address": MessageLookupByLibrary.simpleMessage(
            "12 Street, City 21663, Country"),
        "home": MessageLookupByLibrary.simpleMessage("Casa"),
        "home_address": MessageLookupByLibrary.simpleMessage("Home Address"),
        "how_would_you_rate_this_restaurant_":
            MessageLookupByLibrary.simpleMessage(
                "How would you rate this restaurant ?"),
        "i_agree_txt": MessageLookupByLibrary.simpleMessage("I agree to the"),
        "i_dont_have_an_account":
            MessageLookupByLibrary.simpleMessage("Eu não tenho uma conta?"),
        "i_forgot_password":
            MessageLookupByLibrary.simpleMessage("Esqueci minha senha?"),
        "i_have_account_back_to_login": MessageLookupByLibrary.simpleMessage(
            "Eu tenho conta Volte ao login"),
        "i_remember_my_password_return_to_login":
            MessageLookupByLibrary.simpleMessage(
                "I remember my password return to login"),
        "information": MessageLookupByLibrary.simpleMessage("Em formação"),
        "ingredients": MessageLookupByLibrary.simpleMessage("Ingredientes"),
        "john_doe": MessageLookupByLibrary.simpleMessage("John Doe"),
        "keep_your_old_meals_of_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Mantenha as suas refeições antigas deste restaurante"),
        "languages": MessageLookupByLibrary.simpleMessage("línguas"),
        "lets_start_with_login":
            MessageLookupByLibrary.simpleMessage("Vamos começar com o login!"),
        "lets_start_with_register": MessageLookupByLibrary.simpleMessage(
            "Vamos começar com o registro!"),
        "light_mode": MessageLookupByLibrary.simpleMessage("Modo de luz"),
        "log_out": MessageLookupByLibrary.simpleMessage("Sair"),
        "login": MessageLookupByLibrary.simpleMessage("Entrar"),
        "long_press_to_edit_item_swipe_item_to_delete_it":
            MessageLookupByLibrary.simpleMessage(
                "Long press to edit item, swipe item to delete it"),
        "longpress_on_the_food_to_add_suplements":
            MessageLookupByLibrary.simpleMessage(
                "Pressione longamente os alimentos para adicionar suplementos"),
        "maps_explorer": MessageLookupByLibrary.simpleMessage("Maps Explorer"),
        "menu": MessageLookupByLibrary.simpleMessage("Cardápio"),
        "min_order": MessageLookupByLibrary.simpleMessage("Minimum Order:"),
        "most_popular": MessageLookupByLibrary.simpleMessage("Mais popular"),
        "multirestaurants":
            MessageLookupByLibrary.simpleMessage("Multi-Restaurantes"),
        "my_orders": MessageLookupByLibrary.simpleMessage("minhas ordens"),
        "new_address_added_successfully": MessageLookupByLibrary.simpleMessage(
            "New Address added successfully"),
        "new_order_from_client":
            MessageLookupByLibrary.simpleMessage("New order from client"),
        "not_a_valid_address":
            MessageLookupByLibrary.simpleMessage("Endereço inválido"),
        "not_a_valid_biography":
            MessageLookupByLibrary.simpleMessage("Biografia não válida"),
        "not_a_valid_cvc": MessageLookupByLibrary.simpleMessage("CVC inválido"),
        "not_a_valid_date":
            MessageLookupByLibrary.simpleMessage("Data não válida"),
        "not_a_valid_email":
            MessageLookupByLibrary.simpleMessage("Não é um email válido"),
        "not_a_valid_full_name": MessageLookupByLibrary.simpleMessage(
            "Não é um nome completo válido"),
        "not_a_valid_number":
            MessageLookupByLibrary.simpleMessage("Não é um número válido"),
        "not_a_valid_phone":
            MessageLookupByLibrary.simpleMessage("Não é um telefone válido"),
        "notifications": MessageLookupByLibrary.simpleMessage("Notificações"),
        "notifications_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Notificações atualizadas com sucesso"),
        "nutrition": MessageLookupByLibrary.simpleMessage("Nutrição"),
        "one_time_password":
            MessageLookupByLibrary.simpleMessage("One Time Password"),
        "or_checkout_with":
            MessageLookupByLibrary.simpleMessage("Ou check-out com"),
        "order_id": MessageLookupByLibrary.simpleMessage("ID do pedido"),
        "order_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Pedido atualizado com sucesso"),
        "order_status_changed":
            MessageLookupByLibrary.simpleMessage("Order status changed"),
        "ordered_by_nearby_first":
            MessageLookupByLibrary.simpleMessage("Ordenado por Perto primeiro"),
        "orders_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Pedidos atualizados com sucesso"),
        "otp": MessageLookupByLibrary.simpleMessage("OTP"),
        "password": MessageLookupByLibrary.simpleMessage("Senha"),
        "pay_alert_title": MessageLookupByLibrary.simpleMessage("Pay"),
        "payment_mode":
            MessageLookupByLibrary.simpleMessage("Modo de pagamento"),
        "payment_options":
            MessageLookupByLibrary.simpleMessage("Opções de pagamento"),
        "payment_settings":
            MessageLookupByLibrary.simpleMessage("Configurações de pagamento"),
        "payment_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Configurações de pagamento atualizadas com sucesso"),
        "payments_settings":
            MessageLookupByLibrary.simpleMessage("Configurações de pagamentos"),
        "paypal_payment":
            MessageLookupByLibrary.simpleMessage("Pagamento PayPal"),
        "phone": MessageLookupByLibrary.simpleMessage("telefone"),
        "phone_not_registered": MessageLookupByLibrary.simpleMessage(
            "This phone is not registered"),
        "pickupCreditCard":
            MessageLookupByLibrary.simpleMessage("Pickup - credit card"),
        "profile": MessageLookupByLibrary.simpleMessage("Perfil"),
        "profile_settings":
            MessageLookupByLibrary.simpleMessage("Configurações de perfil"),
        "profile_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "Configurações de perfil atualizadas com sucesso"),
        "quantity": MessageLookupByLibrary.simpleMessage("Quantidade"),
        "recent_orders":
            MessageLookupByLibrary.simpleMessage("pedidos recentes"),
        "recent_reviews":
            MessageLookupByLibrary.simpleMessage("Comentários recentes"),
        "recents_search":
            MessageLookupByLibrary.simpleMessage("Pesquisa Recentes"),
        "register": MessageLookupByLibrary.simpleMessage("registo"),
        "request_failed":
            MessageLookupByLibrary.simpleMessage("Request failed"),
        "res_categories_title":
            MessageLookupByLibrary.simpleMessage("Restaurants Categories"),
        "reset": MessageLookupByLibrary.simpleMessage("Restabelecer"),
        "reset_cart":
            MessageLookupByLibrary.simpleMessage("Redefinir carrinho?"),
        "reset_your_cart_and_order_meals_form_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "Redefina seu carrinho e solicite refeições deste restaurante"),
        "restaurant_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage(
                "Restaurante atualizado com sucesso"),
        "reviews": MessageLookupByLibrary.simpleMessage("Rever"),
        "reviews_refreshed_successfully": MessageLookupByLibrary.simpleMessage(
            "Reviews refreshed successfully!"),
        "save": MessageLookupByLibrary.simpleMessage("Salve "),
        "saving_card_alert_message": m5,
        "saving_card_alert_title":
            MessageLookupByLibrary.simpleMessage("Save CreditCard"),
        "search": MessageLookupByLibrary.simpleMessage("Procurar"),
        "search_for_restaurants_or_foods": MessageLookupByLibrary.simpleMessage(
            "Pesquise restaurantes ou alimentos"),
        "search_items": MessageLookupByLibrary.simpleMessage("Search Items"),
        "select_extras_to_add_them_on_the_food":
            MessageLookupByLibrary.simpleMessage(
                "Selecione extras para adicioná-los à comida"),
        "select_terms_of_service_txt": MessageLookupByLibrary.simpleMessage(
            "Please follow Terms Of Service"),
        "select_your_preferred_languages": MessageLookupByLibrary.simpleMessage(
            "Selecione seus idiomas preferidos"),
        "select_your_preferred_payment_mode":
            MessageLookupByLibrary.simpleMessage(
                "Selecione seu modo de pagamento preferido"),
        "send_password_reset_link":
            MessageLookupByLibrary.simpleMessage("Send password reset link"),
        "settings": MessageLookupByLibrary.simpleMessage("Configurações"),
        "shopping_cart":
            MessageLookupByLibrary.simpleMessage("Carrinho de compras"),
        "should_be_a_valid_email":
            MessageLookupByLibrary.simpleMessage("Deve ser um email válido"),
        "should_be_a_valid_email_phone": MessageLookupByLibrary.simpleMessage(
            "Should be a valid email or phone number"),
        "should_be_more_than_3_characters":
            MessageLookupByLibrary.simpleMessage(
                "Deve ter mais de 3 caracteres"),
        "should_be_more_than_3_letters":
            MessageLookupByLibrary.simpleMessage("Deve ter mais de 3 letras"),
        "should_be_more_than_6_letters":
            MessageLookupByLibrary.simpleMessage("Deve ter mais de 6 letras"),
        "skip": MessageLookupByLibrary.simpleMessage("Pular"),
        "start_exploring":
            MessageLookupByLibrary.simpleMessage("Comece a explorar"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "subtotal": MessageLookupByLibrary.simpleMessage("Subtotal"),
        "tax": MessageLookupByLibrary.simpleMessage("IMPOSTO"),
        "tell_us_about_this_food":
            MessageLookupByLibrary.simpleMessage("Tell us about this food"),
        "terms_of_service_txt":
            MessageLookupByLibrary.simpleMessage("Terms Of Service"),
        "the_address_updated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The address updated successfully"),
        "the_food_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The food has been rated successfully"),
        "the_food_was_removed_from_your_cart": m6,
        "the_restaurant_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage(
                "The restaurant has been rated successfully"),
        "top_restaurants":
            MessageLookupByLibrary.simpleMessage("Melhores Restaurantes"),
        "total": MessageLookupByLibrary.simpleMessage("Total"),
        "tracking_order":
            MessageLookupByLibrary.simpleMessage("Ordem de rastreamento"),
        "tracking_refreshed_successfuly": MessageLookupByLibrary.simpleMessage(
            "Rastreamento atualizado com sucesso"),
        "trending_this_week":
            MessageLookupByLibrary.simpleMessage("Tendências desta semana"),
        "unknown": MessageLookupByLibrary.simpleMessage("Unknown"),
        "update_btn": MessageLookupByLibrary.simpleMessage("Update"),
        "user_already_exist": MessageLookupByLibrary.simpleMessage(
            "User already exists with phone number or email"),
        "verify": MessageLookupByLibrary.simpleMessage("Verificar"),
        "verify_your_internet_connection": MessageLookupByLibrary.simpleMessage(
            "Verifique sua conexão com a Internet"),
        "verify_your_quantity_and_click_checkout":
            MessageLookupByLibrary.simpleMessage(
                "Verifique sua quantidade e clique em check-out"),
        "version": MessageLookupByLibrary.simpleMessage("Versão"),
        "web_page_title": MessageLookupByLibrary.simpleMessage(""),
        "welcome": MessageLookupByLibrary.simpleMessage("Bem vinda"),
        "what_they_say":
            MessageLookupByLibrary.simpleMessage("O que eles disseram ?"),
        "wrong_email_or_password":
            MessageLookupByLibrary.simpleMessage("e-mail ou senha incorretos"),
        "yaadpay_payment":
            MessageLookupByLibrary.simpleMessage("YaadPay Payment"),
        "you_can_discover_restaurants": MessageLookupByLibrary.simpleMessage(
            "Você pode descobrir restaurantes e fastfood ao seu redor e escolher sua melhor refeição após alguns minutos, nós preparamos e entregamos para você"),
        "you_must_add_foods_of_the_same_restaurants_choose_one":
            MessageLookupByLibrary.simpleMessage(
                "Você deve adicionar alimentos dos mesmos restaurantes e escolher apenas um!"),
        "you_must_signin_to_access_to_this_section":
            MessageLookupByLibrary.simpleMessage(
                "You must sign-in to access to this section"),
        "your_address": MessageLookupByLibrary.simpleMessage("Seu endereço"),
        "your_biography": MessageLookupByLibrary.simpleMessage("Sua biografia"),
        "your_order_has_been_successfully_submitted":
            MessageLookupByLibrary.simpleMessage(
                "Seu pedido foi enviado com sucesso!"),
        "your_reset_link_has_been_sent_to_your_email":
            MessageLookupByLibrary.simpleMessage(
                "Your reset link has been sent to your email")
      };
}
