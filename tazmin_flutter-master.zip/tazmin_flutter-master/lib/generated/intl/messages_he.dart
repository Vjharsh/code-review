// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a he locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'he';

  static String m0(foodName) => "${foodName} נוסף להזמנה!";

  static String m1(currency, minOrderPrice) =>
      "דרוש הזמנה מינימלית של ${currency} ${minOrderPrice}";

  static String m2(limitQty) => "עליך לבחור ב- ${limitQty} אפשרויות בלבד!";

  static String m3(counter) => "${counter} מסעדות פתוחות כעת";

  static String m4(id) => "הזמנה: # ${id} בוטלה";

  static String m7(ccLast4Digit) =>
      "האם ברצונך לשלם באמצעות כרטיס האשראי ${ccLast4Digit} שנשמר?";

  static String m5(ccLast4Digit) =>
      "האם ברצונך לשמור את כרטיס האשראי ${ccLast4Digit}?";

  static String m6(foodname) => "${foodname} הוסר מההזמנה שלך";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "about": MessageLookupByLibrary.simpleMessage("מידע"),
        "add": MessageLookupByLibrary.simpleMessage("הוסף"),
        "addToOrder": MessageLookupByLibrary.simpleMessage("הוסף להזמנה"),
        "add_delivery_address":
            MessageLookupByLibrary.simpleMessage("הוסף כתובת למשלוח"),
        "add_new_delivery_address":
            MessageLookupByLibrary.simpleMessage("הוסף כתובת משלוח חדשה"),
        "add_to_cart": MessageLookupByLibrary.simpleMessage("הוסף להזמנה"),
        "add_to_cart_popup_message": m0,
        "added_to_cart":
            MessageLookupByLibrary.simpleMessage("האוכל נוסף בהצלחה!"),
        "address": MessageLookupByLibrary.simpleMessage("כתובת"),
        "addresses_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("הכתובות רועננו בהצלחה"),
        "agree_with_terms": MessageLookupByLibrary.simpleMessage(
            "יש לאשר שקראת את תנאי השירות"),
        "alert_location_service_btn":
            MessageLookupByLibrary.simpleMessage("תן הרשאת מיקום"),
        "alert_location_service_message": MessageLookupByLibrary.simpleMessage(
            "נדרש הרשאת מיקום בכדי להתקדם."),
        "alert_location_service_permission_message":
            MessageLookupByLibrary.simpleMessage(
                "נדרש הרשאת מיקום בכדי להתקדם."),
        "alert_location_service_permission_title":
            MessageLookupByLibrary.simpleMessage("הרשאת מיקום לא מופעלת"),
        "alert_location_service_title":
            MessageLookupByLibrary.simpleMessage("הרשאת מיקום לא מופעלת"),
        "alert_message_min_order": m1,
        "alert_message_save_address": MessageLookupByLibrary.simpleMessage(
            "האם ברצונך לשמור את כתובת המיקום הנוכחית הזו?"),
        "alert_no": MessageLookupByLibrary.simpleMessage("לא, יש לי כרטיס אחר"),
        "alert_ok": MessageLookupByLibrary.simpleMessage("אישור"),
        "alert_title_login_fail":
            MessageLookupByLibrary.simpleMessage("החיבור נכשל"),
        "alert_title_min_order":
            MessageLookupByLibrary.simpleMessage("מינימום הזמנה"),
        "alert_title_save_address": MessageLookupByLibrary.simpleMessage(
            "שמור את כתובת המיקום הנוכחי (מומלץ)"),
        "alert_update_app_version_message": MessageLookupByLibrary.simpleMessage(
            "יש גרסה חדשה זמינה להורדה, אנא עדכן את האפליקציה לגרסה האחרונה."),
        "alert_update_app_version_title":
            MessageLookupByLibrary.simpleMessage("נדרש עדכון"),
        "alert_yes": MessageLookupByLibrary.simpleMessage("כן"),
        "all": MessageLookupByLibrary.simpleMessage("הכל"),
        "all_menu": MessageLookupByLibrary.simpleMessage("כל התפריט"),
        "all_restaurants": MessageLookupByLibrary.simpleMessage("כל המסעדות"),
        "app_language": MessageLookupByLibrary.simpleMessage("שפת אפליקציה"),
        "app_settings": MessageLookupByLibrary.simpleMessage("הגדרות אפליקציה"),
        "application_preferences":
            MessageLookupByLibrary.simpleMessage("העדפות אפליקציה"),
        "applied_coupon_code":
            MessageLookupByLibrary.simpleMessage("קוד קופון מיושם"),
        "apply": MessageLookupByLibrary.simpleMessage("החל"),
        "apply_filters": MessageLookupByLibrary.simpleMessage("החל"),
        "areYouSureYouWantToCancelThisOrder":
            MessageLookupByLibrary.simpleMessage(
                "האם אתה בטוח שברצונך לבטל הזמנה זו?"),
        "back": MessageLookupByLibrary.simpleMessage("חזרה"),
        "busy": MessageLookupByLibrary.simpleMessage("עמוס"),
        "cancel": MessageLookupByLibrary.simpleMessage("ביטול"),
        "cancelOrder": MessageLookupByLibrary.simpleMessage("בטל הזמנה"),
        "canceled": MessageLookupByLibrary.simpleMessage("ההזמנה בוטלה"),
        "card_number": MessageLookupByLibrary.simpleMessage("מספר כרטיס"),
        "cart": MessageLookupByLibrary.simpleMessage("הזמנה"),
        "carts_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("תשלום במזומן"),
        "cash_only": MessageLookupByLibrary.simpleMessage("מזומן בלבד"),
        "category": MessageLookupByLibrary.simpleMessage("קטגוריה"),
        "category_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "change_address": MessageLookupByLibrary.simpleMessage("שינוי כתובת"),
        "checkout": MessageLookupByLibrary.simpleMessage("מעבר לקופה"),
        "checkout_add_to_cart": MessageLookupByLibrary.simpleMessage("לקופה"),
        "clear": MessageLookupByLibrary.simpleMessage("נקה"),
        "click_here": MessageLookupByLibrary.simpleMessage("לחץ כאן"),
        "click_on_the_stars_below_to_leave_comments":
            MessageLookupByLibrary.simpleMessage(
                "לחץ על הכוכבים למטה כדי להשאיר תגובה"),
        "click_to_confirm_your_address_and_pay_or_long_press":
            MessageLookupByLibrary.simpleMessage(
                "לחץ כדי לאשר את הכתובת שלך ולשלם או לחץ לחיצה ארוכה כדי לערוך את הכתובת שלך"),
        "click_to_pay_cash_on_delivery":
            MessageLookupByLibrary.simpleMessage("לחץ כדי לשלם במזומן לשליח"),
        "click_to_pay_on_pickup":
            MessageLookupByLibrary.simpleMessage("לחץ כדי לשלם בעת האיסוף"),
        "click_to_pay_with_your_mastercard":
            MessageLookupByLibrary.simpleMessage(
                "לחץ כדי לשלם באמצעות MasterCard שלך"),
        "click_to_pay_with_your_paypal_account":
            MessageLookupByLibrary.simpleMessage(
                "לחץ כדי לשלם באמצעות חשבון PayPal שלך"),
        "click_to_pay_with_your_visa_card":
            MessageLookupByLibrary.simpleMessage(
                "לחץ כדי לשלם באמצעות כרטיס האשראי"),
        "close": MessageLookupByLibrary.simpleMessage("סגור"),
        "closed": MessageLookupByLibrary.simpleMessage("סגור"),
        "closedForDeliveries":
            MessageLookupByLibrary.simpleMessage("שירות המשלוחים סגור"),
        "confirm_payment": MessageLookupByLibrary.simpleMessage("בצע תשלום"),
        "confirm_your_delivery_address":
            MessageLookupByLibrary.simpleMessage("אשר את כתובת המסירה שלך"),
        "confirmation": MessageLookupByLibrary.simpleMessage("אישור"),
        "confirmpassword": MessageLookupByLibrary.simpleMessage("אישור סיסמה"),
        "continue_order": MessageLookupByLibrary.simpleMessage("המשך בהזמנה"),
        "coupon_code": MessageLookupByLibrary.simpleMessage("קוד קופון"),
        "cuisines": MessageLookupByLibrary.simpleMessage("סוגי חנויות"),
        "current_location":
            MessageLookupByLibrary.simpleMessage("מיקום נוכחי (מומלץ)"),
        "cvc": MessageLookupByLibrary.simpleMessage("CVC"),
        "cvv": MessageLookupByLibrary.simpleMessage("CVV"),
        "dark_mode": MessageLookupByLibrary.simpleMessage("מראה כהה"),
        "default_credit_card":
            MessageLookupByLibrary.simpleMessage("כרטיס אשראי ראשי"),
        "deliverable": MessageLookupByLibrary.simpleMessage("משלוח"),
        "delivery": MessageLookupByLibrary.simpleMessage("משלוח"),
        "delivery_address":
            MessageLookupByLibrary.simpleMessage("כתובת למשלוח"),
        "delivery_address_removed_successfully":
            MessageLookupByLibrary.simpleMessage("כתובת המסירה הוסרה בהצלחה"),
        "delivery_addresses":
            MessageLookupByLibrary.simpleMessage("כתובות למשלוח"),
        "delivery_fee": MessageLookupByLibrary.simpleMessage("דמי משלוח"),
        "delivery_or_pickup":
            MessageLookupByLibrary.simpleMessage("הזמנת משלוח או איסוף עצמי?"),
        "description": MessageLookupByLibrary.simpleMessage("תיאור"),
        "details": MessageLookupByLibrary.simpleMessage("פרטים"),
        "discount": MessageLookupByLibrary.simpleMessage("הנחה"),
        "discover__explorer": MessageLookupByLibrary.simpleMessage("גלה וסייר"),
        "does_not_support_pickup": MessageLookupByLibrary.simpleMessage(
            "לא ניתן לאסוף את האוכל מספק זה"),
        "done": MessageLookupByLibrary.simpleMessage("הסתר"),
        "dont_have_any_item_in_the_notification_list":
            MessageLookupByLibrary.simpleMessage("אין לך התראות"),
        "dont_have_any_item_in_your_cart":
            MessageLookupByLibrary.simpleMessage("ההזמנה שלך ריקה"),
        "double_click_on_the_food_to_add_it_to_the":
            MessageLookupByLibrary.simpleMessage(
                "המאכלים הכי פופולרים של השבוע!"),
        "edit": MessageLookupByLibrary.simpleMessage("עריכה"),
        "email": MessageLookupByLibrary.simpleMessage("אימייל"),
        "emailOrPasswordIsNotValid":
            MessageLookupByLibrary.simpleMessage("אימייל או סיסמה אינם נכונים"),
        "email_address": MessageLookupByLibrary.simpleMessage("כתובת אימייל"),
        "email_already_exists": MessageLookupByLibrary.simpleMessage(
            "אימייל זה כבר רשום, יש להתחבר"),
        "email_phone": MessageLookupByLibrary.simpleMessage("אימייל או נייד"),
        "email_tab": MessageLookupByLibrary.simpleMessage("עם סיסמה"),
        "email_to_reset_password":
            MessageLookupByLibrary.simpleMessage("איפוס סיסמה"),
        "empty_data":
            MessageLookupByLibrary.simpleMessage("עדיין אין לך כלום כאן :("),
        "english": MessageLookupByLibrary.simpleMessage("עברית"),
        "enter_email_or_phone": MessageLookupByLibrary.simpleMessage(
            "אנא הכנס טלפון או דוא ל וסיסמא"),
        "enter_valid_otp":
            MessageLookupByLibrary.simpleMessage("הכנס קוד אימות"),
        "error_verify_email_settings":
            MessageLookupByLibrary.simpleMessage("שגיאה! אימייל לא קיים"),
        "exp_date": MessageLookupByLibrary.simpleMessage("תאריך תפוגה"),
        "expiry_date": MessageLookupByLibrary.simpleMessage("תאריך תפוגה"),
        "extras": MessageLookupByLibrary.simpleMessage("תוספות"),
        "faq": MessageLookupByLibrary.simpleMessage("שאלות נפוצות"),
        "favorite_foods":
            MessageLookupByLibrary.simpleMessage("מאכלים מועדפים"),
        "favorites": MessageLookupByLibrary.simpleMessage("מועדפים"),
        "favorites_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "featured_foods":
            MessageLookupByLibrary.simpleMessage("מאכלים מובחרים"),
        "fields": MessageLookupByLibrary.simpleMessage("שדות"),
        "filter": MessageLookupByLibrary.simpleMessage("סנן תוצאות"),
        "finish_order": MessageLookupByLibrary.simpleMessage("מעבר לתשלום"),
        "food_categories":
            MessageLookupByLibrary.simpleMessage("מסעדות לפי קטגוריה"),
        "food_refresh_message":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "foods_result": MessageLookupByLibrary.simpleMessage("תוצאת מזון"),
        "foods_results": MessageLookupByLibrary.simpleMessage("תוצאות מזון"),
        "full_address": MessageLookupByLibrary.simpleMessage("כתובת מלאה"),
        "full_name": MessageLookupByLibrary.simpleMessage("שם מלא"),
        "g": MessageLookupByLibrary.simpleMessage("g"),
        "go_to_offer": MessageLookupByLibrary.simpleMessage("להצעה"),
        "guest": MessageLookupByLibrary.simpleMessage("אורח"),
        "have_a_coupon":
            MessageLookupByLibrary.simpleMessage("יש לך קוד קופון?"),
        "help__support": MessageLookupByLibrary.simpleMessage("עזרה ותמיכה"),
        "help_support": MessageLookupByLibrary.simpleMessage("עזרה ותמיכה"),
        "help_supports": MessageLookupByLibrary.simpleMessage("עזרה ותמיכה"),
        "hint_full_address": MessageLookupByLibrary.simpleMessage(
            "שכונת אלוונסא, ליד הבית של..."),
        "home": MessageLookupByLibrary.simpleMessage("בית"),
        "home_address": MessageLookupByLibrary.simpleMessage("כתובת בית"),
        "how_would_you_rate_this_restaurant":
            MessageLookupByLibrary.simpleMessage("איך היית מדרג את המסעדה?"),
        "how_would_you_rate_this_restaurant_":
            MessageLookupByLibrary.simpleMessage("איך היית מדרג את המקום הזה?"),
        "i_agree_txt": MessageLookupByLibrary.simpleMessage("אני מסכים ל"),
        "i_dont_have_an_account":
            MessageLookupByLibrary.simpleMessage("יצירת חשבון חדש"),
        "i_forgot_password":
            MessageLookupByLibrary.simpleMessage("שכחתי את הסיסמה"),
        "i_have_account_back_to_login":
            MessageLookupByLibrary.simpleMessage("יש לך חשבון? התחבר."),
        "i_remember_my_password_return_to_login":
            MessageLookupByLibrary.simpleMessage(
                "אפשר להתחבר ללא סיסמה, לחץ כאן"),
        "i_will_pay_in_store":
            MessageLookupByLibrary.simpleMessage("אני אשלם למסעדה בעת האיסוף"),
        "i_will_pay_with_credit_card":
            MessageLookupByLibrary.simpleMessage("אני רוצה לשלם בכרטיס אשראי"),
        "in_stock": MessageLookupByLibrary.simpleMessage("זמין"),
        "information": MessageLookupByLibrary.simpleMessage("מידע"),
        "ingredients": MessageLookupByLibrary.simpleMessage("רכיבים"),
        "insert_here": MessageLookupByLibrary.simpleMessage("הכנס כאן"),
        "items": MessageLookupByLibrary.simpleMessage("פריטים"),
        "john_doe": MessageLookupByLibrary.simpleMessage("שם מלא"),
        "keep_your_old_meals_of_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "שמרו על הארוחות הישנות של המסעדה הזו"),
        "km": MessageLookupByLibrary.simpleMessage("ק׳׳מ"),
        "languages": MessageLookupByLibrary.simpleMessage("שפות"),
        "left_pizza": MessageLookupByLibrary.simpleMessage("חצי שמאלי"),
        "lets_start_with_login":
            MessageLookupByLibrary.simpleMessage("התחבר באמצעות SMS או סיסמה"),
        "lets_start_with_register":
            MessageLookupByLibrary.simpleMessage("הרשמה קלה ומהירה!"),
        "light_mode": MessageLookupByLibrary.simpleMessage("מראה בהיר"),
        "limit_qty_message": m2,
        "limited_quantity":
            MessageLookupByLibrary.simpleMessage("בחירה מוגבלת"),
        "location_permission":
            MessageLookupByLibrary.simpleMessage("הרשאת מיקום"),
        "location_permission_title":
            MessageLookupByLibrary.simpleMessage("הרשאת מיקום"),
        "log_out": MessageLookupByLibrary.simpleMessage("התנתק"),
        "login": MessageLookupByLibrary.simpleMessage("התחבר"),
        "long_press_to_edit_item_swipe_item_to_delete_it":
            MessageLookupByLibrary.simpleMessage(
                "בחר את המיקום הנוכחי שלך לחווית משלוח מהירה"),
        "longpress_on_the_food_to_add_suplements":
            MessageLookupByLibrary.simpleMessage(
                "כל מה שאנחנו מציעים, בין ידיך."),
        "make_it_default":
            MessageLookupByLibrary.simpleMessage("הפוך את זה לברירת מחדל"),
        "maps_explorer": MessageLookupByLibrary.simpleMessage("סייר המפות"),
        "mastercard": MessageLookupByLibrary.simpleMessage("מאסטרקארד"),
        "menu": MessageLookupByLibrary.simpleMessage("תפריט"),
        "mi": MessageLookupByLibrary.simpleMessage("מיל"),
        "min_order": MessageLookupByLibrary.simpleMessage("מינימום הזמנה:"),
        "most_popular":
            MessageLookupByLibrary.simpleMessage("מסעדות חדשות ומומלצות"),
        "multirestaurants":
            MessageLookupByLibrary.simpleMessage("תזמין - משלוחים בכרמל"),
        "my_orders": MessageLookupByLibrary.simpleMessage("ההזמנות שלי"),
        "near_to": MessageLookupByLibrary.simpleMessage("משלוח ל:"),
        "near_to_your_current_location":
            MessageLookupByLibrary.simpleMessage("קרוב למיקום הנוכחי שלך"),
        "new_address_added_successfully":
            MessageLookupByLibrary.simpleMessage("כתובת חדשה נוספה בהצלחה"),
        "new_order_from_client":
            MessageLookupByLibrary.simpleMessage("הזמנה חדשה מלקוח"),
        "next": MessageLookupByLibrary.simpleMessage("הבא"),
        "none": MessageLookupByLibrary.simpleMessage("ללא"),
        "not_a_valid_address":
            MessageLookupByLibrary.simpleMessage("כתובת לא חוקית"),
        "not_a_valid_biography":
            MessageLookupByLibrary.simpleMessage("מידע לא נכון"),
        "not_a_valid_cvc":
            MessageLookupByLibrary.simpleMessage("קוד זיהוי לא תקין"),
        "not_a_valid_date":
            MessageLookupByLibrary.simpleMessage("תאריך לא תקף"),
        "not_a_valid_email":
            MessageLookupByLibrary.simpleMessage("אימייל לא חוקי"),
        "not_a_valid_full_name":
            MessageLookupByLibrary.simpleMessage("שם מלא לא חוקי"),
        "not_a_valid_number":
            MessageLookupByLibrary.simpleMessage("מספר לא תקף"),
        "not_a_valid_phone":
            MessageLookupByLibrary.simpleMessage("נייד לא חוקי"),
        "not_deliverable":
            MessageLookupByLibrary.simpleMessage("איסוף עצמי בלבד"),
        "not_deliverable_message": MessageLookupByLibrary.simpleMessage(
            "אחד או יותר מהמזונות אינם מתאימים למשלוח"),
        "notifications": MessageLookupByLibrary.simpleMessage("התראות"),
        "notifications_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "number": MessageLookupByLibrary.simpleMessage("מספר"),
        "nutrition": MessageLookupByLibrary.simpleMessage("תזונה"),
        "one_time_password":
            MessageLookupByLibrary.simpleMessage("סיסמה חד פעמית"),
        "open": MessageLookupByLibrary.simpleMessage("פתוח"),
        "openForDeliveries":
            MessageLookupByLibrary.simpleMessage("שירות המשלוחים פתוח"),
        "open_restaurants_right_now": m3,
        "opened_restaurants":
            MessageLookupByLibrary.simpleMessage("ספקים פתוחים"),
        "or": MessageLookupByLibrary.simpleMessage(
            "סיסמה חד פעמית תישלח לנייד (SMS)"),
        "or_checkout_with":
            MessageLookupByLibrary.simpleMessage("או שלם באמצעות"),
        "orderDetails": MessageLookupByLibrary.simpleMessage("פרטי הזמנה"),
        "orderThisorderidHasBeenCanceled": m4,
        "order_id": MessageLookupByLibrary.simpleMessage("מספר הזמנה"),
        "order_note": MessageLookupByLibrary.simpleMessage("הערה להזמנה:"),
        "order_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "order_status_changed":
            MessageLookupByLibrary.simpleMessage("סטטוס ההזמנה השתנה"),
        "ordered_by_nearby_first":
            MessageLookupByLibrary.simpleMessage("מסודר לפי קרבת מקום"),
        "orders_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "otp": MessageLookupByLibrary.simpleMessage("הכנס קוד שקיבלת"),
        "otp_tab": MessageLookupByLibrary.simpleMessage("עם SMS"),
        "out_of_stock": MessageLookupByLibrary.simpleMessage("אזל במלאי"),
        "out_of_town_area_title":
            MessageLookupByLibrary.simpleMessage("מחוץ לטווח העבודה שלנו :("),
        "password": MessageLookupByLibrary.simpleMessage("סיסמה"),
        "pay_alert_message": m7,
        "pay_alert_title": MessageLookupByLibrary.simpleMessage("תשלום"),
        "pay_on_pickup": MessageLookupByLibrary.simpleMessage("איסוף עצמי"),
        "payment_card_updated_successfully":
            MessageLookupByLibrary.simpleMessage("כרטיס התשלום עודכן בהצלחה"),
        "payment_mode": MessageLookupByLibrary.simpleMessage("תשלום"),
        "payment_option_message": MessageLookupByLibrary.simpleMessage(
            "האם אתה מעוניין בהזמנת משלוח או איסוף עצמי?"),
        "payment_options":
            MessageLookupByLibrary.simpleMessage("אפשרויות הזמנה"),
        "payment_settings":
            MessageLookupByLibrary.simpleMessage("הגדרות תשלום"),
        "payment_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage("הגדרות תשלום עודכנו בהצלחה"),
        "payments_settings":
            MessageLookupByLibrary.simpleMessage("הגדרות תשלומים"),
        "paypal": MessageLookupByLibrary.simpleMessage("פייפאל"),
        "paypal_payment":
            MessageLookupByLibrary.simpleMessage("תשלום ב- PayPal"),
        "phone": MessageLookupByLibrary.simpleMessage("נייד"),
        "phone_already_exists":
            MessageLookupByLibrary.simpleMessage("מספר זה כבר רשום, יש להתחבר"),
        "phone_not_registered": MessageLookupByLibrary.simpleMessage(
            "מספר זה אינו קיים במערכת, יש ליצור חשבון חדש."),
        "pickup": MessageLookupByLibrary.simpleMessage("איסוף עצמי"),
        "pickupCreditCard":
            MessageLookupByLibrary.simpleMessage("איסוף עצמי (שולם באשראי)"),
        "pickup_btn": MessageLookupByLibrary.simpleMessage("איסוף עצמי"),
        "pickup_your_food_from_the_restaurant":
            MessageLookupByLibrary.simpleMessage("יש לאסוף את ההזמנה מהמסעדה"),
        "pizza_type":
            MessageLookupByLibrary.simpleMessage("איפה לשים את התוספת?"),
        "pleaseSelectAtleastOneItemFrom": MessageLookupByLibrary.simpleMessage(
            "יש לבחור באפשרות אחת לפחות איפה שיש סימן *"),
        "profile": MessageLookupByLibrary.simpleMessage("פרופיל"),
        "profile_settings":
            MessageLookupByLibrary.simpleMessage("הגדרות פרופיל"),
        "profile_settings_updated_successfully":
            MessageLookupByLibrary.simpleMessage("הגדרות פרופיל עודכנו בהצלחה"),
        "quantity": MessageLookupByLibrary.simpleMessage("כמות"),
        "re_order": MessageLookupByLibrary.simpleMessage("להזמין שוב"),
        "recent_orders": MessageLookupByLibrary.simpleMessage("הזמנות אחרונות"),
        "recent_reviews":
            MessageLookupByLibrary.simpleMessage("חוות דעת אחרונות"),
        "recents_search":
            MessageLookupByLibrary.simpleMessage("חיפושים אחרונים"),
        "register": MessageLookupByLibrary.simpleMessage("הרשמה"),
        "register_email_description":
            MessageLookupByLibrary.simpleMessage("מה האימייל שלך?"),
        "register_number_description":
            MessageLookupByLibrary.simpleMessage("מה מספר הטלפון שלך?"),
        "register_password_description":
            MessageLookupByLibrary.simpleMessage("אנא בחר סיסמה חזקה"),
        "register_username_description":
            MessageLookupByLibrary.simpleMessage("מה הוא שמך המלא?"),
        "request_failed": MessageLookupByLibrary.simpleMessage("הבקשה נכשלה"),
        "res_categories_title":
            MessageLookupByLibrary.simpleMessage("בחר מה להציג"),
        "reset": MessageLookupByLibrary.simpleMessage("איפוס"),
        "reset_cart": MessageLookupByLibrary.simpleMessage("לאפס את ההזמנה?"),
        "reset_your_cart_and_order_meals_form_this_restaurant":
            MessageLookupByLibrary.simpleMessage(
                "מחק הזמנה קיימת ובחר מוצרים ממסעדה זו"),
        "restaurant_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "restaurants_near_to":
            MessageLookupByLibrary.simpleMessage("מסעדות ליד"),
        "restaurants_near_to_your_current_location":
            MessageLookupByLibrary.simpleMessage(
                "מסעדות בקרבת המיקום הנוכחי שלך"),
        "restaurants_results":
            MessageLookupByLibrary.simpleMessage("תוצאות מסעדות"),
        "retry": MessageLookupByLibrary.simpleMessage("נסה שוב"),
        "reviews": MessageLookupByLibrary.simpleMessage("חוות דעת"),
        "reviews_refreshed_successfully":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "right_pizza": MessageLookupByLibrary.simpleMessage("חצי ימני"),
        "sale": MessageLookupByLibrary.simpleMessage("מבצע!"),
        "save": MessageLookupByLibrary.simpleMessage("שמור"),
        "saving_card_alert_message": m5,
        "saving_card_alert_title": MessageLookupByLibrary.simpleMessage(
            "שמירת כרטיס אשראי להזמנה עתידית"),
        "search": MessageLookupByLibrary.simpleMessage("חפש"),
        "search_for_restaurants_or_foods":
            MessageLookupByLibrary.simpleMessage("חפש מסעדות או מאכלים"),
        "search_items": MessageLookupByLibrary.simpleMessage("חפש מוצרים"),
        "search_place": MessageLookupByLibrary.simpleMessage("חפש מיקום"),
        "see_menu": MessageLookupByLibrary.simpleMessage("הצג תפריט"),
        "select_all": MessageLookupByLibrary.simpleMessage("בחר הכל"),
        "select_extras_to_add_them_on_the_food":
            MessageLookupByLibrary.simpleMessage("בחר תוספות למאכל זה"),
        "select_terms_of_service_txt": MessageLookupByLibrary.simpleMessage(
            "אנא אשר שקראת את תנאי השירות"),
        "select_your_preferred_languages":
            MessageLookupByLibrary.simpleMessage("בחר את השפה המועדפת עליך"),
        "select_your_preferred_payment_mode":
            MessageLookupByLibrary.simpleMessage("בחר אפשרות תשלום"),
        "send_password_reset_link":
            MessageLookupByLibrary.simpleMessage("איפוס"),
        "settings": MessageLookupByLibrary.simpleMessage("הגדרות"),
        "shopping": MessageLookupByLibrary.simpleMessage("קניות"),
        "shopping_cart": MessageLookupByLibrary.simpleMessage("ההזמנה שלך"),
        "should_be_a_valid_email":
            MessageLookupByLibrary.simpleMessage("אימייל לא חוקי"),
        "should_be_a_valid_email_phone": MessageLookupByLibrary.simpleMessage(
            "צריך להיות כתובת אימייל או מספר טלפון חוקי"),
        "should_be_more_than_3_characters":
            MessageLookupByLibrary.simpleMessage(
                "צריך להיות יותר משלושה תווים"),
        "should_be_more_than_3_letters": MessageLookupByLibrary.simpleMessage(
            "צריך להיות יותר משלוש אותיות"),
        "should_be_more_than_6_letters":
            MessageLookupByLibrary.simpleMessage("צריך להיות יותר מ- 6 אותיות"),
        "show_all": MessageLookupByLibrary.simpleMessage("הצג הכל"),
        "skip": MessageLookupByLibrary.simpleMessage("דלג"),
        "splash_subtext":
            MessageLookupByLibrary.simpleMessage("אפליקציית המשלוחים של הכרמל"),
        "start_exploring": MessageLookupByLibrary.simpleMessage("התחל בהזמנה"),
        "submit": MessageLookupByLibrary.simpleMessage("שלח"),
        "subtotal": MessageLookupByLibrary.simpleMessage("סיכום ביניים"),
        "tax": MessageLookupByLibrary.simpleMessage("עמלה"),
        "tell_us_about_this_food":
            MessageLookupByLibrary.simpleMessage("ספר לנו על האוכל הזה"),
        "tell_us_about_this_restaurant":
            MessageLookupByLibrary.simpleMessage("ספר לנו על המקום הזה"),
        "terms_of_service_txt":
            MessageLookupByLibrary.simpleMessage("תנאי השירות"),
        "test": MessageLookupByLibrary.simpleMessage("test"),
        "the_address_updated_successfully":
            MessageLookupByLibrary.simpleMessage("כתובת למשלוח עודכנה בהצלחה"),
        "the_food_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage("האוכל דורג בהצלחה"),
        "the_food_was_removed_from_your_cart": m6,
        "the_restaurant_has_been_rated_successfully":
            MessageLookupByLibrary.simpleMessage("המסעדה דורגה בהצלחה"),
        "this_account_not_exist":
            MessageLookupByLibrary.simpleMessage("חשבון זה לא קיים"),
        "this_email_account_exists":
            MessageLookupByLibrary.simpleMessage("האימייל כבר קיים"),
        "this_food_was_added_to_cart":
            MessageLookupByLibrary.simpleMessage("אוכל זה התווסף לעגלה"),
        "this_restaurant_is_closed_":
            MessageLookupByLibrary.simpleMessage("העסק הזה סגור!"),
        "top_restaurants":
            MessageLookupByLibrary.simpleMessage("מאיפה מזמינים היום?"),
        "total": MessageLookupByLibrary.simpleMessage("סך הכל"),
        "total_extras": MessageLookupByLibrary.simpleMessage("סה״כ תוספות"),
        "tracking_order": MessageLookupByLibrary.simpleMessage("מעקב הזמנה"),
        "tracking_refreshed_successfuly":
            MessageLookupByLibrary.simpleMessage("בוצע רענון בהצלחה"),
        "trending_this_week":
            MessageLookupByLibrary.simpleMessage("מאכלי השבוע"),
        "unknown": MessageLookupByLibrary.simpleMessage("לא ידוע"),
        "update_btn": MessageLookupByLibrary.simpleMessage("עדכון"),
        "user_already_exist":
            MessageLookupByLibrary.simpleMessage("משתמש כבר קיים"),
        "verify": MessageLookupByLibrary.simpleMessage("כניסה"),
        "verify_your_internet_connection":
            MessageLookupByLibrary.simpleMessage("בדוק את חיבור האינטרנט"),
        "verify_your_quantity_and_click_checkout":
            MessageLookupByLibrary.simpleMessage("ודא/י שהכמויות נכונות"),
        "version": MessageLookupByLibrary.simpleMessage("גרסה"),
        "view": MessageLookupByLibrary.simpleMessage("הצג"),
        "visa_card": MessageLookupByLibrary.simpleMessage("כרטיס אשראי"),
        "web_page_title": MessageLookupByLibrary.simpleMessage(""),
        "welcome": MessageLookupByLibrary.simpleMessage("ברוך הבא"),
        "what_they_say":
            MessageLookupByLibrary.simpleMessage("מה אומרים עלינו?"),
        "whole_pizza": MessageLookupByLibrary.simpleMessage("כל הפיצה"),
        "wrong_email_or_password":
            MessageLookupByLibrary.simpleMessage("שגיאת נתונים"),
        "yaadpay_payment":
            MessageLookupByLibrary.simpleMessage("תשלום בכרטיס אשראי"),
        "youDontHaveAnyOrder":
            MessageLookupByLibrary.simpleMessage("אין לך שום הזמנה"),
        "you_can_discover_restaurants": MessageLookupByLibrary.simpleMessage(
            "גלו מסעדות, קייטרינג ומעדניות סביבכם, בצעו הזמנה ונתחיל להכין אותה בדקות הקרובות"),
        "you_must_add_foods_of_the_same_restaurants_choose_one":
            MessageLookupByLibrary.simpleMessage(
                "עליכם להוסיף אוכל מאותה מסעדה, יש לבחור במסעדה אחת בלבד!"),
        "you_must_signin_to_access_to_this_section":
            MessageLookupByLibrary.simpleMessage(
                "עליך להתחבר בכדי לצפות באיזור זה"),
        "your_address": MessageLookupByLibrary.simpleMessage("הכתובת שלך"),
        "your_biography": MessageLookupByLibrary.simpleMessage("הביו שלך"),
        "your_credit_card_not_valid":
            MessageLookupByLibrary.simpleMessage("כרטיס האשראי שלך לא תקף"),
        "your_order_has_been_successfully_submitted":
            MessageLookupByLibrary.simpleMessage("הזמנתך התקבלה בהצלחה!"),
        "your_reset_link_has_been_sent_to_your_email":
            MessageLookupByLibrary.simpleMessage(
                "אימייל לאיפוס סיסמה נשלח למייל שלך")
      };
}
