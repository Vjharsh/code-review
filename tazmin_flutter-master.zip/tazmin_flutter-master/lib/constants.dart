library Constants;

//For Demo Test
/*const String YAADPAY_KEY     ="7110eda4d09e062aa5e4a390b0a572ac0d2c0220";
const String YAADPAY_PASS    ="yaad";
const String YAADPAY_MASOF   ="0010131918";
const String YAADPAY_TMP      ="5";*/

//For Demo Test 2
/*const String YAADPAY_KEY     ="b6589fc6ab0dc82cf12099d1c2d40ab994e8410c";
const String YAADPAY_PASS    ="yaad";
const String YAADPAY_MASOF   ="0010132415";
const String YAADPAY_TMP      ="5";*/

//For Live 1
/*const String YAADPAY_KEY   ="df42b1a32d1c753547ef1d3b7779c5716cb36943";
const String YAADPAY_PASS  ="diny";
const String YAADPAY_MASOF ="2600082830";
const String YAADPAY_TMP ="5";*/

//For Live 2
const String YAADPAY_KEY   ="ba4cf90eef9ebdd2be7c1a65d93312d66e0d6f16";
const String YAADPAY_PASS  ="tazmin";
const String YAADPAY_MASOF ="4500844133";
const String YAADPAY_TMP ="5";

const String PAYMENT_METHOD_YAADPAY_ON_PICKUP ="Pickup - credit card";
const String PAYMENT_METHOD_YAADPAY ="YaadPay";
const String PAYMENT_METHOD_PAYPAL ="PayPal";
const String PAYMENT_METHOD_CASH_ON_DELIVERY ="Cash on delivery";
const String PAYMENT_METHOD_PICKUP ="Pickup";
const String RETRY ="Retry";