import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:food_delivery_app/src/models/addresses.dart';
import 'package:food_delivery_app/src/pages/home.dart';
import 'package:food_delivery_app/src/pages/home.dart';
import 'package:food_delivery_app/src/pages/pages.dart';
import 'package:geolocator/geolocator.dart';
import 'package:global_configuration/global_configuration.dart';
import 'package:responsive_framework/responsive_framework.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'generated/l10n.dart';
import 'route_generator.dart';
import 'src/helpers/app_config.dart' as config;
import 'src/helpers/custom_trace.dart';
import 'src/models/setting.dart';
import 'dart:io' show HttpClient, HttpOverrides, Platform, SecurityContext, X509Certificate;
import 'src/repository/settings_repository.dart' as settingRepo;
import 'src/repository/user_repository.dart' as userRepo;

class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext? context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await GlobalConfiguration().loadFromAsset("configurations");
  print(CustomTrace(StackTrace.current,
      message: "base_url: ${GlobalConfiguration().getValue('base_url')}"));
  print(CustomTrace(StackTrace.current,
      message:
      "api_base_url: ${GlobalConfiguration().getValue('api_base_url')}"));
  HttpOverrides.global = new MyHttpOverrides();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  static HomeWidget? homeWidget;
  static bool isFirstTime = true;
  static DateTime oldTime = DateTime.now();
  static Addresses? addressDTO;
  static PagesWidget? pagesWidget;
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    if(Platform.isAndroid){
      WebView.platform = SurfaceAndroidWebView();
    }
    settingRepo.initSettings();
    settingRepo.getCurrentLocation();
    userRepo.getCurrentUser();
    intervalLoopThread();
  }

  void intervalLoopThread() {
    // print('intervalLoopThread');
    Future.delayed(const Duration(milliseconds: 1600), () async{
      intervalLoopThread();
      if (MyApp.homeWidget != null) {
        if (MyApp.homeWidget?.homeWidgetState != null) {
          MyApp.homeWidget?.callInternal();

          if(MyApp.isFirstTime) {
            MyApp.isFirstTime = false;
            var geolocationStatus =
            await Geolocator.checkPermission();
            // await Geolocator().checkGeolocationPermissionStatus();
            print('geolocationStatus.value:$geolocationStatus');
            if (geolocationStatus == LocationPermission.whileInUse) {
              var serviceStatus = await Geolocator.checkPermission();
              print('serviceStatus:$serviceStatus');
              if (serviceStatus == LocationPermission.whileInUse) {
                settingRepo.setCurrentLocation().then((_address) async {
                  settingRepo.deliveryAddress.value = _address;
                  // if(_address != null) {
                  //   settingRepo.deliveryAddress.notifyListeners();
                  // }
                }).catchError((e) {});
              }
            }
          }
        }

        if(MyApp.pagesWidget !=null)
        {
          // MyApp.pagesWidget?.refreshCartCount();
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
        valueListenable: settingRepo.setting,
        builder: (context, Setting _setting, _) {
          return MaterialApp(
              builder: (context, widget) => ResponsiveWrapper.builder(
                  BouncingScrollWrapper.builder(context, widget!),
                  maxWidth: 1200,
                  minWidth: 450,
                  defaultScale: true,
                  breakpoints: [
                    ResponsiveBreakpoint.resize(450, name: MOBILE),
                    ResponsiveBreakpoint.autoScale(800, name: TABLET),
                    ResponsiveBreakpoint.autoScale(1000, name: TABLET),
                    ResponsiveBreakpoint.resize(1200, name: DESKTOP),
                    ResponsiveBreakpoint.autoScale(2460, name: "4K"),
                  ],
                  background: Container(color: Color(0xFFF5F5F5))),
              navigatorKey: settingRepo.navigatorKey,
              title: _setting.appName,
              initialRoute: '/Splash',
              onGenerateRoute: RouteGenerator.generateRoute,
              debugShowCheckedModeBanner: false,
              locale: _setting.mobileLanguage.value,
              localizationsDelegates: [
                // location_picker.S.delegate,
                S.delegate,
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              supportedLocales: S.delegate.supportedLocales,
              theme: _setting.brightness.value == Brightness.light
                  ? ThemeData(
                fontFamily: 'Assistant',
                primaryColor: Colors.white,
                colorScheme: ColorScheme(
                  primary: config.Colors().mainColor(1),  //defines primary
                  primaryVariant: config.Colors().mainColor(0.8),
                  secondary: config.Colors().mainColor(1),
                  secondaryVariant: config.Colors().mainColor(0.8),
                  surface: config.Colors().mainColor(1),
                  background: config.Colors().secondColor(1),
                  error: Colors.red,
                  onPrimary: Colors.black,
                  onSecondary: Colors.black,
                  onSurface: Colors.black,
                  onBackground: Colors.black,
                  onError: Colors.red,
                  brightness: Brightness.light,
                ),
                floatingActionButtonTheme: FloatingActionButtonThemeData(
                    elevation: 0, foregroundColor: Colors.white),
                brightness: Brightness.light,
                cursorColor: config.Colors().mainColor(1),
                secondaryHeaderColor: config.Colors().mainColor(1),
                backgroundColor: config.Colors().scaffoldColor(1),
                accentColor: config.Colors().mainColor(1),
                primaryColorLight: config.Colors().mainColor(1),
                indicatorColor: config.Colors().mainColor(1),
                snackBarTheme: SnackBarThemeData(
                    backgroundColor: config.Colors().secondColor(1),
                    actionTextColor: config.Colors().scaffoldColor(1)
                ),
                dividerColor: config.Colors().accentColor(0.1),
                focusColor: config.Colors().accentColor(1),
                hintColor: config.Colors().secondColor(1),
                textTheme: TextTheme(
                  headline6: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().mainColor(1)),
                  headline5: TextStyle(
                      fontSize: 18.0,
                      color: config.Colors().secondColor(1)),
                  headline4: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().secondColor(1)),
                  headline3: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().secondColor(1)),
                  headline2: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.w600,
                      color: config.Colors().mainColor(1)),
                  headline1: TextStyle(
                      fontSize: 23.0,
                      fontWeight: FontWeight.w400,
                      color: config.Colors().secondColor(1)),
                  subtitle1: TextStyle(
                      fontSize: 19.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondColor(1)),
                  bodyText2: TextStyle(
                      fontSize: 17.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondColor(1)),
                  bodyText1: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondColor(1)),
                  caption: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                      color: config.Colors().secondColor(0.6)),
                ),
              )
                  : ThemeData(
                fontFamily: 'Assistant',
                primaryColor: Color(0xFF252525),
                brightness: Brightness.dark,
                colorScheme: ColorScheme(
                  primary: config.Colors().mainDarkColor(1),  //defines primary
                  primaryVariant: config.Colors().mainDarkColor(0.8),
                  secondary: config.Colors().mainDarkColor(1),
                  secondaryVariant: config.Colors().mainDarkColor(0.8),
                  surface: config.Colors().mainDarkColor(1),
                  background: Colors.black,
                  error: Colors.red,
                  onPrimary: Colors.white,
                  onSecondary: Colors.white,
                  onSurface: Colors.white,
                  onBackground: Colors.white,
                  onError: Colors.red,
                  brightness: Brightness.dark,
                ),
                scaffoldBackgroundColor: Color(0xFF2C2C2C),
                secondaryHeaderColor: config.Colors().mainDarkColor(1),
                accentColor: config.Colors().mainDarkColor(1),
                primaryColorDark: config.Colors().mainDarkColor(1),
                indicatorColor: config.Colors().mainDarkColor(1),
                dividerColor: config.Colors().accentColor(0.1),
                hintColor: config.Colors().secondDarkColor(1),
                backgroundColor: config.Colors().scaffoldDarkColor(1),
                focusColor: config.Colors().accentDarkColor(1),
                textTheme: TextTheme(
                  headline6: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().mainDarkColor(1)),
                  headline5: TextStyle(
                      fontSize: 18.0,
                      color: config.Colors().secondDarkColor(1)),
                  headline4: TextStyle(
                      fontSize: 20.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().secondDarkColor(1)),
                  headline3: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.w700,
                      color: config.Colors().secondDarkColor(1)),
                  headline2: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.w600,
                      color: config.Colors().mainDarkColor(1)),
                  headline1: TextStyle(
                      fontSize: 23.0,
                      fontWeight: FontWeight.w400,
                      color: config.Colors().secondDarkColor(1)),
                  subtitle1: TextStyle(
                      fontSize: 19.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondDarkColor(1)),
                  bodyText2: TextStyle(
                      fontSize: 17.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondDarkColor(1)),
                  bodyText1: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w500,
                      color: config.Colors().secondDarkColor(1)),
                  caption: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w400,
                      color: config.Colors().secondDarkColor(0.6)),
                ),
              ));
        });
  }
}

/*void main() async{
  // Set `enableInDevMode` to true to see reports while in debug mode
  // This is only to be used for confirming that reports are being
  // submitted as expected. It is not intended to be used for everyday
  // development.
  WidgetsFlutterBinding.ensureInitialized();
  _configure();
  Crashlytics.instance.enableInDevMode = true;

  // Pass all uncaught errors to Crashlytics.
  FlutterError.onError = Crashlytics.instance.recordFlutterError;

  runZoned(() {
    runApp(MyApp());
  }, onError: Crashlytics.instance.recordError);
}

Future<void> _configure() async {
  final FirebaseApp app = await FirebaseApp.configure(
    name: 'foo',
    options: FirebaseOptions(googleAppID: '1:480604133835:android:834913e06326a7bedc7e4e',gcmSenderID: '480604133835',apiKey: ' AIzaSyALX_u6MUQqe1rdpcWvsRFTDK7dIBjVpdE '),
  );
  assert(app != null);
  print('Configured $app');
}

class MyApp extends StatefulWidget {
  static HomeWidget homeWidget;
  static bool isFirstTime = true;
  static DateTime oldTime = DateTime.now();
  static Addresses addressDTO;
  static PagesWidget pagesWidget;
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Crashlytics example app'),
        ),
        body: Center(
          child: Column(
            children: <Widget>[
              FlatButton(
                  child: const Text('Key'),
                  onPressed: () {
                    Crashlytics.instance.setString('foo', 'bar');
                  }),
              FlatButton(
                  child: const Text('Log'),
                  onPressed: () {
                    Crashlytics.instance.log('baz');
                  }),
              FlatButton(
                  child: const Text('Crash'),
                  onPressed: () {
                    // Use Crashlytics to throw an error. Use this for
                    // confirmation that errors are being correctly reported.
                    Crashlytics.instance.crash();
                  }),
              FlatButton(
                  child: const Text('Throw Error'),
                  onPressed: () {
                    // Example of thrown error, it will be caught and sent to
                    // Crashlytics.
                    throw StateError('Uncaught error thrown by app.');
                  }),
              FlatButton(
                  child: const Text('Async out of bounds'),
                  onPressed: () {
                    // Example of an exception that does not get caught
                    // by `FlutterError.onError` but is caught by the `onError` handler of
                    // `runZoned`.
                    Future<void>.delayed(const Duration(seconds: 2), () {
                      final List<int> list = <int>[];
                      print(list[100]);
                    });
                  }),
              FlatButton(
                  child: const Text('Record Error'),
                  onPressed: () {
                    try {
                      throw 'error_example';
                    } catch (e, s) {
                      // "context" will append the word "thrown" in the
                      // Crashlytics console.
                      Crashlytics.instance
                          .recordError(e, s, context: 'as an example');
                    }
                  }),
            ],
          ),
        ),
      ),
    );
  }
}*/

